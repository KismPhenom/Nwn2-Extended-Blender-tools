import bpy
import bmesh
from mathutils import Vector

class NWN2MapProperties(bpy.types.PropertyGroup):
    """Properties for NWN2 map creation"""
    
    map_size: bpy.props.FloatProperty(
        name="Map Size",
        description="Size of the map in meters",
        default=100.0,
        min=10.0,
        max=1000.0
    )
    
    grid_spacing: bpy.props.FloatProperty(
        name="Grid Spacing",
        description="Spacing between grid lines in meters",
        default=5.0,
        min=0.5,
        max=20.0
    )
    
    create_ground: bpy.props.BoolProperty(
        name="Create Ground Plane",
        description="Create a ground plane for the map",
        default=True
    )
    
    ground_height: bpy.props.FloatProperty(
        name="Ground Height",
        description="Height of the ground plane",
        default=0.0,
        min=-10.0,
        max=10.0
    )
    
    create_grid: bpy.props.BoolProperty(
        name="Create Grid",
        description="Create a visual grid",
        default=True
    )
    
    create_origin: bpy.props.BoolProperty(
        name="Create Origin Marker",
        description="Create a marker at the world origin",
        default=True
    )
    
    # Tile-based properties
    map_x: bpy.props.IntProperty(
        name="Width (Tiles)",
        description="Map width in NWN2 tiles",
        default=4,
        min=1,
        max=32
    )
    
    map_y: bpy.props.IntProperty(
        name="Length (Tiles)",
        description="Map length in NWN2 tiles",
        default=4,
        min=1,
        max=32
    )
    
    show_grid_mesh: bpy.props.BoolProperty(
        name="Show Grid Mesh",
        description="Add grid subdivisions for visual reference",
        default=True
    )
    
    grid_scale: bpy.props.IntProperty(
        name="Grid Scale",
        description="Number of grid subdivisions per tile",
        default=1,
        min=1,
        max=4
    )
    
    show_distance_markers: bpy.props.BoolProperty(
        name="Show Distance Markers",
        description="Add distance markers along map edges",
        default=True
    )
    
    marker_interval: bpy.props.FloatProperty(
        name="Marker Interval",
        description="Distance between markers in meters",
        default=50.0,
        min=5.0,
        max=200.0
    )
    
    # Map naming
    map_name: bpy.props.StringProperty(
        name="Map Name",
        description="Name for this map (will be prompted on creation)",
        default="Custom_Map"
    )

class NWN2_OT_CreateMap(bpy.types.Operator):
    """Create NWN2-style map environment"""
    bl_idname = "nwn2.create_map"
    bl_label = "Create NWN2 Map"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        scene = context.scene
        map_props = scene.nwn2_map_props
        
        # Set default name based on map dimensions
        default_name = f"Map_{map_props.map_x}x{map_props.map_y}"
        map_props.map_name = default_name
        
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        map_props = scene.nwn2_map_props
        
        layout.label(text="Name your map:")
        layout.prop(map_props, "map_name", text="")
        layout.separator()
        layout.label(text=f"Dimensions: {map_props.map_x}x{map_props.map_y} tiles")
        layout.label(text=f"Size: {map_props.map_x * 50}x{map_props.map_y * 50} BU")
    
    def execute(self, context):
        scene = context.scene
        map_props = scene.nwn2_map_props
        
        # Get the custom map name
        map_name = map_props.map_name.strip()
        if not map_name:
            map_name = f"Map_{map_props.map_x}x{map_props.map_y}"
        
        # Use tile-based sizing
        tile_size = 50.0  # Blender Units per NWN2 tile
        map_width = map_props.map_x * tile_size
        map_length = map_props.map_y * tile_size
        half_width = map_width / 2
        half_length = map_length / 2
        
        # Create main map object first
        main_map_obj = self.create_tile_based_ground(context, map_width, map_length, map_props, map_name)
        
        # Create proper intersecting grid lines and parent to main map
        if map_props.create_grid:
            self.create_crossing_grid(context, half_width, half_length, map_props.grid_spacing, main_map_obj, map_name)
        
        # Create origin marker and parent to main map
        origin_parent = None
        if map_props.create_origin:
            origin_parent = self.create_origin_marker(context, main_map_obj, map_name)
        
        # Create distance markers and parent to origin object
        if map_props.show_distance_markers:
            self.create_distance_markers(context, half_width, half_length, map_props.marker_interval, origin_parent, main_map_obj, map_name)
        
        # Select the main map object
        bpy.ops.object.select_all(action='DESELECT')
        main_map_obj.select_set(True)
        context.view_layer.objects.active = main_map_obj
        
        self.report({'INFO'}, f"Created NWN2 map: {map_name} ({map_props.map_x}x{map_props.map_y} tiles)")
        return {'FINISHED'}
    
    def create_tile_based_ground(self, context, map_width, map_length, map_props, map_name):
        """Create ground mesh with proper grid for entire map"""
        mesh = bpy.data.meshes.new(f"NWN2_{map_name}_Mesh")
        bm = bmesh.new()
        
        half_width = map_width / 2
        half_length = map_length / 2
        
        # Always create a grid mesh that covers the entire map
        if map_props.show_grid_mesh:
            # Calculate vertices based on grid scale
            verts_x = (map_props.map_x * map_props.grid_scale) + 1
            verts_y = (map_props.map_y * map_props.grid_scale) + 1
            
            vertices = []
            for i in range(verts_x):
                for j in range(verts_y):
                    x = -half_width + (i * (map_width / (verts_x - 1)))
                    y = -half_length + (j * (map_length / (verts_y - 1)))
                    vertices.append(bm.verts.new((x, y, map_props.ground_height)))
            
            # Create faces to grid the entire map
            for i in range(verts_x - 1):
                for j in range(verts_y - 1):
                    v1 = i * verts_y + j
                    v2 = i * verts_y + j + 1
                    v3 = (i + 1) * verts_y + j + 1
                    v4 = (i + 1) * verts_y + j
                    bm.faces.new([vertices[v1], vertices[v2], vertices[v3], vertices[v4]])
        else:
            # Create simple quad mesh that still covers entire map
            v1 = bm.verts.new((-half_width, -half_length, map_props.ground_height))
            v2 = bm.verts.new((half_width, -half_length, map_props.ground_height))
            v3 = bm.verts.new((half_width, half_length, map_props.ground_height))
            v4 = bm.verts.new((-half_width, half_length, map_props.ground_height))
            bm.faces.new([v1, v2, v3, v4])
        
        # Update mesh
        bm.to_mesh(mesh)
        bm.free()
        
        # Create object with custom name
        obj = bpy.data.objects.new(f"NWN2_{map_name}", mesh)
        bpy.context.collection.objects.link(obj)
        
        # Add wireframe display to show the grid
        obj.show_wire = True
        obj.show_all_edges = True
        
        # Create simple ground material with unique name
        self.create_ground_material(obj, map_name)
        
        return obj
    
    def create_crossing_grid(self, context, half_width, half_length, spacing, parent_obj, map_name):
        """Create grid lines that cross through the center, not connect to it"""
        # Create grid material - simple dark gray
        grid_mat = bpy.data.materials.new(name=f"NWN2_{map_name}_Grid_Material")
        grid_mat.use_nodes = True
        nodes = grid_mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        output = nodes.new('ShaderNodeOutputMaterial')
        grid_mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        # Simple dark gray grid lines
        bsdf.inputs['Base Color'].default_value = (0.3, 0.3, 0.3, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.8
        
        # Create separate objects for better visibility
        # X grid lines (vertical lines that cross through center)
        x_mesh = bpy.data.meshes.new(f"NWN2_{map_name}_Grid_X_Mesh")
        x_bm = bmesh.new()
        
        for x in range(int(-half_width), int(half_width) + 1, int(spacing)):
            if x == 0:  # Skip center line for now
                continue
            # Create vertices for this vertical line (crosses entire height)
            v1 = x_bm.verts.new((x, -half_length, 0.02))
            v2 = x_bm.verts.new((x, half_length, 0.02))
            # Create edge
            x_bm.edges.new([v1, v2])
        
        # Update X mesh
        x_bm.to_mesh(x_mesh)
        x_bm.free()
        
        # Create X grid object with unique name
        x_grid_obj = bpy.data.objects.new(f"NWN2_{map_name}_Grid_X", x_mesh)
        bpy.context.collection.objects.link(x_grid_obj)
        x_grid_obj.data.materials.append(grid_mat)
        x_grid_obj.show_wire = True
        x_grid_obj.show_all_edges = True
        x_grid_obj.parent = parent_obj
        
        # Y grid lines (horizontal lines that cross through center)
        y_mesh = bpy.data.meshes.new(f"NWN2_{map_name}_Grid_Y_Mesh")
        y_bm = bmesh.new()
        
        for y in range(int(-half_length), int(half_length) + 1, int(spacing)):
            if y == 0:  # Skip center line for now
                continue
            # Create vertices for this horizontal line (crosses entire width)
            v1 = y_bm.verts.new((-half_width, y, 0.02))
            v2 = y_bm.verts.new((half_width, y, 0.02))
            # Create edge
            y_bm.edges.new([v1, v2])
        
        # Update Y mesh
        y_bm.to_mesh(y_mesh)
        y_bm.free()
        
        # Create Y grid object with unique name
        y_grid_obj = bpy.data.objects.new(f"NWN2_{map_name}_Grid_Y", y_mesh)
        bpy.context.collection.objects.link(y_grid_obj)
        y_grid_obj.data.materials.append(grid_mat)
        y_grid_obj.show_wire = True
        y_grid_obj.show_all_edges = True
        y_grid_obj.parent = parent_obj
        
        # Create center cross lines (thicker/different color for visibility)
        center_mat = bpy.data.materials.new(name=f"NWN2_{map_name}_Grid_Center_Material")
        center_mat.use_nodes = True
        nodes = center_mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        output = nodes.new('ShaderNodeOutputMaterial')
        center_mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        # Red color for center lines
        bsdf.inputs['Base Color'].default_value = (0.8, 0.2, 0.2, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.8
        
        # Center X line (vertical)
        center_x_mesh = bpy.data.meshes.new(f"NWN2_{map_name}_Grid_Center_X_Mesh")
        center_x_bm = bmesh.new()
        v1 = center_x_bm.verts.new((0, -half_length, 0.03))
        v2 = center_x_bm.verts.new((0, half_length, 0.03))
        center_x_bm.edges.new([v1, v2])
        center_x_bm.to_mesh(center_x_mesh)
        center_x_bm.free()
        
        center_x_obj = bpy.data.objects.new(f"NWN2_{map_name}_Grid_Center_X", center_x_mesh)
        bpy.context.collection.objects.link(center_x_obj)
        center_x_obj.data.materials.append(center_mat)
        center_x_obj.show_wire = True
        center_x_obj.show_all_edges = True
        center_x_obj.parent = parent_obj
        
        # Center Y line (horizontal)
        center_y_mesh = bpy.data.meshes.new(f"NWN2_{map_name}_Grid_Center_Y_Mesh")
        center_y_bm = bmesh.new()
        v1 = center_y_bm.verts.new((-half_width, 0, 0.03))
        v2 = center_y_bm.verts.new((half_width, 0, 0.03))
        center_y_bm.edges.new([v1, v2])
        center_y_bm.to_mesh(center_y_mesh)
        center_y_bm.free()
        
        center_y_obj = bpy.data.objects.new(f"NWN2_{map_name}_Grid_Center_Y", center_y_mesh)
        bpy.context.collection.objects.link(center_y_obj)
        center_y_obj.data.materials.append(center_mat)
        center_y_obj.show_wire = True
        center_y_obj.show_all_edges = True
        center_y_obj.parent = parent_obj
        
    def create_ground_material(self, obj, map_name):
        """Create simple ground material"""
        ground_mat = bpy.data.materials.new(name=f"NWN2_{map_name}_Ground_Material")
        ground_mat.use_nodes = True
        nodes = ground_mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        output = nodes.new('ShaderNodeOutputMaterial')
        ground_mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        # Simple light gray color for better visibility
        bsdf.inputs['Base Color'].default_value = (0.8, 0.8, 0.8, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.9
        
        obj.data.materials.append(ground_mat)
    
    def create_origin_marker(self, context, parent_obj, map_name):
        """Create origin marker that will be hidden but used as parent"""
        bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
        origin = context.active_object
        origin.name = f"NWN2_{map_name}_Origin"
        origin.scale = (1, 1, 1)
        
        # Hide the origin object from viewport and render
        origin.hide_set(True)
        origin.hide_render = True
        
        # Parent to main map object
        origin.parent = parent_obj
        
        return origin  # Return the origin object to use as parent for markers
    
    def create_distance_markers(self, context, half_width, half_length, spacing, origin_parent, main_map_obj, map_name):
        """Create distance markers parented to origin object"""
        # Create simple marker material with unique name
        marker_mat = bpy.data.materials.new(name=f"NWN2_{map_name}_Marker_Material")
        marker_mat.use_nodes = True
        nodes = marker_mat.node_tree.nodes
        nodes.clear()
        
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        output = nodes.new('ShaderNodeOutputMaterial')
        marker_mat.node_tree.links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        # Simple black color for markers
        bsdf.inputs['Base Color'].default_value = (0.0, 0.0, 0.0, 1.0)
        bsdf.inputs['Roughness'].default_value = 0.8
        
        # Create markers along X axis (INCLUDING 0)
        for i in range(int(-half_width), int(half_width) + 1, int(spacing)):
            # Positive Y edge
            bpy.ops.mesh.primitive_cube_add(size=0.5, location=(i, half_length, 0.25))
            marker = context.active_object
            marker.name = f"NWN2_{map_name}_Marker_X{i}_Y{half_length}"
            marker.data.materials.append(marker_mat)
            # Parent to origin object instead of main map
            if origin_parent:
                marker.parent = origin_parent
            else:
                marker.parent = main_map_obj
            
            # Negative Y edge
            bpy.ops.mesh.primitive_cube_add(size=0.5, location=(i, -half_length, 0.25))
            marker = context.active_object
            marker.name = f"NWN2_{map_name}_Marker_X{i}_Y{-half_length}"
            marker.data.materials.append(marker_mat)
            # Parent to origin object instead of main map
            if origin_parent:
                marker.parent = origin_parent
            else:
                marker.parent = main_map_obj
            
            # Add distance text (positive Y edge) - larger text
            bpy.ops.object.text_add(location=(i, half_length + 1, 0.5))
            text = context.active_object
            text.name = f"NWN2_{map_name}_Text_X{i}"
            text.data.body = f"{i}m"
            # Larger text scale
            text.scale = (0.5, 0.5, 0.5)
            # Parent to origin object instead of main map
            if origin_parent:
                text.parent = origin_parent
            else:
                text.parent = main_map_obj
        
        # Create markers along Y axis (INCLUDING 0)
        for i in range(int(-half_length), int(half_length) + 1, int(spacing)):
            # Positive X edge
            bpy.ops.mesh.primitive_cube_add(size=0.5, location=(half_width, i, 0.25))
            marker = context.active_object
            marker.name = f"NWN2_{map_name}_Marker_Y{i}_X{half_width}"
            marker.data.materials.append(marker_mat)
            # Parent to origin object instead of main map
            if origin_parent:
                marker.parent = origin_parent
            else:
                marker.parent = main_map_obj
            
            # Negative X edge
            bpy.ops.mesh.primitive_cube_add(size=0.5, location=(-half_width, i, 0.25))
            marker = context.active_object
            marker.name = f"NWN2_{map_name}_Marker_Y{i}_X{-half_width}"
            marker.data.materials.append(marker_mat)
            # Parent to origin object instead of main map
            if origin_parent:
                marker.parent = origin_parent
            else:
                marker.parent = main_map_obj
            
            # Add distance text (positive X edge) - larger text
            bpy.ops.object.text_add(location=(half_width + 1, i, 0.5))
            text = context.active_object
            text.name = f"NWN2_{map_name}_Text_Y{i}"
            text.data.body = f"{i}m"
            # Larger text scale
            text.scale = (0.5, 0.5, 0.5)
            # Parent to origin object instead of main map
            if origin_parent:
                text.parent = origin_parent
            else:
                text.parent = main_map_obj

class NWN2_OT_ClearAllMaps(bpy.types.Operator):
    """Clear all NWN2 map objects"""
    bl_idname = "nwn2.clear_all_maps"
    bl_label = "Clear All NWN2 Maps"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Find and remove ALL NWN2 map objects
        removed_count = 0
        for obj in bpy.data.objects:
            if obj.name.startswith("NWN2_"):
                bpy.data.objects.remove(obj, do_unlink=True)
                removed_count += 1
        
        # Remove ALL NWN2 materials
        materials_to_remove = []
        for mat in bpy.data.materials:
            if mat.name.startswith("NWN2_"):
                materials_to_remove.append(mat)
        
        for mat in materials_to_remove:
            bpy.data.materials.remove(mat)
        
        self.report({'INFO'}, f"Removed {removed_count} NWN2 objects and {len(materials_to_remove)} materials")
        return {'FINISHED'}

# ==============================================
# PANEL
# ==============================================

    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        map_props = scene.nwn2_map_props
        
        # Tile-based settings
        layout.label(text="Map Settings:")
        box = layout.box()
        box.prop(map_props, "map_x")
        box.prop(map_props, "map_y")
        box.prop(map_props, "grid_scale")
        
        # Creation options
        layout.separator()
        layout.label(text="Creation Options:")
        box = layout.box()
        box.prop(map_props, "create_ground")
        if map_props.create_ground:
            box.prop(map_props, "ground_height")
        box.prop(map_props, "create_grid")
        if map_props.create_grid:
            box.prop(map_props, "grid_spacing")
        box.prop(map_props, "create_origin")
        
        # Grid and marker options
        box.prop(map_props, "show_grid_mesh")
        box.prop(map_props, "show_distance_markers")
        if map_props.show_distance_markers:
            box.prop(map_props, "marker_interval")
        
        # Action buttons
        layout.separator()
        row = layout.row()
        row.operator("nwn2.create_map", icon='MATPLANE')
        row.operator("nwn2.clear_all_maps", icon='TRASH')
        
        # Show current maps in scene
        layout.separator()
        layout.label(text="Current Maps in Scene:")
        box = layout.box()
        
        nwn2_maps = [obj for obj in bpy.data.objects if obj.name.startswith("NWN2_") and not obj.name.endswith("_Origin")]
        if nwn2_maps:
            for obj in nwn2_maps:
                # Only show main map objects, not children
                if not obj.parent and obj.name.startswith("NWN2_") and not obj.name.endswith(("_Grid", "_Marker", "_Text")):
                    row = box.row()
                    row.label(text=obj.name)
                    # Add select button
                    op = row.operator("object.select_all", text="", icon='RESTRICT_SELECT_OFF')
                    op.action = 'DESELECT'
                    row.operator("object.select_pattern", text="", icon='VIEWZOOM').pattern = obj.name
        else:
            box.label(text="No NWN2 maps in scene")

# Registration
map_classes = (
    NWN2MapProperties,
    NWN2_OT_CreateMap,
    NWN2_OT_ClearAllMaps,
)

def register_map_system():
    for cls in map_classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nwn2_map_props = bpy.props.PointerProperty(type=NWN2MapProperties)

def unregister_map_system():
    for cls in map_classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.nwn2_map_props

if __name__ == "__main__":
    register_map_system()