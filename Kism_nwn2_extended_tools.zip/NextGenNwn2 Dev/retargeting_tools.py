# Blender imports
import bpy
import bmesh
from mathutils import Vector
from bpy.props import (
    StringProperty, BoolProperty, 
    EnumProperty, PointerProperty,
    CollectionProperty, IntProperty,
    FloatProperty
)
from bpy.types import Operator, PropertyGroup, UIList

# ==============================================
# PROPERTY GROUPS
# ==============================================

class BoneListItem(PropertyGroup):
    """Group of properties representing a bone in the list"""
    name: StringProperty(name="Bone Name")
    include_bone: EnumProperty(
        name="Include",
        description="Include this bone in empty generation",
        items=[
            ('YES', "Yes", "Include this bone"),
            ('NO', "No", "Exclude this bone")
        ],
        default='YES'
    )
    bone_index: IntProperty()

class DynamicProperties(PropertyGroup):
    """Properties for dynamic retargeting tools"""
    current_tab: EnumProperty(
        name="Tab",
        items=[
            ('dynamic_retargeting', "Dynamic Retargeting", ""),
            ('source_constraints', "Source Constraints", ""),
            ('target_constraints', "Target Constraints", "")
        ],
        default='dynamic_retargeting'
    )

    prefix_empties: StringProperty(name="Prefix for Empties", default="")
    prefix_constraints: StringProperty(name="Prefix for Constraints", default="")
    
    # Bone selection properties
    bone_list: CollectionProperty(type=BoneListItem)
    bone_list_index: IntProperty(default=0)
    show_bone_selection: BoolProperty(default=False)
    
    # Filter properties
    filter_bone_names: StringProperty(
        name="Filter Bones",
        description="Filter bones by name (comma-separated, e.g., arm,leg,hand)",
        default=""
    )
    filter_action: EnumProperty(
        name="Filter Action",
        items=[
            ('INCLUDE', "Include Only", "Only include bones matching the filter"),
            ('EXCLUDE', "Exclude", "Exclude bones matching the filter"),
            ('SELECT', "Select Matching", "Select bones matching the filter"),
            ('DESELECT', "Deselect Matching", "Deselect bones matching the filter")
        ],
        default='INCLUDE'
    )
    
    # Vertex snapping properties
    vertex_size: FloatProperty(
        name="Vertex Size",
        description="Size of created vertices",
        default=0.05,
        min=0.001,
        max=1.0
    )

# ==============================================
# RETARGETING FUNCTIONS
# ==============================================

def find_nearest_bone(obj, armature):
    """Find the nearest bone for a given object"""
    nearest_bone = None
    min_distance = float('inf')
    
    for bone in armature.pose.bones:
        distance = (bone.head - obj.location).length
        if distance < min_distance:
            nearest_bone = bone
            min_distance = distance
    
    return nearest_bone

def connect_armatures_callback(context):
    """Connect two armatures with copy rotation and location constraints"""
    selected_armatures = bpy.context.selected_objects

    if len(selected_armatures) != 2:
        raise ValueError("Please select exactly two armatures")

    for bone in selected_armatures[0].pose.bones:
        if bone.name in selected_armatures[1].pose.bones:
            target_bone = selected_armatures[1].pose.bones[bone.name]

            copy_rot_constraint = target_bone.constraints.new(type='COPY_ROTATION')
            copy_rot_constraint.target = selected_armatures[0]
            copy_rot_constraint.subtarget = bone.name

            copy_loc_constraint = target_bone.constraints.new(type='COPY_LOCATION')
            copy_loc_constraint.target = selected_armatures[0]
            copy_loc_constraint.subtarget = bone.name

def toggle_selected_bone_constraints_callback(context):
    """Toggle bone constraints only for selected bones in pose mode"""
    selected_armature = bpy.context.active_object

    if (selected_armature is not None and 
        selected_armature.type == 'ARMATURE' and 
        bpy.context.mode == 'POSE'):
        
        selected_bones = [bone for bone in selected_armature.pose.bones if bone.bone.select]
        
        if not selected_bones:
            print("No bones selected in pose mode.")
            return
        
        for bone in selected_bones:
            for constraint in bone.constraints:
                constraint.mute = not constraint.mute
        
        print(f"Toggled constraints for {len(selected_bones)} selected bone(s).")
    else:
        print("No armature selected or not in pose mode.")

# ==============================================
# UI LIST FOR BONE SELECTION
# ==============================================

class BONE_UL_List(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            row.label(text=item.name)
            row.prop(item, "include_bone", text="")
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.prop(item, "include_bone", text=item.name)

# ==============================================
# DYNAMIC RETARGETING OPERATORS
# ==============================================

class OBJECT_OT_ConnectArmatures(bpy.types.Operator):
    bl_idname = "object.connect_armatures"
    bl_label = "Connect Armatures"
    bl_description = "Connect two armatures with copy rotation and location constraints"

    def execute(self, context):
        connect_armatures_callback(context)
        return {'FINISHED'}

class OBJECT_OT_ToggleSelectedBoneConstraints(bpy.types.Operator):
    bl_idname = "object.toggle_selected_bone_constraints"
    bl_label = "Toggle Selected Bone Constraints"
    bl_description = "Toggle constraints only for bones selected in pose mode"

    def execute(self, context):
        toggle_selected_bone_constraints_callback(context)
        return {'FINISHED'}

class OBJECT_OT_ToggleConstraints(bpy.types.Operator):
    bl_idname = "object.toggle_constraints"
    bl_label = "Toggle Constraints"
    bl_description = "Toggle constraints with specific prefix"
    
    prefix: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        selected_armature = scene.objects.get(scene.selected_armature)

        if selected_armature and selected_armature.type == 'ARMATURE':
            for bone in selected_armature.data.bones:
                pose_bone = selected_armature.pose.bones.get(bone.name)
                if pose_bone:
                    for constraint in pose_bone.constraints:
                        if constraint.name.startswith(self.prefix):
                            constraint.mute = not constraint.mute

            scene.active_constraint_prefix = self.prefix

        return {'FINISHED'}

# ==============================================
# BONE SELECTION OPERATORS
# ==============================================

class OBJECT_OT_RefreshBoneList(bpy.types.Operator):
    bl_idname = "object.refresh_bone_list"
    bl_label = "Refresh Bone List"
    bl_description = "Refresh the list of bones from the selected armature"
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        # Clear the existing list
        dynamic_props.bone_list.clear()
        
        # Get the active armature
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            # Add all bones from the armature to the list
            for i, bone in enumerate(armature.pose.bones):
                item = dynamic_props.bone_list.add()
                item.name = bone.name
                item.bone_index = i
                item.include_bone = 'YES'
            
            self.report({'INFO'}, f"Refreshed bone list with {len(armature.pose.bones)} bones")
        else:
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class OBJECT_OT_SelectBonesFromPoseMode(bpy.types.Operator):
    bl_idname = "object.select_bones_from_pose_mode"
    bl_label = "Sync from Pose Selection"
    bl_description = "Update bone list selection based on currently selected bones in pose mode"
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        armature = context.active_object
        if armature and armature.type == 'ARMATURE':
            # Get currently selected bones in pose mode
            selected_bones = [bone.name for bone in armature.pose.bones if bone.bone.select]
            
            # Update the bone list selection
            for item in dynamic_props.bone_list:
                item.include_bone = 'YES' if item.name in selected_bones else 'NO'
            
            self.report({'INFO'}, f"Synced selection from {len(selected_bones)} selected bones")
        else:
            self.report({'WARNING'}, "No armature selected or not in pose mode")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class OBJECT_OT_SelectAllBones(bpy.types.Operator):
    bl_idname = "object.select_all_bones"
    bl_label = "Select All"
    bl_description = "Select all bones in the list"
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        for item in dynamic_props.bone_list:
            item.include_bone = 'YES'
        
        self.report({'INFO'}, f"Selected all {len(dynamic_props.bone_list)} bones")
        return {'FINISHED'}

class OBJECT_OT_DeselectAllBones(bpy.types.Operator):
    bl_idname = "object.deselect_all_bones"
    bl_label = "Deselect All"
    bl_description = "Deselect all bones in the list"
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        for item in dynamic_props.bone_list:
            item.include_bone = 'NO'
        
        self.report({'INFO'}, f"Deselected all {len(dynamic_props.bone_list)} bones")
        return {'FINISHED'}

class OBJECT_OT_ApplyBoneFilter(bpy.types.Operator):
    bl_idname = "object.apply_bone_filter"
    bl_label = "Apply Filter"
    bl_description = "Apply the bone name filter"
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        filter_names = dynamic_props.filter_bone_names.strip()
        if not filter_names:
            self.report({'INFO'}, "No filter specified")
            return {'CANCELLED'}
        
        filter_terms = [term.strip().lower() for term in filter_names.split(',') if term.strip()]
        
        processed_count = 0
        for item in dynamic_props.bone_list:
            bone_name_lower = item.name.lower()
            matches_filter = any(term in bone_name_lower for term in filter_terms)
            
            if dynamic_props.filter_action == 'INCLUDE':
                item.include_bone = 'YES' if matches_filter else 'NO'
                processed_count += 1
            elif dynamic_props.filter_action == 'EXCLUDE':
                item.include_bone = 'NO' if matches_filter else 'YES'
                processed_count += 1
            elif dynamic_props.filter_action == 'SELECT':
                if matches_filter:
                    item.include_bone = 'YES'
                    processed_count += 1
            elif dynamic_props.filter_action == 'DESELECT':
                if matches_filter:
                    item.include_bone = 'NO'
                    processed_count += 1
        
        self.report({'INFO'}, f"Filter applied to {processed_count} bones using {len(filter_terms)} term(s)")
        return {'FINISHED'}

# ==============================================
# SOURCE CONSTRAINTS OPERATORS
# ==============================================

class OBJECT_OT_CreateControlEmpties(bpy.types.Operator):
    bl_idname = "object.create_control_empties"
    bl_label = "Create Control Empties"
    bl_description = "Create control empties for selected bones in the armature"
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter prefix for constraints:")
        layout.prop(context.scene.dynamic_props, "prefix_constraints", text="")
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}
        
        # Check if we have any bones selected
        selected_bones = [item for item in dynamic_props.bone_list if item.include_bone == 'YES']
        if not selected_bones:
            self.report({'WARNING'}, "No bones selected in the bone list")
            return {'CANCELLED'}
        
        # Find root bone
        root_bone = None
        for bone in armature.pose.bones:
            if bone.parent is None:
                root_bone = bone
                break

        # Create or get the rigging constraints collection
        rigging_constraints_collection = bpy.data.collections.get("RiggingConstraints")
        if rigging_constraints_collection is None:
            rigging_constraints_collection = bpy.data.collections.new("RiggingConstraints")
            context.scene.collection.children.link(rigging_constraints_collection)

        created_count = 0
        for item in selected_bones:
            bone = armature.pose.bones.get(item.name)
            if bone:
                # Determine control empty name
                if bone == root_bone:
                    ctrl_name = "root_ctrl"
                else:
                    ctrl_name = f"{bone.name}_CTRL"
                
                # Check if empty already exists
                existing_empty = rigging_constraints_collection.objects.get(ctrl_name)
                if existing_empty:
                    continue
                
                # Create new control empty
                ctrl_empty = bpy.data.objects.new(name=ctrl_name, object_data=None)
                ctrl_empty.empty_display_type = 'CUBE'
                ctrl_empty.empty_display_size = 0.01
                rigging_constraints_collection.objects.link(ctrl_empty)
                
                # Position empty at bone location
                bone_matrix = armature.matrix_world @ bone.matrix
                ctrl_empty.location = bone_matrix.to_translation()
                created_count += 1

        # Apply prefix to constraints if specified
        prefix = dynamic_props.prefix_constraints.strip()
        constraint_count = 0
        if prefix:
            for bone in armature.pose.bones:
                for constraint in bone.constraints:
                    constraint.name = prefix + constraint.name
                    constraint_count += 1
        
        if created_count > 0:
            self.report({'INFO'}, f"Created {created_count} control empties and prefixed {constraint_count} constraints")
        else:
            self.report({'INFO'}, "No new control empties created (they may already exist)")
        
        return {'FINISHED'}

class OBJECT_OT_AddConstraintToNearestBone(bpy.types.Operator):
    bl_idname = "object.add_constraint_to_nearest_bone"
    bl_label = "Sync to Bones"
    bl_description = "Add copy transforms constraints from empties to nearest bones"
    
    def execute(self, context):
        collection = bpy.data.collections.get("RiggingConstraints")
        if not collection:
            self.report({'WARNING'}, "Collection 'RiggingConstraints' not found.")
            return {'CANCELLED'}
            
        armature = context.active_object
        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature object selected or selected object is not an armature.")
            return {'CANCELLED'}
        
        constraint_count = 0
        for obj in collection.objects:
            nearest_bone = self.find_nearest_bone(obj, armature)
            if nearest_bone:
                # Remove existing copy transforms constraints
                for constraint in obj.constraints:
                    if constraint.type == 'COPY_TRANSFORMS':
                        obj.constraints.remove(constraint)
                
                # Add new copy transforms constraint
                copy_constraint = obj.constraints.new('COPY_TRANSFORMS')
                copy_constraint.target = armature
                copy_constraint.subtarget = nearest_bone.name
                constraint_count += 1
        
        self.report({'INFO'}, f"Added {constraint_count} copy transforms constraints")
        return {'FINISHED'}

    def find_nearest_bone(self, obj, armature):
        nearest_bone = None
        min_distance = float('inf')
        for bone in armature.pose.bones:
            distance = (bone.head - obj.location).length
            if distance < min_distance:
                nearest_bone = bone
                min_distance = distance
        return nearest_bone

# ==============================================
# VERTEX SNAPPING OPERATORS (NEW)
# ==============================================

class OBJECT_OT_CreateBoneVertices(bpy.types.Operator):
    """Create single vertices at each bone location for snapping"""
    bl_idname = "object.create_bone_vertices"
    bl_label = "Create Bone Vertices"
    bl_description = "Create single vertices at each bone location for snapping"
    
    use_bone_list: BoolProperty(
        name="Use Bone List Selection",
        description="Only create vertices for bones selected in the bone list",
        default=True
    )
    
    vertex_size: FloatProperty(
        name="Vertex Size",
        description="Display size of vertices",
        default=0.05,
        min=0.001,
        max=1.0
    )
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'ARMATURE' and 
                context.mode == 'OBJECT')
    
    def invoke(self, context, event):
        # Set default vertex size from dynamic props if available
        if hasattr(context.scene, 'dynamic_props'):
            self.vertex_size = context.scene.dynamic_props.vertex_size
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "use_bone_list")
        layout.prop(self, "vertex_size")
        
        if self.use_bone_list:
            layout.label(text="Only creates vertices for bones", icon='INFO')
            layout.label(text="marked 'YES' in the bone list", icon='DOT')
    
    def execute(self, context):
        scene = context.scene
        armature = context.active_object
        
        # Update vertex size in dynamic props
        if hasattr(scene, 'dynamic_props'):
            scene.dynamic_props.vertex_size = self.vertex_size
        
        # Create a new mesh object
        mesh_name = f"{armature.name}_BoneVerts"
        
        # Remove existing mesh if it exists
        existing_mesh = bpy.data.meshes.get(mesh_name)
        if existing_mesh:
            bpy.data.meshes.remove(existing_mesh)
        
        # Create new mesh
        mesh_data = bpy.data.meshes.new(mesh_name)
        vert_obj = bpy.data.objects.new(mesh_name, mesh_data)
        context.scene.collection.objects.link(vert_obj)
        
        # Set location to match armature
        vert_obj.location = armature.location
        vert_obj.rotation_euler = armature.rotation_euler
        vert_obj.scale = armature.scale
        
        # Set vertex size display
        vert_obj.data.show_extra_indices = True
        
        # Create bmesh and add vertices
        bm = bmesh.new()
        
        # Get bones to process
        if self.use_bone_list and hasattr(scene, 'dynamic_props'):
            dynamic_props = scene.dynamic_props
            bones_to_process = []
            
            if hasattr(dynamic_props, 'bone_list'):
                for item in dynamic_props.bone_list:
                    if item.include_bone == 'YES':
                        bone = armature.pose.bones.get(item.name)
                        if bone:
                            bones_to_process.append(bone)
        else:
            # Use all bones
            bones_to_process = list(armature.pose.bones)
        
        vertex_count = 0
        for bone in bones_to_process:
            # Get bone world position
            bone_matrix = armature.matrix_world @ bone.matrix
            bone_pos = bone_matrix.to_translation()
            
            # Convert to local space of the mesh object
            local_pos = vert_obj.matrix_world.inverted() @ bone_pos
            
            # Create vertex
            bm.verts.new(local_pos)
            vertex_count += 1
        
        # Update mesh
        bm.to_mesh(mesh_data)
        bm.free()
        
        # Add vertex group for each bone
        for i, bone in enumerate(bones_to_process):
            vert_group = vert_obj.vertex_groups.new(name=bone.name)
            vert_group.add([i], 1.0, 'ADD')
        
        # Add geometry nodes modifier to show vertices as points
        if hasattr(bpy.types, 'GeometryNodeTree'):
            try:
                # Create geometry nodes setup to visualize vertices
                mod = vert_obj.modifiers.new(name="VertexDisplay", type='NODES')
                
                # Create new geometry node group
                node_group = bpy.data.node_groups.new("VertexDisplay", 'GeometryNodeTree')
                mod.node_group = node_group
                
                # Create nodes
                group_input = node_group.nodes.new('NodeGroupInput')
                group_output = node_group.nodes.new('NodeGroupOutput')
                
                # Set positions
                group_input.location = (-300, 0)
                group_output.location = (300, 0)
                
                # Add mesh to points node
                mesh_to_points = node_group.nodes.new('GeometryNodeMeshToPoints')
                mesh_to_points.location = (0, 0)
                
                # Add set material node
                set_material = node_group.nodes.new('GeometryNodeSetMaterial')
                set_material.location = (150, 0)
                
                # Create a simple material for vertices
                mat = bpy.data.materials.new("VertexMaterial")
                mat.use_nodes = True
                mat.node_tree.nodes.clear()
                
                # Add emission node
                emission = mat.node_tree.nodes.new('ShaderNodeEmission')
                emission.inputs[0].default_value = (1, 0.5, 0, 1)  # Orange color
                emission.inputs[1].default_value = 5.0  # Strength
                
                # Add material output
                output = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
                emission.location = (-200, 0)
                output.location = (0, 0)
                
                # Connect nodes
                mat.node_tree.links.new(emission.outputs[0], output.inputs[0])
                
                # Set material to object
                vert_obj.data.materials.append(mat)
                
                # Connect geometry nodes
                node_group.links.new(group_input.outputs[0], mesh_to_points.inputs[0])
                node_group.links.new(mesh_to_points.outputs[0], set_material.inputs[0])
                node_group.links.new(set_material.outputs[0], group_output.inputs[0])
                
                # Set material in node
                set_material.inputs[2].default_value = mat
                
                # Set point radius
                mesh_to_points.inputs[2].default_value = self.vertex_size
                
            except Exception as e:
                print(f"Could not create geometry nodes: {e}")
        
        self.report({'INFO'}, f"Created {vertex_count} vertices for {armature.name}")
        return {'FINISHED'}

class OBJECT_OT_DeleteBoneVertices(bpy.types.Operator):
    """Delete bone vertices mesh"""
    bl_idname = "object.delete_bone_vertices"
    bl_label = "Delete Bone Vertices"
    bl_description = "Delete the bone vertices mesh"
    
    delete_all: BoolProperty(
        name="Delete All Vertex Meshes",
        description="Delete all bone vertex meshes in the scene",
        default=True
    )
    
    @classmethod
    def poll(cls, context):
        return True
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "delete_all")
        
        if self.delete_all:
            layout.label(text="Will delete ALL bone vertex meshes", icon='INFO')
        else:
            layout.label(text="Will delete only active bone vertex mesh", icon='INFO')
    
    def execute(self, context):
        deleted_count = 0
        
        if self.delete_all:
            # Find and delete all bone vertex meshes
            for obj in list(context.scene.objects):
                if obj.type == 'MESH' and obj.name.endswith('_BoneVerts'):
                    bpy.data.objects.remove(obj, do_unlink=True)
                    deleted_count += 1
        else:
            # Delete only active object if it's a bone vertex mesh
            active_obj = context.active_object
            if active_obj and active_obj.type == 'MESH' and active_obj.name.endswith('_BoneVerts'):
                bpy.data.objects.remove(active_obj, do_unlink=True)
                deleted_count = 1
        
        if deleted_count > 0:
            self.report({'INFO'}, f"Deleted {deleted_count} bone vertex mesh(es)")
        else:
            self.report({'INFO'}, "No bone vertex meshes found")
        
        return {'FINISHED'}

class OBJECT_OT_SnapEmptiesToVertices(bpy.types.Operator):
    """Snap empties to bone vertices"""
    bl_idname = "object.snap_empties_to_vertices"
    bl_label = "Snap Empties to Bone Vertices"
    bl_description = "Snap empties to corresponding bone vertices"
    
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'
    
    def execute(self, context):
        vert_mesh = context.active_object
        
        # Check if this is a bone vertex mesh
        if not vert_mesh.name.endswith('_BoneVerts'):
            self.report({'WARNING'}, "Active object is not a bone vertex mesh")
            return {'CANCELLED'}
        
        # Get all empties in the scene
        empties = [obj for obj in context.scene.objects if obj.type == 'EMPTY']
        
        snapped_count = 0
        
        for empty in empties:
            # Try to find matching vertex by name
            empty_base_name = empty.name.replace('_CTRL', '').replace('_Rot', '').replace('root_ctrl', 'root').replace('root_Rot', 'root')
            
            for bone_name in vert_mesh.vertex_groups.keys():
                if bone_name in empty_base_name or empty_base_name in bone_name:
                    # Get vertex position from mesh
                    # Find the vertex index for this bone
                    vert_index = None
                    for i, v in enumerate(vert_mesh.data.vertices):
                        # Check if vertex is in this bone's vertex group
                        for vg in v.groups:
                            if vg.group == vert_mesh.vertex_groups[bone_name].index:
                                vert_index = i
                                break
                        if vert_index is not None:
                            break
                    
                    if vert_index is not None:
                        # Get vertex world position
                        vert_pos = vert_mesh.matrix_world @ vert_mesh.data.vertices[vert_index].co
                        
                        # Snap empty to vertex position
                        empty.location = vert_pos
                        snapped_count += 1
                        break
        
        self.report({'INFO'}, f"Snapped {snapped_count} empties to vertices")
        return {'FINISHED'}

# ==============================================
# TARGET CONSTRAINTS OPERATORS
# ==============================================

class OBJECT_OT_CreateRotationEmpties(bpy.types.Operator):
    bl_idname = "object.create_rotation_empties"
    bl_label = "Create Parent Empties"
    bl_description = "Create empties for selected bones in the armature"
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter prefix for empties:")
        layout.prop(context.scene.dynamic_props, "prefix_empties", text="")
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}
        
        # Check if we have any bones selected
        selected_bones = [item for item in dynamic_props.bone_list if item.include_bone == 'YES']
        if not selected_bones:
            self.report({'WARNING'}, "No bones selected in the bone list")
            return {'CANCELLED'}
        
        # Find root bone
        root_bone = None
        for bone in armature.pose.bones:
            if bone.parent is None:
                root_bone = bone
                break

        # Create or get the rotation empties collection
        rotation_empties_collection = bpy.data.collections.get("RotationEmpties")
        if rotation_empties_collection is None:
            rotation_empties_collection = bpy.data.collections.new("RotationEmpties")
            context.scene.collection.children.link(rotation_empties_collection)

        created_count = 0
        skipped_count = 0
        
        for item in selected_bones:
            bone = armature.pose.bones.get(item.name)
            if bone:
                # Determine rotation empty name
                if bone == root_bone:
                    rot_name = "root_Rot"
                else:
                    rot_name = f"{bone.name}_Rot"
                
                # Apply prefix if specified
                prefix = dynamic_props.prefix_empties.strip()
                if prefix:
                    rot_name = prefix + rot_name
                
                # Check if empty already exists
                existing_empty = rotation_empties_collection.objects.get(rot_name)
                if existing_empty:
                    skipped_count += 1
                    continue
                
                # Create new rotation empty
                rot_empty = bpy.data.objects.new(name=rot_name, object_data=None)
                rot_empty.empty_display_type = 'SPHERE'
                rot_empty.empty_display_size = 0.01
                rotation_empties_collection.objects.link(rot_empty)
                
                # Position and rotate empty to match bone
                bone_matrix = armature.matrix_world @ bone.matrix
                rot_empty.location = bone_matrix.to_translation()
                rot_empty.rotation_euler = bone_matrix.to_euler()
                
                # Add copy rotation constraint to bone
                copy_rotation_constraint = bone.constraints.new(type='COPY_ROTATION')
                copy_rotation_constraint.target = rot_empty
                
                # Add copy location constraint for root bone
                if bone == root_bone:
                    copy_location_constraint = bone.constraints.new(type='COPY_LOCATION')
                    copy_location_constraint.target = rot_empty
                
                created_count += 1

        # Apply prefix to collection name if specified
        prefix = dynamic_props.prefix_empties.strip()
        if prefix:
            rotation_empties_collection.name = prefix + "RotationEmpties"
        
        if created_count > 0:
            self.report({'INFO'}, f"Created {created_count} rotation empties")
            if skipped_count > 0:
                self.report({'INFO'}, f"Skipped {skipped_count} existing empties")
        else:
            if skipped_count > 0:
                self.report({'INFO'}, f"All rotation empties already exist ({skipped_count} skipped)")
            else:
                self.report({'INFO'}, "No rotation empties created")
        
        return {'FINISHED'}

class OBJECT_OT_CreateRotationEmptiesWithBoneList(bpy.types.Operator):
    """Create rotation empties for selected bones in the list"""
    bl_idname = "object.create_rotation_empties_with_bone_list"
    bl_label = "Create Rotation Empties (Bone List)"
    bl_description = "Create rotation empties for bones selected in the bone list"
    
    prefix: StringProperty(name="Prefix", default="")
    
    def invoke(self, context, event):
        # Set default prefix from dynamic props if available
        if hasattr(context.scene, 'dynamic_props'):
            self.prefix = context.scene.dynamic_props.prefix_empties
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter prefix for empties (optional):")
        layout.prop(self, "prefix", text="")
        
        # Show bone count info
        scene = context.scene
        if hasattr(scene, 'dynamic_props'):
            dynamic_props = scene.dynamic_props
            if hasattr(dynamic_props, 'bone_list'):
                selected_count = sum(1 for item in dynamic_props.bone_list if item.include_bone == 'YES')
                total_count = len(dynamic_props.bone_list)
                layout.label(text=f"Selected: {selected_count} of {total_count} bones", icon='BONE_DATA')
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}
        
        # Check if we have any bones selected in the bone list
        if not hasattr(dynamic_props, 'bone_list') or len(dynamic_props.bone_list) == 0:
            self.report({'WARNING'}, "Bone list is empty. Refresh bone list first.")
            return {'CANCELLED'}
        
        selected_bones = [item for item in dynamic_props.bone_list if item.include_bone == 'YES']
        if not selected_bones:
            self.report({'WARNING'}, "No bones selected in the bone list")
            return {'CANCELLED'}
        
        # Find root bone
        root_bone = None
        for bone in armature.pose.bones:
            if bone.parent is None:
                root_bone = bone
                break
        
        # Create or get the rotation empties collection
        rotation_empties_collection = bpy.data.collections.get("RotationEmpties")
        if rotation_empties_collection is None:
            rotation_empties_collection = bpy.data.collections.new("RotationEmpties")
            context.scene.collection.children.link(rotation_empties_collection)
        
        created_count = 0
        skipped_count = 0
        
        for item in selected_bones:
            bone = armature.pose.bones.get(item.name)
            if bone:
                # Determine rotation empty name
                if bone == root_bone:
                    rot_name = "root_Rot"
                else:
                    rot_name = f"{bone.name}_Rot"
                
                # Apply prefix if specified
                if self.prefix:
                    rot_name = self.prefix + rot_name
                
                # Check if empty already exists
                existing_empty = rotation_empties_collection.objects.get(rot_name)
                if existing_empty:
                    skipped_count += 1
                    continue
                
                # Create new rotation empty
                rot_empty = bpy.data.objects.new(name=rot_name, object_data=None)
                rot_empty.empty_display_type = 'SPHERE'
                rot_empty.empty_display_size = 0.01
                rotation_empties_collection.objects.link(rot_empty)
                
                # Position and rotate empty to match bone
                bone_matrix = armature.matrix_world @ bone.matrix
                rot_empty.location = bone_matrix.to_translation()
                rot_empty.rotation_euler = bone_matrix.to_euler()
                
                # Add copy rotation constraint to bone
                copy_rotation_constraint = bone.constraints.new(type='COPY_ROTATION')
                copy_rotation_constraint.target = rot_empty
                
                # Add copy location constraint for root bone
                if bone == root_bone:
                    copy_location_constraint = bone.constraints.new(type='COPY_LOCATION')
                    copy_location_constraint.target = rot_empty
                
                created_count += 1
        
        # Apply prefix to collection name if specified
        if self.prefix:
            rotation_empties_collection.name = self.prefix + "RotationEmpties"
        
        if created_count > 0:
            self.report({'INFO'}, f"Created {created_count} rotation empties for selected bones")
            if skipped_count > 0:
                self.report({'INFO'}, f"Skipped {skipped_count} existing empties")
        else:
            if skipped_count > 0:
                self.report({'INFO'}, f"All rotation empties already exist ({skipped_count} skipped)")
            else:
                self.report({'INFO'}, "No rotation empties created")
        
        # Update the prefix in dynamic props
        if self.prefix and hasattr(dynamic_props, 'prefix_empties'):
            dynamic_props.prefix_empties = self.prefix
        
        return {'FINISHED'}

class OBJECT_OT_ParentGeneratedEmpties(bpy.types.Operator):
    bl_idname = "object.parent_generated_empties"
    bl_label = "Parent to Control Empties"
    bl_description = "Parent rotation empties to control empties"

    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        
        rigging_constraints_collection = bpy.data.collections.get("RiggingConstraints")
        rotation_empties_collection = bpy.data.collections.get("RotationEmpties")

        if not rigging_constraints_collection or not rotation_empties_collection:
            self.report({'WARNING'}, "Required collections not found. Create control and rotation empties first.")
            return {'CANCELLED'}

        parented_count = 0
        for rot_empty in rotation_empties_collection.objects:
            # Determine corresponding control empty name
            if rot_empty.name == "root_Rot" or rot_empty.name.endswith("_Rot"):
                if rot_empty.name == "root_Rot":
                    ctrl_name = "root_ctrl"
                else:
                    base_name = rot_empty.name
                    # Remove prefix if present
                    prefix = dynamic_props.prefix_empties
                    if prefix and base_name.startswith(prefix):
                        base_name = base_name[len(prefix):]
                    ctrl_name = base_name.replace("_Rot", "_CTRL")
                    # Add prefix back if needed
                    if prefix:
                        ctrl_name = prefix + ctrl_name
                
                # Find and parent to control empty
                ctrl_empty = rigging_constraints_collection.objects.get(ctrl_name)
                if ctrl_empty:
                    rot_empty.parent = ctrl_empty
                    rot_empty.matrix_parent_inverse = ctrl_empty.matrix_world.inverted()
                    parented_count += 1

        if parented_count > 0:
            self.report({'INFO'}, f"Parented {parented_count} rotation empties to control empties")
        else:
            self.report({'WARNING'}, "No empties were parented. Check naming conventions.")
        
        return {'FINISHED'}

class OBJECT_OT_AddPrefixToConstraints(bpy.types.Operator):
    bl_idname = "object.add_prefix_to_constraints"
    bl_label = "Add Prefix to Constraints"
    bl_description = "Add a prefix to the names of the constraints"

    def execute(self, context):
        prefix = context.scene.dynamic_props.prefix_constraints
        armature = context.active_object

        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}

        constraint_count = 0
        for bone in armature.pose.bones:
            for constraint in bone.constraints:
                constraint.name = prefix + constraint.name
                constraint_count += 1

        self.report({'INFO'}, f"Added prefix to {constraint_count} constraints")
        return {'FINISHED'}

class OBJECT_OT_AddPrefixToEmpties(bpy.types.Operator):
    bl_idname = "object.add_prefix_to_empties"
    bl_label = "Add Prefix to Empties"
    bl_description = "Add a prefix to the names of generated empties"

    def execute(self, context):
        empty_prefix = context.scene.dynamic_props.prefix_empties
        rigging_constraints_collection = bpy.data.collections.get("RiggingConstraints")
        rotation_empties_collection = bpy.data.collections.get("RotationEmpties")

        renamed_count = 0
        
        if rigging_constraints_collection:
            for ctrl_empty in rigging_constraints_collection.objects:
                ctrl_empty.name = empty_prefix + ctrl_empty.name
                renamed_count += 1
            rigging_constraints_collection.name = empty_prefix + "RiggingConstraints"

        if rotation_empties_collection:
            for rot_empty in rotation_empties_collection.objects:
                rot_empty.name = empty_prefix + rot_empty.name
                renamed_count += 1
            rotation_empties_collection.name = empty_prefix + "RotationEmpties"

        self.report({'INFO'}, f"Added prefix to {renamed_count} empties")
        return {'FINISHED'}

# ==============================================
# BONE LIST UTILITY OPERATORS (NEW)
# ==============================================

class OBJECT_OT_SelectBonesByList(bpy.types.Operator):
    """Select bones in pose mode based on bone list selection"""
    bl_idname = "object.select_bones_by_list"
    bl_label = "Select Bones by List"
    bl_description = "Select bones in pose mode based on bone list selection"
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'ARMATURE' and 
                context.mode == 'POSE')
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        # Deselect all bones first
        bpy.ops.pose.select_all(action='DESELECT')
        
        # Select bones based on bone list
        selected_count = 0
        if hasattr(dynamic_props, 'bone_list'):
            for item in dynamic_props.bone_list:
                if item.include_bone == 'YES':
                    bone = armature.pose.bones.get(item.name)
                    if bone:
                        bone.bone.select = True
                        bone.bone.select_head = True
                        bone.bone.select_tail = True
                        selected_count += 1
        
        if selected_count > 0:
            self.report({'INFO'}, f"Selected {selected_count} bones in pose mode")
        else:
            self.report({'WARNING'}, "No bones selected from bone list")
        
        return {'FINISHED'}

class OBJECT_OT_SelectAllListBones(bpy.types.Operator):
    """Select all bones that are in the bone list"""
    bl_idname = "object.select_all_list_bones"
    bl_label = "Select All List Bones"
    bl_description = "Select all bones that are included in the bone list"
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                context.active_object.type == 'ARMATURE' and 
                context.mode == 'POSE')
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        # Deselect all bones first
        bpy.ops.pose.select_all(action='DESELECT')
        
        # Select all bones that are in the list
        selected_count = 0
        if hasattr(dynamic_props, 'bone_list'):
            for item in dynamic_props.bone_list:
                bone = armature.pose.bones.get(item.name)
                if bone:
                    bone.bone.select = True
                    bone.bone.select_head = True
                    bone.bone.select_tail = True
                    selected_count += 1
        
        if selected_count > 0:
            self.report({'INFO'}, f"Selected all {selected_count} bones from list")
        else:
            self.report({'WARNING'}, "No bones in bone list")
        
        return {'FINISHED'}

class OBJECT_OT_HighlightBoneListSelection(bpy.types.Operator):
    """Highlight bones selected in the bone list"""
    bl_idname = "object.highlight_bone_list_selection"
    bl_label = "Highlight Bone List Selection"
    bl_description = "Visualize which bones are selected in the bone list"
    
    highlight_color: bpy.props.FloatVectorProperty(
        name="Highlight Color",
        subtype='COLOR',
        default=(1.0, 0.5, 0.0, 1.0),
        size=4,
        min=0.0,
        max=1.0
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "highlight_color")
        layout.label(text="Creates temporary colored empties", icon='INFO')
        layout.label(text="at bone locations for visualization", icon='DOT')
    
    def execute(self, context):
        scene = context.scene
        dynamic_props = scene.dynamic_props
        armature = context.active_object
        
        if not armature or armature.type != 'ARMATURE':
            self.report({'WARNING'}, "No armature selected")
            return {'CANCELLED'}
        
        # Create a temporary collection for highlights
        highlight_collection = bpy.data.collections.get("BoneListHighlights")
        if highlight_collection is None:
            highlight_collection = bpy.data.collections.new("BoneListHighlights")
            context.scene.collection.children.link(highlight_collection)
        else:
            # Clear existing highlights
            for obj in list(highlight_collection.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
        
        # Create highlight empties for selected bones
        if hasattr(dynamic_props, 'bone_list'):
            created_count = 0
            for item in dynamic_props.bone_list:
                if item.include_bone == 'YES':
                    bone = armature.pose.bones.get(item.name)
                    if bone:
                        # Create highlight empty
                        highlight_name = f"HL_{bone.name}"
                        highlight_empty = bpy.data.objects.new(name=highlight_name, object_data=None)
                        highlight_empty.empty_display_type = 'CUBE'
                        highlight_empty.empty_display_size = 0.005
                        
                        # Set color (using custom property since empties don't have materials by default)
                        highlight_empty["highlight_color"] = self.highlight_color
                        
                        highlight_collection.objects.link(highlight_empty)
                        
                        # Position at bone location
                        bone_matrix = armature.matrix_world @ bone.matrix
                        highlight_empty.location = bone_matrix.to_translation()
                        
                        created_count += 1
            
            self.report({'INFO'}, f"Created {created_count} highlight empties")
        else:
            self.report({'WARNING'}, "No bone list found")
        
        return {'FINISHED'}

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    BoneListItem,
    DynamicProperties,
    BONE_UL_List,
    OBJECT_OT_ConnectArmatures,
    OBJECT_OT_ToggleSelectedBoneConstraints,
    OBJECT_OT_ToggleConstraints,
    OBJECT_OT_RefreshBoneList,
    OBJECT_OT_SelectBonesFromPoseMode,
    OBJECT_OT_SelectAllBones,
    OBJECT_OT_DeselectAllBones,
    OBJECT_OT_ApplyBoneFilter,
    OBJECT_OT_CreateControlEmpties,
    OBJECT_OT_AddConstraintToNearestBone,
    OBJECT_OT_CreateRotationEmpties,
    OBJECT_OT_ParentGeneratedEmpties,
    OBJECT_OT_AddPrefixToConstraints,
    OBJECT_OT_AddPrefixToEmpties,
    # NEW OPERATORS
    OBJECT_OT_CreateBoneVertices,
    OBJECT_OT_DeleteBoneVertices,
    OBJECT_OT_SnapEmptiesToVertices,
    OBJECT_OT_CreateRotationEmptiesWithBoneList,
    OBJECT_OT_SelectBonesByList,
    OBJECT_OT_SelectAllListBones,
    OBJECT_OT_HighlightBoneListSelection,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.dynamic_props = PointerProperty(type=DynamicProperties)
    bpy.types.Scene.show_armature_constraints = BoolProperty(default=False)
    bpy.types.Scene.selected_armature = StringProperty()
    bpy.types.Scene.active_constraint_prefix = StringProperty()

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    props_to_remove = [
        'dynamic_props',
        'show_armature_constraints',
        'selected_armature',
        'active_constraint_prefix'
    ]
    
    for prop in props_to_remove:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

if __name__ == "__main__":
    register()