import bpy
from bpy.types import Operator, Panel, PropertyGroup, UIList
from bpy.props import BoolProperty, CollectionProperty, IntProperty, PointerProperty, StringProperty, EnumProperty, FloatVectorProperty
import random


class MergeTextureBake_SelectedObjectItem(PropertyGroup):
    object_ref: PointerProperty(name="Object Reference", type=bpy.types.Object)

    def get_object_name(self):
        return self.object_ref.name if self.object_ref else "N/A"


def MergeTextureBake_ensure_object_has_materials(obj):
    if not obj.data.materials:
        raise ValueError(f"Object '{obj.name}' has no materials.")


def MergeTextureBake_ensure_uv_map_does_not_exist(mesh, uv_name):
    if uv_name in mesh.uv_layers:
        raise ValueError(f"UV map named '{uv_name}' already exists in object '{mesh.name}'.")


def MergeTextureBake_create_texture(scene, texture_name):
    if texture_name in bpy.data.images:
        bpy.data.images.remove(bpy.data.images[texture_name])

    bpy.ops.image.new(
        name=texture_name,
        width=scene.MergeTextureBake_texture_width,
        height=scene.MergeTextureBake_texture_height,
        color=scene.MergeTextureBake_image_color,
        alpha=scene.MergeTextureBake_use_alpha,
        generated_type=scene.MergeTextureBake_image_generated_type,
        float=scene.MergeTextureBake_use_32bit_float,
        tiled=scene.MergeTextureBake_use_tiled
    )
    return bpy.data.images.get(texture_name)


class MERGETEXTUREBAKE_OT_create_texture_for_materials(Operator):
    bl_idname = "mergetexturebake.create_texture_for_materials"
    bl_label = "Create Texture for Materials"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "Please add objects to the list before creating texture nodes.")
            return {'CANCELLED'}

        try:
            for item in scene.MergeTextureBake_selected_objects_list:
                obj = item.object_ref
                if obj and obj.type == 'MESH':
                    MergeTextureBake_ensure_object_has_materials(obj)
        except ValueError as e:
            self.report({'WARNING'}, str(e))
            return {'CANCELLED'}

        texture_name = scene.MergeTextureBake_texture_name
        new_image = MergeTextureBake_create_texture(scene, texture_name)
        if not new_image:
            self.report({'WARNING'}, "Failed to create texture. Check the parameters.")
            return {'CANCELLED'}

        materials_with_texture = set()
        bpy.context.view_layer.update()
        for item in scene.MergeTextureBake_selected_objects_list:
            obj = item.object_ref
            if obj and obj.type == 'MESH':
                for mat in obj.data.materials:
                    if mat and mat.use_nodes and mat.name not in materials_with_texture:
                        materials_with_texture.add(mat.name)
                        texture_node = mat.node_tree.nodes.new('ShaderNodeTexImage')
                        texture_node.image = new_image
                        texture_node.select = True
                        mat.node_tree.nodes.active = texture_node

        self.report({'INFO'}, f"Texture '{texture_name}' created and applied to selected objects.")
        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_delete_texture_nodes(Operator):
    bl_idname = "mergetexturebake.delete_texture_nodes"
    bl_label = "Delete Texture Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        texture_name = context.scene.MergeTextureBake_texture_name
        found_texture = False

        if not context.scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "Please add objects to the list before deleting texture nodes.")
            return {'CANCELLED'}

        bpy.context.view_layer.update()
        for item in context.scene.MergeTextureBake_selected_objects_list:
            obj = item.object_ref
            if obj and obj.type == 'MESH':
                try:
                    MergeTextureBake_ensure_object_has_materials(obj)
                except ValueError as e:
                    self.report({'WARNING'}, str(e))
                    return {'CANCELLED'}
                for mat in obj.data.materials:
                    if mat and mat.use_nodes:
                        nodes = mat.node_tree.nodes
                        texture_nodes = [n for n in nodes if n.type == 'TEX_IMAGE' and n.image and n.image.name == texture_name]
                        if texture_nodes:
                            for node in texture_nodes:
                                nodes.remove(node)
                            found_texture = True

        if not found_texture:
            self.report({'WARNING'}, f"Texture nodes named '{texture_name}' not found in selected objects' materials.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Texture nodes named '{texture_name}' deleted from selected objects' materials.")
        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_add_selected_object(Operator):
    bl_idname = "mergetexturebake.add_selected_object"
    bl_label = "Add Selected Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        existing_objects = {item.object_ref for item in context.scene.MergeTextureBake_selected_objects_list}

        if not selected_objects:
            self.report({'WARNING'}, "No objects selected in the scene to add.")
            return {'CANCELLED'}

        for obj in selected_objects:
            if obj.type == 'MESH' and obj not in existing_objects:
                item = context.scene.MergeTextureBake_selected_objects_list.add()
                item.object_ref = obj

        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_remove_selected_object(Operator):
    bl_idname = "mergetexturebake.remove_selected_object"
    bl_label = "Remove Selected Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "No objects in the list to remove.")
            return {'CANCELLED'}

        context.scene.MergeTextureBake_selected_objects_list.remove(context.scene.MergeTextureBake_selected_objects_index)
        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_clear_selected_objects_list(Operator):
    bl_idname = "mergetexturebake.clear_selected_objects_list"
    bl_label = "Clear Selected Objects List"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "No objects in the list to clear.")
            return {'CANCELLED'}

        context.scene.MergeTextureBake_selected_objects_list.clear()
        self.report({'INFO'}, "Selected objects list cleared.")
        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_create_uv_map(Operator):
    bl_idname = "mergetexturebake.create_uv_map"
    bl_label = "Create UV Map"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        uv_name = context.scene.MergeTextureBake_uv_map_name

        if not context.scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "Please add objects to the list before creating UV maps.")
            return {'CANCELLED'}

        bpy.context.view_layer.update()
        for item in context.scene.MergeTextureBake_selected_objects_list:
            obj = item.object_ref
            if obj and obj.type == 'MESH':
                mesh = obj.data
                try:
                    MergeTextureBake_ensure_uv_map_does_not_exist(mesh, uv_name)
                except ValueError as e:
                    self.report({'WARNING'}, str(e))
                    return {'CANCELLED'}

                new_uv_layer = mesh.uv_layers.new(name=uv_name)
                mesh.uv_layers.active = new_uv_layer

        self.report({'INFO'}, f"UV map '{uv_name}' created and set as active UV for selected objects.")
        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_remove_uv_map(Operator):
    bl_idname = "mergetexturebake.remove_uv_map"
    bl_label = "Remove UV Map"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        uv_name = context.scene.MergeTextureBake_uv_map_name

        if not uv_name:
            self.report({'WARNING'}, "Please specify a UV map name to remove.")
            return {'CANCELLED'}

        if not context.scene.MergeTextureBake_selected_objects_list:
            self.report({'WARNING'}, "Please add objects to the list before removing UV maps.")
            return {'CANCELLED'}

        removed = False
        bpy.context.view_layer.update()
        for item in context.scene.MergeTextureBake_selected_objects_list:
            obj = item.object_ref
            if obj and obj.type == 'MESH':
                mesh = obj.data
                uv_layer = next((uv for uv in mesh.uv_layers if uv.name == uv_name), None)

                if uv_layer:
                    mesh.uv_layers.remove(uv_layer)
                    removed = True
                    self.report({'INFO'}, f"UV map named '{uv_name}' removed from object '{obj.name}'.")

        if not removed:
            self.report({'WARNING'}, f"No UV map named '{uv_name}' found on selected objects.")

        return {'FINISHED'}


class MERGETEXTUREBAKE_OT_bake_custom(Operator):
    bl_idname = "mergetexturebake.bake_custom"
    bl_label = "Bake Custom"
    bl_options = {'REGISTER', 'UNDO'}

    bake_type: StringProperty()

    _timer = None
    _texture_created = False
    _objects_selected = False
    _bake_started = False
    _original_metallic_values = {}
    _original_metallic_connections = {}
    _stored_metallic_data = {}  # New dictionary for better organization
    _original_render_engine = None  # Store original render engine

    def modal(self, context, event):
        if event.type == 'TIMER':
            if not self._texture_created:
                # Store original render engine before doing anything
                if not self._original_render_engine:
                    self._original_render_engine = bpy.context.scene.render.engine
                
                # Switch to Cycles for baking
                bpy.context.scene.render.engine = 'CYCLES'
                
                bpy.ops.mergetexturebake.create_texture_for_materials()
                self._texture_created = True
                return {'PASS_THROUGH'}

            if not self._objects_selected:
                # Select a random object from the list and set it as active
                selected_item = random.choice(context.scene.MergeTextureBake_selected_objects_list)
                obj = selected_item.object_ref
                if obj and obj.type == 'MESH':
                    obj.select_set(True)
                    context.view_layer.objects.active = obj  # Set as active object
                
                bpy.ops.object.select_all(action='DESELECT')
                for item in context.scene.MergeTextureBake_selected_objects_list:
                    obj = item.object_ref
                    if obj and obj.type == 'MESH':
                        obj.select_set(True)
                self._objects_selected = True
                return {'PASS_THROUGH'}

            if not self._bake_started:
                # Check all materials have texture nodes
                for item in context.scene.MergeTextureBake_selected_objects_list:
                    obj = item.object_ref
                    if obj and obj.type == 'MESH':
                        for mat in obj.data.materials:
                            if mat and mat.use_nodes:
                                texture_nodes = [n for n in mat.node_tree.nodes if n.type == 'TEX_IMAGE']
                                if not texture_nodes:
                                    return {'PASS_THROUGH'}
                
                # Apply custom bake type mapping
                actual_bake_type = self.bake_type
                if self.bake_type == 'METALLIC':
                    actual_bake_type = 'EMIT'
                
                # If baking DIFFUSE, temporarily disable metallic
                if self.bake_type == 'DIFFUSE':
                    self._stored_metallic_data.clear()
                    
                    for item in context.scene.MergeTextureBake_selected_objects_list:
                        obj = item.object_ref
                        if obj and obj.type == 'MESH':
                            for mat in obj.data.materials:
                                if mat and mat.use_nodes:
                                    # Find Principled BSDF nodes
                                    for node in mat.node_tree.nodes:
                                        if node.type == 'BSDF_PRINCIPLED':
                                            # Create a unique identifier for this node
                                            node_id = (obj.name, mat.name, node.name)
                                            
                                            # Store original metallic value
                                            original_value = node.inputs['Metallic'].default_value
                                            self._stored_metallic_data[node_id] = {
                                                'value': original_value,
                                                'connections': None
                                            }
                                            
                                            # Check if metallic is connected
                                            metallic_input = node.inputs['Metallic']
                                            if metallic_input.is_linked:
                                                # Store connection info
                                                link = metallic_input.links[0]
                                                self._stored_metallic_data[node_id]['connections'] = {
                                                    'from_node': link.from_node.name,
                                                    'from_socket': link.from_socket.name
                                                }
                                                # Disconnect the metallic input
                                                mat.node_tree.links.remove(link)
                                            
                                            # Set metallic to 0 for baking
                                            node.inputs['Metallic'].default_value = 0.0
                
                # Start the bake operation with basic parameters
                bpy.ops.object.bake('INVOKE_DEFAULT', type=actual_bake_type, save_mode='INTERNAL')
                
                self._bake_started = True
                return {'PASS_THROUGH'}

            # Count and pack dirty images
            dirty_images = [img for img in bpy.data.images if img.is_dirty]
            if dirty_images:
                context.scene.MergeTextureBake_bake_counter += len(dirty_images)
                for img in dirty_images:
                    img.pack()

            # Check if baking is complete
            if context.scene.MergeTextureBake_bake_counter >= len(context.scene.MergeTextureBake_selected_objects_list):
                # If baking DIFFUSE, restore metallic after bake
                if self.bake_type == 'DIFFUSE':
                    self._restore_metallic_after_bake()
                
                # Restore original render engine
                self._restore_render_engine(context)
                
                context.window_manager.event_timer_remove(self._timer)
                bpy.ops.mergetexturebake.delete_texture_nodes()

                # Manually call MergeTextureBake_check_texture_name to update has_duplicate_texture_name
                MergeTextureBake_check_texture_name(context.scene, context)

                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def _restore_metallic_after_bake(self):
        """Restore metallic nodes to original state after baking"""
        for node_id, data in self._stored_metallic_data.items():
            obj_name, mat_name, node_name = node_id
            
            # Find the object
            obj = bpy.data.objects.get(obj_name)
            if obj and obj.type == 'MESH':
                # Find the material
                mat = bpy.data.materials.get(mat_name)
                if mat and mat.use_nodes:
                    # Find the Principled BSDF node
                    node = mat.node_tree.nodes.get(node_name)
                    if node and node.type == 'BSDF_PRINCIPLED':
                        # Restore original metallic value
                        node.inputs['Metallic'].default_value = data['value']
                        
                        # Restore connection if it existed
                        if data['connections']:
                            conn_info = data['connections']
                            from_node = mat.node_tree.nodes.get(conn_info['from_node'])
                            if from_node:
                                from_socket = None
                                for socket in from_node.outputs:
                                    if socket.name == conn_info['from_socket']:
                                        from_socket = socket
                                        break
                                if from_socket:
                                    # Check if metallic input is already connected
                                    metallic_input = node.inputs['Metallic']
                                    if not metallic_input.is_linked:
                                        mat.node_tree.links.new(
                                            from_socket,
                                            metallic_input
                                        )
        
        # Clear stored data
        self._stored_metallic_data.clear()

    def _restore_render_engine(self, context):
        """Restore the original render engine"""
        if self._original_render_engine:
            try:
                bpy.context.scene.render.engine = self._original_render_engine
                
                # Determine engine name for reporting
                engine_name = "Eevee" if self._original_render_engine == 'BLENDER_EEVEE' else (
                    "Eevee Next" if self._original_render_engine == 'BLENDER_EEVEE_NEXT' else self._original_render_engine
                )
                
                # Only report if we actually switched engines
                if self._original_render_engine != 'CYCLES':
                    self.report({'INFO'}, f"Render engine restored to {engine_name}")
            except Exception as e:
                self.report({'WARNING'}, f"Could not restore render engine: {str(e)}")
        
        self._original_render_engine = None

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        context.scene.MergeTextureBake_bake_counter = 0  # Reset bake counter
        
        # Initialize engine tracking
        self._original_render_engine = None
        
        return {'RUNNING_MODAL'}


class MERGETEXTUREBAKE_UL_selected_objects(UIList):
    bl_idname = "MERGETEXTUREBAKE_UL_selected_objects"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        obj = item.object_ref
        if obj:
            uv_icon = 'GROUP_UVS' if obj.data.uv_layers else 'BLANK1'
            layout.label(text=obj.name, icon='OBJECT_DATA')
            layout.label(icon=uv_icon)
            layout.label(icon='MATERIAL' if any(mat for mat in obj.data.materials if mat) else 'BLANK1')
        else:
            layout.label(text="N/A", icon='OBJECT_DATA')

        layout.alert = (index == context.scene.MergeTextureBake_selected_objects_index)

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list

        flt_flags = []
        flt_neworder = []

        search_filter = self.filter_name.lower()
        for idx, item in enumerate(items):
            if search_filter in item.object_ref.name.lower():
                flt_flags.append(self.bitflag_filter_item)
                flt_neworder.append(idx)
            else:
                flt_flags.append(0)

        return flt_flags, flt_neworder


def MergeTextureBake_update_selection(self, context):
    selected_index = context.scene.MergeTextureBake_selected_objects_index
    selected_item = context.scene.MergeTextureBake_selected_objects_list[selected_index]

    object_to_select = bpy.data.objects.get(selected_item.get_object_name())

    if object_to_select:
        bpy.ops.object.select_all(action='DESELECT')
        object_to_select.select_set(True)
        bpy.context.view_layer.objects.active = object_to_select


def MergeTextureBake_check_texture_name(self, context):
    self.MergeTextureBake_has_duplicate_texture_name = self.MergeTextureBake_texture_name in bpy.data.images


bpy.types.Scene.MergeTextureBake_custom_bake_type = EnumProperty(
    name="Bake Type",
    description="Select the bake type",
    items=[
        ('COMBINED', "Combined", ""),
        ('AO', "Ambient Occlusion", ""),
        ('SHADOW', "Shadow", ""),
        ('POSITION', "Position", ""),
        ('NORMAL', "Normal", ""),
        ('UV', "UV", ""),
        ('ROUGHNESS', "Roughness", ""),
        ('EMIT', "Emit", ""),
        ('ENVIRONMENT', "Environment", ""),
        ('DIFFUSE', "Diffuse", ""),
        ('GLOSSY', "Glossy", ""),
        ('TRANSMISSION', "Transmission", ""),
        ('METALLIC', "Metallic", "Custom Metallic Bake Type"),  # Custom bake type
    ]
)

# Collapsible panel properties
bpy.types.Scene.MergeTextureBake_show_object_management = BoolProperty(
    name="Show Object Management",
    description="Show/Hide Object Management section",
    default=True
)

bpy.types.Scene.MergeTextureBake_show_uv_operations = BoolProperty(
    name="Show UV Operations",
    description="Show/Hide UV Map Operations section",
    default=False
)

bpy.types.Scene.MergeTextureBake_show_texture_settings = BoolProperty(
    name="Show Texture Settings",
    description="Show/Hide Texture Settings section",
    default=False
)

bpy.types.Scene.MergeTextureBake_show_baking = BoolProperty(
    name="Show Baking",
    description="Show/Hide Baking section",
    default=False
)


def register():
    bpy.utils.register_class(MergeTextureBake_SelectedObjectItem)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_create_texture_for_materials)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_delete_texture_nodes)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_add_selected_object)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_remove_selected_object)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_create_uv_map)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_remove_uv_map)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_clear_selected_objects_list)
    bpy.utils.register_class(MERGETEXTUREBAKE_UL_selected_objects)
    bpy.utils.register_class(MERGETEXTUREBAKE_OT_bake_custom)
    


    bpy.types.Scene.MergeTextureBake_selected_objects_list = CollectionProperty(type=MergeTextureBake_SelectedObjectItem)
    bpy.types.Scene.MergeTextureBake_selected_objects_index = IntProperty(default=0, update=MergeTextureBake_update_selection)
    bpy.types.Scene.MergeTextureBake_uv_map_name = StringProperty(name="UV Map Name", default="MergeTextureBake_UVMap")
    bpy.types.Scene.MergeTextureBake_texture_width = IntProperty(name="Width", default=1024)
    bpy.types.Scene.MergeTextureBake_texture_height = IntProperty(name="Height", default=1024)
    bpy.types.Scene.MergeTextureBake_use_alpha = BoolProperty(name="Use Alpha", default=False)
    bpy.types.Scene.MergeTextureBake_texture_name = StringProperty(name="Texture Name", default="MergeTextureBake_BakeTexture", update=MergeTextureBake_check_texture_name)
    bpy.types.Scene.MergeTextureBake_has_duplicate_texture_name = BoolProperty(name="Has Duplicate Texture Name", default=False)
    bpy.types.Scene.MergeTextureBake_image_generated_type = EnumProperty(
        name="Generated Type",
        description="Select the generated image type",
        items=[
            ('BLANK', "Blank", ""),
            ('UV_GRID', "UV Grid", ""),
            ('COLOR_GRID', "Color Grid", "")
        ],
        default='BLANK'
    )
    bpy.types.Scene.MergeTextureBake_use_32bit_float = BoolProperty(name="32-bit Float", default=False)
    bpy.types.Scene.MergeTextureBake_use_tiled = BoolProperty(name="Tiled", default=False)
    bpy.types.Scene.MergeTextureBake_image_color = FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(0.0, 0.0, 0.0, 1.0)
    )
    bpy.types.Scene.MergeTextureBake_custom_bake_type = EnumProperty(
        name="Bake Type",
        description="Select the bake type",
        items=[
            ('COMBINED', "Combined", ""),
            ('AO', "Ambient Occlusion", ""),
            ('SHADOW', "Shadow", ""),
            ('POSITION', "Position", ""),
            ('NORMAL', "Normal", ""),
            ('UV', "UV", ""),
            ('ROUGHNESS', "Roughness", ""),
            ('EMIT', "Emit", ""),
            ('ENVIRONMENT', "Environment", ""),
            ('DIFFUSE', "Diffuse", ""),
            ('GLOSSY', "Glossy", ""),
            ('TRANSMISSION', "Transmission", ""),
            ('METALLIC', "Metallic", "Custom Metallic Bake Type"), 
        ]
    )
    bpy.types.Scene.MergeTextureBake_bake_counter = IntProperty(default=0)
    bpy.types.Scene.MergeTextureBake_bake_timer = None


def unregister():
    
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_bake_custom)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_UL_selected_objects)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_clear_selected_objects_list)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_remove_uv_map)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_create_uv_map)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_remove_selected_object)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_add_selected_object)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_delete_texture_nodes)
    bpy.utils.unregister_class(MERGETEXTUREBAKE_OT_create_texture_for_materials)
    bpy.utils.unregister_class(MergeTextureBake_SelectedObjectItem)

    del bpy.types.Scene.MergeTextureBake_selected_objects_list
    del bpy.types.Scene.MergeTextureBake_selected_objects_index
    del bpy.types.Scene.MergeTextureBake_uv_map_name
    del bpy.types.Scene.MergeTextureBake_texture_width
    del bpy.types.Scene.MergeTextureBake_texture_height
    del bpy.types.Scene.MergeTextureBake_use_alpha
    del bpy.types.Scene.MergeTextureBake_texture_name
    del bpy.types.Scene.MergeTextureBake_has_duplicate_texture_name
    del bpy.types.Scene.MergeTextureBake_image_generated_type
    del bpy.types.Scene.MergeTextureBake_use_32bit_float
    del bpy.types.Scene.MergeTextureBake_use_tiled
    del bpy.types.Scene.MergeTextureBake_image_color
    del bpy.types.Scene.MergeTextureBake_custom_bake_type
    del bpy.types.Scene.MergeTextureBake_bake_counter
    del bpy.types.Scene.MergeTextureBake_bake_timer
    register()