# Standard library imports
import os
import ast
from typing import List, Dict, Tuple, Optional, Set, Any
from mathutils import Matrix

# Blender imports
import bpy
from bpy.props import (
    StringProperty, BoolProperty, EnumProperty,
    PointerProperty
)
from bpy.types import Panel, Operator, PropertyGroup

# ==============================================
# CONSTANTS & CONFIGURATION
# ==============================================

class EquipmentConfig:
    """Centralized configuration for equipment slots and appearance items"""
    
    SLOTS = [
        ("Chest", "chest"),
        ("Back", "back"),
        ("Pelvis", "pelvis"),
        ("FrontHip", "f_hip"),
        ("BackHip", "b_hip"),
        ("Shoulder_R", "r_shoulder"),
        ("UpperArm_R", "r_upper_arm"),
        ("Elbow_R", "r_elbow"),
        ("LowerArm_R", "r_lower_arm"),
        ("Weapon_R", "r_weapon"),
        ("Shoulder_L", "l_shoulder"),
        ("UpperArm_L", "l_upper_arm"),
        ("Elbow_L", "l_elbow"),
        ("LowerArm_L", "l_lower_arm"),
        ("Shield", "shield"),
        ("Weapon_L", "l_weapon"),
        ("Hip_R", "r_hip"),
        ("Thigh_R", "r_thigh"),
        ("Knee_R", "r_knee"),
        ("Shin_R", "r_shin"),
        ("Ankle_R", "r_ankle"),
        ("Foot_R", "r_foot"),
        ("Hip_L", "l_hip"),
        ("Thigh_L", "l_thigh"),
        ("Knee_L", "l_knee"),
        ("Shin_L", "l_shin"),
        ("Ankle_L", "l_ankle"),
        ("Foot_L", "l_foot")
    ]
    
    APPEARANCE_SUFFIXES = {
        'body': '_Body',
        'gloves': '_Gloves',
        'boots': '_Boots',
        'belt': '_Belt',
        'head': '_Head',        
        'hair': '_Hair',        
        'fhair': '_fhair',
        'helm': '_Helm',      
        'eye': '_eye'         
    }
    
    ARMOR_TYPES = [
        ("ALL", "All", "Show all armor types"),
        ("NONE", "None", "Show no armor (hide all)"),
        ("CL", "Cloth", "Show cloth armor"),
        ("CP", "Cloth Padded", "Show cloth padded armor"),
        ("LE", "Leather", "Show leather armor"),
        ("LS", "Leather Studded", "Show leather studded armor"),
        ("CH", "Chain", "Show chain armor"),
        ("SC", "Scale", "Show scale armor"),
        ("BA", "Banded", "Show banded armor"),
        ("PH", "Half-Plate", "Show half-plate armor"),
        ("PF", "Full-Plate", "Show full-plate armor"),
        ("HD", "Hide", "Show hide armor"),
        ("NK", "Naked", "Show no armor (naked)")
    ]
    
    LOD_SUFFIXES = [f"_L{i:02d}" for i in range(1, 11)]
    
    # Add custom armor types storage
    CUSTOM_ARMOR_TYPES = []
    
    @classmethod
    def get_equipment_prefix(cls, slot_name: str) -> str:
        """Get the empty object prefix for a slot"""
        if slot_name in {'Weapon_R', 'Weapon_L', 'Shield'}:
            return f"Weapon_{slot_name}_"
        return f"Armor_{slot_name}_"

    @classmethod
    def get_all_armor_types(cls):
        """Get all armor types including custom ones"""
        all_types = list(cls.ARMOR_TYPES)  # Start with base types
        for custom_type in cls.CUSTOM_ARMOR_TYPES:
            all_types.append((custom_type['id'], custom_type['name'], custom_type['description']))
        return all_types
    
    @classmethod
    def add_custom_armor_type(cls, type_id, name, description):
        """Add a new custom armor type"""
        # Validate ID format (uppercase, 2-3 characters)
        if not (2 <= len(type_id) <= 3 and type_id.isalpha() and type_id.isupper()):
            raise ValueError("Type ID must be 2-3 uppercase letters")
        
        # Check for duplicates
        for existing in cls.CUSTOM_ARMOR_TYPES:
            if existing['id'] == type_id:
                raise ValueError(f"Armor type '{type_id}' already exists")
        
        # Check against base types
        for base_type in cls.ARMOR_TYPES:
            if base_type[0] == type_id:
                raise ValueError(f"Armor type '{type_id}' conflicts with base type")
        
        # Add to custom types
        cls.CUSTOM_ARMOR_TYPES.append({
            'id': type_id,
            'name': name,
            'description': description
        })
        
        # Save to persistent storage
        cls._save_custom_types()
    
    @classmethod
    def remove_custom_armor_type(cls, type_id):
        """Remove a custom armor type"""
        cls.CUSTOM_ARMOR_TYPES = [t for t in cls.CUSTOM_ARMOR_TYPES if t['id'] != type_id]
        cls._save_custom_types()
    
    @classmethod
    def _save_custom_types(cls):
        """Save custom types to Blender text block for persistence"""
        text_name = "nwn2_custom_armor_types"
        
        # Create or update text block
        if text_name not in bpy.data.texts:
            text = bpy.data.texts.new(text_name)
        else:
            text = bpy.data.texts[text_name]
        
        # Clear existing content
        text.clear()
        
        # Write custom types as Python code
        text.write("CUSTOM_ARMOR_TYPES = [\n")
        for armor_type in cls.CUSTOM_ARMOR_TYPES:
            text.write(f"    {{'id': '{armor_type['id']}', 'name': '{armor_type['name']}', 'description': '{armor_type['description']}'}},\n")
        text.write("]\n")
    
    @classmethod
    def load_custom_types(cls):
        """Load custom types from Blender text block"""
        text_name = "nwn2_custom_armor_types"
        
        if text_name in bpy.data.texts:
            text = bpy.data.texts[text_name]
            
            # Clear existing custom types
            cls.CUSTOM_ARMOR_TYPES.clear()
            
            # Parse the text content
            in_list = False
            for line in text.as_string().split('\n'):
                line = line.strip()
                if line == "CUSTOM_ARMOR_TYPES = [":
                    in_list = True
                    continue
                elif line == "]":
                    break
                elif in_list and line.startswith("{") and line.endswith("},"):
                    try:
                        # Extract the dictionary data
                        armor_dict = ast.literal_eval(line.rstrip(','))
                        if isinstance(armor_dict, dict) and 'id' in armor_dict:
                            cls.CUSTOM_ARMOR_TYPES.append(armor_dict)
                    except:
                        continue

# ==============================================
# UTILITY FUNCTIONS
# ==============================================

def get_armature(context) -> Optional[bpy.types.Object]:
    """Get the active armature with validation"""
    obj = context.active_object
    return obj if obj and obj.type == 'ARMATURE' else None

def get_character_prefix(armature: bpy.types.Object) -> Optional[Tuple[str, str]]:
    """Extract character prefix and race from armature name"""
    if not armature:
        return None
    
    parts = armature.name.split('_')
    if len(parts) != 3:
        return None
    
    prefix = parts[0].upper()  # P, C, etc.
    race = parts[1]           # HHM, DDM, Cat, etc.
    
    return (prefix, race)

def get_character_name(armature: bpy.types.Object) -> Optional[str]:
    """Extract character name from armature name"""
    if not armature:
        return None
    parts = armature.name.split('_')
    if len(parts) == 3 and parts[0].lower() in ('c', 'p') and parts[2].lower() == 'skel':
        return parts[1]
    return None

def ensure_visibility(obj: bpy.types.Object) -> None:
    """Ensure object is visible by unhiding it directly"""
    if obj:
        obj.hide_viewport = False
        obj.hide_render = False

# ==============================================
# EQUIPMENT MANAGEMENT
# ==============================================

class EquipmentManager:
    """Centralized equipment management functionality"""

    @staticmethod
    def parse_weapon_name(mesh_name: str) -> str:
        """Extract base weapon name from mesh name (w_BAxe01_a -> BAxe01)"""
        if mesh_name.startswith('w_') and '_' in mesh_name:
            parts = mesh_name[2:].split('_')  # Remove 'w_' prefix
            return parts[0]  # Return base name (BAxe01)
        return mesh_name

    @staticmethod
    def get_weapon_variants(mesh_name: str, parent_empty: bpy.types.Object) -> List[str]:
        """Get all variants of a weapon from its parent empty"""
        base_name = EquipmentManager.parse_weapon_name(mesh_name)
        variants = []
        if parent_empty:
            for child in parent_empty.children:
                if child.type == 'MESH' and child.name.startswith(f'w_{base_name}_'):
                    variants.append(child.name)
        return variants if variants else [mesh_name]
    
    @staticmethod
    def create_collections(character_name: str) -> str:
        """Create the collection structure for a character"""
        main_coll_name = f"{character_name}_Equipment"
        
        main_coll = bpy.data.collections.get(main_coll_name)
        if not main_coll:
            main_coll = bpy.data.collections.new(main_coll_name)
            bpy.context.scene.collection.children.link(main_coll)
        
        for slot_name, _ in EquipmentConfig.SLOTS:
            coll_name = f"{character_name}_{slot_name}"
            if not bpy.data.collections.get(coll_name):
                sub_coll = bpy.data.collections.new(coll_name)
                main_coll.children.link(sub_coll)
        
        return main_coll_name

    @staticmethod
    def clear_collections(character_name: str) -> bool:
        """Remove existing collections for a character"""
        main_coll_name = f"{character_name}_Equipment"
        main_coll = bpy.data.collections.get(main_coll_name)
        
        if not main_coll:
            return False
        
        for sub_coll in list(main_coll.children):
            for obj in list(sub_coll.objects):
                sub_coll.objects.unlink(obj)
            bpy.data.collections.remove(sub_coll)
        
        bpy.data.collections.remove(main_coll)
        return True

    @staticmethod
    def get_equipment_items(armature: bpy.types.Object, slot_name: str, filter_num: str = None) -> Tuple[List[Tuple[str, str, str]], bool]:
        items = [("None", "None", "No equipment in this slot")]
        has_items = False
        
        character_name = get_character_name(armature)
        if not character_name:
            return items, False
        
        main_coll = bpy.data.collections.get(f"{character_name}_Equipment")
        if not main_coll:
            return items, False
        
        sub_coll = main_coll.children.get(f"{character_name}_{slot_name}")
        if not sub_coll:
            return items, False
        
        # Weapon handling - different from armor
        if slot_name in {'Weapon_R', 'Weapon_L'}:
            # Find all weapon empties in this slot's collection
            weapon_empties = [obj for obj in sub_coll.objects 
                             if obj.type == 'EMPTY' and obj.name.startswith('Weapon_')]
            
            # Track unique weapon base names
            weapon_groups = {}
            
            for empty in weapon_empties:
                for mesh in empty.children:
                    if mesh.type == 'MESH' and mesh.name.startswith('w_'):
                        # Extract base weapon name (w_BAxe01_a -> BAxe01)
                        base_name = mesh.name[2:].split('_')[0]
                        
                        # Group variants by base name
                        if base_name not in weapon_groups:
                            weapon_groups[base_name] = []
                        weapon_groups[base_name].append(mesh.name)
            
            # Add one entry per weapon type
            for base_name, variants in weapon_groups.items():
                # Use the first variant as representative
                items.append((variants[0], base_name, f"Equip {base_name}"))
                has_items = True
            
            return items, has_items
        
        # Original handling for shields and armor
        empty_prefix = EquipmentConfig.get_equipment_prefix(slot_name)
        equipment_data = []
        
        for obj in sub_coll.objects:
            if obj.type == 'EMPTY' and obj.name.startswith(empty_prefix):
                for mesh in obj.children:
                    if mesh.type == 'MESH':
                        if any(mesh.name.endswith(suffix) for suffix in EquipmentConfig.LOD_SUFFIXES):
                            continue
                        
                        # Original armor/shield handling
                        base_name = mesh.name.split('.')[0]
                        mesh_num = ''.join(filter(str.isdigit, base_name.split('_')[-1]))
                        if filter_num and filter_num != "NONE" and mesh_num != filter_num:
                            continue
                        
                        display_parts = mesh.name.split('_')
                        if len(display_parts) >= 4:
                            slot_part = display_parts[1].replace('_', ' ')
                            num_part = ''.join(filter(str.isdigit, display_parts[-1]))
                            display_name = f"{slot_part} {num_part}" if num_part else slot_part
                        else:
                            display_name = display_parts[-1]
                            num_part = ''.join(filter(str.isdigit, display_name))
                            if num_part:
                                base_name = display_name.replace(num_part, '').rstrip('_')
                                display_name = f"{base_name} {num_part}"
                        
                        try:
                            sort_key = int(num_part) if num_part else 0
                        except:
                            sort_key = 0
                        
                        equipment_data.append((sort_key, mesh.name, display_name))
                        has_items = True
        
        equipment_data.sort(key=lambda x: x[0])
        
        items.extend([
            (full_name, display_name, f"Equip {display_name}") 
            for _, full_name, display_name in equipment_data
        ])
        
        return items, has_items
    
    @staticmethod
    def update_equipment_visibility(armature: bpy.types.Object, properties: Any) -> None:
        if not armature:
            return
        
        character_name = get_character_name(armature)
        if not character_name:
            return
        
        main_coll = bpy.data.collections.get(f"{character_name}_Equipment")
        if not main_coll:
            return
        
        # First hide everything
        for sub_coll in main_coll.children:
            for obj in sub_coll.objects:
                if obj.type == 'EMPTY' and (obj.name.startswith("Armor_") or obj.name.startswith("Weapon_")):
                    for mesh in obj.children:
                        if mesh.type == 'MESH' and not any(mesh.name.endswith(suffix) for suffix in EquipmentConfig.LOD_SUFFIXES):
                            mesh.hide_set(True)
        
        # Show selected items
        for slot_name, prop_name in EquipmentConfig.SLOTS:
            selected_mesh_name = getattr(properties, prop_name)
            if selected_mesh_name != "None":
                selected_mesh = bpy.data.objects.get(selected_mesh_name)
                if selected_mesh:
                    # Special handling for weapons
                    if slot_name in {'Weapon_R', 'Weapon_L'} and selected_mesh.name.startswith('w_'):
                        # Show all variants of this weapon
                        base_name = selected_mesh.name[2:].split('_')[0]
                        parent = selected_mesh.parent
                        if parent:
                            for child in parent.children:
                                if child.type == 'MESH' and child.name.startswith(f'w_{base_name}_'):
                                    child.hide_set(False)
                        selected_mesh.hide_set(False)
                    else:
                        # Normal handling for shields/armor
                        selected_mesh.hide_set(False)
        
        # Refresh UI
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'OUTLINER', 'VIEW_3D'}:
                    area.tag_redraw()

# ==============================================
# APPEARANCE MANAGEMENT
# ==============================================

class AppearanceManager:
    """Enhanced appearance management with dynamic number support"""

    @staticmethod
    def get_available_numbers(context):
        """Dynamically find all unique numbers from armor attachment meshes"""
        numbers = set()
        armature = get_armature(context)
        
        if not armature:
            return [("NONE", "No armature", "")]
        
        character_name = get_character_name(armature)
        if not character_name:
            return [("NONE", "Invalid character name", "")]
        
        main_coll = bpy.data.collections.get(f"{character_name}_Equipment")
        if not main_coll:
            return [("NONE", "No equipment collections", "")]
        
        for slot_name, _ in EquipmentConfig.SLOTS:
            if slot_name in {'Weapon_R', 'Weapon_L', 'Shield'}:
                continue
                
            sub_coll = main_coll.children.get(f"{character_name}_{slot_name}")
            if not sub_coll:
                continue
                
            empty_prefix = EquipmentConfig.get_equipment_prefix(slot_name)
            
            for obj in sub_coll.objects:
                if obj.type == 'EMPTY' and obj.name.startswith(empty_prefix):
                    for mesh in obj.children:
                        if mesh.type == 'MESH':
                            # Skip any mesh that has _L## in its name (LOD meshes)
                            if "_L" in mesh.name:
                                # Get the suffix after last underscore
                                last_part = mesh.name.split('_')[-1]
                                # Check if it matches L## pattern
                                if len(last_part) == 3 and last_part[0] == 'L' and last_part[1:].isdigit():
                                    continue
                            
                            # Extract number from the main mesh name (not LOD)
                            base_name = mesh.name.split('.')[0]  # Remove .001 suffix
                            # Get the last part before any LOD suffix
                            relevant_part = base_name.split('_L')[0]
                            num_part = ''.join(filter(str.isdigit, relevant_part.split('_')[-1]))
                            if num_part:
                                numbers.add(num_part)
        
        if not numbers:
            return [("NONE", "No numbered attachments", "")]
        
        # Sort numerically (convert to int for sorting)
        sorted_numbers = sorted(numbers, key=lambda x: int(x))
        items = [("NONE", "None", "Display all attachments")]
        items.extend((num, num, f"Show attachments ending with {num}") for num in sorted_numbers)
        
        return items

    @staticmethod
    def update_attachment_filter(self, context):
        """Apply number filter to all armor attachment meshes"""
        selected_num = self.attachment_number
        armature = get_armature(context)
        
        if not armature:
            return
        
        # First reset all properties to None
        for slot_name, prop_name in EquipmentConfig.SLOTS:
            if slot_name in {'Weapon_R', 'Weapon_L', 'Shield'}:
                continue
                
            setattr(self, prop_name, "None")
        
        if selected_num != "NONE":
            character_name = get_character_name(armature)
            if not character_name:
                return
                
            main_coll = bpy.data.collections.get(f"{character_name}_Equipment")
            if not main_coll:
                return
                
            for slot_name, prop_name in EquipmentConfig.SLOTS:
                if slot_name in {'Weapon_R', 'Weapon_L', 'Shield'}:
                    continue
                    
                sub_coll = main_coll.children.get(f"{character_name}_{slot_name}")
                if not sub_coll:
                    continue
                    
                empty_prefix = EquipmentConfig.get_equipment_prefix(slot_name)
                items = []
                
                for obj in sub_coll.objects:
                    if obj.type == 'EMPTY' and obj.name.startswith(empty_prefix):
                        for mesh in obj.children:
                            if mesh.type == 'MESH':
                                # Compare numbers directly (no zero-padding)
                                base_name = mesh.name.split('.')[0]  # Remove .001 suffix
                                mesh_num = ''.join(filter(str.isdigit, base_name.split('_')[-1]))
                                if mesh_num == selected_num:
                                    items.append((mesh.name, mesh.name.split('_')[-1], ""))
                
                if len(items) == 1:
                    setattr(self, prop_name, items[0][0])
        
        EquipmentManager.update_equipment_visibility(armature, self)
        
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
                
    @staticmethod
    def get_appearance_items(armature: bpy.types.Object, 
                           appearance_type: str, 
                           filter_type: str = "ALL") -> Tuple[List[Tuple[str, str, str]], bool]:
        """Get available appearance items with improved number handling"""
        items = [("None", "None", "No appearance item")]
        has_items = False
        
        if not armature:
            return items, False
        
        prefix_race = get_character_prefix(armature)
        if not prefix_race:
            return items, False
            
        prefix, race = prefix_race
        app_type_lower = appearance_type.lower()
        char_name = get_character_name(armature) or ""
        
        # Special handling for non-armored items
        if app_type_lower in ['head', 'eye', 'hair', 'fhair']:
            for obj in armature.children:
                if obj.type != 'MESH':
                    continue
                    
                obj_name = obj.name
                
                # Skip LOD models
                if any(obj_name.endswith(suffix) for suffix in EquipmentConfig.LOD_SUFFIXES):
                    continue
                
                # Handle eyes (supports P_HHM_Eye01 and p_hhm_eye01)
                if app_type_lower == 'eye' and 'eye' in obj_name.lower():
                    if (obj_name.lower().startswith((f'p_{race.lower()}_eye', f'{char_name.lower()}_eye')) or
                        obj_name.startswith((f'{prefix}_{race}_Eye', f'{char_name}_Eye'))):
                        num = ''.join(filter(str.isdigit, obj_name.split('_')[-1]))
                        display_name = f"Eyes {num}" if num else "Eyes"
                        items.append((obj.name, display_name, f"Use {display_name}"))
                        has_items = True
                    
                # Handle head (P_HHM_Head01)
                elif app_type_lower == 'head' and 'head' in obj_name.lower():
                    if (obj_name.startswith((f'{prefix}_{race}_Head', f'{char_name}_Head')) 
                        and '_fhair' not in obj_name):
                        num = ''.join(filter(str.isdigit, obj_name.split('_')[-1]))
                        display_name = f"Head {num}" if num else "Head"
                        items.append((obj.name, display_name, f"Use {display_name}"))
                        has_items = True
                    
                # Handle facial hair (P_HHM_Head01_fhair)
                elif app_type_lower == 'fhair' and '_fhair' in obj_name.lower():
                    base_name = obj_name.split('_fhair')[0]
                    num = ''.join(filter(str.isdigit, base_name.split('_')[-1]))
                    display_name = f"Facial Hair {num}" if num else "Facial Hair"
                    items.append((obj.name, display_name, f"Use {display_name}"))
                    has_items = True
                    
                # Handle hair (P_HHM_hair01)
                elif app_type_lower == 'hair' and 'hair' in obj_name.lower():
                    if obj_name.startswith((f'{prefix}_{race}_hair', f'{char_name}_hair')):
                        num = ''.join(filter(str.isdigit, obj_name.split('_')[-1]))
                        display_name = f"Hair {num}" if num else "Hair"
                        items.append((obj.name, display_name, f"Use {display_name}"))
                        has_items = True
                    
            return items, has_items

        # Armored items filtering - USE ALL ARMOR TYPES NOW
        target_suffix = EquipmentConfig.APPEARANCE_SUFFIXES.get(app_type_lower, "")
        
        for obj in armature.children:
            if obj.type != 'MESH':
                continue
                
            obj_name = obj.name
            
            if any(obj_name.endswith(suffix) for suffix in EquipmentConfig.LOD_SUFFIXES):
                continue
            
            parts = obj_name.split('_')
            if len(parts) >= 4 and (parts[0] == prefix or parts[0] == char_name) and parts[1] == race:
                armor_type = parts[2]
                item_type = parts[3]
                
                if not item_type.lower().startswith(app_type_lower):
                    continue
                    
                # Check against all armor types (base + custom)
                if filter_type != "ALL" and armor_type != filter_type:
                    continue
                
                num = ''.join(filter(str.isdigit, item_type))
                display_name = f"{armor_type} {appearance_type.title()}"
                if num:
                    display_name += f" {num}"
                
                items.append((obj.name, display_name, f"Use {display_name}"))
                has_items = True
        
        return items, has_items

    @staticmethod
    def get_visible_appearance(armature: bpy.types.Object, appearance_type: str) -> str:
        """Get visible appearance item with improved detection"""
        if not armature:
            return "None"
        
        prefix_race = get_character_prefix(armature)
        if not prefix_race:
            return "None"
            
        prefix, race = prefix_race
        app_type_lower = appearance_type.lower()
        char_name = get_character_name(armature) or ""
        
        for obj in armature.children:
            if obj.type == 'MESH' and not obj.hide_viewport:
                # Special handling for head
                if app_type_lower == 'head' and 'head' in obj.name.lower():
                    if (obj.name.startswith((f'{prefix}_{race}_Head', f'{char_name}_Head')) and 
                       '_fhair' not in obj.name):
                        return obj.name
                
                # Handle other types
                suffix = EquipmentConfig.APPEARANCE_SUFFIXES.get(app_type_lower, "")
                if suffix and suffix.lower() in obj.name.lower():
                    return obj.name
        
        return "None"
    
    @staticmethod
    def update_appearance_visibility(armature: bpy.types.Object, properties: Any) -> None:
        """Update visibility with support for dynamic numbers"""
        if not armature:
            return
        
        # First hide all appearance meshes
        for obj in armature.children:
            if obj.type == 'MESH':
                for suffix in EquipmentConfig.APPEARANCE_SUFFIXES.values():
                    if suffix.lower() in obj.name.lower():
                        obj.hide_set(True)
        
        # Show selected items
        for app_type in EquipmentConfig.APPEARANCE_SUFFIXES.keys():
            prop_name = f"app_{app_type}"
            filter_prop = f"{app_type}_armor_type"
            
            if hasattr(properties, prop_name):
                # Skip if filtered to NONE
                if hasattr(properties, filter_prop) and getattr(properties, filter_prop) == "NONE":
                    continue
                    
                selected_name = getattr(properties, prop_name)
                if selected_name != "None":
                    selected_obj = bpy.data.objects.get(selected_name)
                    if selected_obj:
                        selected_obj.hide_set(False)
        
        # Refresh UI
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'OUTLINER', 'VIEW_3D'}:
                    area.tag_redraw()

# ==============================================
# CUSTOM ARMOR TYPE OPERATORS
# ==============================================

class EQUIPMENT_OT_AddCustomArmorType(bpy.types.Operator):
    """Add a new custom armor type"""
    bl_idname = "equipment.add_custom_armor_type"
    bl_label = "Add Custom Armor Type"
    bl_description = "Add a new custom armor type"
    bl_options = {'REGISTER', 'UNDO'}


    type_id: StringProperty(
        name="Type ID",
        description="2-3 uppercase letters (e.g., 'DR', 'SK')",
        default="",
        maxlen=3
    )
    
    type_name: StringProperty(
        name="Display Name",
        description="Name shown in the UI",
        default=""
    )
    
    type_description: StringProperty(
        name="Description",
        description="Description shown in tooltips",
        default=""
    )
    
    def execute(self, context):
        try:
            EquipmentConfig.add_custom_armor_type(
                self.type_id.upper(),
                self.type_name,
                self.type_description
            )
            self.report({'INFO'}, f"Added custom armor type: {self.type_name}")
            return {'FINISHED'}
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        
        layout.prop(self, "type_id")
        layout.prop(self, "type_name")
        layout.prop(self, "type_description")
        
        # Show validation info
        if self.type_id:
            box = layout.box()
            if len(self.type_id) < 2 or len(self.type_id) > 3:
                box.label(text="ID must be 2-3 characters", icon='ERROR')
            if not self.type_id.isalpha():
                box.label(text="ID must contain only letters", icon='ERROR')
            if not self.type_id.isupper():
                box.label(text="ID will be converted to uppercase", icon='INFO')

class EQUIPMENT_OT_RemoveCustomArmorType(bpy.types.Operator):
    """Remove a custom armor type"""
    bl_idname = "equipment.remove_custom_armor_type"
    bl_label = "Remove Custom Armor Type"
    bl_description = "Remove a custom armor type"
    bl_options = {'REGISTER', 'UNDO'}
    
    type_id: StringProperty(
        name="Type ID",
        description="ID of the armor type to remove",
        default=""
    )
    
    def execute(self, context):
        EquipmentConfig.remove_custom_armor_type(self.type_id)
        self.report({'INFO'}, f"Removed custom armor type: {self.type_id}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text=f"Remove armor type: {self.type_id}?")
        layout.label(text="This cannot be undone!")

class EQUIPMENT_OT_ManageCustomArmorTypes(bpy.types.Operator):
    """Manage custom armor types"""
    bl_idname = "equipment.manage_custom_armor_types"
    bl_label = "Manage Custom Armor Types"
    bl_description = "Manage custom armor types"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        
        # Header
        header_box = layout.box()
        header_row = header_box.row()
        header_row.label(text="Custom Armor Types", icon='MOD_CLOTH')
        header_row.operator("equipment.add_custom_armor_type", text="Add New", icon='ADD')
        
        # Current custom types
        if EquipmentConfig.CUSTOM_ARMOR_TYPES:
            types_box = layout.box()
            types_box.label(text="Current Custom Types:", icon='CHECKMARK')
            
            for armor_type in EquipmentConfig.CUSTOM_ARMOR_TYPES:
                row = types_box.row()
                row.label(text=f"{armor_type['id']}: {armor_type['name']}")
                
                op = row.operator("equipment.remove_custom_armor_type", text="", icon='X')
                op.type_id = armor_type['id']
                
                # Show description on hover
                row = types_box.row()
                row.label(text=f"   {armor_type['description']}")
        else:
            no_types_box = layout.box()
            no_types_box.label(text="No custom armor types", icon='INFO')
            no_types_box.label(text="Click 'Add New' to create custom armor types")

# ==============================================
# CHARACTER SHEET OPERATOR
# ==============================================

class EQUIPMENT_OT_CharacterSheet(bpy.types.Operator):
    """Main equipment management interface"""
    bl_idname = "wm.character_sheet"
    bl_label = "Equipment Slots"
    bl_description = "Manage equipment slots for the character"
    bl_options = {'UNDO', 'INTERNAL'}

    ui_tab: bpy.props.EnumProperty(
        name="Tab",
        description="Select which tab to display",
        items=[
            ('APPEARANCE', "Appearance", "Character appearance settings"),
            ('ARMOR', "Armor", "Armor equipment settings"),
            ('WEAPONS', "Weapons", "Weapon equipment settings"),
            ('ATTACHMENTS', "Attachments", "Armor attachment settings"),
            ('CORE', "Core Armor", "Core armor settings"),
        ],
        default='APPEARANCE'
    )

    attachment_number: EnumProperty(
        name="Attachment Number",
        description="Filter attachments by their number suffix",
        items=lambda s, c: AppearanceManager.get_available_numbers(c),
        update=AppearanceManager.update_attachment_filter
    )

    @staticmethod
    def ensure_armature_properties(armature):
        """Ensure all required properties exist on armature"""
        for _, prop_name in EquipmentConfig.SLOTS:
            if prop_name not in armature:
                armature[prop_name] = "None"
        
        for app_type in EquipmentConfig.APPEARANCE_SUFFIXES.keys():
            prop_name = f"app_{app_type}"
            if prop_name not in armature:
                armature[prop_name] = "None"
            
            filter_prop = f"{app_type}_armor_type"
            if filter_prop not in armature:
                armature[filter_prop] = "ALL"

    # Dynamic property generation for equipment slots
    for slot_name, prop_name in EquipmentConfig.SLOTS:
        exec(f"""
def get_{prop_name}(self):
    armature = get_armature(bpy.context)
    return armature.get('{prop_name}', 'None') if armature else 'None'

def set_{prop_name}(self, value):
    armature = get_armature(bpy.context)
    if armature:
        armature['{prop_name}'] = value
        EquipmentManager.update_equipment_visibility(armature, self)
    self['{prop_name}'] = value

{prop_name}: EnumProperty(
    name="{slot_name.replace('_', ' ')}",
    items=lambda s, c: EquipmentManager.get_equipment_items(c.active_object, "{slot_name}")[0],
    get=get_{prop_name},
    set=set_{prop_name}
)
""")

    # Dynamic property generation for appearance items
    for app_type in EquipmentConfig.APPEARANCE_SUFFIXES.keys():
        exec(f"""
def get_app_{app_type}(self):
    armature = get_armature(bpy.context)
    return armature.get('app_{app_type}', 'None') if armature else 'None'

def set_app_{app_type}(self, value):
    armature = get_armature(bpy.context)
    if armature:
        armature['app_{app_type}'] = value
        AppearanceManager.update_appearance_visibility(armature, self)
    self['app_{app_type}'] = value

app_{app_type}: EnumProperty(
    name="{app_type.title()}",
    items=lambda s, c: AppearanceManager.get_appearance_items(
        c.active_object, 
        "{app_type}", 
        s.{app_type}_armor_type
    )[0],
    get=get_app_{app_type},
    set=set_app_{app_type}
)

def get_{app_type}_armor_type(self):
    armature = get_armature(bpy.context)
    return armature.get('{app_type}_armor_type', 'ALL') if armature else 'ALL'

def set_{app_type}_armor_type(self, value):
    armature = get_armature(bpy.context)
    if armature:
        armature['{app_type}_armor_type'] = value
        armature['app_{app_type}'] = 'None'
        AppearanceManager.update_appearance_visibility(armature, self)
    self['{app_type}_armor_type'] = value

{app_type}_armor_type: EnumProperty(
    name="{app_type.title()} Armor Type",
    items=EquipmentConfig.ARMOR_TYPES,
    default="ALL",
    get=get_{app_type}_armor_type,
    set=set_{app_type}_armor_type
)
""")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        armature = get_armature(context)
        if not armature:
            self.report({'ERROR'}, "Please select an armature first")
            return {'CANCELLED'}

        self.ensure_armature_properties(armature)
        EquipmentManager.update_equipment_visibility(armature, self)
        AppearanceManager.update_appearance_visibility(armature, self)

        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        armature = get_armature(context)
        character_name = get_character_name(armature) if armature else None
        prefix_race = get_character_prefix(armature) if armature else None

        # Header Section (outside tabs)
        header_box = layout.box()
        header_row = header_box.row()
        if character_name and prefix_race:
            prefix, race = prefix_race
            header_row.label(text=f"Character: {character_name} ({prefix}_{race})", icon='ARMATURE_DATA')
        elif character_name:
            header_row.label(text=f"Character: {character_name}", icon='ARMATURE_DATA')
        else:
            header_row.label(text="No Valid Armature Selected", icon='ERROR')

        # Create main tab system
        tabs = layout.row()
        tabs.prop(self, "ui_tab", expand=True)

        # Tab content
        if self.ui_tab == 'APPEARANCE':
            # Appearance Section
            appearance_box = layout.box()
            appearance_box.label(text="Appearance", icon='USER')
            
            # Facial Features
            face_box = appearance_box.box()
            face_box.label(text="Facial Features:")
            face_split = face_box.split(factor=0.33, align=True)
            
            left_face = face_split.column(align=True)
            left_face.prop(self, "app_head", text="Head")
            left_face.prop(self, "app_eye", text="Eyes")
            
            right_face = face_split.column(align=True)
            right_face.prop(self, "app_hair", text="Hair")
            right_face.prop(self, "app_fhair", text="Facial Hair")

        elif self.ui_tab == 'ARMOR':
            # Armor Section
            armor_box = layout.box()
            armor_box.label(text="Armor", icon='MOD_CLOTH')
            
            # Helm
            helm_box = armor_box.box()
            helm_row = helm_box.row(align=True)
            helm_row.prop(self, "helm_armor_type", text="Type")
            helm_row.prop(self, "app_helm", text="Helm")
            
            # Body
            body_box = armor_box.box()
            body_row = body_box.row(align=True)
            body_row.prop(self, "body_armor_type", text="Type")
            body_row.prop(self, "app_body", text="Body")
            
            # Gloves
            gloves_box = armor_box.box()
            gloves_row = gloves_box.row(align=True)
            gloves_row.prop(self, "gloves_armor_type", text="Type")
            gloves_row.prop(self, "app_gloves", text="Gloves")
            
            # Boots
            boots_box = armor_box.box()
            boots_row = boots_box.row(align=True)
            boots_row.prop(self, "boots_armor_type", text="Type")
            boots_row.prop(self, "app_boots", text="Boots")
            
            # Belt
            belt_box = armor_box.box()
            belt_row = belt_box.row(align=True)
            belt_row.prop(self, "belt_armor_type", text="Type")
            belt_row.prop(self, "app_belt", text="Belt")

        elif self.ui_tab == 'WEAPONS':
            # Weapons Section
            weapons_box = layout.box()
            weapons_box.label(text="Weapons", icon='TOOL_SETTINGS')
            
            weapons_split = weapons_box.split(factor=0.5, align=True)
            
            left_weapons = weapons_split.column(align=True)
            left_weapons.prop(self, "r_weapon", text="Right Weapon")
            left_weapons.prop(self, "shield", text="Shield")
            
            right_weapons = weapons_split.column(align=True)
            right_weapons.prop(self, "l_weapon", text="Left Weapon")

        elif self.ui_tab == 'ATTACHMENTS':
            # Armor Attachments Section
            limbs_box = layout.box()
            limbs_box.label(text="Armor Attachments", icon='MOD_ARMATURE')
            
            # Dynamic Number Filter Dropdown
            filter_box = limbs_box.box()
            filter_row = filter_box.row()
            filter_row.label(text="Filter by Attachment Number:")
            filter_row.prop(self, "attachment_number", text="")
            
            limbs_split = limbs_box.split(factor=0.5, align=True)
            
            # Right Side
            right_col = limbs_split.column(align=True)
            right_col.label(text="Right Side", icon='ARROW_LEFTRIGHT')
            
            right_arm = right_col.box()
            right_arm.label(text="Arm")
            right_arm.prop(self, "r_shoulder", text="Shoulder")
            right_arm.prop(self, "r_upper_arm", text="Upper Arm")
            right_arm.prop(self, "r_elbow", text="Elbow")
            right_arm.prop(self, "r_lower_arm", text="Lower Arm")
            
            right_leg = right_col.box()
            right_leg.label(text="Leg")
            right_leg.prop(self, "r_thigh", text="Thigh")
            right_leg.prop(self, "r_knee", text="Knee")
            right_leg.prop(self, "r_shin", text="Shin")
            right_leg.prop(self, "r_foot", text="Foot")

            # Left Side
            left_col = limbs_split.column(align=True)
            left_col.label(text="Left Side", icon='ARROW_LEFTRIGHT')
            
            left_arm = left_col.box()
            left_arm.label(text="Arm")
            left_arm.prop(self, "l_shoulder", text="Shoulder")
            left_arm.prop(self, "l_upper_arm", text="Upper Arm")
            left_arm.prop(self, "l_elbow", text="Elbow")
            left_arm.prop(self, "l_lower_arm", text="Lower Arm")
            
            left_leg = left_col.box()
            left_leg.label(text="Leg")
            left_leg.prop(self, "l_thigh", text="Thigh")
            left_leg.prop(self, "l_knee", text="Knee")
            left_leg.prop(self, "l_shin", text="Shin")
            left_leg.prop(self, "l_foot", text="Foot")

        elif self.ui_tab == 'CORE':
            # Core Armor Section
            core_box = layout.box()
            core_box.label(text="Core Armor", icon='MODIFIER')
            
            core_split = core_box.split(factor=0.5, align=True)
            
            upper_core = core_split.column(align=True)
            upper_core_box = upper_core.box()
            upper_core_box.prop(self, "chest", text="Chest")
            upper_core_box.prop(self, "back", text="Back")
            upper_core_box.prop(self, "pelvis", text="Pelvis")
            
            lower_core = core_split.column(align=True)
            lower_core_box = lower_core.box()
            lower_core_box.prop(self, "f_hip", text="Front Hip")
            lower_core_box.prop(self, "b_hip", text="Back Hip")

# ==============================================
# SETUP COLLECTIONS OPERATOR
# ==============================================

class EQUIPMENT_OT_SetupCollections(bpy.types.Operator):
    """Create collection structure for character equipment"""
    bl_idname = "wm.setup_equipment_collections"
    bl_label = "Setup Equipment Collections"
    bl_description = "Create collection structure for character equipment"
    bl_options = {'REGISTER', 'UNDO'}
    
    overwrite: BoolProperty(
        name="Overwrite Existing",
        description="Overwrite existing collections",
        default=False
    )
    
    def execute(self, context):
        armature = get_armature(context)
        if not armature:
            self.report({'ERROR'}, "Please select an armature first")
            return {'CANCELLED'}
        
        character_name = get_character_name(armature)
        if not character_name:
            self.report({'ERROR'}, "Armature must follow naming convention: c/p_name_skel")
            return {'CANCELLED'}
        
        if self.overwrite:
            EquipmentManager.clear_collections(character_name)
        
        created_name = EquipmentManager.create_collections(character_name)
        self.report({'INFO'}, f"Created equipment collections: {created_name}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        armature = get_armature(context)
        if not armature:
            self.report({'ERROR'}, "Please select an armature first")
            return {'CANCELLED'}
        
        character_name = get_character_name(armature)
        if not character_name:
            self.report({'ERROR'}, "Invalid armature naming convention")
            return {'CANCELLED'}
        
        if bpy.data.collections.get(f"{character_name}_Equipment"):
            return context.window_manager.invoke_props_dialog(self, width=400)
        
        return self.execute(context)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Collections already exist!", icon='ERROR')
        layout.label(text="Overwrite existing collections?")
        layout.prop(self, "overwrite")

# ==============================================
# EMPTY PARENTING OPERATORS
# ==============================================

class KISM_OT_AutoParentToBones(Operator):
    bl_idname = "kism.auto_parent_to_bones"
    bl_label = "Auto-Parent KISM to Bones"
    bl_description = "Parent all KISM objects to nearest bones in selected armature"
    bl_options = {'REGISTER', 'UNDO'}
    
    def find_closest_bone(self, armature, world_pos):
        """Find the closest bone to a world position"""
        if not armature or armature.type != 'ARMATURE':
            return None
            
        closest_bone = None
        min_distance = float('inf')
        
        for bone in armature.pose.bones:
            head = armature.matrix_world @ bone.head
            tail = armature.matrix_world @ bone.tail
            bone_vec = tail - head
            pos_vec = world_pos - head
            dot = pos_vec.dot(bone_vec)
            
            if dot <= 0:
                dist = (head - world_pos).length
            elif dot >= bone_vec.length_squared:
                dist = (tail - world_pos).length
            else:
                proj = head + (dot / bone_vec.length_squared) * bone_vec
                dist = (proj - world_pos).length
            
            if dist < min_distance:
                min_distance = dist
                closest_bone = bone.name
        
        return closest_bone
    
    def execute(self, context):
        armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'ERROR'}, "No armature selected")
            return {'CANCELLED'}
        
        armature = armatures[0]
        kism_objects = [obj for obj in bpy.data.objects if obj.name.startswith("KISM_")]
        if not kism_objects:
            self.report({'ERROR'}, "No KISM_ objects found")
            return {'CANCELLED'}

        original_mode = armature.mode
        original_active = context.view_layer.objects.active
        original_selection = context.selected_objects.copy()
        bpy.ops.object.mode_set(mode='OBJECT')
        
        success_count = 0
        
        for obj in kism_objects:
            try:
                original_matrix = obj.matrix_world.copy()
                world_pos = original_matrix.translation
                bone_name = self.find_closest_bone(armature, world_pos)
                if not bone_name:
                    continue
                
                obj.parent = None
                obj.matrix_parent_inverse = Matrix()
                obj.parent = armature
                obj.parent_type = 'BONE'
                obj.parent_bone = bone_name
                
                bpy.context.view_layer.update()
                
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone:
                    bone_matrix = armature.matrix_world @ pose_bone.matrix
                    obj.matrix_parent_inverse = bone_matrix.inverted()
                
                obj.matrix_world = original_matrix
                success_count += 1
                
            except Exception as e:
                print(f"Error parenting {obj.name}: {str(e)}")
                continue
        
        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selection:
            obj.select_set(True)
        context.view_layer.objects.active = original_active
        bpy.ops.object.mode_set(mode=original_mode)
        
        self.report({'INFO'}, f"Parented {success_count}/{len(kism_objects)} KISM objects")
        return {'FINISHED'}

class KISM_OT_AttachObjectToAP(Operator):
    bl_idname = "kism.attach_object_to_ap"
    bl_label = "Attach Object to AP"
    bl_description = "Link object to AP using constraints only"
    
    # REMOVE this line - you don't need it
    # ap_name: StringProperty(name="AP Target")

    def execute(self, context):
        obj = context.active_object
        
        # Get the selected AP from kism_props
        scene = context.scene
        if not hasattr(scene, 'kism_props'):
            self.report({'ERROR'}, "KISM properties not available")
            return {'CANCELLED'}
        
        ap_name = scene.kism_props.filtered_aps
        if not ap_name:
            self.report({'ERROR'}, "No AP selected")
            return {'CANCELLED'}
            
        ap_empty = bpy.data.objects.get(ap_name)

        # Validation
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
            
        # Optional: check if it's a weapon/armor object (you can remove this if you want)
        # if not obj.name.startswith(("Weapon_", "Armor_")):
        #     self.report({'ERROR'}, "Select a Weapon_ or Armor_ object")
        #     return {'CANCELLED'}
            
        if not ap_empty:
            self.report({'ERROR'}, f"AP '{ap_name}' not found")
            return {'CANCELLED'}

        # Clean existing constraints
        obj.constraints.clear()

        # Create new constraints
        copy_loc = obj.constraints.new('COPY_LOCATION')
        copy_loc.target = ap_empty
        copy_rot = obj.constraints.new('COPY_ROTATION') 
        copy_rot.target = ap_empty

        self.report({'INFO'}, f"Constrained {obj.name} to {ap_empty.name}")
        return {'FINISHED'}

class KISM_OT_DetachObjectAP(Operator):
    bl_idname = "kism.detach_object_ap"
    bl_label = "Remove Attachment"
    bl_description = "Clear all attachment constraints"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj or not obj.name.startswith(("Weapon_", "Armor_")):
            self.report({'ERROR'}, "Select a Weapon_ or Armor_ object")
            return {'CANCELLED'}
        
        # Remove only attachment constraints
        for c in reversed(obj.constraints):
            if c.type in {'COPY_LOCATION', 'COPY_ROTATION'}:
                obj.constraints.remove(c)
        
        self.report({'INFO'}, f"Detached {obj.name}")
        return {'FINISHED'}

# ==============================================
# PROPERTY GROUPS
# ==============================================

class APCreationProperties(PropertyGroup):
    """Properties for AP empty creation"""
    
    # Show/hide sections
    show_core: BoolProperty(name="Show Core", default=True)
    show_head: BoolProperty(name="Show Head", default=True)
    show_right_arm: BoolProperty(name="Show Right Arm", default=True)
    show_left_arm: BoolProperty(name="Show Left Arm", default=True)
    show_right_leg: BoolProperty(name="Show Right Leg", default=True)
    show_left_leg: BoolProperty(name="Show Left Leg", default=True)
    show_special: BoolProperty(name="Show Special", default=True)
    
    # Bone selection properties
    AP_HEAD_bone: StringProperty(name="Head Bone", default="")
    AP_CHEST_bone: StringProperty(name="Chest Bone", default="")
    AP_BACK_bone: StringProperty(name="Back Bone", default="")
    AP_PELVIS_bone: StringProperty(name="Pelvis Bone", default="")
    
    AP_RSHOULDER_bone: StringProperty(name="Right Shoulder Bone", default="")
    AP_RUPPERARM_bone: StringProperty(name="Right Upper Arm Bone", default="")
    AP_RELBOW_bone: StringProperty(name="Right Elbow Bone", default="")
    AP_RLOWERARM_bone: StringProperty(name="Right Lower Arm Bone", default="")
    AP_RHAND_bone: StringProperty(name="Right Hand Bone", default="")
    AP_WEAPON_R_bone: StringProperty(name="Right Weapon Bone", default="")
    
    AP_LSHOULDER_bone: StringProperty(name="Left Shoulder Bone", default="")
    AP_LUPPERARM_bone: StringProperty(name="Left Upper Arm Bone", default="")
    AP_LELBOW_bone: StringProperty(name="Left Elbow Bone", default="")
    AP_LLOWERARM_bone: StringProperty(name="Left Lower Arm Bone", default="")
    AP_LHAND_bone: StringProperty(name="Left Hand Bone", default="")
    AP_WEAPON_L_bone: StringProperty(name="Left Weapon Bone", default="")
    AP_SHIELD_bone: StringProperty(name="Shield Bone", default="")
    
    AP_RHIP_bone: StringProperty(name="Right Hip Bone", default="")
    AP_RTHIGH_bone: StringProperty(name="Right Thigh Bone", default="")
    AP_RKNEE_bone: StringProperty(name="Right Knee Bone", default="")
    AP_RSHIN_bone: StringProperty(name="Right Shin Bone", default="")
    AP_RANKLE_bone: StringProperty(name="Right Ankle Bone", default="")
    AP_RFOOT_bone: StringProperty(name="Right Foot Bone", default="")
    
    AP_LHIP_bone: StringProperty(name="Left Hip Bone", default="")
    AP_LTHIGH_bone: StringProperty(name="Left Thigh Bone", default="")
    AP_LKNEE_bone: StringProperty(name="Left Knee Bone", default="")
    AP_LSHIN_bone: StringProperty(name="Left Shin Bone", default="")
    AP_LANKLE_bone: StringProperty(name="Left Ankle Bone", default="")
    AP_LFOOT_bone: StringProperty(name="Left Foot Bone", default="")
    
    AP_CAMERA_bone: StringProperty(name="Camera Bone", default="")
    AP_EYE_R_bone: StringProperty(name="Right Eye Bone", default="")
    AP_EYE_L_bone: StringProperty(name="Left Eye Bone", default="")
    AP_MOUTH_bone: StringProperty(name="Mouth Bone", default="")
    AP_CAPE_bone: StringProperty(name="Cape/Cloak Bone", default="")
    AP_WEAPON_BACK_bone: StringProperty(name="Weapon Back Bone", default="")
    AP_WEAPON_BELT_bone: StringProperty(name="Weapon Belt Bone", default="")
    AP_WEAPON_HIP_bone: StringProperty(name="Weapon Hip Bone", default="")

# Scene properties for armature selection
class APSceneProperties(PropertyGroup):
    selected_armature: StringProperty(name="Armature", default="")

# ==============================================
# OPERATOR - CLEAN VERSION WITHOUT MODE SWITCHING
# ==============================================

class AP_OT_CreateAPEmpties(Operator):
    """Create AP empties parented to bone heads"""
    bl_idname = "ap.create_ap_empties"
    bl_label = "Create AP Empties"
    bl_description = "Create AP empties parented to bone heads"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        props = scene.ap_creation_props
        scene_props = scene.ap_scene_props
        
        # Get armature
        armature_name = scene_props.selected_armature
        if not armature_name:
            self.report({'ERROR'}, "Please select an armature first")
            return {'CANCELLED'}
        
        armature = bpy.data.objects.get(armature_name)
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Selected armature not found")
            return {'CANCELLED'}
        
        # Store current mode and selection
        original_mode = context.mode
        original_active = context.view_layer.objects.active
        original_selected = list(context.selected_objects)
        
        # Make sure we're in object mode
        if original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        created = 0
        
        # Map of AP points with their bone selections
        ap_map = [
            ("AP_HEAD", props.AP_HEAD_bone),
            ("AP_CHEST", props.AP_CHEST_bone),
            ("AP_BACK", props.AP_BACK_bone),
            ("AP_PELVIS", props.AP_PELVIS_bone),
            
            ("AP_RSHOULDER", props.AP_RSHOULDER_bone),
            ("AP_RUPPERARM", props.AP_RUPPERARM_bone),
            ("AP_RELBOW", props.AP_RELBOW_bone),
            ("AP_RLOWERARM", props.AP_RLOWERARM_bone),
            ("AP_RHAND", props.AP_RHAND_bone),
            ("AP_WEAPON_R", props.AP_WEAPON_R_bone),
            
            ("AP_LSHOULDER", props.AP_LSHOULDER_bone),
            ("AP_LUPPERARM", props.AP_LUPPERARM_bone),
            ("AP_LELBOW", props.AP_LELBOW_bone),
            ("AP_LLOWERARM", props.AP_LLOWERARM_bone),
            ("AP_LHAND", props.AP_LHAND_bone),
            ("AP_WEAPON_L", props.AP_WEAPON_L_bone),
            ("AP_SHIELD", props.AP_SHIELD_bone),
            
            ("AP_RHIP", props.AP_RHIP_bone),
            ("AP_RTHIGH", props.AP_RTHIGH_bone),
            ("AP_RKNEE", props.AP_RKNEE_bone),
            ("AP_RSHIN", props.AP_RSHIN_bone),
            ("AP_RANKLE", props.AP_RANKLE_bone),
            ("AP_RFOOT", props.AP_RFOOT_bone),
            
            ("AP_LHIP", props.AP_LHIP_bone),
            ("AP_LTHIGH", props.AP_LTHIGH_bone),
            ("AP_LKNEE", props.AP_LKNEE_bone),
            ("AP_LSHIN", props.AP_LSHIN_bone),
            ("AP_LANKLE", props.AP_LANKLE_bone),
            ("AP_LFOOT", props.AP_LFOOT_bone),
            
            ("AP_CAMERA", props.AP_CAMERA_bone),
            ("AP_EYE_R", props.AP_EYE_R_bone),
            ("AP_EYE_L", props.AP_EYE_L_bone),
            ("AP_MOUTH", props.AP_MOUTH_bone),
            ("AP_CAPE", props.AP_CAPE_bone),
            ("AP_WEAPON_BACK", props.AP_WEAPON_BACK_bone),
            ("AP_WEAPON_BELT", props.AP_WEAPON_BELT_bone),
            ("AP_WEAPON_HIP", props.AP_WEAPON_HIP_bone),
        ]
        
        for ap_name, bone_name in ap_map:
            # Skip if no bone selected
            if not bone_name or bone_name == "":
                continue
            
            # Check if bone exists
            if bone_name not in armature.data.bones:
                self.report({'WARNING'}, f"Bone '{bone_name}' not found in {armature.name}")
                continue
            
            # Check if empty already exists
            full_name = f"{ap_name}"
            if full_name in bpy.data.objects:
                self.report({'INFO'}, f"{full_name} already exists")
                continue
            
            # Get the bone
            bone = armature.data.bones[bone_name]
            
            # Get bone's head in world space
            bone_head_world = armature.matrix_world @ bone.head_local
            
            # Deselect everything
            bpy.ops.object.select_all(action='DESELECT')
            
            # Create empty directly at bone head position in world space
            bpy.ops.object.empty_add(type='PLAIN_AXES', location=bone_head_world)
            empty = bpy.context.object
            empty.name = full_name
            
            # Parent to armature (not directly to bone yet)
            empty.parent = armature
            
            # Use a Child Of constraint to attach to the bone's HEAD
            # This gives us more control than bone parenting
            constraint = empty.constraints.new('CHILD_OF')
            constraint.target = armature
            constraint.subtarget = bone_name
            
            # IMPORTANT: Set the inverse to maintain the current position
            # This tells Blender "stay where you are relative to this bone"
            constraint.set_inverse_pending = True
            
            # Set display settings
            empty.empty_display_size = 0.1
            empty.show_name = True
            empty.show_in_front = True
            
            # Add custom property
            empty["is_ap_point"] = True
            empty["ap_type"] = ap_name
            
            created += 1
        
        # Restore original selection and mode
        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selected:
            obj.select_set(True)
        
        if original_active:
            context.view_layer.objects.active = original_active
        
        # Restore original mode if it wasn't OBJECT
        if original_mode != 'OBJECT':
            try:
                if original_mode == 'EDIT_MESH':
                    bpy.ops.object.mode_set(mode='EDIT')
                elif original_mode == 'POSE':
                    bpy.ops.object.mode_set(mode='POSE')
                elif original_mode == 'EDIT_ARMATURE':
                    bpy.ops.object.mode_set(mode='EDIT')
            except:
                pass  # If we can't restore the mode, just stay in OBJECT
        
        self.report({'INFO'}, f"Created {created} AP empties for {armature.name}")
        return {'FINISHED'}

# ==============================================
# CLEAR BONE SELECTIONS OPERATOR
# ==============================================

class AP_OT_ClearBoneSelections(Operator):
    """Clear all bone selections"""
    bl_idname = "ap.clear_bone_selections"
    bl_label = "Clear Bone Selections"
    bl_description = "Clear all bone selections"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.ap_creation_props
        
        props.AP_HEAD_bone = ""
        props.AP_CHEST_bone = ""
        props.AP_BACK_bone = ""
        props.AP_PELVIS_bone = ""
        
        props.AP_RSHOULDER_bone = ""
        props.AP_RUPPERARM_bone = ""
        props.AP_RELBOW_bone = ""
        props.AP_RLOWERARM_bone = ""
        props.AP_RHAND_bone = ""
        props.AP_WEAPON_R_bone = ""
        
        props.AP_LSHOULDER_bone = ""
        props.AP_LUPPERARM_bone = ""
        props.AP_LELBOW_bone = ""
        props.AP_LLOWERARM_bone = ""
        props.AP_LHAND_bone = ""
        props.AP_WEAPON_L_bone = ""
        props.AP_SHIELD_bone = ""
        
        props.AP_RHIP_bone = ""
        props.AP_RTHIGH_bone = ""
        props.AP_RKNEE_bone = ""
        props.AP_RSHIN_bone = ""
        props.AP_RANKLE_bone = ""
        props.AP_RFOOT_bone = ""
        
        props.AP_LHIP_bone = ""
        props.AP_LTHIGH_bone = ""
        props.AP_LKNEE_bone = ""
        props.AP_LSHIN_bone = ""
        props.AP_LANKLE_bone = ""
        props.AP_LFOOT_bone = ""
        
        props.AP_CAMERA_bone = ""
        props.AP_EYE_R_bone = ""
        props.AP_EYE_L_bone = ""
        props.AP_MOUTH_bone = ""
        props.AP_CAPE_bone = ""
        props.AP_WEAPON_BACK_bone = ""
        props.AP_WEAPON_BELT_bone = ""
        props.AP_WEAPON_HIP_bone = ""
        
        self.report({'INFO'}, "Cleared all bone selections")
        return {'FINISHED'}


# ==============================================
# REGISTRATION
# ==============================================

classes = (
    EQUIPMENT_OT_SetupCollections,
    EQUIPMENT_OT_CharacterSheet,
    EQUIPMENT_OT_AddCustomArmorType,
    EQUIPMENT_OT_RemoveCustomArmorType,
    EQUIPMENT_OT_ManageCustomArmorTypes,
    KISM_OT_AttachObjectToAP,
    KISM_OT_DetachObjectAP,
    KISM_OT_AutoParentToBones,
    AP_OT_CreateAPEmpties,
    AP_OT_ClearBoneSelections,
    APCreationProperties,
    APSceneProperties,    
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Load custom armor types
    EquipmentConfig.load_custom_types()
    
    # ADD THESE POINTER PROPERTIES:
    bpy.types.Scene.ap_creation_props = PointerProperty(type=APCreationProperties)
    bpy.types.Scene.ap_scene_props = PointerProperty(type=APSceneProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # REMOVE THESE POINTER PROPERTIES:
    del bpy.types.Scene.ap_creation_props
    del bpy.types.Scene.ap_scene_props

if __name__ == "__main__":
    register()