import bpy
from bpy.types import Panel, PropertyGroup, Operator, UIList
from bpy.props import StringProperty, EnumProperty, BoolProperty, CollectionProperty, IntProperty, PointerProperty, FloatProperty
import os  

# ==============================================
# ANIMATION TOOLS FALLBACK PROPERTY GROUPS
# ==============================================

class AnimationListItem(PropertyGroup):
    """Fallback AnimationListItem PropertyGroup"""
    name: StringProperty(name="Animation Name")
    action: PointerProperty(type=bpy.types.Action)
    display_name: StringProperty(name="Display Name")
    full_name: StringProperty(name="Full Name")
    
class AnimationFileListItem(PropertyGroup):
    """Fallback AnimationFileListItem PropertyGroup"""
    name: StringProperty(name="File Name")
    filepath: StringProperty(name="File Path")
    display_name: StringProperty(name="Display Name")
    file_type: StringProperty(name="File Type")  # "GR2" or "FBX"

# ==============================================
# RETARGETING TOOLS FALLBACK PROPERTY GROUPS
# ==============================================

class BoneListItem(PropertyGroup):
    """Fallback BoneListItem PropertyGroup"""
    name: StringProperty(name="Bone Name")
    include_bone: EnumProperty(
        name="Include",
        description="Include this bone in empty generation",
        items=[
            ('YES', "Yes", "Include this bone"),
            ('NO', "No", "Exclude this bone")
        ],
        default='YES'
    )
    bone_index: IntProperty()

# Simple fallback UI list for bones
class BONE_UL_List(UIList):
    """Fallback UI list for bones"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "include_bone", text="", emboss=False)
            row.label(text=item.name, icon='BONE_DATA')
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text=item.name, icon='BONE_DATA')

# Try to import animation tools FIRST
try:
    from .animation_tools import AnimationListItem as ImportedAnimationListItem, AnimationFileListItem as ImportedAnimationFileListItem
    ANIMATION_TOOLS_AVAILABLE = True
    print("✓ Animation tools imported successfully")
    # Use imported classes if available
    AnimationListItem = ImportedAnimationListItem
    AnimationFileListItem = ImportedAnimationFileListItem
except ImportError as e:
    print(f"Animation tools import error: {e}")
    ANIMATION_TOOLS_AVAILABLE = False
    # Use the fallback PropertyGroups defined above

# Try to import retargeting tools
try:
    from .retargeting_tools import BoneListItem as ImportedBoneListItem
    RETARGETING_TOOLS_AVAILABLE = True
    print("✓ Retargeting tools imported successfully")
    # Use imported class if available
    BoneListItem = ImportedBoneListItem
except ImportError as e:
    print(f"Retargeting tools import error: {e}")
    RETARGETING_TOOLS_AVAILABLE = False
    # Use the fallback PropertyGroup defined above

# ==============================================
# EQUIPMENT TOOLS IMPORT
# ==============================================

try:
    from .equipment_tools import get_character_name, EquipmentConfig, APCreationProperties, APSceneProperties
    EQUIPMENT_TOOLS_AVAILABLE = True
    print("✓ Equipment tools imported successfully")
except ImportError as e:
    print(f"Equipment tools import error: {e}")
    EQUIPMENT_TOOLS_AVAILABLE = False
    
    # Fallback function
    def get_character_name(armature):
        """Fallback character name extractor"""
        if not armature:
            return None
        parts = armature.name.split('_')
        if len(parts) == 3 and parts[0].lower() in ('c', 'p') and parts[2].lower() == 'skel':
            return parts[1]
        return armature.name
    
    # Fallback EquipmentConfig
    class EquipmentConfig:
        ARMOR_TYPES = [
            ("ALL", "All", "Show all armor types"),
            ("NONE", "None", "Show no armor (hide all)"),
            ("CL", "Cloth", "Show cloth armor"),
            ("CP", "Cloth Padded", "Show cloth padded armor"),
            ("LE", "Leather", "Show leather armor"),
            ("LS", "Leather Studded", "Show leather studded armor"),
            ("CH", "Chain", "Show chain armor"),
            ("SC", "Scale", "Show scale armor"),
            ("BA", "Banded", "Show banded armor"),
            ("PH", "Half-Plate", "Show half-plate armor"),
            ("PF", "Full-Plate", "Show full-plate armor"),
            ("HD", "Hide", "Show hide armor"),
            ("NK", "Naked", "Show no armor (naked)")
        ]
        CUSTOM_ARMOR_TYPES = []
    
    # Fallback APCreationProperties
    class APCreationProperties(PropertyGroup):
        show_core: BoolProperty(default=True)
        show_right_arm: BoolProperty(default=True)
        show_left_arm: BoolProperty(default=True)
        show_right_leg: BoolProperty(default=True)
        show_left_leg: BoolProperty(default=True)
        show_special: BoolProperty(default=True)
        
        # Bone properties
        AP_HEAD_bone: StringProperty(name="Head Bone")
        AP_CHEST_bone: StringProperty(name="Chest Bone")
        AP_BACK_bone: StringProperty(name="Back Bone")
        AP_PELVIS_bone: StringProperty(name="Pelvis Bone")
        AP_RSHOULDER_bone: StringProperty(name="Right Shoulder Bone")
        AP_RUPPERARM_bone: StringProperty(name="Right Upper Arm Bone")
        AP_RELBOW_bone: StringProperty(name="Right Elbow Bone")
        AP_RLOWERARM_bone: StringProperty(name="Right Lower Arm Bone")
        AP_RHAND_bone: StringProperty(name="Right Hand Bone")
        AP_WEAPON_R_bone: StringProperty(name="Right Weapon Bone")
        AP_LSHOULDER_bone: StringProperty(name="Left Shoulder Bone")
        AP_LUPPERARM_bone: StringProperty(name="Left Upper Arm Bone")
        AP_LELBOW_bone: StringProperty(name="Left Elbow Bone")
        AP_LLOWERARM_bone: StringProperty(name="Left Lower Arm Bone")
        AP_LHAND_bone: StringProperty(name="Left Hand Bone")
        AP_WEAPON_L_bone: StringProperty(name="Left Weapon Bone")
        AP_SHIELD_bone: StringProperty(name="Shield Bone")
        AP_RHIP_bone: StringProperty(name="Right Hip Bone")
        AP_RTHIGH_bone: StringProperty(name="Right Thigh Bone")
        AP_RKNEE_bone: StringProperty(name="Right Knee Bone")
        AP_RSHIN_bone: StringProperty(name="Right Shin Bone")
        AP_RANKLE_bone: StringProperty(name="Right Ankle Bone")
        AP_RFOOT_bone: StringProperty(name="Right Foot Bone")
        AP_LHIP_bone: StringProperty(name="Left Hip Bone")
        AP_LTHIGH_bone: StringProperty(name="Left Thigh Bone")
        AP_LKNEE_bone: StringProperty(name="Left Knee Bone")
        AP_LSHIN_bone: StringProperty(name="Left Shin Bone")
        AP_LANKLE_bone: StringProperty(name="Left Ankle Bone")
        AP_LFOOT_bone: StringProperty(name="Left Foot Bone")
        AP_CAMERA_bone: StringProperty(name="Camera Bone")
        AP_EYE_R_bone: StringProperty(name="Right Eye Bone")
        AP_EYE_L_bone: StringProperty(name="Left Eye Bone")
        AP_MOUTH_bone: StringProperty(name="Mouth Bone")
        AP_CAPE_bone: StringProperty(name="Cape/Cloak Bone")
        AP_WEAPON_BACK_bone: StringProperty(name="Weapon Back Bone")
        AP_WEAPON_BELT_bone: StringProperty(name="Weapon Belt Bone")
        AP_WEAPON_HIP_bone: StringProperty(name="Weapon Hip Bone")

# ==============================================
# TWODA TOOLS IMPORT
# ==============================================

try:
    from .twoda_tools import (
        PlaceablesColumnInfo, 
        AppearanceColumnInfo, 
        WingColumnInfo, 
        TailColumnInfo,
        BaseitemColumnInfo,
        NWN2_UL_2DAList,
        TwoDAConstants
    )
    TWODA_TOOLS_AVAILABLE = True
    print("✓ 2DA Tools imported successfully")
except ImportError as e:
    print(f"2DA Tools import error: {e}")
    TWODA_TOOLS_AVAILABLE = False
    
    class TwoDAConstants:
        @staticmethod
        def get_config(file_type):
            configs = {
                'placeables': {"filename": "placeables.2da", "icon": "CUBE", "row_display_attr": "Label"},
                'appearance': {"filename": "appearance.2da", "icon": "ARMATURE_DATA", "row_display_attr": "LABEL"},
                'wingmodel': {"filename": "wingmodel.2da", "icon": "MOD_ARMATURE", "row_display_attr": "LABEL"},
                'tailmodel': {"filename": "tailmodel.2da", "icon": "MOD_ARMATURE", "row_display_attr": "LABEL"},
                'baseitem': {"filename": "baseitems.2da", "icon": "SHADERFX", "row_display_attr": "label"}
            }
            return configs.get(file_type, {})
        
        @staticmethod
        def get_display_attributes(file_type):
            display_map = {
                'placeables': ('CUBE', 'Label'),
                'appearance': ('ARMATURE_DATA', 'LABEL'),
                'wingmodel': ('MOD_ARMATURE', 'LABEL'),
                'tailmodel': ('MOD_ARMATURE', 'LABEL'),
                'baseitem': ('SHADERFX', 'label')
            }
            return display_map.get(file_type, ('QUESTION', 'Label'))
    
    class PlaceablesColumnInfo:
        @classmethod
        def get_column_info(cls, column_name):
            return {"description": "No info available", "purpose": "", "icon": 'QUESTION'}
    
    class AppearanceColumnInfo:
        @classmethod
        def get_column_info(cls, column_name):
            return {"description": "No info available", "purpose": "", "icon": 'QUESTION'}
    
    class WingColumnInfo:
        @classmethod
        def get_column_info(cls, column_name):
            return {"description": "No info available", "purpose": "", "icon": 'QUESTION'}
    
    class TailColumnInfo:
        @classmethod
        def get_column_info(cls, column_name):
            return {"description": "No info available", "purpose": "", "icon": 'QUESTION'}
    
    class BaseitemColumnInfo:
        @classmethod
        def get_column_info(cls, column_name):
            return {"description": "No info available", "purpose": "", "icon": 'QUESTION'}
    
    # CREATE THE UI LIST CLASS HERE TOO
    class NWN2_UL_2DAList:
        """Fallback UI list for 2DA rows"""
        pass


# ==============================================
# CONSOLIDATED PROPERTY GROUPS
# ==============================================

class DynamicProperties(PropertyGroup):
    """Consolidated property group for dynamic properties used across all tools"""
    
    # Export folder properties
    model_export_folder: StringProperty(
        name="Model Export Folder",
        description="Folder for exporting models",
        default="",
        subtype='DIR_PATH'
    )
    
    material_export_folder: StringProperty(
        name="Material Export Folder", 
        description="Folder for exporting materials/textures",
        default="",
        subtype='DIR_PATH'
    )
    
    # Animation tools properties
    my_text: StringProperty(
        name="Prefix", 
        description="Prefix for animation names", 
        default=""
    )
    
    # Retargeting tools properties
    current_tab: EnumProperty(
        name="Current Tab",
        description="Current active tab in retargeting tools",
        items=[
            ('dynamic_retargeting', 'Dynamic Retargeting', ''),
            ('source_constraints', 'Source Constraints', ''),
            ('target_constraints', 'Target Constraints', '')
        ],
        default='dynamic_retargeting'
    )
    
    # Bone selection properties for retargeting
    bone_list: CollectionProperty(type=BoneListItem)
    bone_list_index: IntProperty(default=0)
    show_bone_selection: BoolProperty(default=False)
    
    # Filter properties for retargeting
    filter_bone_names: StringProperty(
        name="Filter Bones",
        description="Filter bones by name (comma-separated, e.g., arm,leg,hand)",
        default=""
    )
    filter_action: EnumProperty(
        name="Filter Action",
        items=[
            ('INCLUDE', "Include Only", "Only include bones matching the filter"),
            ('EXCLUDE', "Exclude", "Exclude bones matching the filter"),
            ('SELECT', "Select Matching", "Select bones matching the filter"),
            ('DESELECT', "Deselect Matching", "Deselect bones matching the filter")
        ],
        default='INCLUDE'
    )
    
    # Prefix properties for retargeting
    prefix_empties: StringProperty(name="Prefix for Empties", default="")
    prefix_constraints: StringProperty(name="Prefix for Constraints", default="")
    
    # Vertex size for retargeting
    vertex_size: FloatProperty(
        name="Vertex Size",
        description="Size of vertices created for bone snapping",
        default=0.1,
        min=0.01,
        max=1.0
    )

# ==============================================
# MDB/GR2 FILE ITEM PROPERTY GROUP
# ==============================================

class MDBGR2FileItem(PropertyGroup):
    """Property group for MDB/GR2 file items"""
    name: StringProperty(name="File Name")
    filepath: StringProperty(name="File Path")
    file_type: StringProperty(name="File Type")  # "MDB" or "GR2"

# ==============================================
# CUSTOM OPERATORS FOR FOLDER SELECTION
# ==============================================

class NWN2_OT_select_import_folder(bpy.types.Operator):
    """Select folder containing MDB/GR2 files"""
    bl_idname = "nwn2.select_import_folder"
    bl_label = "Select Import Folder"
    bl_description = "Open a directory browser, hold Shift to open the file, Alt to browse containing directory"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory:
            context.scene.mdb_gr2_import_directory = self.directory
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class NWN2_OT_select_model_export_folder(bpy.types.Operator):
    """Select folder for exporting models"""
    bl_idname = "nwn2.select_model_export_folder"
    bl_label = "Choose Model Export Folder"
    bl_description = "Select the folder where models will be exported"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory and hasattr(context.scene, 'dynamic_props'):
            context.scene.dynamic_props.model_export_folder = self.directory
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class NWN2_OT_select_material_export_folder(bpy.types.Operator):
    """Select folder for exporting materials/textures"""
    bl_idname = "wm.select_export_folder"
    bl_label = "Choose Export Folder"
    bl_description = "Select the folder where the textures and models will be exported"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory and hasattr(context.scene, 'dynamic_props'):
            context.scene.dynamic_props.material_export_folder = self.directory
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class NWN2_OT_select_animation_import_folder(bpy.types.Operator):
    """Select folder containing animation files (FBX/GR2)"""
    bl_idname = "nwn2.select_animation_import_folder"
    bl_label = "Select Animation Import Folder"
    bl_description = "Select folder containing FBX or GR2 animation files"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory:
            context.scene.animation_import_directory = self.directory
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class NWN2_OT_select_animation_export_folder(bpy.types.Operator):
    """Select folder for exporting animations"""
    bl_idname = "nwn2.select_animation_export_folder"
    bl_label = "Choose Animation Export Folder"
    bl_description = "Select the folder where animations will be exported"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory:
            context.scene.animation_export_directory = self.directory
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# ==============================================
# TOOLTIP OPERATOR (from old panel)
# ==============================================

class TWODA_OT_ShowTooltip(Operator):
    """Show column description tooltip"""
    bl_idname = "twoda.show_tooltip"
    bl_label = "Column Description"
    bl_description = "Show column description"
    
    tooltip_text: StringProperty(name="Tooltip Text", default="")
    
    def execute(self, context):
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Column Description", icon='INFO')
        layout.separator()
        
        lines = self.tooltip_text.split('\n')
        for line in lines:
            layout.label(text=line)

# ==============================================
# SCROLL OPERATORS
# ==============================================

class NWN2_OT_ScrollImportList(bpy.types.Operator):
    """Scroll through the import file list"""
    bl_idname = "nwn2.scroll_import_list"
    bl_label = "Scroll List"
    bl_description = "Scroll through the file list"
    
    direction: EnumProperty(
        name="Direction",
        description="Scroll direction",
        items=[
            ('PREV', 'Previous', 'Go to previous page'),
            ('NEXT', 'Next', 'Go to next page'),
        ]
    )
    
    def execute(self, context):
        scene = context.scene
        
        # Calculate items per page
        items_per_page = max(1, int(scene.mdb_gr2_scroll_height))
        file_count = len(scene.mdb_gr2_file_collection)
        total_pages = max(1, (file_count + items_per_page - 1) // items_per_page)
        
        if self.direction == 'PREV':
            scene.mdb_gr2_scroll_index = max(0, scene.mdb_gr2_scroll_index - 1)
        else:  # NEXT
            scene.mdb_gr2_scroll_index = min(total_pages - 1, scene.mdb_gr2_scroll_index + 1)
        
        return {'FINISHED'}

class NWN2_OT_ScrollAnimationList(bpy.types.Operator):
    """Scroll through the animation file list"""
    bl_idname = "nwn2.scroll_animation_list"
    bl_label = "Scroll Animation List"
    bl_description = "Scroll through the animation file list"
    
    direction: EnumProperty(
        name="Direction",
        description="Scroll direction",
        items=[
            ('PREV', 'Previous', 'Go to previous page'),
            ('NEXT', 'Next', 'Go to next page'),
        ]
    )
    
    def execute(self, context):
        scene = context.scene
        
        # Calculate items per page
        items_per_page = max(1, int(scene.animation_scroll_height))
        file_count = len(scene.animation_file_collection)
        total_pages = max(1, (file_count + items_per_page - 1) // items_per_page)
        
        if self.direction == 'PREV':
            scene.animation_scroll_index = max(0, scene.animation_scroll_index - 1)
        else:  # NEXT
            scene.animation_scroll_index = min(total_pages - 1, scene.animation_scroll_index + 1)
        
        return {'FINISHED'}

# ==============================================
# WORKFLOW GUIDES
# ==============================================

class NWN2WorkflowGuides:
    """Workflow guides for each tool section with collapsible sections"""
    
    @staticmethod
    def _draw_collapsible_section(parent, prop_suffix, label, icon, description, draw_content):
        """Enhanced visual for collapsible sections"""
        scene = bpy.context.scene
        prop_name = f"show_{prop_suffix}_section"
        
        # Create a visually enhanced box with subtle styling
        box = parent.box()
        box.scale_y = 1.02  # Slightly taller for better visual weight
        
        # Create header with improved visual hierarchy
        header = box.row()
        header.scale_y = 1.1  # Taller header area
        
        # Use Python's getattr to check if property exists
        if hasattr(scene, prop_name):
            expanded = getattr(scene, prop_name)
            # Use more distinct icons for better visual feedback
            header.prop(scene, prop_name, 
                       text="", 
                       icon='DOWNARROW_HLT' if expanded else 'RIGHTARROW',
                       emboss=False)
        else:
            # Property doesn't exist, default to collapsed
            expanded = False
            header.label(text="", icon='RIGHTARROW')
        
        # Label with improved typography
        header.label(text=label, icon=icon)
        
        # Add subtle visual indicator on the right
        status = header.row()
        status.alignment = 'RIGHT'
        
        # Draw content if expanded with enhanced visual styling
        if hasattr(scene, prop_name) and getattr(scene, prop_name):
            content_box = box.column(align=True)
            content_box.scale_y = 0.98  # Slightly compressed for better density
            
            if description:
                # Description in a subtle info box
                desc_box = content_box.box()
                desc_box.scale_y = 0.9
                desc_box.label(text=description, icon='INFO')
                content_box.separator(factor=0.5)
            
            # Draw the content with better visual separation
            draw_content(content_box)

# =========================================================================
# MODEL WORKFLOW METHODS
# =========================================================================
    
    @staticmethod
    def draw_model_workflow(layout):
        """Model tools workflow guide"""
        box = layout.box()
        box.scale_y = 1.03  # Slightly taller main container
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Model Export Workflow", icon='MESH_DATA')
        
        # Import and Setup with better visual separation
        NWN2WorkflowGuides._draw_collapsible_section(box, "mdb_gr2_import", "Import MDB/GR2 Files", 'IMPORT',
            "Import NWN2 model files (MDB for static, GR2 for armatures)",
            lambda col: NWN2WorkflowGuides._draw_mdb_gr2_import(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "object_renaming", "Object Renaming", 'SORTALPHA',
            "Rename objects with NWN2 naming conventions",
            lambda col: NWN2WorkflowGuides._draw_object_renaming(col)
        )
        
        # CHANGED: Model Preparation
        NWN2WorkflowGuides._draw_collapsible_section(box, "model_prepare", "Model Preparation", 'TOOL_SETTINGS',
            "Essential steps before export", 
            lambda col: NWN2WorkflowGuides._draw_model_prepare(col)
        )
        
        # CHANGED: Mesh Tools (renamed from "Additional Tools")
        NWN2WorkflowGuides._draw_collapsible_section(box, "model_tools", "Mesh Tools", 'MODIFIER',
            "Tools for cleaning and preparing meshes",
            lambda col: NWN2WorkflowGuides._draw_model_tools(col)
        )
        
        # CHANGED: Export Model/Skel (renamed from "Model Export")
        NWN2WorkflowGuides._draw_collapsible_section(box, "model_folders", "Export Model/Skel", 'FILE_FOLDER', 
            "Set folder and export models or skeletons",
            lambda col: NWN2WorkflowGuides._draw_model_folders(col)
        )

    @staticmethod
    def _draw_mdb_gr2_import(col):
        """MDB/GR2 import section with scrollable list - Enhanced visual"""
        scene = bpy.context.scene
        
        # Directory selection - ONLY button, no text field
        col.label(text="Import Directory:", icon='FILE_FOLDER')
        row = col.row(align=True)
        
        # Display current folder in an enhanced box
        import_dir = scene.mdb_gr2_import_directory
        box = row.box()
        box.scale_y = 0.85  # Slightly taller for better readability
        if import_dir:
            # Display just the folder name
            display_name = os.path.basename(import_dir)
            if not display_name:
                display_name = import_dir
            # Truncate if too long
            if len(display_name) > 30:
                box.label(text=display_name[:27] + "...")
            else:
                box.label(text=display_name)
        else:
            box.label(text="No folder selected")
        
        # Folder button with better visual
        row.operator("nwn2.select_import_folder", text="", icon='FILE_FOLDER')
        
        # Show current folder status with enhanced visuals
        if import_dir:
            # Check if it's a valid directory
            abs_path = bpy.path.abspath(import_dir) if import_dir.startswith('//') else import_dir
            if os.path.isdir(abs_path):
                status_box = col.box()
                status_box.scale_y = 0.9
                status_box.label(text=f"✓ Valid folder: {os.path.basename(abs_path)}", icon='CHECKMARK')
            else:
                status_box = col.box()
                status_box.alert = True
                status_box.scale_y = 0.9
                status_box.label(text=f"✗ Invalid folder path", icon='ERROR')
        
        # Refresh and import all with better button styling
        row = col.row(align=True)
        row.scale_y = 1.1
        row.operator("object.refresh_mdb_gr2_file_list", text="Refresh File List", icon='FILE_REFRESH')
        row.operator("object.import_all_mdb_gr2_files", text="Import All Files", icon='IMPORT')
        
        # File list display
        file_count = len(scene.mdb_gr2_file_collection)
        if file_count > 0:
            col.separator(factor=0.8)
            
            # File count and UI scale controls with better layout
            row = col.row(align=True)
            row.label(text=f"Found {file_count} files:", icon='FILE_BLANK')
            
            # UI Scale control on the right
            row_right = row.row(align=True)
            row_right.alignment = 'RIGHT'
            row_right.label(text="UI Scale:")
            row_right.prop(scene, "mdb_gr2_ui_scale", text="", slider=True)
            
            # Selection controls with better button sizing
            row = col.row(align=True)
            row.scale_y = 1.05
            row.operator("object.select_all_mdb_gr2_files", text="Select All")
            row.operator("object.deselect_all_mdb_gr2_files", text="Deselect All")
            
            # Scrollable area for file list
            scroll_height = scene.mdb_gr2_scroll_height
            if scroll_height < 1:
                scroll_height = 1
            
            # Create a template list for scrolling
            row = col.row()
            col_list = row.column()
            
            # Calculate how many files to show based on scroll position and UI scale
            items_per_page = max(1, int(scroll_height))
            current_page = scene.mdb_gr2_scroll_index
            total_pages = max(1, (file_count + items_per_page - 1) // items_per_page)
            
            # Clamp current page
            if current_page >= total_pages:
                current_page = total_pages - 1
                scene.mdb_gr2_scroll_index = current_page
            
            start_idx = current_page * items_per_page
            end_idx = min(start_idx + items_per_page, file_count)
            
            # Scroll controls with enhanced visuals
            if file_count > items_per_page:
                scroll_row = col.row(align=True)
                scroll_row.alignment = 'CENTER'
                scroll_row.scale_y = 1.1
                
                # Previous page
                if current_page > 0:
                    prev_op = scroll_row.operator("nwn2.scroll_import_list", text="", icon='TRIA_LEFT')
                    prev_op.direction = 'PREV'
                else:
                    scroll_row.label(text="", icon='TRIA_LEFT')
                
                # Page indicator with better styling
                scroll_row.label(text=f"Page {current_page + 1}/{total_pages} ({start_idx + 1}-{end_idx} of {file_count})")
                
                # Next page
                if current_page < total_pages - 1:
                    next_op = scroll_row.operator("nwn2.scroll_import_list", text="", icon='TRIA_RIGHT')
                    next_op.direction = 'NEXT'
                else:
                    scroll_row.label(text="", icon='TRIA_RIGHT')
            
            # File list with adjustable UI scale
            ui_scale = scene.mdb_gr2_ui_scale
            list_box = col_list.box()
            list_box.scale_y = 0.95  # Slightly compressed for better density
            
            for i in range(start_idx, end_idx):
                item = scene.mdb_gr2_file_collection[i]
                is_selected = scene.mdb_gr2_selection_flags.get(item.name, False)
                is_active = (i == scene.mdb_gr2_file_index)
                
                row_item = list_box.row(align=True)
                row_item.scale_y = ui_scale * 0.9  # Slightly smaller for better fit
                
                # Selection toggle with better visual feedback
                toggle_op = row_item.operator("object.toggle_file_selection", 
                                           text="", 
                                           icon='CHECKBOX_HLT' if is_selected else 'CHECKBOX_DEHLT',
                                           emboss=False)
                toggle_op.index = i
                
                # File info
                file_icon = 'MESH_DATA' if item.file_type == 'MDB' else 'ARMATURE_DATA'
                
                # Truncate filename if too long
                display_name = item.name
                if len(display_name) > 40:
                    display_name = display_name[:37] + "..."
                
                row_item.label(text=display_name, icon=file_icon)
                
                # File type on the right with subtle styling
                sub = row_item.row(align=True)
                sub.alignment = 'RIGHT'
                sub.scale_x = 0.8
                sub.label(text=item.file_type)
            
            # Scroll height control with better layout
            if file_count > 5:
                col.separator(factor=0.5)
                row = col.row(align=True)
                row.label(text="Items per page:")
                row.prop(scene, "mdb_gr2_scroll_height", text="", slider=True)
                row.label(text=f"(1-{min(20, file_count)})")
            
            # Import buttons with enhanced visual prominence
            selected_count = sum(1 for item in scene.mdb_gr2_file_collection 
                               if scene.mdb_gr2_selection_flags.get(item.name, False))
            
            col.separator(factor=0.8)
            row = col.row(align=True)
            row.scale_y = 1.15
            row.operator("object.import_mdb_gr2_file", text="Import Active", icon='IMPORT')
            row.operator("object.import_selected_mdb_gr2_files", text=f"Import Checked ({selected_count})", icon='IMPORT')
            
            if selected_count > 0:
                status_box = col.box()
                status_box.scale_y = 0.9
                status_box.label(text=f"{selected_count} file(s) ready for import", icon='CHECKMARK')
        else:
            col.separator(factor=0.8)
            info_box = col.box()
            info_box.scale_y = 0.9
            info_box.label(text="No MDB/GR2 files found", icon='INFO')
            info_box.label(text="Set directory and click Refresh", icon='DOT')
        
        # Collection cleanup with better button styling
        col.separator(factor=0.8)
        row = col.row()
        row.scale_y = 1.1
        row.operator("object.cleanup_mdb_gr2_collections", text="Organize Imported Objects", icon='OUTLINER_COLLECTION')
        
        col.label(text="• Moves imported objects to 'Imported MDB/GR2' collection", icon='DOT')
        
        # Quick info with enhanced layout
        col.separator(factor=0.8)
        quick_info = col.box()
        quick_info.scale_y = 0.95
        quick_info.label(text="Quick Info:", icon='INFO')
        quick_info.label(text="• MDB: Static models", icon='DOT')
        quick_info.label(text="• GR2: Models with armatures", icon='DOT')
        quick_info.label(text="• Click checkboxes for multi-select", icon='DOT')
        quick_info.label(text="• Use UI Scale to adjust list item size", icon='DOT')

    @staticmethod
    def _draw_object_renaming(col):
        """Object renaming tools section - Enhanced visual"""
        scene = bpy.context.scene
        selected_count = len(bpy.context.selected_objects)
        
        # Selection Info with enhanced styling
        if selected_count == 0:
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Select objects to rename", icon='ERROR')
        else:
            status_box = col.box()
            status_box.scale_y = 0.9
            status_box.label(text=f"Selected: {selected_count} objects", icon='OBJECT_DATA')
        
        # Naming controls - compact layout with better visual grouping
        control_box = col.box()
        control_box.scale_y = 0.95
        
        row = control_box.row()
        col_left = row.column()
        col_left.label(text="Prefix")
        col_left.prop(scene, "nwn2_rename_prefix", text="")
        
        col_mid = row.column()
        col_mid.label(text="Type") 
        col_mid.prop(scene, "nwn2_rename_type", text="")
        
        col_right = row.column()
        col_right.label(text="Number")
        col_right.prop(scene, "nwn2_rename_numeric", text="")
        
        # Custom type field (only shown when Custom is selected)
        if scene.nwn2_rename_type == 'Custom':
            custom_box = control_box.box()
            custom_box.scale_y = 0.9
            custom_box.prop(scene, "nwn2_rename_custom_type", text="Custom Type")
        
        # Numbering options with better layout
        option_box = control_box.box()
        option_box.scale_y = 0.9
        row = option_box.row(align=True)
        row.prop(scene, "nwn2_rename_sequential", text="Sequential")
        
        if not scene.nwn2_rename_sequential:
            row.prop(scene, "nwn2_rename_letter", text="Letter")
        
        # Preview with enhanced styling
        preview_box = col.box()
        preview_box.scale_y = 0.9
        
        # Get the actual type name (either from enum or custom field)
        type_name = scene.nwn2_rename_type
        if type_name == 'Custom':
            type_name = scene.nwn2_rename_custom_type
        
        base_name = f"{scene.nwn2_rename_prefix.upper()}_{type_name}{scene.nwn2_rename_numeric}"
        
        if scene.nwn2_rename_sequential and selected_count > 1:
            preview_box.label(text=f"Preview: {base_name} → {int(scene.nwn2_rename_numeric) + 1:02d} → ...", icon='VIEWZOOM')
        elif not scene.nwn2_rename_sequential and scene.nwn2_rename_letter and selected_count > 1:
            if scene.nwn2_rename_letter.upper() == 'C':
                preview_box.label(text=f"Preview: {base_name} → {base_name}_C2 → ...", icon='VIEWZOOM')
            else:
                preview_box.label(text=f"Preview: {base_name} → {base_name}_L02 → ...", icon='VIEWZOOM')
        else:
            preview_box.label(text=f"Preview: {base_name}", icon='VIEWZOOM')
            if selected_count > 1:
                preview_box.label(text="All objects get same name")
        
        # Action buttons with enhanced visual prominence
        action_box = col.box()
        action_box.scale_y = 1.05
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.extract_prefix_from_selection", text="Extract Pattern", icon='EYEDROPPER')
        
        if selected_count > 0:
            apply_row = action_box.row()
            apply_row.scale_y = 1.3
            apply_row.operator(
                "nwn2.rename_with_prefix", 
                text=f"Rename {selected_count} Objects",
                icon='CHECKMARK'
            )

    @staticmethod
    def _draw_model_prepare(col):
        """Model preparation section - Enhanced visual"""
        # Apply Transforms with better grouping
        transform_box = col.box()
        transform_box.scale_y = 1.05
        
        transform_box.label(text="Transform Tools:", icon='OBJECT_ORIGIN')
        
        action_box = transform_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.apply_all_transforms", text="Apply Transforms", icon='OBJECT_ORIGIN')
        row.operator("object.apply_all_transforms", text="Apply All Selected", icon='OBJECT_DATA')
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("object.origin_set", text="Set Origin to Geometry", icon='OBJECT_ORIGIN')
        
        info_box = transform_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Apply: Current object | Apply All: All selected objects", icon='DOT')
        
        col.separator(factor=0.8)
        
        # Weight Transfer with enhanced styling
        weight_box = col.box()
        weight_box.scale_y = 1.05
        
        row = weight_box.row()
        row.scale_y = 1.1
        row.operator("nwn2.weight_transfer", text="Transfer Vertex Weights", icon='MOD_VERTEX_WEIGHT')
        
        info_box = weight_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Copies skinning between similar meshes", icon='DOT')
        info_box.label(text="• REQUIREMENT: Both meshes parented to same armature", icon='DOT')
        info_box.label(text="• Select source mesh first, then target mesh", icon='DOT')

    @staticmethod
    def _draw_model_tools(col):
        """Mesh tools section - Enhanced visual"""
        # Mesh Cleanup with better grouping
        cleanup_box = col.box()
        cleanup_box.scale_y = 1.05
        
        cleanup_box.label(text="Mesh Cleanup:", icon='BRUSH_DATA')
        
        action_box = cleanup_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("mesh.cleanup_mesh", text="Cleanup Mesh", icon='BRUSH_DATA')
        
        info_box = action_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Removes duplicate vertices and faces", icon='DOT')
        
        # Merge by Distance with better grouping
        merge_box = col.box()
        merge_box.scale_y = 1.05
        
        merge_box.label(text="Vertex Tools:", icon='VERTEXSEL')
        
        action_box = merge_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("mesh.remove_doubles", text="Merge by Distance", icon='AUTOMERGE_ON')
        
        info_box = action_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Merges vertices within specified distance", icon='DOT')
        
        # Normals Tools with better grouping
        normals_box = col.box()
        normals_box.scale_y = 1.05
        
        normals_box.label(text="Normal Tools:", icon='SNAP_NORMAL')
        
        action_box = normals_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("mesh.normals_make_consistent", text="Reset Normals", icon='SNAP_NORMAL')
        row.operator("mesh.set_normals_from_faces", text="Set from Faces", icon='SNAP_FACE')
        
        info_box = action_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Reset: Makes normals consistent", icon='DOT')
        info_box.label(text="• Set from Faces: Aligns to face orientation", icon='DOT')

    @staticmethod
    def _draw_model_folders(col):
        """Model export folders section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Model export folder - ONLY button, no text field
        folder_box = col.box()
        folder_box.scale_y = 1.05
        
        folder_box.label(text="Model Export Folder:", icon='LAYER_ACTIVE')
        
        if hasattr(scene, 'dynamic_props'):
            row = folder_box.row(align=True)
            
            # Display current folder in an enhanced box
            export_dir = scene.dynamic_props.model_export_folder
            display_box = row.box()
            display_box.scale_y = 0.85
            if export_dir:
                # Display just the folder name
                display_name = os.path.basename(export_dir)
                if not display_name:
                    display_name = export_dir
                # Truncate if too long
                if len(display_name) > 30:
                    display_box.label(text=display_name[:27] + "...")
                else:
                    display_box.label(text=display_name)
            else:
                display_box.label(text="No folder selected")
            
            # Folder button with better visual
            row.operator("nwn2.select_model_export_folder", text="", icon='FILE_FOLDER')
            
            # Show current folder status with enhanced visuals
            if export_dir:
                abs_path = bpy.path.abspath(export_dir) if export_dir.startswith('//') else export_dir
                if os.path.isdir(abs_path):
                    status_box = folder_box.box()
                    status_box.scale_y = 0.9
                    status_box.label(text=f"✓ Valid folder: {os.path.basename(abs_path)}", icon='CHECKMARK')
                else:
                    status_box = folder_box.box()
                    status_box.alert = True
                    status_box.scale_y = 0.9
                    status_box.label(text=f"✗ Invalid folder path", icon='ERROR')
            
            # Export buttons - ADDED SKELETON EXPORT
            export_box = col.box()
            export_box.scale_y = 1.05
            
            export_box.label(text="Export Options:", icon='EXPORT')
            
            # Model Export with better grouping
            model_box = export_box.box()
            model_box.scale_y = 0.95
            
            row = model_box.row()
            row.scale_y = 1.1
            row.operator("wm.export_model", text="Export Model as MDB", icon='MESH_DATA')
            
            info_box = model_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Exports selected models as NWN2 MDB files", icon='DOT')
            info_box.label(text="• Requires: Applied transforms and proper armature setup", icon='DOT')
            
            # Skeleton Export with better grouping
            skeleton_box = export_box.box()
            skeleton_box.scale_y = 0.95
            
            row = skeleton_box.row()
            row.scale_y = 1.1
            row.operator("object.setup_armature", text="Export Armature as GR2", icon='ARMATURE_DATA')
            
            info_box = skeleton_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Exports selected armature as skeleton file", icon='DOT')
            info_box.label(text="• For character animations and rigs", icon='DOT')
        else:
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Dynamic properties not available", icon='ERROR')

# =========================================================================
# MATERIAL WORKFLOW METHODS
# =========================================================================

    @staticmethod
    def draw_material_workflow(layout):
        """Material tools workflow guide - Enhanced visual"""
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Material & Texture Workflow", icon='MATERIAL')
        
        # Setup and Creation with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "material_setup", "Material Setup", 'SHADING_RENDERED',
            "Create or convert materials",
            lambda col: NWN2WorkflowGuides._draw_material_setup(col)
        )
        
        # NEW: Retopology Tools Section
        NWN2WorkflowGuides._draw_collapsible_section(box, "material_retopology", "Retopology Tools", 'MODIFIER',
            "Mesh optimization and texture baking tools",
            lambda col: NWN2WorkflowGuides._draw_material_retopology(col)
        )
        
        # NEW: Merge Texture Tools Section
        NWN2WorkflowGuides._draw_collapsible_section(box, "material_merge_texture", "Merge Texture Tools", 'NODE_COMPOSITING',
            "Texture merging and multi-object baking",
            lambda col: NWN2WorkflowGuides._draw_material_merge_texture(col)
        )
        
        # Export and Management with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "material_folders", "Export Folders", 'FILE_FOLDER',
            "Set texture export folder",
            lambda col: NWN2WorkflowGuides._draw_material_folders(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "material_tools", "Material Tools", 'TOOL_SETTINGS',
            "Additional utilities",
            lambda col: NWN2WorkflowGuides._draw_material_tools(col)
        )


    # =========================================================================
    # RETOPOLOGY TOOLS WORKFLOW METHODS
    # =========================================================================

    @staticmethod
    def _draw_material_retopology(col):
        """Retopology tools section - Enhanced visual (Material operations removed)"""
        scene = bpy.context.scene
        
        # Check if retopology tools are available
        if not hasattr(scene, 'retopology_bake_settings'):
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Retopology tools not available")  # Removed icon
            
            # Try to load tools button
            row = error_box.row()
            row.scale_y = 1.1
            row.operator("wm.reload_scripts", text="Reload Scripts", icon='FILE_REFRESH')
            return
        
        # Show active object status
        obj = bpy.context.active_object
        if obj:
            status_box = col.box()
            status_box.scale_y = 0.95
            
            if obj.type == 'MESH':
                # Object info
                info_row = status_box.row()
                info_row.label(text=f"Active: {obj.name}")  # Removed icon
                
                # Modifier count
                modifier_count = len(obj.modifiers)
                info_row.label(text=f"Modifiers: {modifier_count}")
                
                # Mesh info
                mesh_info = status_box.box()
                mesh_info.scale_y = 0.9
                mesh_row = mesh_info.row()
                mesh_row.label(text=f"Vertices: {len(obj.data.vertices)}")
                mesh_row.label(text=f"Faces: {len(obj.data.polygons)}")
                
                # Material info (if any)
                if obj.data.materials:
                    mat = obj.data.materials[0]
                    if mat:
                        mat_info = status_box.box()
                        mat_info.scale_y = 0.9
                        mat_info.label(text=f"Material: {mat.name}")  # Removed icon
            else:
                error_box = status_box.box()
                error_box.alert = True
                error_box.scale_y = 0.9
                error_box.label(text="Select a mesh object")  # Removed icon
        
        # Modifiers section - collapsed by default
        col.separator(factor=0.8)
        NWN2WorkflowGuides._draw_collapsible_section(col, "retopology_modifiers", "Mesh Modifiers", 'MODIFIER',
            "Add and manage mesh modifiers for retopology",
            lambda col: NWN2WorkflowGuides._draw_retopology_modifiers(col, scene)
        )
        
        # Baking section - collapsed by default
        NWN2WorkflowGuides._draw_collapsible_section(col, "retopology_baking", "Texture Baking", 'RENDER_STILL',
            "Bake textures for PBR materials after retopology",
            lambda col: NWN2WorkflowGuides._draw_retopology_baking(col, scene)
        )
        
        # Quick Tips section
        col.separator(factor=0.8)
        tips_box = col.box()
        tips_box.scale_y = 1.05
        
        tips_box.label(text="Retopology Workflow:")  # Removed icon
        
        tips_content = tips_box.box()
        tips_content.scale_y = 0.9
        
        tips_content.label(text="1. Use Modifiers section to optimize mesh")  # Removed icon
        tips_content.label(text="2. Go to 'Material Setup' tab for PBR materials")  # Removed icon
        tips_content.label(text="3. Return here to bake textures")  # Removed icon
        tips_content.label(text="4. Adjust bake settings for quality vs speed")  # Removed icon

    @staticmethod
    def _draw_retopology_modifiers(col, scene):
        """Retopology modifiers section - Enhanced visual"""
        obj = bpy.context.active_object
        
        # Decimate Modifier section
        decimate_box = col.box()
        decimate_box.scale_y = 1.05
        
        decimate_box.label(text="Decimate Modifier", icon='MOD_DECIM')
        
        action_box = decimate_box.box()
        action_box.scale_y = 0.95
        
        # Check if mesh object is selected
        if obj and obj.type == 'MESH':
            # Check if decimate modifier exists
            has_decimate = any(mod.type == 'DECIMATE' for mod in obj.modifiers)
            
            if not has_decimate:
                # Add button if no modifier exists
                action_box.operator("retopology.add_decimate_modifier", icon='ADD', text="Add Decimate")
            else:
                # Show update and remove buttons if modifier exists
                row = action_box.row(align=True)
                row.scale_y = 1.1
                row.operator("retopology.update_decimate_modifier", icon='FILE_REFRESH', text="Update")
                row.operator("retopology.remove_decimate_modifier", icon='X', text="Remove")
                
                # Apply button
                action_box.operator("retopology.apply_decimate_modifier", icon='CHECKMARK', text="Apply Modifier")
        else:
            action_box.label(text="Select a mesh object")  # Removed icon
        
        # Decimate Settings
        settings_box = decimate_box.box()
        settings_box.scale_y = 0.95
        settings_box.label(text="Settings:", icon='SETTINGS')
        
        decimate_settings = scene.retopology_decimate_settings
        settings_col = settings_box.column(align=True)
        
        settings_col.prop(decimate_settings, "decimate_ratio", slider=True)
        settings_col.prop(decimate_settings, "decimate_type")
        
        if decimate_settings.decimate_type == 'COLLAPSE':
            settings_col.prop(decimate_settings, "use_collapse_triangulate")
        
        settings_col.prop(decimate_settings, "use_symmetry")
        if decimate_settings.use_symmetry:
            settings_col.prop(decimate_settings, "symmetry_axis")
        
        # Vertex group settings for decimate
        if obj and obj.type == 'MESH':
            settings_col.separator()
            settings_col.prop_search(decimate_settings, "vertex_group", 
                                obj, "vertex_groups", text="Vertex Group")
            
            if decimate_settings.vertex_group:
                settings_col.prop(decimate_settings, "vertex_group_factor", slider=True)
                settings_col.prop(decimate_settings, "invert_vertex_group")
        
        # Displace Modifier section
        col.separator(factor=0.5)
        displace_box = col.box()
        displace_box.scale_y = 1.05
        
        displace_box.label(text="Displace Modifier", icon='MOD_DISPLACE')
        
        action_box = displace_box.box()
        action_box.scale_y = 0.95
        
        # Check if mesh object is selected
        if obj and obj.type == 'MESH':
            # Check if displace modifier exists
            has_displace = any(mod.type == 'DISPLACE' for mod in obj.modifiers)
            
            if not has_displace:
                # Add button if no modifier exists
                action_box.operator("retopology.add_displace_modifier", icon='ADD', text="Add Displace")
            else:
                # Show update and remove buttons if modifier exists
                row = action_box.row(align=True)
                row.scale_y = 1.1
                row.operator("retopology.update_displace_modifier", icon='FILE_REFRESH', text="Update")
                row.operator("retopology.remove_displace_modifier", icon='X', text="Remove")
                
                # Apply button
                action_box.operator("retopology.apply_displace_modifier", icon='CHECKMARK', text="Apply Modifier")
        else:
            action_box.label(text="Select a mesh object")  # Removed icon
        
        # Displace Settings
        settings_box = displace_box.box()
        settings_box.scale_y = 0.95
        settings_box.label(text="Settings:", icon='SETTINGS')
        
        displace_settings = scene.retopology_displace_settings
        settings_col = settings_box.column(align=True)
        
        settings_col.prop(displace_settings, "displace_strength", slider=True)
        settings_col.prop(displace_settings, "displace_midlevel", slider=True)
        settings_col.prop(displace_settings, "displace_direction")
        settings_col.prop(displace_settings, "texture_coords")
        
        # Vertex group for displace
        if obj and obj.type == 'MESH':
            settings_col.prop_search(displace_settings, "vertex_group", 
                                obj, "vertex_groups", text="Vertex Group")
        
        if displace_settings.texture_coords == 'OBJECT':
            settings_col.prop(displace_settings, "texture_coords_object")
        
        if displace_settings.texture_coords == 'UV':
            # Get available UV layers
            if obj and obj.type == 'MESH' and obj.data.uv_layers:
                settings_col.prop_search(displace_settings, "uv_layer", 
                                    obj.data, "uv_layers", text="UV Layer")
            else:
                settings_col.label(text="No UV layers available")  # Removed icon

    @staticmethod
    def _draw_retopology_baking(col, scene):
        """Retopology baking section - Enhanced visual"""
        bake_settings = scene.retopology_bake_settings
        
        # Main Bake Button (prominent)
        row = col.row()
        row.scale_y = 1.5
        row.operator("retopology.bake_textures", text="Bake Textures", icon='RENDER_STILL')
        
        col.separator()
        
        # Bake Type
        col.prop(bake_settings, "bake_type")
        
        # Basic Settings
        settings_box = col.box()
        settings_box.scale_y = 0.95
        settings_box.label(text="Basic Settings:", icon='SETTINGS')
        
        settings_col = settings_box.column(align=True)
        settings_col.prop(bake_settings, "bake_width")
        settings_col.prop(bake_settings, "bake_height")
        settings_col.prop(bake_settings, "bake_samples")
        settings_col.prop(bake_settings, "bake_margin")
        settings_col.prop(bake_settings, "margin_type")
        
        # Target settings
        settings_col.separator()
        settings_col.prop(bake_settings, "target")
        if bake_settings.target == 'IMAGE_TEXTURES':
            settings_col.prop(bake_settings, "use_clear")
        
        # View settings
        settings_col.separator()
        settings_col.prop(bake_settings, "view_from")
        
        # Selected to Active settings
        col.separator()
        selected_box = col.box()
        selected_box.scale_y = 0.95
        selected_box.label(text="Selected to Active:", icon='OBJECT_DATA')
        
        selected_col = selected_box.column(align=True)
        selected_col.prop(bake_settings, "use_selected_to_active")
        
        if bake_settings.use_selected_to_active:
            selected_col.prop(bake_settings, "use_cage")
            if bake_settings.use_cage:
                selected_col.prop(bake_settings, "cage_object")
                selected_col.prop(bake_settings, "cage_extrusion")
            else:
                selected_col.prop(bake_settings, "cage_extrusion", text="Extrusion")
            
            selected_col.prop(bake_settings, "max_ray_distance")
        
        # Influence settings (based on bake type)
        col.separator()
        influence_box = col.box()
        influence_box.scale_y = 0.95
        influence_box.label(text="Influence Settings:", icon='LIGHT')
        
        influence_col = influence_box.column(align=True)
        
        if bake_settings.bake_type == 'NORMAL':
            influence_col.prop(bake_settings, "normal_space", text="Space")
            
            sub = influence_col.column(align=True)
            sub.prop(bake_settings, "normal_r", text="Swizzle R")
            sub.prop(bake_settings, "normal_g", text="G")
            sub.prop(bake_settings, "normal_b", text="B")
            
        elif bake_settings.bake_type == 'COMBINED':
            influence_col = influence_box.column(heading="Lighting", align=True)
            influence_col.prop(bake_settings, "use_pass_direct")
            influence_col.prop(bake_settings, "use_pass_indirect")
            
            influence_col = influence_box.column(heading="Contributions", align=True)
            influence_col.active = bake_settings.use_pass_direct or bake_settings.use_pass_indirect
            influence_col.prop(bake_settings, "use_pass_diffuse")
            influence_col.prop(bake_settings, "use_pass_glossy")
            influence_col.prop(bake_settings, "use_pass_transmission")
            influence_col.prop(bake_settings, "use_pass_emit")
            
        elif bake_settings.bake_type in {'DIFFUSE', 'GLOSSY', 'TRANSMISSION'}:
            influence_col = influence_box.column(heading="Contributions", align=True)
            influence_col.prop(bake_settings, "use_pass_direct")
            influence_col.prop(bake_settings, "use_pass_indirect")
            influence_col.prop(bake_settings, "use_pass_color")
        
        # Show progress if baking
        if bake_settings.bake_progress > 0:
            col.separator()
            progress_box = col.box()
            progress_box.scale_y = 1.05
            progress_box.label(text="Baking Progress", icon='TIME')
            progress_box.prop(bake_settings, "bake_progress", slider=True)

    # =========================================================================
    # MERGE TEXTURE TOOLS WORKFLOW METHODS
    # =========================================================================

    @staticmethod
    def _draw_material_merge_texture(col):
        """Merge texture tools section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Check if merge texture tools are available
        if not hasattr(scene, 'MergeTextureBake_selected_objects_list'):
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Merge Texture tools not available")  # Removed icon
            
            # Try to load tools button
            row = error_box.row()
            row.scale_y = 1.1
            row.operator("wm.reload_scripts", text="Reload Scripts", icon='FILE_REFRESH')
            return
        
        # Object Management section
        NWN2WorkflowGuides._draw_collapsible_section(col, "merge_texture_objects", "Object Management", 'OBJECT_DATA',
            "Manage objects for texture merging and baking",
            lambda col: NWN2WorkflowGuides._draw_merge_texture_objects(col, scene)
        )
        
        # UV Operations section
        NWN2WorkflowGuides._draw_collapsible_section(col, "merge_texture_uv", "UV Map Operations", 'UV',
            "Create and manage UV maps for selected objects",
            lambda col: NWN2WorkflowGuides._draw_merge_texture_uv(col, scene)
        )
        
        # Texture Operations section
        NWN2WorkflowGuides._draw_collapsible_section(col, "merge_texture_texture", "Texture Operations", 'IMAGE_DATA',
            "Create and manage textures for selected objects",
            lambda col: NWN2WorkflowGuides._draw_merge_texture_texture(col, scene)
        )
        
        # Baking section
        NWN2WorkflowGuides._draw_collapsible_section(col, "merge_texture_baking", "Multi-Object Baking", 'RENDER_STILL',
            "Bake textures across multiple objects",
            lambda col: NWN2WorkflowGuides._draw_merge_texture_baking(col, scene)
        )

    @staticmethod
    def _draw_merge_texture_objects(col, scene):
        """Merge texture objects management section - Enhanced visual"""
        # Object list
        list_box = col.box()
        list_box.scale_y = 1.05
        
        list_box.label(text="Selected Objects:", icon='OBJECT_DATA')
        
        # Create the list
        list_area = list_box.box()
        list_area.scale_y = 0.95
        list_area.template_list(
            "MERGETEXTUREBAKE_UL_selected_objects", 
            "", 
            scene, 
            "MergeTextureBake_selected_objects_list",
            scene, 
            "MergeTextureBake_selected_objects_index",
            rows=4
        )
        
        # Object management buttons
        action_box = list_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("mergetexturebake.add_selected_object", icon='ADD', text="Add Selected")
        row.operator("mergetexturebake.remove_selected_object", icon='REMOVE', text="Remove")
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("mergetexturebake.clear_selected_objects_list", icon='X', text="Clear List")
        
        # Object count
        obj_count = len(scene.MergeTextureBake_selected_objects_list)
        status_box = list_box.box()
        status_box.scale_y = 0.9
        if obj_count > 0:
            status_box.label(text=f"{obj_count} object(s) in list")  # Removed icon
        else:
            status_box.label(text="No objects in list")  # Removed icon
            status_box.label(text="• Select mesh objects in 3D view and click 'Add Selected'")  # Removed icon

    @staticmethod
    def _draw_merge_texture_uv(col, scene):
        """Merge texture UV operations section - Enhanced visual"""
        # UV Operations
        uv_box = col.box()
        uv_box.scale_y = 1.05
        
        uv_box.label(text="UV Map Operations:", icon='UV')
        
        # UV name input
        name_box = uv_box.box()
        name_box.scale_y = 0.95
        
        row = name_box.row()
        row.scale_y = 1.1
        row.prop(scene, "MergeTextureBake_uv_map_name", text="UV Map Name")
        
        # UV action buttons
        action_box = uv_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("mergetexturebake.create_uv_map", icon='ADD', text="Create UV")
        row.operator("mergetexturebake.remove_uv_map", icon='REMOVE', text="Remove UV")
        
        # UV status info
        obj_count = len(scene.MergeTextureBake_selected_objects_list)
        if obj_count > 0:
            info_box = uv_box.box()
            info_box.scale_y = 0.9
            uv_name = scene.MergeTextureBake_uv_map_name
            info_box.label(text=f"• Creates/removes '{uv_name}' on all {obj_count} objects")  # Removed icon
            info_box.label(text="• Sets the new UV map as active for baking")  # Removed icon

    @staticmethod
    def _draw_merge_texture_texture(col, scene):
        """Merge texture operations section - Enhanced visual"""
        # Texture Creation
        texture_box = col.box()
        texture_box.scale_y = 1.05
        
        texture_box.label(text="Texture Operations:", icon='IMAGE_DATA')
        
        # Texture Settings
        settings_box = texture_box.box()
        settings_box.scale_y = 0.95
        
        settings_col = settings_box.column(align=True)
        
        # Texture name with duplicate warning
        row = settings_col.row()
        row.alert = scene.MergeTextureBake_has_duplicate_texture_name
        row.prop(scene, "MergeTextureBake_texture_name", text="Texture Name")
        
        # Texture dimensions
        row = settings_col.row(align=True)
        row.prop(scene, "MergeTextureBake_texture_width", text="Width")
        row.prop(scene, "MergeTextureBake_texture_height", text="Height")
        
        # Texture options
        options_col = settings_col.column(align=True)
        options_col.prop(scene, "MergeTextureBake_use_alpha", text="Alpha")
        options_col.prop(scene, "MergeTextureBake_image_generated_type", text="Generated Type")
        options_col.prop(scene, "MergeTextureBake_use_32bit_float", text="32-bit Float")
        options_col.prop(scene, "MergeTextureBake_use_tiled", text="Tiled")
        
        # Color picker
        color_box = settings_col.box()
        color_box.scale_y = 0.9
        color_box.prop(scene, "MergeTextureBake_image_color", text="Color")
        
        # Action buttons
        action_box = texture_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("mergetexturebake.create_texture_for_materials", icon='ADD', text="Create Texture Nodes")
        row.operator("mergetexturebake.delete_texture_nodes", icon='TRASH', text="Delete Nodes")
        
        # Info about duplicates
        if scene.MergeTextureBake_has_duplicate_texture_name:
            warning_box = texture_box.box()
            warning_box.alert = True
            warning_box.scale_y = 0.9
            texture_name = scene.MergeTextureBake_texture_name
            warning_box.label(text=f"Texture '{texture_name}' already exists")  # Removed icon
            warning_box.label(text="• Existing texture will be overwritten")  # Removed icon

    @staticmethod
    def _draw_merge_texture_baking(col, scene):
        """Merge texture baking section - Enhanced visual"""
        # Baking
        bake_box = col.box()
        bake_box.scale_y = 1.05
        
        bake_box.label(text="Multi-Object Baking:", icon='RENDER_STILL')
        
        # Main bake button
        action_box = bake_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.5
        
        # Get bake type
        bake_type = scene.MergeTextureBake_custom_bake_type
        if bake_type == 'METALLIC':
            bake_type = 'EMIT'
        
        operator = row.operator("mergetexturebake.bake_custom", text="Bake Textures", icon='RENDER_STILL')
        operator.bake_type = bake_type
        
        # Bake type selection
        type_box = bake_box.box()
        type_box.scale_y = 0.95
        
        type_box.prop(scene, "MergeTextureBake_custom_bake_type", text="Bake Type")
        
        # Get Blender's bake settings
        rd = scene.render
        cbk = rd.bake
        
        # Basic settings
        basic_box = bake_box.box()
        basic_box.scale_y = 0.95
        basic_box.label(text="Basic Settings:", icon='SETTINGS')
        
        basic_col = basic_box.column(align=True)
        
        # View from
        basic_col.prop(cbk, "view_from")
        basic_col.active = scene.camera is not None
        
        # Selected to Active
        selected_box = bake_box.box()
        selected_box.scale_y = 0.95
        selected_box.label(text="Selected to Active:", icon='OBJECT_DATA')
        
        selected_col = selected_box.column(align=True)
        selected_col.prop(cbk, "use_selected_to_active")
        
        if cbk.use_selected_to_active:
            selected_col.prop(cbk, "use_cage", text="Cage")
            if cbk.use_cage:
                selected_col.prop(cbk, "cage_object")
                selected_col = selected_box.column()
                selected_col.prop(cbk, "cage_extrusion")
                selected_col.active = cbk.cage_object is None
            else:
                selected_col.prop(cbk, "cage_extrusion", text="Extrusion")
            
            selected_col = selected_box.column()
            selected_col.prop(cbk, "max_ray_distance")
        
        # Influence settings
        if scene.MergeTextureBake_custom_bake_type in {'NORMAL', 'COMBINED', 'DIFFUSE', 'GLOSSY', 'TRANSMISSION'}:
            influence_box = bake_box.box()
            influence_box.scale_y = 0.95
            influence_box.label(text="Influence Settings:", icon='LIGHT')
            
            influence_col = influence_box.column(align=True)
            
            if scene.MergeTextureBake_custom_bake_type == 'NORMAL':
                influence_col.prop(cbk, "normal_space", text="Space")
                
                sub = influence_col.column(align=True)
                sub.prop(cbk, "normal_r", text="Swizzle R")
                sub.prop(cbk, "normal_g", text="G")
                sub.prop(cbk, "normal_b", text="B")
                
            elif scene.MergeTextureBake_custom_bake_type == 'COMBINED':
                influence_col = influence_box.column(heading="Lighting", align=True)
                influence_col.prop(cbk, "use_pass_direct")
                influence_col.prop(cbk, "use_pass_indirect")
                
                influence_col = influence_box.column(heading="Contributions", align=True)
                influence_col.active = cbk.use_pass_direct or cbk.use_pass_indirect
                influence_col.prop(cbk, "use_pass_diffuse")
                influence_col.prop(cbk, "use_pass_glossy")
                influence_col.prop(cbk, "use_pass_transmission")
                influence_col.prop(cbk, "use_pass_emit")
                
            elif scene.MergeTextureBake_custom_bake_type in {'DIFFUSE', 'GLOSSY', 'TRANSMISSION'}:
                influence_col = influence_box.column(heading="Contributions", align=True)
                influence_col.prop(cbk, "use_pass_direct")
                influence_col.prop(cbk, "use_pass_indirect")
                influence_col.prop(cbk, "use_pass_color")
        
        # Output settings
        output_box = bake_box.box()
        output_box.scale_y = 0.95
        output_box.label(text="Output Settings:", icon='EXPORT')
        
        output_col = output_box.column(align=True)
        output_col.prop(cbk, "target")
        
        if cbk.target == 'IMAGE_TEXTURES':
            output_col.prop(cbk, "use_clear", text="Clear Image")
            
            # Margin settings
            margin_box = output_box.box()
            margin_box.scale_y = 0.9
            
            if (scene.MergeTextureBake_custom_bake_type == 'NORMAL' and cbk.normal_space == 'TANGENT') or scene.MergeTextureBake_custom_bake_type == 'UV':
                margin_box.prop(cbk, "margin", text="Size")
            else:
                margin_box.prop(cbk, "margin_type", text="Type")
                margin_box.prop(cbk, "margin", text="Size")
        
        # Bake info
        obj_count = len(scene.MergeTextureBake_selected_objects_list)
        info_box = bake_box.box()
        info_box.scale_y = 0.9
        
        if obj_count > 0:
            info_box.label(text=f"• Will bake {obj_count} objects with same texture")  # Removed icon
            info_box.label(text="• Creates UV map if it doesn't exist")  # Removed icon
            info_box.label(text="• Sets up texture nodes automatically")  # Removed icon
            info_box.label(text="• Uses modal operator for progress tracking")  # Removed icon
        else:
            info_box.label(text="• Add objects to the list first")  # Removed icon
        
        # Show bake counter if baking
        if hasattr(scene, 'MergeTextureBake_bake_counter') and scene.MergeTextureBake_bake_counter > 0:
            progress_box = bake_box.box()
            progress_box.scale_y = 1.05
            progress_box.label(text=f"Baked: {scene.MergeTextureBake_bake_counter} objects", icon='TIME')

    @staticmethod
    def _draw_material_setup(col):
        """Material setup section - Enhanced visual with operations from both tools"""
        scene = bpy.context.scene
        
        # Check if tools are available
        retopology_available = hasattr(scene, 'retopology_bake_settings')
        merge_texture_available = hasattr(scene, 'MergeTextureBake_selected_objects_list')
        
        # Create New Material with better grouping
        create_box = col.box()
        create_box.scale_y = 1.05
        
        create_box.label(text="Material Creation:")  # Removed icon
        
        action_box = create_box.box()
        action_box.scale_y = 0.95
        
        # Row 1: Basic material creation
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.add_principled_bsdf_setup", text="Create PBR Materials", icon='ADD')
        row.operator("nwn2.convert_to_principled", text="Convert Existing", icon='SHADING_RENDERED')
        
        # Row 2: Retopology material operations
        if retopology_available:
            retopology_row = action_box.row(align=True)
            retopology_row.scale_y = 1.1
            retopology_row.operator("retopology.setup_pbr", text="Setup PBR (Retopology)", icon='MATERIAL')
            retopology_row.operator("retopology.add_material_slot", text="Add Slot", icon='ADD')
        
        info_box = create_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Create: Organized Principled BSDF material from scratch")  # Removed icon
        info_box.label(text="• Convert: Automatically detects and connects texture types")  # Removed icon
        if retopology_available:
            info_box.label(text="• Setup PBR: Creates PBR material with image textures")  # Removed icon
            info_box.label(text="• Add Slot: Adds empty material slot to active object")  # Removed icon
        
        col.separator(factor=0.8)
        
        # Material Management section
        manage_box = col.box()
        manage_box.scale_y = 1.05
        
        manage_box.label(text="Material Management:", icon='TOOL_SETTINGS')
        
        # Show active material info
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            status_box = manage_box.box()
            status_box.scale_y = 0.9
            
            if obj.data.materials:
                mat = obj.data.materials[0]
                if mat:
                    status_box.label(text=f"Active material: {mat.name}")  # Removed icon
                    # Show material stats
                    stats_row = status_box.row()
                    stats_row.label(text=f"Nodes: {len(mat.node_tree.nodes)}" if mat.use_nodes else "No nodes")
                    stats_row.label(text=f"Users: {mat.users}")
                else:
                    status_box.label(text="Active: [Empty Slot]")  # Removed icon
            else:
                status_box.label(text="No materials assigned")  # Removed icon
        
        # Material management buttons
        action_box = manage_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        
        # Retopology clear materials
        if retopology_available:
            row.operator("retopology.clear_materials", icon='TRASH', text="Clear All")
        
        # Merge texture operations
        if merge_texture_available:
            row.operator("mergetexturebake.create_texture_for_materials", icon='IMAGE_DATA', text="Create Texture")
            row.operator("mergetexturebake.delete_texture_nodes", icon='TRASH', text="Delete Texture Nodes")
        
        # Override existing option (from retopology)
        if retopology_available:
            bake_settings = scene.retopology_bake_settings
            option_box = manage_box.box()
            option_box.scale_y = 0.9
            option_box.prop(bake_settings, "override_existing", 
                        text="Override Existing Material",
                        toggle=True,
                        icon='FILE_REFRESH' if bake_settings.override_existing else 'FILE_NEW')
            option_box.label(text="• When enabled, existing materials will be replaced")  # Removed icon
        
        col.separator(factor=0.8)
        
        # Texture & Material Tools section
        tools_box = col.box()
        tools_box.scale_y = 1.05
        
        tools_box.label(text="Texture & Material Tools:", icon='TOOL_SETTINGS')
        
        # Row 1: Material cleanup tools
        cleanup_row = tools_box.box()
        cleanup_row.scale_y = 0.95
        
        row = cleanup_row.row(align=True)
        row.scale_y = 1.1
        row.operator("material.clean_materials", text="Clean Unused Materials", icon='BRUSH_DATA')
        row.operator("material.reload_textures", text="Reload All Textures", icon='FILE_REFRESH')
        
        # Row 2: Merge texture specific tools
        if merge_texture_available:
            merge_tools_box = tools_box.box()
            merge_tools_box.scale_y = 0.95
            
            merge_tools_box.label(text="Multi-Object Texture Tools:", icon='IMAGE_DATA')
            
            merge_row = merge_tools_box.row(align=True)
            merge_row.scale_y = 1.1
            merge_row.operator("mergetexturebake.add_selected_object", icon='OBJECT_DATA', text="Add Objects")
            merge_row.operator("mergetexturebake.clear_selected_objects_list", icon='X', text="Clear List")
            
            # Show object count
            obj_count = len(scene.MergeTextureBake_selected_objects_list)
            count_box = merge_tools_box.box()
            count_box.scale_y = 0.9
            if obj_count > 0:
                count_box.label(text=f"{obj_count} object(s) in texture list")  # Removed icon
                count_box.label(text="• Use UV and Texture sections for operations")  # Removed icon
            else:
                count_box.label(text="No objects in texture list")  # Removed icon
                count_box.label(text="• Select mesh objects and click 'Add Objects'")  # Removed icon
        
        # Quick actions info
        info_box = tools_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="Quick Actions:")  # Removed icon
        info_box.label(text="• Clean Unused: Removes materials not assigned to any object")  # Removed icon
        info_box.label(text="• Reload Textures: Reloads all image textures from disk")  # Removed icon
        if merge_texture_available:
            info_box.label(text="• Add Objects: Adds selected mesh objects to texture list")  # Removed icon
            info_box.label(text="• Clear List: Removes all objects from texture list")  # Removed icon
        
        col.separator(factor=0.8)
        
        # Material Settings section
        settings_box = col.box()
        settings_box.scale_y = 1.05
        
        settings_box.label(text="Material Settings:", icon='SETTINGS')
        
        # Texture settings from merge texture tools
        if merge_texture_available:
            texture_settings = settings_box.box()
            texture_settings.scale_y = 0.95
            
            texture_settings.label(text="Texture Settings:", icon='IMAGE_DATA')
            
            tex_col = texture_settings.column(align=True)
            tex_col.prop(scene, "MergeTextureBake_texture_name", text="Texture Name")
            
            # Show duplicate warning
            if scene.MergeTextureBake_has_duplicate_texture_name:
                warning_row = tex_col.row()
                warning_row.alert = True
                warning_row.label(text="Texture name already exists")  # Removed icon
            
            dim_row = tex_col.row(align=True)
            dim_row.prop(scene, "MergeTextureBake_texture_width", text="Width")
            dim_row.prop(scene, "MergeTextureBake_texture_height", text="Height")
        
        # Render settings from retopology tools
        if retopology_available:
            render_settings = settings_box.box()
            render_settings.scale_y = 0.95
            
            render_settings.label(text="Render Settings:", icon='RENDER_STILL')
            
            render_col = render_settings.column(align=True)
            render_col.prop(scene.retopology_bake_settings, "bake_samples", text="Samples")
            render_col.prop(scene.retopology_bake_settings, "bake_width", text="Width")
            render_col.prop(scene.retopology_bake_settings, "bake_height", text="Height")

    @staticmethod
    def _draw_material_folders(col):
        """Material export folders section - Enhanced visual"""
        scene = bpy.context.scene
        
        # ONLY texture export folder - ONLY button, no text field
        folder_box = col.box()
        folder_box.scale_y = 1.05
        
        folder_box.label(text="Texture Export Folder:", icon='FILE_FOLDER')
        
        if hasattr(scene, 'dynamic_props'):
            row = folder_box.row(align=True)
            
            # Display current folder in an enhanced box
            export_dir = scene.dynamic_props.material_export_folder
            display_box = row.box()
            display_box.scale_y = 0.85
            if export_dir:
                # Display just the folder name
                display_name = os.path.basename(export_dir)
                if not display_name:
                    display_name = export_dir
                # Truncate if too long
                if len(display_name) > 30:
                    display_box.label(text=display_name[:27] + "...")
                else:
                    display_box.label(text=display_name)
            else:
                display_box.label(text="No folder selected")
            
            # Folder button with better visual
            row.operator("wm.select_export_folder", text="", icon='FILE_FOLDER')
            
            # Show current folder status with enhanced visuals
            if export_dir:
                abs_path = bpy.path.abspath(export_dir) if export_dir.startswith('//') else export_dir
                if os.path.isdir(abs_path):
                    status_box = folder_box.box()
                    status_box.scale_y = 0.9
                    status_box.label(text=f"Valid folder: {os.path.basename(abs_path)}")  # Removed icon
                else:
                    status_box = folder_box.box()
                    status_box.alert = True
                    status_box.scale_y = 0.9
                    status_box.label(text=f"Invalid folder path")  # Removed icon
        else:
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Dynamic properties not available")  # Removed icon
        
        col.separator(factor=0.8)
        
        # Export buttons with enhanced visual prominence
        export_box = col.box()
        export_box.scale_y = 1.05
        
        row = export_box.row(align=True)
        row.scale_y = 1.1
        row.operator("wm.export_textures", text="Export Textures", icon='EXPORT')
        row.operator("wm.export_model", text="Export Model", icon='EXPORT')
        
        col.separator(factor=0.8)
        
        # Note with enhanced styling
        note_box = col.box()
        note_box.scale_y = 0.95
        
        note_box.label(text="Note:")  # Removed icon
        note_box.label(text="• Model export folder is in the Model Tools tab")  # Removed icon
        note_box.label(text="• This tab is for texture/material export only")  # Removed icon

# =========================================================================
# ANIMATION WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_animation_workflow(layout):
        """Animation tools workflow guide - Enhanced visual"""
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Animation Workflow", icon='ANIM')
        
        # Import with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "animation_import", "Import Animations", 'IMPORT',
            "Import GR2 or FBX animation files with checkbox selection",
            lambda col: NWN2WorkflowGuides._draw_animation_import(col)
        )
        
        # Export with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "animation_export", "Export Animations", 'EXPORT',
            "Export animations to GR2 format",
            lambda col: NWN2WorkflowGuides._draw_animation_export(col)
        )
        
        # Management and Tools with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "animation_management", "Animation Management", 'ANIM_DATA',
            "Organize and manage animations",
            lambda col: NWN2WorkflowGuides._draw_animation_management(col)
        )

    @staticmethod
    def _draw_animation_import(col):
        """Animation import section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Check if animation_file_collection exists
        if not hasattr(scene, 'animation_file_collection'):
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Animation properties not initialized", icon='ERROR')
            row = error_box.row()
            row.scale_y = 1.1
            row.operator("wm.reload_scripts", text="Reload Scripts", icon='FILE_REFRESH')
            return
        
        # Directory selection - ONLY button, no text field
        col.label(text="Import Directory:", icon='FILE_FOLDER')
        row = col.row(align=True)
        
        # Display current folder in an enhanced box
        import_dir = scene.animation_import_directory
        box = row.box()
        box.scale_y = 0.85
        if import_dir:
            # Display just the folder name
            display_name = os.path.basename(import_dir)
            if not display_name:
                display_name = import_dir
            # Truncate if too long
            if len(display_name) > 30:
                box.label(text=display_name[:27] + "...")
            else:
                box.label(text=display_name)
        else:
            box.label(text="No folder selected")
        
        # Folder button with better visual
        row.operator("nwn2.select_animation_import_folder", text="", icon='FILE_FOLDER')
        
        # Show current folder status with enhanced visuals
        if import_dir:
            # Check if it's a valid directory
            abs_path = bpy.path.abspath(import_dir) if import_dir.startswith('//') else import_dir
            if os.path.isdir(abs_path):
                status_box = col.box()
                status_box.scale_y = 0.9
                status_box.label(text=f"✓ Valid folder: {os.path.basename(abs_path)}", icon='CHECKMARK')
            else:
                status_box = col.box()
                status_box.alert = True
                status_box.scale_y = 0.9
                status_box.label(text=f"✗ Invalid folder path", icon='ERROR')
        
        # Refresh and import all with better button styling
        row = col.row(align=True)
        row.scale_y = 1.1
        row.operator("anim.refresh_animation_file_list", text="Refresh File List", icon='FILE_REFRESH')
        row.operator("anim.import_all_animation_files", text="Import All Files", icon='IMPORT')
        
        # File list display
        file_count = len(scene.animation_file_collection)
        if file_count > 0:
            col.separator(factor=0.8)
            
            # File count and UI scale controls with better layout
            row = col.row(align=True)
            row.label(text=f"Found {file_count} files:", icon='FILE_BLANK')
            
            # UI Scale control on the right
            row_right = row.row(align=True)
            row_right.alignment = 'RIGHT'
            row_right.label(text="UI Scale:")
            row_right.prop(scene, "animation_ui_scale", text="", slider=True)
            
            # Selection controls with better button sizing
            row = col.row(align=True)
            row.scale_y = 1.05
            row.operator("anim.select_all_animation_files", text="Select All")
            row.operator("anim.deselect_all_animation_files", text="Deselect All")
            
            # Scrollable area for file list
            scroll_height = scene.animation_scroll_height
            if scroll_height < 1:
                scroll_height = 1
            
            # Calculate how many files to show based on scroll position and UI scale
            items_per_page = max(1, int(scroll_height))
            current_page = scene.animation_scroll_index
            total_pages = max(1, (file_count + items_per_page - 1) // items_per_page)
            
            # Clamp current page
            if current_page >= total_pages:
                current_page = total_pages - 1
                scene.animation_scroll_index = current_page
            
            start_idx = current_page * items_per_page
            end_idx = min(start_idx + items_per_page, file_count)
            
            # Scroll controls with enhanced visuals
            if file_count > items_per_page:
                scroll_row = col.row(align=True)
                scroll_row.alignment = 'CENTER'
                scroll_row.scale_y = 1.1
                
                # Previous page
                if current_page > 0:
                    prev_op = scroll_row.operator("nwn2.scroll_animation_list", text="", icon='TRIA_LEFT')
                    prev_op.direction = 'PREV'
                else:
                    scroll_row.label(text="", icon='TRIA_LEFT')
                
                # Page indicator with better styling
                scroll_row.label(text=f"Page {current_page + 1}/{total_pages} ({start_idx + 1}-{end_idx} of {file_count})")
                
                # Next page
                if current_page < total_pages - 1:
                    next_op = scroll_row.operator("nwn2.scroll_animation_list", text="", icon='TRIA_RIGHT')
                    next_op.direction = 'NEXT'
                else:
                    scroll_row.label(text="", icon='TRIA_RIGHT')
            
            # File list with adjustable UI scale
            ui_scale = scene.animation_ui_scale
            list_box = col.box()
            list_box.scale_y = 0.95
            
            for i in range(start_idx, end_idx):
                item = scene.animation_file_collection[i]
                # Check if selection_flags exists
                if hasattr(scene, 'animation_selection_flags'):
                    is_selected = scene.animation_selection_flags.get(item.name, False)
                else:
                    is_selected = False
                
                row_item = list_box.row(align=True)
                row_item.scale_y = ui_scale * 0.9
                
                # Selection toggle with better visual feedback
                toggle_op = row_item.operator("anim.toggle_file_selection", 
                                           text="", 
                                           icon='CHECKBOX_HLT' if is_selected else 'CHECKBOX_DEHLT',
                                           emboss=False)
                toggle_op.index = i
                
                # File info
                file_icon = 'ARMATURE_DATA' if getattr(item, 'file_type', '') == 'GR2' else 'FILE_3D'
                
                # Truncate filename if too long
                display_name = item.name
                if len(display_name) > 40:
                    display_name = display_name[:37] + "..."
                
                row_item.label(text=display_name, icon=file_icon)
                
                # File type on the right with subtle styling
                sub = row_item.row(align=True)
                sub.alignment = 'RIGHT'
                sub.scale_x = 0.8
                file_type = getattr(item, 'file_type', 'Unknown')
                sub.label(text=file_type)
            
            # Scroll height control with better layout
            if file_count > 5:
                col.separator(factor=0.5)
                row = col.row(align=True)
                row.label(text="Items per page:")
                row.prop(scene, "animation_scroll_height", text="", slider=True)
                row.label(text=f"(1-{min(20, file_count)})")
            
            # Import buttons with enhanced visual prominence
            if hasattr(scene, 'animation_selection_flags'):
                selected_count = sum(1 for item in scene.animation_file_collection 
                                   if scene.animation_selection_flags.get(item.name, False))
            else:
                selected_count = 0
            
            col.separator(factor=0.8)
            row = col.row(align=True)
            row.scale_y = 1.15
            row.operator("anim.import_single_animation_file", text="Import Active", icon='IMPORT')
            row.operator("anim.import_selected_animation_files", text=f"Import Checked ({selected_count})", icon='IMPORT')
            
            if selected_count > 0:
                status_box = col.box()
                status_box.scale_y = 0.9
                status_box.label(text=f"{selected_count} file(s) ready for import", icon='CHECKMARK')
        else:
            col.separator(factor=0.8)
            info_box = col.box()
            info_box.scale_y = 0.9
            info_box.label(text="No animation files found", icon='INFO')
            info_box.label(text="Set directory and click Refresh", icon='DOT')
        
        # Quick info with enhanced layout
        col.separator(factor=0.8)
        quick_info = col.box()
        quick_info.scale_y = 0.95
        quick_info.label(text="Quick Info:", icon='INFO')
        quick_info.label(text="• FBX: Universal animation format", icon='DOT')
        quick_info.label(text="• GR2: NWN2 native format", icon='DOT')
        quick_info.label(text="• Click checkboxes for multi-select", icon='DOT')
        quick_info.label(text="• Use UI Scale to adjust list item size", icon='DOT')

    @staticmethod
    def _draw_animation_export(col):
        """Animation export section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Check if required properties exist
        if not hasattr(scene, 'animation_export_directory'):
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Animation properties not initialized", icon='ERROR')
            return
        
        # Export folder - ONLY button, no text field
        folder_box = col.box()
        folder_box.scale_y = 1.05
        
        folder_box.label(text="Export Directory:", icon='FILE_FOLDER')
        row = folder_box.row(align=True)
        
        # Display current folder in an enhanced box
        export_dir = scene.animation_export_directory
        display_box = row.box()
        display_box.scale_y = 0.85
        if export_dir:
            # Display just the folder name
            display_name = os.path.basename(export_dir)
            if not display_name:
                display_name = export_dir
            # Truncate if too long
            if len(display_name) > 30:
                display_box.label(text=display_name[:27] + "...")
            else:
                display_box.label(text=display_name)
        else:
            display_box.label(text="No folder selected")
        
        # Folder button with better visual
        row.operator("nwn2.select_animation_export_folder", text="", icon='FILE_FOLDER')
        
        # Show current folder status with enhanced visuals
        if export_dir:
            abs_path = bpy.path.abspath(export_dir) if export_dir.startswith('//') else export_dir
            if os.path.isdir(abs_path):
                status_box = folder_box.box()
                status_box.scale_y = 0.9
                status_box.label(text=f"✓ Valid folder: {os.path.basename(abs_path)}", icon='CHECKMARK')
            else:
                status_box = folder_box.box()
                status_box.alert = True
                status_box.scale_y = 0.9
                status_box.label(text=f"✗ Invalid folder path", icon='ERROR')
        
        # Export name/suffix
        settings_box = col.box()
        settings_box.scale_y = 1.05
        
        settings_box.label(text="Export Settings:", icon='SETTINGS')
        if hasattr(scene, 'animation_suffix'):
            row = settings_box.row()
            row.scale_y = 1.1
            row.prop(scene, "animation_suffix", text="Export Name")
        else:
            error_box = settings_box.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Export Name property not available", icon='ERROR')
        
        # Check if we have animations loaded
        has_animations = hasattr(scene, 'animation_list_collection') and scene.animation_list_collection
        has_armatures = bpy.data.collections.get("Source Armature") is not None
        
        # Status with enhanced styling
        col.separator(factor=0.8)
        status_box = col.box()
        status_box.scale_y = 1.05
        
        if has_animations and has_armatures:
            status_box.label(text="✓ Ready to Export", icon='CHECKMARK')
            anim_count = len(scene.animation_list_collection)
            armature_collection = bpy.data.collections.get("Source Armature")
            armature_count = sum(1 for obj in armature_collection.objects if obj.type == 'ARMATURE') if armature_collection else 0
            
            stats_box = status_box.box()
            stats_box.scale_y = 0.9
            stats_row = stats_box.row()
            stats_row.label(text=f"{anim_count} Animations", icon='ACTION')
            stats_row.label(text=f"{armature_count} Armatures", icon='ARMATURE_DATA')
        else:
            status_box.label(text="Setup Required", icon='ERROR')
            info_box = status_box.box()
            info_box.scale_y = 0.9
            if not has_animations:
                info_box.label(text="• Import animations first", icon='DOT')
            if not has_armatures:
                info_box.label(text="• Check Source Armature collection", icon='DOT')
        
        # Export operations with enhanced visual grouping
        col.separator(factor=0.8)
        col.label(text="Export Operations:", icon='EXPORT')
        
        if has_animations:
            # Primary operations with better button sizing
            primary_box = col.box()
            primary_box.scale_y = 1.05
            
            primary_row = primary_box.row(align=True)
            primary_row.scale_y = 1.2
            primary_row.operator("anim.bake_and_extract_operator", text="Bake & Export", icon='RENDER_ANIMATION')
            primary_row.operator("anim.extract_operator", text="Export Only", icon='EXPORT')
            
            # Secondary operations with better grouping
            secondary_box = col.box()
            secondary_box.scale_y = 1.05
            
            secondary_row = secondary_box.row(align=True)
            secondary_row.scale_y = 1.1
            secondary_row.operator("anim.just_bake_operator", text="Bake Only", icon='MOD_PHYSICS')
            secondary_row.operator("anim.export_all_animations", text="Export All", icon='FILE_FOLDER')
            
            # Instructions with enhanced layout
            help_box = col.box()
            help_box.scale_y = 1.05
            
            help_box.label(text="Quick Guide:", icon='INFO')
            
            help_col = help_box.box()
            help_col.scale_y = 0.9
            help_col.label(text="• Bake & Export: Full process (recommended)", icon='DOT')
            help_col.label(text="• Export Only: Skip baking", icon='DOT')
            help_col.label(text="• Bake Only: Convert to keyframes", icon='DOT')
            help_col.label(text="• Export All: Batch process all animations", icon='DOT')
        else:
            info_box = col.box()
            info_box.scale_y = 0.9
            info_box.label(text="No animations to export", icon='INFO')
        
        # Race collection check with enhanced warning styling
        races_collection = bpy.data.collections.get("RACES")
        if not races_collection:
            warning_box = col.box()
            warning_box.alert = True
            warning_box.scale_y = 0.9
            warning_box.label(text="⚠️ RACES Collection Required", icon='ERROR')
            warning_box.label(text="Create RACES collection with target armatures", icon='DOT')

    @staticmethod
    def _draw_animation_management(col):
        """Animation management section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Prefix renaming with better grouping
        rename_box = col.box()
        rename_box.scale_y = 1.05
        
        rename_box.label(text="Rename Animations:", icon='SORTALPHA')
        
        rename_col = rename_box.box()
        rename_col.scale_y = 0.95
        
        if hasattr(scene, 'dynamic_props'):
            row = rename_col.row()
            row.scale_y = 1.1
            row.prop(scene.dynamic_props, "my_text", text="Prefix")
        
        row = rename_col.row()
        row.scale_y = 1.1
        row.operator("anim.apply_prefix", text="Apply Prefix to All Animations", icon='SORTALPHA')
        
        # Display mode toggle with better styling
        if hasattr(scene, 'display_all_animations'):
            mode_box = col.box()
            mode_box.scale_y = 1.05
            
            mode_row = mode_box.row()
            mode_row.scale_y = 1.1
            mode_row.operator("anim.toggle_display_mode", 
                            text="Full Names" if scene.display_all_animations else "Filtered Names",
                            icon='ARMATURE_DATA' if scene.display_all_animations else 'ACTION')
            mode_row.label(text="Display Mode")
        
        # Animation list with enhanced visual container
        if hasattr(scene, 'animation_list_collection') and scene.animation_list_collection:
            list_box = col.box()
            list_box.scale_y = 1.05
            
            list_box.label(text="Loaded Animations:", icon='ANIM_DATA')
            
            try:
                from .animation_tools import ANIM_UL_actions_list
                list_area = list_box.box()
                list_area.scale_y = 0.95
                list_area.template_list(
                    "ANIM_UL_actions_list", 
                    "", 
                    scene, 
                    "animation_list_collection",
                    scene, 
                    "animation_list_index",
                    rows=6
                )
            except ImportError:
                # Fallback: simple list display
                fallback_box = list_box.box()
                fallback_box.scale_y = 0.95
                for i, item in enumerate(scene.animation_list_collection):
                    row = fallback_box.row()
                    if i == getattr(scene, 'animation_list_index', 0):
                        row.label(text=f"▶ {item.name}", icon='ACTION')
                    else:
                        row.label(text=f"  {item.name}", icon='ACTION')
            
            # Current animation info with enhanced grouping
            if hasattr(scene, 'animation_list_index'):
                if 0 <= scene.animation_list_index < len(scene.animation_list_collection):
                    current_item = scene.animation_list_collection[scene.animation_list_index]
                    
                    try:
                        from .animation_tools import safe_get_display_name, safe_get_full_name, safe_get_action
                        display_name = safe_get_display_name(current_item)
                        full_name = safe_get_full_name(current_item)
                        action = safe_get_action(current_item)
                    except ImportError:
                        display_name = getattr(current_item, 'display_name', getattr(current_item, 'name', 'Unknown'))
                        full_name = getattr(current_item, 'full_name', display_name)
                        action = getattr(current_item, 'action', None)
                    
                    # Current animation section
                    current_box = col.box()
                    current_box.scale_y = 1.05
                    
                    current_box.label(text="Current Animation:", icon='ACTION')
                    
                    # Apply button with enhanced prominence
                    apply_box = current_box.box()
                    apply_box.scale_y = 0.95
                    
                    apply_row = apply_box.row()
                    apply_row.scale_y = 1.5
                    apply_row.operator("anim.apply_animation_to_armatures", 
                                    text=f"Apply '{display_name}'", 
                                    icon='PLAY')
                    
                    # Animation details with better grouping
                    if action:
                        details_box = current_box.box()
                        details_box.scale_y = 0.95
                        
                        frame_range = getattr(action, 'frame_range', (1, 1))
                        frame_count = int(frame_range[1] - frame_range[0]) + 1
                        details_row = details_box.row()
                        details_row.label(text=f"Frames: {int(frame_range[0])}-{int(frame_range[1])}")
                        details_row.label(text=f"Length: {frame_count}")
        
        # Cleanup tools with enhanced visual grouping
        col.separator(factor=0.8)
        tools_box = col.box()
        tools_box.scale_y = 1.05
        
        tools_box.label(text="Animation Tools:", icon='TOOL_SETTINGS')
        
        cleanup_box = tools_box.box()
        cleanup_box.scale_y = 0.95
        
        cleanup_box.label(text="Cleanup Tools:", icon='TRASH')
        
        cleanup_col = cleanup_box.box()
        cleanup_col.scale_y = 0.9
        
        row = cleanup_col.row(align=True)
        row.scale_y = 1.1
        row.operator("anim.delete_baked_animations", text="Delete Baked Animations", icon='TRASH')
        row.operator("anim.cleanup_collections", text="Cleanup Collections", icon='OUTLINER')

# =========================================================================
# RETARGETING WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_retargeting_workflow(layout):
        """Retargeting tools workflow guide - Enhanced visual"""
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Animation Retargeting", icon='ARMATURE_DATA')
        
        # Tab Selection with enhanced styling
        if hasattr(scene, 'dynamic_props'):
            tab_box = box.box()
            tab_box.scale_y = 1.05
            row = tab_box.row()
            row.prop(scene.dynamic_props, "current_tab", expand=True)
        
        col = box.column(align=True)
        
        if hasattr(scene, 'dynamic_props'):
            # Dynamic Retargeting Tab
            if scene.dynamic_props.current_tab == 'dynamic_retargeting':
                NWN2WorkflowGuides._draw_collapsible_section(col, "retarget_connect", "Connect Armatures", 'LINKED',
                    "Link source and target armatures",
                    lambda col: NWN2WorkflowGuides._draw_retarget_connect(col)
                )
                
                NWN2WorkflowGuides._draw_collapsible_section(col, "retarget_manage", "Manage Constraints", 'CONSTRAINT',
                    "Enable/disable constraints for editing",
                    lambda col: NWN2WorkflowGuides._draw_retarget_manage(col)
                )
            
            # Source Constraints Tab - VERTEX TOOLS FIRST
            elif scene.dynamic_props.current_tab == 'source_constraints':
                # VERTEX SNAPPING TOOLS - NOW FIRST
                NWN2WorkflowGuides._draw_collapsible_section(col, "source_vertex", "Vertex Snapping Tools", 'VERTEXSEL',
                    "Create bone vertices for precise snapping",
                    lambda col: NWN2WorkflowGuides._draw_vertex_snapping(col, scene)
                )
                
                NWN2WorkflowGuides._draw_collapsible_section(col, "source_bones", "Bone Selection", 'BONE_DATA',
                    "Select bones to include in retargeting",
                    lambda col: NWN2WorkflowGuides._draw_source_bones(col, scene)
                )
                
                NWN2WorkflowGuides._draw_collapsible_section(col, "source_controls", "Control Rig", 'EMPTY_DATA',
                    "Generate control system for selected bones",
                    lambda col: NWN2WorkflowGuides._draw_source_controls(col)
                )
            
            # Target Constraints Tab
            elif scene.dynamic_props.current_tab == 'target_constraints':
                NWN2WorkflowGuides._draw_collapsible_section(col, "target_rotation", "Rotation System", 'ORIENTATION_GIMBAL',
                    "Create rotation control system",
                    lambda col: NWN2WorkflowGuides._draw_target_rotation(col)
                )
                
                NWN2WorkflowGuides._draw_collapsible_section(col, "target_parenting", "Parent System", 'LINKED',
                    "Connect rotation system to control system",
                    lambda col: NWN2WorkflowGuides._draw_target_parenting(col)
                )

    @staticmethod
    def _draw_retarget_connect(col):
        """Retarget connect section - Enhanced visual"""
        connect_box = col.box()
        connect_box.scale_y = 1.05
        
        row = connect_box.row()
        row.scale_y = 1.1
        row.operator("object.connect_armatures", text="Connect Source & Target Armatures", icon='CONSTRAINT_BONE')
        
        info_box = connect_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Select both armatures (source first, then target)", icon='DOT')
        info_box.label(text="• Adds Copy Rotation and Location constraints", icon='DOT')

    @staticmethod
    def _draw_retarget_manage(col):
        """Retarget manage section - Enhanced visual"""
        manage_box = col.box()
        manage_box.scale_y = 1.05
        
        row = manage_box.row()
        row.scale_y = 1.1
        row.operator("object.toggle_selected_bone_constraints", text="Toggle Selected Bone Constraints", icon='HIDE_ON')
        
        if hasattr(bpy.context.scene, 'selected_armature'):
            armature_box = manage_box.box()
            armature_box.scale_y = 0.95
            
            row = armature_box.row()
            row.scale_y = 1.1
            row.prop(bpy.context.scene, "selected_armature", text="Select Armature")
            
            selected_armature = bpy.context.scene.objects.get(bpy.context.scene.selected_armature)
            if selected_armature and selected_armature.type == 'ARMATURE':
                prefix_set = set()
                for bone in selected_armature.data.bones:
                    for constraint in selected_armature.pose.bones[bone.name].constraints:
                        prefix = constraint.name.split('_')[0]
                        prefix_set.add(prefix)
                
                if prefix_set:
                    prefix_box = manage_box.box()
                    prefix_box.scale_y = 0.95
                    
                    prefix_box.label(text="Toggle constraints by prefix:", icon='FILTER')
                    
                    for prefix in prefix_set:
                        row = prefix_box.row()
                        row.scale_y = 1.05
                        op = row.operator("object.toggle_constraints", 
                                        text=f"Toggle {prefix} Constraints", 
                                        icon='CHECKBOX_HLT')
                        op.prefix = prefix
        
        # Quick Actions with enhanced styling
        quick_box = col.box()
        quick_box.scale_y = 1.05
        
        row = quick_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.refresh_bone_list", text="Refresh Bone List", icon='FILE_REFRESH')
        row.operator("object.select_bones_from_pose_mode", text="Sync from Pose Mode", icon='BONE_DATA')
        
        # Additional bone list utilities with better grouping
        util_box = col.box()
        util_box.scale_y = 1.05
        
        util_box.label(text="Bone List Utilities:", icon='BONE_DATA')
        
        action_box = util_box.box()
        action_box.scale_y = 0.95
        
        util_row = action_box.row(align=True)
        util_row.scale_y = 1.1
        util_row.operator("object.select_bones_by_list", text="Select by List", icon='RESTRICT_SELECT_OFF')
        util_row.operator("object.select_all_list_bones", text="Select All List", icon='SELECT_SET')
        
        info_box = action_box.box()
        info_box.scale_y = 0.9
        
        row = info_box.row()
        row.scale_y = 1.1
        row.operator("object.highlight_bone_list_selection", text="Highlight Bone Selection", icon='HIDE_OFF')
        
        info_box.label(text="• Visualizes which bones are selected in the list", icon='DOT')

    @staticmethod
    def _draw_vertex_snapping(col, scene):
        """Vertex snapping section - Enhanced visual"""
        # Vertex Size Setting with better layout
        if hasattr(scene, 'dynamic_props'):
            size_box = col.box()
            size_box.scale_y = 1.05
            
            size_row = size_box.row()
            size_row.label(text="Vertex Size:")
            size_row.prop(scene.dynamic_props, "vertex_size", text="", slider=True)
        
        # Create Bone Vertices with better grouping
        create_box = col.box()
        create_box.scale_y = 1.05
        
        create_box.label(text="Create Bone Vertices", icon='MESH_DATA')
        
        action_box = create_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.create_bone_vertices", text="Create Vertices", icon='ADD')
        row.operator("object.delete_bone_vertices", text="Delete Vertices", icon='TRASH')
        
        info_box = create_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Creates vertices at bone head positions", icon='DOT')
        info_box.label(text="• Useful for precise control empty placement", icon='DOT')
        
        # Note about bone list with enhanced styling
        note_box = create_box.box()
        note_box.scale_y = 0.9
        
        note_box.label(text="Note about Bone Selection:", icon='INFO')
        note_box.label(text="• Uses bone list selection from 'Bone Selection' section", icon='DOT')
        note_box.label(text="• Mark bones as YES in the bone list below", icon='DOT')
        note_box.label(text="• Create vertices first, then use bone selection tools", icon='DOT')
        
        # Snap Empties to Vertices with better grouping
        snap_box = col.box()
        snap_box.scale_y = 1.05
        
        snap_box.label(text="Snap Empties", icon='SNAP_VERTEX')
        
        action_box = snap_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("object.snap_empties_to_vertices", text="Snap Empties to Vertices", icon='SNAP_ON')
        
        info_box = snap_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Snaps control empties to bone vertices", icon='DOT')
        info_box.label(text="• Requires: Active bone vertex mesh", icon='DOT')
        info_box.label(text="• Useful after creating control empties", icon='DOT')

    @staticmethod
    def _draw_source_bones(col, scene):
        """Bone selection section - Enhanced visual"""
        # Quick actions row with better styling
        quick_box = col.box()
        quick_box.scale_y = 1.05
        
        quick_row = quick_box.row(align=True)
        quick_row.scale_y = 1.1
        quick_row.operator("object.refresh_bone_list", text="Refresh", icon='FILE_REFRESH')
        quick_row.operator("object.select_bones_from_pose_mode", text="Sync from Pose", icon='BONE_DATA')
        quick_row.operator("object.select_bones_by_list", text="Select in Pose", icon='RESTRICT_SELECT_OFF')
        
        # Selection controls with better grouping
        select_box = col.box()
        select_box.scale_y = 1.05
        
        row = select_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.select_all_bones", text="Select All", icon='SELECT_SET')
        row.operator("object.deselect_all_bones", text="Deselect All", icon='SELECT_EXTEND')
        
        # Filter section with enhanced layout
        if hasattr(scene.dynamic_props, 'filter_bone_names'):
            filter_box = col.box()
            filter_box.scale_y = 1.05
            
            filter_box.label(text="Bone Filter:", icon='FILTER')
            
            control_box = filter_box.box()
            control_box.scale_y = 0.95
            
            row = control_box.row()
            row.scale_y = 1.1
            row.prop(scene.dynamic_props, "filter_bone_names", text="Filter Names")
            
            row = control_box.row()
            row.scale_y = 1.1
            row.prop(scene.dynamic_props, "filter_action", text="Action")
            
            row = control_box.row()
            row.scale_y = 1.1
            row.operator("object.apply_bone_filter", text="Apply Filter", icon='CHECKMARK')
            
            info_box = filter_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Comma-separated names (arm,leg,hand)", icon='DOT')
        
        # Bone list display with enhanced container
        if (hasattr(scene.dynamic_props, 'bone_list') and 
            len(scene.dynamic_props.bone_list) > 0):
            
            list_box = col.box()
            list_box.scale_y = 1.05
            
            list_box.label(text="Bone List:", icon='BONE_DATA')
            
            # Draw the bone list
            list_area = list_box.box()
            list_area.scale_y = 0.95
            list_area.template_list("BONE_UL_List", "", 
                                scene.dynamic_props, "bone_list",
                                scene.dynamic_props, "bone_list_index", 
                                rows=6)
            
            # Show selection status with better styling
            selected_count = sum(1 for item in scene.dynamic_props.bone_list 
                               if item.include_bone == 'YES')
            total_count = len(scene.dynamic_props.bone_list)
            
            status_box = list_box.box()
            status_box.scale_y = 0.9
            
            status_row = status_box.row()
            status_row.label(text=f"Selected: {selected_count} of {total_count} bones", icon='BONE_DATA')
            
            # Add highlight button with enhanced styling
            highlight_box = list_box.box()
            highlight_box.scale_y = 0.95
            
            row = highlight_box.row()
            row.scale_y = 1.1
            row.operator("object.highlight_bone_list_selection", 
                        text="Highlight Selected Bones", 
                        icon='HIDE_OFF')
            
            info_box = highlight_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Creates temporary empties at bone locations", icon='DOT')
            info_box.label(text="• Selection affects vertex creation above", icon='DOT')
            
        else:
            empty_box = col.box()
            empty_box.scale_y = 1.05
            
            empty_box.label(text="No bones in list", icon='INFO')
            
            action_box = empty_box.box()
            action_box.scale_y = 0.95
            
            row = action_box.row()
            row.scale_y = 1.1
            row.operator("object.refresh_bone_list", text="Refresh Bone List", icon='FILE_REFRESH')
            
            info_box = empty_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Select an armature and click Refresh", icon='DOT')

    @staticmethod
    def _draw_source_controls(col):
        """Control rig section - Enhanced visual"""
        # Control empties creation with better grouping
        create_box = col.box()
        create_box.scale_y = 1.05
        
        create_box.label(text="Create Control Empties", icon='CUBE')
        
        if hasattr(bpy.context.scene, 'dynamic_props'):
            prefix_box = create_box.box()
            prefix_box.scale_y = 0.95
            
            row = prefix_box.row()
            row.scale_y = 1.1
            row.prop(bpy.context.scene.dynamic_props, "prefix_constraints", text="Constraint Prefix")
        
        action_box = create_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.create_control_empties", text="Create Control Empties", icon='CUBE')
        row.operator("object.add_constraint_to_nearest_bone", text="Sync to Bones", icon='CONSTRAINT')
        
        info_box = create_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Creates cube empties in 'RiggingConstraints' collection", icon='DOT')
        info_box.label(text="• Adds copy transforms constraints", icon='DOT')
        info_box.label(text="• Uses bone list selection from above", icon='DOT')
        info_box.label(text="• Use vertex snapping for precise placement", icon='DOT')

    @staticmethod
    def _draw_target_rotation(col):
        """Rotation system section - Enhanced visual"""
        # Rotation empties creation - MAIN OPTION
        create_box = col.box()
        create_box.scale_y = 1.05
        
        create_box.label(text="Create Rotation Empties", icon='SPHERE')
        
        if hasattr(bpy.context.scene, 'dynamic_props'):
            prefix_box = create_box.box()
            prefix_box.scale_y = 0.95
            
            row = prefix_box.row()
            row.scale_y = 1.1
            row.prop(bpy.context.scene.dynamic_props, "prefix_empties", text="Empty Prefix")
        
        action_box = create_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.create_rotation_empties", text="Create Rotation Empties", icon='SPHERE')
        
        info_box = create_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Creates sphere empties in 'RotationEmpties' collection", icon='DOT')
        info_box.label(text="• Adds copy rotation constraints to bones", icon='DOT')
        
        # NEW: Bone list version - ALTERNATIVE OPTION
        alt_box = col.box()
        alt_box.scale_y = 1.05
        
        alt_box.label(text="Alternative: Create from Bone List", icon='TOOL_SETTINGS')
        
        action_box = alt_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("object.create_rotation_empties_with_bone_list", 
                    text="Create Rotation Empties (Bone List)", 
                    icon='SPHERE')
        
        info_box = alt_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Only creates empties for bones selected in bone list", icon='DOT')
        info_box.label(text="• Useful for partial rig setups", icon='DOT')
        info_box.label(text="• Use with vertex snapping for precise placement", icon='DOT')

    @staticmethod
    def _draw_target_parenting(col):
        """Parent system section - Enhanced visual"""
        # Parenting section with better grouping
        parent_box = col.box()
        parent_box.scale_y = 1.05
        
        parent_box.label(text="Parent System", icon='LINKED')
        
        action_box = parent_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("object.parent_generated_empties", text="Parent Rotation to Controls", icon='LINK_BLEND')
        
        info_box = parent_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Links rotation empties to control empties", icon='DOT')
        
        # Constraint toggling with better grouping
        toggle_box = col.box()
        toggle_box.scale_y = 1.05
        
        toggle_box.label(text="Constraint Management", icon='CONSTRAINT')
        
        action_box = toggle_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("object.toggle_selected_bone_constraints", text="Toggle Selected", icon='HIDE_ON')
        row.operator("object.toggle_constraints", text="Toggle by Prefix", icon='HIDE_OFF')
        
        info_box = toggle_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Enable/disable constraints for editing", icon='DOT')
        
        # Prefix management with enhanced styling
        prefix_box = col.box()
        prefix_box.scale_y = 1.05
        
        prefix_box.label(text="Prefix Management", icon='SORTALPHA')
        
        action_box = prefix_box.box()
        action_box.scale_y = 0.95
        
        prefix_row = action_box.row(align=True)
        prefix_row.scale_y = 1.1
        prefix_row.operator("object.add_prefix_to_constraints", text="Prefix Constraints", icon='TEXT')
        prefix_row.operator("object.add_prefix_to_empties", text="Prefix Empties", icon='TEXT')
        
        info_box = prefix_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Add prefixes to existing constraints/empties", icon='DOT')
        info_box.label(text="• Useful for organizing multiple retarget setups", icon='DOT')

# =========================================================================
# TWODA WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_twoda_workflow(layout):
        """2DA tools workflow guide - Enhanced visual"""
        if not TWODA_TOOLS_AVAILABLE:
            error_box = layout.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="2DA Tools Not Available", icon='ERROR')
            error_box.label(text="Please ensure twoda_tools.py is properly registered", icon='INFO')
            return
            
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="NWN2 2DA File Editor", icon='TEXT')
        
        # File Operations and Editing with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "twoda_files", "Load and Manage 2DA Files", 'FILE_FOLDER',
            "Load and manage 2DA files",
            lambda col: NWN2WorkflowGuides._draw_twoda_files(col, scene)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "twoda_editor", "File Editor", 'TEXT',
            "Edit 2DA file content",
            lambda col: NWN2WorkflowGuides._draw_twoda_editor(col, scene)
        )

    @staticmethod
    def _draw_twoda_files(col, scene):
        """2DA files section - Enhanced visual"""
        # Load 2DA Files with better grouping
        load_box = col.box()
        load_box.scale_y = 1.05
        
        load_box.label(text="Load 2DA Files:", icon='IMPORT')
        
        action_box = load_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("twoda.select_folder", text="Load 2DA Files from Folder", icon='IMPORT')
        
        info_box = load_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Loads: placeables.2da, appearance.2da, wingmodel.2da, tailmodel.2da, baseitems.2da", icon='DOT')
        info_box.label(text="• Automatically detects supported files in selected folder", icon='DOT')
        
        col.separator(factor=0.8)
        
        # File Management with enhanced layout
        manage_box = col.box()
        manage_box.scale_y = 1.05
        
        manage_box.label(text="File Management:", icon='FILE_TICK')
        
        action_box = manage_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("twoda.apply_changes", text="Save Changes", icon='FILE_TICK')
        row.operator("twoda.undo_changes", text="Undo Changes", icon='LOOP_BACK')
        
        info_box = manage_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Save: Writes all changes to the 2DA files", icon='DOT')
        info_box.label(text="• Undo: Reloads original files (loses unsaved changes)", icon='DOT')
        
        # Display loaded 2da files status with enhanced layout
        col.separator(factor=0.8)
        status_box = col.box()
        status_box.scale_y = 1.05
        
        status_box.label(text="Loaded 2DA Files:", icon='LINENUMBERS_ON')
        
        if hasattr(scene, 'twoda_active_tab'):
            # Show status for all file types
            file_types = [
                ('placeables', 'Placeables', 'CUBE'),
                ('appearance', 'Appearance', 'ARMATURE_DATA'), 
                ('wingmodel', 'Wing Models', 'MOD_ARMATURE'),
                ('tailmodel', 'Tail Models', 'MOD_ARMATURE'),
                ('baseitem', 'Base Items', 'SHADERFX')
            ]
            
            for file_type, display_name, icon in file_types:
                file_data = NWN2WorkflowGuides.safe_get_file_data(scene, file_type)
                file_box = status_box.box()
                file_box.scale_y = 0.95
                
                status_row = file_box.row()
                
                if file_data and getattr(file_data, 'file_loaded', False):
                    config = TwoDAConstants.get_config(file_type)
                    filename = config.get("filename", "Unknown") if config else "Unknown"
                    row_count = len(file_data.rows) if hasattr(file_data, 'rows') else 0
                    
                    status_row.label(text=f"✓ {display_name}", icon=icon)
                    status_row.label(text=f"{filename} ({row_count} rows)")
                else:
                    status_row.label(text=f"✗ {display_name}", icon=icon)
                    status_row.label(text="Not loaded")

    @staticmethod
    def _draw_twoda_editor(col, scene):
        """2DA editor section - Enhanced visual"""
        # FILE TYPE SELECTION moved to TOP
        type_box = col.box()
        type_box.scale_y = 1.05
        
        type_box.label(text="Select File Type:", icon='FILE_BLEND')
        if hasattr(scene, 'twoda_active_tab'):
            type_area = type_box.box()
            type_area.scale_y = 0.95
            type_area.prop(scene, "twoda_active_tab", expand=True)
        
        # Show current file status
        active_tab = scene.twoda_active_tab if hasattr(scene, 'twoda_active_tab') else 'placeables'
        file_data = NWN2WorkflowGuides.safe_get_file_data(scene, active_tab)
        
        status_box = col.box()
        status_box.scale_y = 1.05
        
        if file_data and file_data.file_loaded:
            config = TwoDAConstants.get_config(active_tab)
            filename = config.get("filename", "Unknown") if config else "Unknown"
            
            status_row = status_box.row()
            status_row.label(text=f"✓ Editing: {filename}", icon='CHECKMARK')
            status_row.label(text=f"Rows: {len(file_data.rows)}")
        else:
            # Show which file types are loaded
            loaded_files = []
            for file_type in ['placeables', 'appearance', 'wingmodel', 'tailmodel', 'baseitem']:
                file_data_check = NWN2WorkflowGuides.safe_get_file_data(scene, file_type)
                if file_data_check and file_data_check.file_loaded:
                    config = TwoDAConstants.get_config(file_type)
                    if config:
                        loaded_files.append(config.get("filename", file_type))
            
            if loaded_files:
                status_box.label(text=f"Loaded: {', '.join(loaded_files)}", icon='INFO')
                status_box.label(text=f"Select a loaded file type above", icon='DOT')
            else:
                status_box.label(text="No 2DA files loaded", icon='INFO')
                status_box.label(text="Use 'Load 2DA Files' to begin editing", icon='DOT')
        
        # FILE CONTENT DISPLAY - Only show if file is loaded
        if file_data and file_data.file_loaded and hasattr(file_data, 'rows') and file_data.rows:
            col.separator(factor=0.8)
            
            content_box = col.box()
            content_box.scale_y = 1.05
            
            content_box.label(text="File Content:", icon='TEXT')
            
            # Create a proper list layout
            list_box = content_box.box()
            list_box.scale_y = 0.95
            
            # Show current selection info with better styling
            if 0 <= file_data.active_index < len(file_data.rows):
                active_row = file_data.rows[file_data.active_index]
                icon, display_attr = TwoDAConstants.get_display_attributes(active_tab)
                display_value = getattr(active_row, display_attr, "****")
                
                selected_box = list_box.box()
                selected_box.scale_y = 0.9
                
                row_header = selected_box.row()
                row_header.label(text="CURRENTLY SELECTED ROW:", icon='RESTRICT_SELECT_OFF')
                row_info = selected_box.row()
                row_info.label(text=f"Row {file_data.active_index}: {display_value}", icon=icon)
            
            # List display
            rows = min(8, len(file_data.rows))
            list_area = list_box.box()
            list_area.scale_y = 0.9
            list_area.template_list(
                "NWN2_UL_2DAList", 
                "", 
                file_data, 
                "rows",
                file_data, 
                "active_index",
                rows=rows
            )
            
            # ROW OPERATIONS with enhanced button styling
            ops_box = list_box.box()
            ops_box.scale_y = 0.95
            
            row_ops = ops_box.row(align=True)
            row_ops.scale_y = 1.1
            row_ops.operator("twoda.add_row", text="Add New Row", icon='ADD')
            row_ops.operator("twoda.remove_row", text="Remove Selected", icon='REMOVE')
            row_ops.operator("twoda.export_file", text="Export File", icon='EXPORT')
            
            info_box = list_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Add Row: Creates new empty row at the end", icon='DOT')
            info_box.label(text="• Remove Row: Deletes the currently selected row", icon='DOT')
            info_box.label(text="• Export: Saves current state to 2DA file", icon='DOT')
            
            # Navigation help with better grouping
            nav_box = list_box.box()
            nav_box.scale_y = 0.9
            
            nav_box.label(text="Navigation:", icon='VIEWZOOM')
            nav_help = nav_box.box()
            nav_help.scale_y = 0.9
            nav_row = nav_help.row()
            nav_row.label(text="• Filter: Type in search box", icon='DOT')
            nav_row.label(text="• Navigate: Use arrow buttons", icon='DOT')
            
            col.separator(factor=0.8)
        
        # OBJECT SYNCHRONIZATION with enhanced visual grouping
        # Only show if file is loaded
        if file_data and file_data.file_loaded:
            sync_box = col.box()
            sync_box.scale_y = 1.05
            
            sync_box.label(text="Object Synchronization:", icon='LINKED')
            
            if file_data:
                sync_active = getattr(file_data, 'sync_active', False)
                
                if sync_active:
                    # Active sync status with enhanced warning styling
                    active_box = sync_box.box()
                    active_box.alert = True
                    active_box.scale_y = 0.95
                    
                    status_row = active_box.row()
                    last_sync = getattr(file_data, 'last_sync_name', 'Unknown')
                    status_row.label(text=f"ACTIVE SYNC: {last_sync}", icon='RESTRICT_SELECT_ON')
                    
                    # Sync instructions with better grouping
                    help_box = sync_box.box()
                    help_box.scale_y = 0.95
                    
                    help_box.label(text="Auto-sync is ACTIVE:", icon='INFO')
                    help_info = help_box.box()
                    help_info.scale_y = 0.9
                    help_info.label(text="• Changes to selected objects update 2DA automatically", icon='DOT')
                    help_info.label(text="• Object selection changes are tracked in real-time", icon='DOT')
                    help_info.label(text="• Deactivate to stop automatic updates", icon='DOT')
                    
                    # Deactivate sync button with enhanced styling
                    deactivate_box = sync_box.box()
                    deactivate_box.scale_y = 0.95
                    
                    row = deactivate_box.row()
                    row.scale_y = 1.1
                    deactivate_op = row.operator("twoda.deactivate_sync", text="Deactivate Auto-Sync", icon='RESTRICT_SELECT_OFF')
                    deactivate_op.file_type = active_tab
                else:
                    # Sync activation buttons with better grouping
                    activate_box = sync_box.box()
                    activate_box.scale_y = 0.95
                    
                    activate_box.label(text="Activate Auto-Sync:", icon='RESTRICT_SELECT_ON')
                    
                    # Single sync button based on file type
                    sync_area = activate_box.box()
                    sync_area.scale_y = 0.9
                    
                    if active_tab == 'placeables':
                        row = sync_area.row()
                        row.scale_y = 1.1
                        row.operator("twoda.sync_placeable", text="Sync Placeable Objects", icon='CUBE')
                        sync_area.label(text="• Select MESH objects to sync with placeables", icon='DOT')
                    elif active_tab == 'appearance':
                        row = sync_area.row()
                        row.scale_y = 1.1
                        row.operator("twoda.sync_appearance", text="Sync Appearance Data", icon='ARMATURE_DATA')
                        sync_area.label(text="• Select ARMATURE objects to sync with appearance", icon='DOT')
                    elif active_tab == 'wingmodel':
                        row = sync_area.row()
                        row.scale_y = 1.1
                        row.operator("twoda.sync_wingmodel", text="Sync Wing Models", icon='MOD_ARMATURE')
                        sync_area.label(text="• Select 2 ARMATURES + 1 MESH for wing models", icon='DOT')
                    elif active_tab == 'tailmodel':
                        row = sync_area.row()
                        row.scale_y = 1.1
                        row.operator("twoda.sync_tailmodel", text="Sync Tail Models", icon='MOD_ARMATURE')
                        sync_area.label(text="• Select 2 ARMATURES + 1 MESH for tail models", icon='DOT')
                    elif active_tab == 'baseitem':
                        row = sync_area.row()
                        row.scale_y = 1.1
                        row.operator("twoda.sync_baseitem", text="Sync Base Items", icon='SHADERFX')
                        sync_area.label(text="• Select MESH objects to sync with base items", icon='DOT')
                    
                    # Sync behavior explanation with better layout
                    behavior_box = sync_box.box()
                    behavior_box.scale_y = 0.95
                    
                    behavior_box.label(text="Sync Behavior:", icon='INFO')
                    
                    behavior_info = behavior_box.box()
                    behavior_info.scale_y = 0.9
                    behavior_info.label(text="• NEW objects: Choose row in dialog", icon='DOT')
                    behavior_info.label(text="• EXISTING objects: Auto-update matching entries", icon='DOT')
                    behavior_info.label(text="• Real-time: Changes sync automatically while active", icon='DOT')
            
            col.separator(factor=0.8)
            
            # COMPLETE ROW DETAILS with enhanced visual container
            if (hasattr(file_data, 'active_index') and 
                0 <= file_data.active_index < len(file_data.rows)):
                
                # Use the standard collapsible section approach
                details_box = col.box()
                details_box.scale_y = 1.05
                
                details_row = details_box.row()
                icon = 'DOWNARROW_HLT' if getattr(scene, 'row_details_expanded', False) else 'RIGHTARROW'
                details_row.prop(scene, "row_details_expanded", 
                            text="Show Complete Row Details", 
                            toggle=True,
                            icon=icon)
                
                # Row Details with enhanced layout
                if getattr(scene, 'row_details_expanded', False):
                    content_box = details_box.box()
                    content_box.scale_y = 0.95
                    
                    content_box.label(text="Complete Row Details:", icon='PROPERTIES')
                    
                    # Get the active row
                    active_row = file_data.rows[file_data.active_index]
                    
                    # Display ALL columns with values
                    headers = file_data.headers.split(',') if file_data.headers else []
                    
                    # Create scrollable region for many columns
                    scroll_box = content_box.box()
                    scroll_box.scale_y = 0.9
                    
                    # Split into three columns for better organization
                    split = scroll_box.split(factor=0.3)
                    name_col = split.column()
                    value_col = split.split(factor=0.4).column()
                    desc_col = split.column()
                    
                    # Headers with better spacing
                    name_col.label(text="Column:")
                    value_col.label(text="Value:")
                    desc_col.label(text="Description:")
                    
                    for header in headers:
                        if header and hasattr(active_row, header):
                            # Column name
                            name_row = name_col.row()
                            name_row.label(text=header)
                            
                            # Current value - EDITABLE
                            value_row = value_col.row()
                            current_value = getattr(active_row, header)
                            if current_value is not None:
                                value_row.prop(active_row, header, text="")
                            else:
                                value_row.label(text="[empty]")
                            
                            # Description - CLICKABLE ICON FOR ALL FILE TYPES
                            desc_row = desc_col.row()
                            
                            # Get appropriate tooltip text based on file type
                            tooltip_text = NWN2WorkflowGuides.get_column_tooltip(active_tab, header)
                            
                            # Always show the clickable question icon
                            op = desc_row.operator("twoda.show_tooltip", text="", icon='QUESTION', emboss=False)
                            op.tooltip_text = tooltip_text
                            desc_row.label(text="Click for info")
            else:
                info_box = col.box()
                info_box.scale_y = 0.9
                info_box.label(text="Select a row to view details", icon='INFO')
        
            # Open full editor button with enhanced styling
            col.separator(factor=0.8)
            editor_box = col.box()
            editor_box.scale_y = 1.05
            
            row = editor_box.row()
            row.scale_y = 1.1
            row.operator("twoda.open_editor", text="Open Full 2DA Editor Window", icon='WINDOW')
        else:
            # If file type selected but not loaded, show a helpful message
            if file_data and not file_data.file_loaded:
                info_box = col.box()
                info_box.scale_y = 0.9
                config = TwoDAConstants.get_config(active_tab)
                filename = config.get("filename", "Unknown") if config else "Unknown"
                info_box.label(text=f"File not loaded: {filename}", icon='INFO')
                info_box.label(text="Load this file type using 'Load 2DA Files'", icon='DOT')

# =========================================================================
# EQUIPMENT WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_equipment_workflow(layout):
        """Equipment tools workflow guide - Enhanced visual"""
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Character Equipment Workflow", icon='OUTLINER_OB_ARMATURE')
        
        # Status only - no quick actions with enhanced styling
        quick_box = box.box()
        quick_box.scale_y = 1.05
        
        active_obj = bpy.context.active_object
        
        # Use the imported get_character_name function directly
        if active_obj and active_obj.type == 'ARMATURE':
            try:
                char_name = get_character_name(active_obj)
                status_box = quick_box.box()
                status_box.scale_y = 0.95
                status_box.label(text=f"Active: {char_name}", icon='CHECKMARK')
                
                # Quick access to character sheet with better button styling
                action_box = quick_box.box()
                action_box.scale_y = 0.95
                
                row = action_box.row()
                row.scale_y = 1.1
                row.operator("wm.character_sheet", text="Open Character Sheet", icon='PROPERTIES')
            except NameError:
                # Fallback if get_character_name is not available
                status_box = quick_box.box()
                status_box.scale_y = 0.95
                status_box.label(text=f"Active: {active_obj.name}", icon='CHECKMARK')
                
                action_box = quick_box.box()
                action_box.scale_y = 0.95
                
                row = action_box.row()
                row.scale_y = 1.1
                row.operator("wm.character_sheet", text="Open Character Sheet", icon='PROPERTIES')
        else:
            error_box = quick_box.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Select an armature first", icon='ERROR')
        
        quick_box.separator(factor=0.5)
        
        # Setup and Organization with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "equipment_setup", "Equipment Setup", 'OUTLINER_COLLECTION',
            "Create organized collection structure",
            lambda col: NWN2WorkflowGuides._draw_equipment_setup(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "equipment_organization", "Equipment Organization", 'VIEWZOOM',
            "Equipment slot organization guide",
            lambda col: NWN2WorkflowGuides._draw_equipment_organization(col)
        )

        # AP Creation Tools with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "ap_creation", "AP (Animation Point) Creation", 'EMPTY_AXIS',
            "Create attachment points for equipment",
            lambda col: NWN2WorkflowGuides._draw_ap_creation(col)
        )

        # Import and Customization with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "equipment_import", "Import Equipment", 'IMPORT',
            "Import and organize equipment models",
            lambda col: NWN2WorkflowGuides._draw_equipment_import(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "equipment_custom", "Custom Armor Types", 'MOD_CLOTH',
            "Create and manage custom armor types",
            lambda col: NWN2WorkflowGuides._draw_equipment_custom(col)
        )

    @staticmethod
    def _draw_equipment_setup(col):
        """Equipment setup section - Enhanced visual"""
        # Setup Equipment Collection with better grouping
        setup_box = col.box()
        setup_box.scale_y = 1.05
        
        action_box = setup_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("wm.setup_equipment_collections", text="Setup Equipment Collection", icon='ADD')
        
        info_box = setup_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Creates structured hierarchy for all equipment slots", icon='DOT')
        info_box.label(text="• Organizes by slot type (chest, weapons, limbs, etc.)", icon='DOT')
        
        # KISM Attachment System with enhanced layout
        col.separator(factor=0.8)
        kism_box = col.box()
        kism_box.scale_y = 1.05
        
        kism_box.label(text="KISM Attachment Tools:", icon='LINKED')
        
        # NOTE ABOUT AP NAMING with better styling
        naming_box = kism_box.box()
        naming_box.scale_y = 0.95
        
        naming_box.label(text="AP Naming Convention:", icon='SORTALPHA')
        
        naming_info = naming_box.box()
        naming_info.scale_y = 0.9
        naming_info.label(text="• Prefix: AP_ (e.g., AP_HEAD, AP_RHAND)", icon='DOT')
        naming_info.label(text="• Standard APs: HEAD, CHEST, LHAND, RHAND, etc.", icon='DOT')
        naming_info.label(text="• Create empties with AP_ prefix in your scene", icon='DOT')
        
        # Animation Point Attachments with better grouping
        attach_box = kism_box.box()
        attach_box.scale_y = 0.95
        
        attach_box.label(text="Animation Point Attachments:", icon='CONSTRAINT_BONE')
        
        # AP Point selection and attachment actions
        scene = bpy.context.scene
        if hasattr(scene, 'kism_props'):
            # AP Point selection
            ap_box = attach_box.box()
            ap_box.scale_y = 0.9
            
            ap_row = ap_box.row()
            ap_row.label(text="Attachment Point:")
            ap_row.prop(scene.kism_props, "filtered_aps", text="")
            
            # Attachment actions
            action_area = attach_box.box()
            action_area.scale_y = 0.9
            
            attach_actions = action_area.row(align=True)
            attach_actions.scale_y = 1.1
            attach_actions.operator("kism.attach_object_to_ap", text="Attach to AP", icon='LINKED')
            attach_actions.operator("kism.detach_object_ap", text="Detach", icon='UNLINKED')
            
            # Auto-parenting
            auto_box = attach_box.box()
            auto_box.scale_y = 0.9
            
            row = auto_box.row()
            row.scale_y = 1.1
            row.operator("kism.auto_parent_to_bones", text="Auto-Parent to Bones", icon='BONE_DATA')
            
            auto_box.label(text="• Parents KISM objects to nearest bones", icon='DOT')
            
            # AP Settings with collapsible section
            if hasattr(scene.kism_props, 'show_advanced') and scene.kism_props.show_advanced:
                settings_box = attach_box.box()
                settings_box.scale_y = 0.95
                
                settings_box.label(text="AP Settings:", icon='SETTINGS')
                
                settings_area = settings_box.box()
                settings_area.scale_y = 0.9
                settings_area.prop(scene.kism_props, "highlight_ap_points", text="Highlight AP Points")
                if hasattr(scene.kism_props, "constraint_strength"):
                    settings_area.prop(scene.kism_props, "constraint_strength", text="Constraint Strength")
        else:
            # Fallback if kism_props not available with better layout
            fallback_box = attach_box.box()
            fallback_box.scale_y = 0.9
            
            row = fallback_box.row()
            row.scale_y = 1.1
            row.operator("kism.attach_object_to_ap", text="Attach Object to AP", icon='LINKED')
            fallback_box.label(text="• Attach object to animation point", icon='DOT')
            
            row = fallback_box.row()
            row.scale_y = 1.1
            row.operator("kism.detach_object_ap", text="Detach Object from AP", icon='UNLINKED')
            fallback_box.label(text="• Remove object from animation point", icon='DOT')
            
            row = fallback_box.row()
            row.scale_y = 1.1
            row.operator("kism.auto_parent_to_bones", text="Auto-Parent to Bones", icon='BONE_DATA')
            fallback_box.label(text="• Automatically parent objects to nearest bones", icon='DOT')
        
        # Equipment attachment preview system with enhanced styling
        col.separator(factor=0.8)
        preview_box = col.box()
        preview_box.scale_y = 1.05
        
        preview_box.label(text="Equipment Preview System:", icon='EMPTY_AXIS')
        
        preview_actions = preview_box.box()
        preview_actions.scale_y = 0.95
        
        row = preview_actions.row()
        row.scale_y = 1.1
        row.operator("equipment.scan_attachments", text="Scan for Attachments", icon='VIEWZOOM')
        preview_actions.label(text="• Auto-finds equipment in character hierarchy", icon='DOT')
        
        row = preview_actions.row()
        row.scale_y = 1.1
        row.operator("equipment.clear_attachments", text="Clear Attachment Preview", icon='TRASH')
        preview_actions.label(text="• Removes all attachment preview objects", icon='DOT')
        preview_actions.label(text="• Keeps original equipment intact", icon='DOT')
        
        # Open Character Sheet with enhanced button styling
        col.separator(factor=0.8)
        sheet_box = col.box()
        sheet_box.scale_y = 1.05
        
        action_box = sheet_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("wm.character_sheet", text="Open Character Sheet", icon='PROPERTIES')
        
        info_box = sheet_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Manage equipment visibility and settings", icon='DOT')
        info_box.label(text="• Includes custom armor type management in 'Custom Types' tab", icon='DOT')

    @staticmethod
    def _draw_ap_creation(col):
        """AP creation section - Enhanced visual"""
        scene = bpy.context.scene
        
        # Armature selection with better grouping
        armature_box = col.box()
        armature_box.scale_y = 1.05
        
        armature_box.label(text="AP Empty Creation", icon='EMPTY_AXIS')
        
        # Armature dropdown
        selection_box = armature_box.box()
        selection_box.scale_y = 0.95
        
        row = selection_box.row()
        row.label(text="Select Armature:", icon='ARMATURE_DATA')
        row.prop_search(scene.ap_scene_props, "selected_armature", bpy.data, "objects", text="")
        
        # Clear selections button
        row.operator("ap.clear_bone_selections", text="", icon='X')
        
        armature_name = scene.ap_scene_props.selected_armature
        armature = bpy.data.objects.get(armature_name) if armature_name else None
        
        if armature and armature.type == 'ARMATURE':
            # Armature info with enhanced styling
            info_box = armature_box.box()
            info_box.scale_y = 0.95
            
            info_row = info_box.row()
            info_row.label(text=f"✓ {armature.name}", icon='CHECKMARK')
            info_row.label(text=f"Bones: {len(armature.data.bones)}", icon='BONE_DATA')
            
            # Create button with enhanced prominence
            create_box = armature_box.box()
            create_box.scale_y = 0.95
            
            create_row = create_box.row(align=True)
            create_row.scale_y = 1.1
            create_row.operator("ap.create_ap_empties", text="Create AP Empties", icon='PLUS')
            create_row.label(text="Creates empties parented to bone HEADS")
            
            # Collapsible sections for bone selection with enhanced visuals
            col.separator(factor=0.8)
            
            # Head & Core Section
            core_box = col.box()
            core_box.scale_y = 1.05
            
            row = core_box.row()
            row.prop(scene.ap_creation_props, "show_core", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_core else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Head & Core", icon='USER')
            
            if scene.ap_creation_props.show_core:
                core_col = core_box.box()
                core_col.scale_y = 0.95
                core_col.prop_search(scene.ap_creation_props, "AP_HEAD_bone", armature.data, "bones", text="Head")
                core_col.prop_search(scene.ap_creation_props, "AP_CHEST_bone", armature.data, "bones", text="Chest")
                core_col.prop_search(scene.ap_creation_props, "AP_BACK_bone", armature.data, "bones", text="Back")
                core_col.prop_search(scene.ap_creation_props, "AP_PELVIS_bone", armature.data, "bones", text="Pelvis")
            
            # Right Arm Section
            right_arm_box = col.box()
            right_arm_box.scale_y = 1.05
            
            row = right_arm_box.row()
            row.prop(scene.ap_creation_props, "show_right_arm", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_right_arm else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Right Arm & Hand", icon='ARROW_LEFTRIGHT')
            
            if scene.ap_creation_props.show_right_arm:
                right_arm_col = right_arm_box.box()
                right_arm_col.scale_y = 0.95
                right_arm_col.prop_search(scene.ap_creation_props, "AP_RSHOULDER_bone", armature.data, "bones", text="Shoulder")
                right_arm_col.prop_search(scene.ap_creation_props, "AP_RUPPERARM_bone", armature.data, "bones", text="Upper Arm")
                right_arm_col.prop_search(scene.ap_creation_props, "AP_RELBOW_bone", armature.data, "bones", text="Elbow")
                right_arm_col.prop_search(scene.ap_creation_props, "AP_RLOWERARM_bone", armature.data, "bones", text="Lower Arm")
                right_arm_col.prop_search(scene.ap_creation_props, "AP_RHAND_bone", armature.data, "bones", text="Hand")
                right_arm_col.prop_search(scene.ap_creation_props, "AP_WEAPON_R_bone", armature.data, "bones", text="Weapon")
            
            # Left Arm Section
            left_arm_box = col.box()
            left_arm_box.scale_y = 1.05
            
            row = left_arm_box.row()
            row.prop(scene.ap_creation_props, "show_left_arm", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_left_arm else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Left Arm & Hand", icon='ARROW_LEFTRIGHT')
            
            if scene.ap_creation_props.show_left_arm:
                left_arm_col = left_arm_box.box()
                left_arm_col.scale_y = 0.95
                left_arm_col.prop_search(scene.ap_creation_props, "AP_LSHOULDER_bone", armature.data, "bones", text="Shoulder")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_LUPPERARM_bone", armature.data, "bones", text="Upper Arm")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_LELBOW_bone", armature.data, "bones", text="Elbow")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_LLOWERARM_bone", armature.data, "bones", text="Lower Arm")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_LHAND_bone", armature.data, "bones", text="Hand")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_WEAPON_L_bone", armature.data, "bones", text="Weapon")
                left_arm_col.prop_search(scene.ap_creation_props, "AP_SHIELD_bone", armature.data, "bones", text="Shield")
            
            # Right Leg Section
            right_leg_box = col.box()
            right_leg_box.scale_y = 1.05
            
            row = right_leg_box.row()
            row.prop(scene.ap_creation_props, "show_right_leg", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_right_leg else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Right Leg & Foot", icon='MOD_ARMATURE')
            
            if scene.ap_creation_props.show_right_leg:
                right_leg_col = right_leg_box.box()
                right_leg_col.scale_y = 0.95
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RHIP_bone", armature.data, "bones", text="Hip")
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RTHIGH_bone", armature.data, "bones", text="Thigh")
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RKNEE_bone", armature.data, "bones", text="Knee")
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RSHIN_bone", armature.data, "bones", text="Shin")
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RANKLE_bone", armature.data, "bones", text="Ankle")
                right_leg_col.prop_search(scene.ap_creation_props, "AP_RFOOT_bone", armature.data, "bones", text="Foot")
            
            # Left Leg Section
            left_leg_box = col.box()
            left_leg_box.scale_y = 1.05
            
            row = left_leg_box.row()
            row.prop(scene.ap_creation_props, "show_left_leg", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_left_leg else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Left Leg & Foot", icon='MOD_ARMATURE')
            
            if scene.ap_creation_props.show_left_leg:
                left_leg_col = left_leg_box.box()
                left_leg_col.scale_y = 0.95
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LHIP_bone", armature.data, "bones", text="Hip")
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LTHIGH_bone", armature.data, "bones", text="Thigh")
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LKNEE_bone", armature.data, "bones", text="Knee")
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LSHIN_bone", armature.data, "bones", text="Shin")
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LANKLE_bone", armature.data, "bones", text="Ankle")
                left_leg_col.prop_search(scene.ap_creation_props, "AP_LFOOT_bone", armature.data, "bones", text="Foot")
            
            # Special APs Section
            special_box = col.box()
            special_box.scale_y = 1.05
            
            row = special_box.row()
            row.prop(scene.ap_creation_props, "show_special", 
                    icon='DOWNARROW_HLT' if scene.ap_creation_props.show_special else 'RIGHTARROW', 
                    icon_only=True, emboss=False)
            row.label(text="Special APs", icon='SETTINGS')
            
            if scene.ap_creation_props.show_special:
                special_col = special_box.box()
                special_col.scale_y = 0.95
                special_col.prop_search(scene.ap_creation_props, "AP_CAMERA_bone", armature.data, "bones", text="Camera")
                special_col.prop_search(scene.ap_creation_props, "AP_EYE_R_bone", armature.data, "bones", text="Right Eye")
                special_col.prop_search(scene.ap_creation_props, "AP_EYE_L_bone", armature.data, "bones", text="Left Eye")
                special_col.prop_search(scene.ap_creation_props, "AP_MOUTH_bone", armature.data, "bones", text="Mouth")
                special_col.prop_search(scene.ap_creation_props, "AP_CAPE_bone", armature.data, "bones", text="Cape/Cloak")
                special_col.prop_search(scene.ap_creation_props, "AP_WEAPON_BACK_bone", armature.data, "bones", text="Weapon Back")
                special_col.prop_search(scene.ap_creation_props, "AP_WEAPON_BELT_bone", armature.data, "bones", text="Weapon Belt")
                special_col.prop_search(scene.ap_creation_props, "AP_WEAPON_HIP_bone", armature.data, "bones", text="Weapon Hip")
            
            # Info box with enhanced layout
            info_box = col.box()
            info_box.scale_y = 1.05
            
            info_box.label(text="AP Naming Convention:", icon='INFO')
            
            info_content = info_box.box()
            info_content.scale_y = 0.9
            info_content.label(text="• All APs start with 'AP_' prefix", icon='DOT')
            info_content.label(text="• Common APs: HEAD, CHEST, LHAND, RHAND", icon='DOT')
            info_content.label(text="• L/R indicate left/right side", icon='DOT')
            info_content.label(text="• Empties are parented to bone HEADS", icon='DOT')
            info_content.label(text="• With Copy Location constraints", icon='DOT')
            info_content.label(text="• Select bones, then click 'Create AP Empties'", icon='DOT')
            
        elif armature_name:
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="✗ Not a valid armature", icon='ERROR')
        else:
            info_box = col.box()
            info_box.scale_y = 0.9
            info_box.label(text="Select an armature to begin", icon='INFO')

    @staticmethod
    def _draw_equipment_organization(col):
        """Equipment organization section - Enhanced visual"""
        info_box = col.box()
        info_box.scale_y = 1.05
        
        info_content = info_box.box()
        info_content.scale_y = 0.9
        info_content.label(text="• Core Armor: Chest, Back, Pelvis, Hips", icon='DOT')
        info_content.label(text="• Weapons: Right/Left hand, Shield", icon='DOT')
        info_content.label(text="• Limb Attachments: Shoulders, Arms, Legs", icon='DOT')
        info_content.label(text="• Appearance: Head, Eyes, Hair, Armor types", icon='DOT')
        
        # Custom armor type info with enhanced styling
        col.separator(factor=0.8)
        custom_box = col.box()
        custom_box.scale_y = 1.05
        
        custom_box.label(text="Custom Armor Types:", icon='MOD_CLOTH')
        
        custom_info = custom_box.box()
        custom_info.scale_y = 0.9
        custom_info.label(text="• Create unique armor types (Dragon, Shadow, etc.)", icon='DOT')
        custom_info.label(text="• 2-3 letter codes (DR, SK, SH)", icon='DOT')
        custom_info.label(text="• Saved persistently with your Blender file", icon='DOT')

    @staticmethod
    def _draw_equipment_import(col):
        """Equipment import section - Enhanced visual"""
        info_box = col.box()
        info_box.scale_y = 1.05
        
        info_box.label(text="Manual Import Process:", icon='INFO')
        
        process_box = info_box.box()
        process_box.scale_y = 0.9
        process_box.label(text="1. Import equipment models (MDB/GR2 format)", icon='DOT')
        process_box.label(text="2. Parent equipment to appropriate empties", icon='DOT')
        process_box.label(text="3. Organize into correct collection slots", icon='DOT')
        process_box.label(text="4. Use Character Sheet to manage visibility", icon='DOT')
        
        # Additional info about custom types with enhanced styling
        col.separator(factor=0.8)
        custom_box = col.box()
        custom_box.scale_y = 1.05
        
        custom_box.label(text="For Custom Armor Types:", icon='MOD_CLOTH')
        
        custom_info = custom_box.box()
        custom_info.scale_y = 0.9
        custom_info.label(text="• Name meshes with custom type codes (e.g., DR_Body01)", icon='DOT')
        custom_info.label(text="• Use 'Custom Types' tab to manage type definitions", icon='DOT')

    @staticmethod
    def _draw_equipment_custom(col):
        """Custom armor types section - Enhanced visual"""
        
        # Quick access to custom type management with better button styling
        if EQUIPMENT_TOOLS_AVAILABLE:
            manage_box = col.box()
            manage_box.scale_y = 1.05
            
            action_box = manage_box.box()
            action_box.scale_y = 0.95
            
            row = action_box.row()
            row.scale_y = 1.1
            row.operator("equipment.manage_custom_armor_types", text="Manage Custom Armor Types", icon='PREFERENCES')
            
            info_box = manage_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Create and remove custom armor types", icon='DOT')
            
            # Show current custom types count with enhanced status
            try:
                custom_count = len(EquipmentConfig.CUSTOM_ARMOR_TYPES)
                status_box = manage_box.box()
                status_box.scale_y = 0.9
                if custom_count > 0:
                    status_box.label(text=f"• {custom_count} custom type(s) defined", icon='CHECKMARK')
                else:
                    status_box.label(text="• No custom types defined yet", icon='INFO')
            except:
                error_box = manage_box.box()
                error_box.alert = True
                error_box.scale_y = 0.9
                error_box.label(text="• Could not load custom types", icon='ERROR')
        else:
            error_box = col.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="Equipment tools not available", icon='ERROR')
            error_box.label(text="Check console for import errors", icon='INFO')
        
        # Usage instructions with enhanced layout
        col.separator(factor=0.8)
        usage_box = col.box()
        usage_box.scale_y = 1.05
        
        usage_box.label(text="How to Use Custom Types:", icon='QUESTION')
        
        usage_info = usage_box.box()
        usage_info.scale_y = 0.9
        usage_info.label(text="1. Create custom type in Character Sheet", icon='DOT')
        usage_info.label(text="2. Name meshes with type code (e.g., DR_Body01)", icon='DOT')
        usage_info.label(text="3. Select custom type in armor dropdowns", icon='DOT')
        usage_info.label(text="4. Equipment will filter automatically", icon='DOT')
        
        # Naming conventions with enhanced styling
        col.separator(factor=0.8)
        naming_box = col.box()
        naming_box.scale_y = 1.05
        
        naming_box.label(text="Naming Convention:", icon='TEXT')
        
        naming_info = naming_box.box()
        naming_info.scale_y = 0.9
        naming_info.label(text="Base: P_HHM_Body01", icon='DOT')
        naming_info.label(text="Custom: P_HHM_Gloves01", icon='DOT')
        naming_info.label(text="Weapon: w_Sword01_a", icon='DOT')
        
        # Validation info with enhanced layout
        col.separator(factor=0.8)
        validation_box = col.box()
        validation_box.scale_y = 1.05
        
        validation_box.label(text="Requirements:", icon='SETTINGS')
        
        validation_info = validation_box.box()
        validation_info.scale_y = 0.9
        validation_info.label(text="• 2-3 uppercase letters only", icon='DOT')
        validation_info.label(text="• No duplicates with base types", icon='DOT')
        validation_info.label(text="• Must be unique across all types", icon='DOT')

# =========================================================================
# MOVEMENT WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_movement_workflow(layout):
        """Movement tools workflow guide - Enhanced visual"""
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Movement Animation Tools", icon='ANIM_DATA')
        
        # Presets and Configuration with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "movement_presets", "Race Presets", 'PRESET',
            "Load predefined movement parameters",
            lambda col: NWN2WorkflowGuides._draw_movement_presets(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "movement_settings", "Movement Settings", 'SETTINGS',
            "Configure movement type and parameters",
            lambda col: NWN2WorkflowGuides._draw_movement_settings(col, scene)
        )
        
        # Tools and Creation with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "movement_tools", "Movement Tools", 'PLAY',
            "Create and manage movement animations",
            lambda col: NWN2WorkflowGuides._draw_movement_tools(col, scene)
        )
        
        # Add calculations display with enhanced container
        if hasattr(scene, 'nwn2_movement_props') and scene.nwn2_movement_props.show_calculations:
            calc_box = box.box()
            calc_box.scale_y = 1.05
            calc_box.label(text="Movement Calculations", icon='SCRIPT')
            NWN2WorkflowGuides._draw_movement_calculations(calc_box, scene)

    @staticmethod
    def _draw_movement_presets(col):
        """Movement presets section - Enhanced visual"""
        preset_box = col.box()
        preset_box.scale_y = 1.05
        
        action_box = preset_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.load_preset", text="Human").preset = 'HUMAN'
        row.operator("nwn2.load_preset", text="Dwarf").preset = 'DWARF'
        row.operator("nwn2.load_preset", text="Horse").preset = 'HORSE'
        
        info_box = preset_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Human: MOVERATE=4.5, WALKDIST=1.6, RUNDIST=3.2", icon='DOT')
        info_box.label(text="• Dwarf: MOVERATE=4.5, WALKDIST=1.06, RUNDIST=2.12", icon='DOT')

    @staticmethod
    def _draw_movement_settings(col, scene):
        """Movement settings section - Enhanced visual"""
        if hasattr(scene, 'nwn2_movement_props'):
            props = scene.nwn2_movement_props
            
            # Movement Type with enhanced layout
            type_box = col.box()
            type_box.scale_y = 1.05
            
            type_box.label(text="Movement Type:", icon='ARMATURE_DATA')
            
            type_area = type_box.box()
            type_area.scale_y = 0.95
            type_area.prop(props, "movement_type", expand=True)
            
            # NWN2 Parameters with better grouping
            param_box = col.box()
            param_box.scale_y = 1.05
            
            param_box.label(text="NWN2 Parameters:", icon='PROPERTIES')
            
            param_area = param_box.box()
            param_area.scale_y = 0.95
            
            row = param_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "moverate", text="MOVERATE")
            row.prop(props, "walkdist", text="WALKDIST")
            
            row = param_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "rundist", text="RUNDIST")
            row.prop(props, "perspace", text="PERSPACE")
            
            # Animation Settings with enhanced layout
            anim_box = col.box()
            anim_box.scale_y = 1.05
            
            anim_box.label(text="Animation Settings:", icon='ANIM')
            
            anim_area = anim_box.box()
            anim_area.scale_y = 0.95
            
            row = anim_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "animation_length", text="Animation Length")
            row.prop(props, "path_multiplier", text="Path Multiplier")
            
            # Path Settings with better grouping
            path_box = col.box()
            path_box.scale_y = 1.05
            
            path_box.label(text="Path Settings:", icon='CURVE_DATA')
            
            path_area = path_box.box()
            path_area.scale_y = 0.95
            
            row = path_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "path_resolution", text="Path Resolution")
            row.prop(props, "auto_smooth_path", text="Auto Smooth", toggle=True)

    @staticmethod
    def _draw_movement_tools(col, scene):
        """Movement tools section - Enhanced visual"""
        # Main tools with enhanced button styling
        tools_box = col.box()
        tools_box.scale_y = 1.05
        
        action_box = tools_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.create_movement", text="Create Movement", icon='ANIM')
        row.operator("nwn2.extend_path", text="Extend Path", icon='ADD')
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("nwn2.duplicate_keyframes", text="Duplicate Cycles", icon='DUPLICATE')
        row.operator("nwn2.clear_movement", text="Clear", icon='TRASH')
        
        info_box = tools_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Creates editable Bezier path with control points", icon='DOT')
        info_box.label(text="• Extend: Add more cycles to existing path", icon='DOT')
        info_box.label(text="• Duplicate: Copy keyframes for additional cycles", icon='DOT')
        
        # Custom Presets with enhanced layout
        if hasattr(scene, 'nwn2_movement_props'):
            props = scene.nwn2_movement_props
            col.separator(factor=0.8)
            
            custom_box = col.box()
            custom_box.scale_y = 1.05
            
            custom_box.label(text="Custom Presets:", icon='BOOKMARKS')
            
            save_box = custom_box.box()
            save_box.scale_y = 0.95
            
            row = save_box.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "custom_preset_name", text="Preset Name")
            row.operator("nwn2.save_custom_preset", text="Save", icon='ADD')
            
            # Load/Delete custom presets with better list styling
            if hasattr(scene, 'nwn2_custom_presets') and scene.nwn2_custom_presets:
                list_box = custom_box.box()
                list_box.scale_y = 0.95
                
                for preset_name in scene.nwn2_custom_presets:
                    preset_row = list_box.row()
                    preset_row.label(text=preset_name)
                    op = preset_row.operator("nwn2.load_custom_preset", text="Load")
                    op.preset_name = preset_name
                    op = preset_row.operator("nwn2.delete_custom_preset", text="", icon='X')
                    op.preset_name = preset_name

    @staticmethod
    def _draw_movement_calculations(col, scene):
        """Movement calculations section - Enhanced visual"""
        if not hasattr(scene, 'nwn2_movement_props'):
            return
            
        props = scene.nwn2_movement_props
        
        # Calculate values
        run_speed = props.moverate
        walk_speed = 2.2
        
        if props.movement_type == 'WALK':
            speed = walk_speed
            speed_type = "Walk"
        else:
            speed = run_speed
            speed_type = "Run"
            
        base_distance = speed * (props.animation_length / 24.0)
        final_distance = base_distance * props.path_multiplier
        
        # Display calculations with enhanced layout
        summary_box = col.box()
        summary_box.scale_y = 1.05
        
        summary_box.label(text=f"Movement Summary ({speed_type}):", icon='INFO')
        
        calc_box = summary_box.box()
        calc_box.scale_y = 0.9
        calc_box.label(text=f"Speed: {speed} m/s")
        calc_box.label(text=f"Distance per cycle: {final_distance:.2f} m")
        calc_box.label(text=f"Frames per cycle: {props.animation_length}")
        calc_box.label(text=f"Path points: {props.path_resolution}")
        
        if props.movement_type == 'RUN':
            compare_box = summary_box.box()
            compare_box.scale_y = 0.9
            compare_box.label(text=f"Walk Speed: {walk_speed} m/s (for comparison)")
            compare_box.label(text=f"Speed Ratio: {run_speed/walk_speed:.1f}x faster than walk")

# =========================================================================
# REVERSE MOVEMENT WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_reverse_workflow(layout):
        """Reverse movement tools workflow guide - Enhanced visual"""
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="Reverse Movement Tools", icon='CONSTRAINT')
        
        # Status only - no quick actions with enhanced styling
        quick_box = box.box()
        quick_box.scale_y = 1.05
        
        active_obj = bpy.context.active_object
        empty_name = f"{active_obj.name}_Reverse_Movement" if active_obj else ""
        empty_exists = bpy.data.objects.get(empty_name) is not None if active_obj else False
        
        if active_obj:
            status_box = quick_box.box()
            status_box.scale_y = 0.95
            
            if empty_exists:
                status_box.label(text="✓ Reverse movement empty exists", icon='CHECKMARK')
                
                action_box = quick_box.box()
                action_box.scale_y = 0.95
                
                row = action_box.row(align=True)
                row.scale_y = 1.1
                row.operator("rm.update_reverse_empty", text="Update", icon='FILE_REFRESH')
                row.operator("rm.delete_reverse_empty", text="Delete", icon='TRASH')
            else:
                status_box.label(text="No reverse movement created", icon='INFO')
        
        quick_box.separator(factor=0.5)
        
        # Settings and Workflow with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "reverse_settings", "Movement Settings", 'SETTINGS',
            "Configure reverse movement axes",
            lambda col: NWN2WorkflowGuides._draw_reverse_settings(col)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "reverse_workflow", "Workflow Guide", 'BOOKMARKS',
            "How to use reverse movement",
            lambda col: NWN2WorkflowGuides._draw_reverse_workflow_guide(col)
        )

    @staticmethod
    def _draw_reverse_settings(col):
        """Reverse settings section - Enhanced visual"""
        if hasattr(bpy.context.scene, 'reverse_movement_props'):
            props = bpy.context.scene.reverse_movement_props
            
            # Use Axes with enhanced layout
            axes_box = col.box()
            axes_box.scale_y = 1.05
            
            axes_box.label(text="Use Axes:", icon='AXIS_TOP')
            
            axes_area = axes_box.box()
            axes_area.scale_y = 0.95
            
            row = axes_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "use_x", text="X")
            row.prop(props, "use_y", text="Y")
            row.prop(props, "use_z", text="Z")
            
            # Invert Axes with better grouping
            invert_box = col.box()
            invert_box.scale_y = 1.05
            
            invert_box.label(text="Invert Axes:", icon='ARROW_LEFTRIGHT')
            
            invert_area = invert_box.box()
            invert_area.scale_y = 0.95
            
            row = invert_area.row(align=True)
            row.scale_y = 1.1
            row.prop(props, "invert_x", text="X")
            row.prop(props, "invert_y", text="Y")
            row.prop(props, "invert_z", text="Z")
            
            # Create Reverse Empty with enhanced button styling
            col.separator(factor=0.8)
            create_box = col.box()
            create_box.scale_y = 1.05
            
            action_box = create_box.box()
            action_box.scale_y = 0.95
            
            row = action_box.row()
            row.scale_y = 1.1
            row.operator("rm.create_reverse_empty", text="Create Reverse Empty", icon='ADD')
            
            info_box = create_box.box()
            info_box.scale_y = 0.9
            info_box.label(text="• Creates empty for reverse movement control", icon='DOT')

    @staticmethod
    def _draw_reverse_workflow_guide(col):
        """Reverse workflow guide section - Enhanced visual"""
        guide_box = col.box()
        guide_box.scale_y = 1.05
        
        guide_content = guide_box.box()
        guide_content.scale_y = 0.9
        guide_content.label(text="1. Create forward movement animation first", icon='DOT')
        guide_content.label(text="2. Create reverse empty using this tool", icon='DOT')
        guide_content.label(text="3. PARENT character armature to reverse empty", icon='DOT')
        guide_content.label(text="4. Result: Character animates in place", icon='DOT')
        
        # Clear constraint button with enhanced styling
        col.separator(factor=0.8)
        clear_box = col.box()
        clear_box.scale_y = 1.05
        
        action_box = clear_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("rm.clear_reverse_constraint", text="Clear Constraint", icon='CONSTRAINT')

# =========================================================================
# JSON WORKFLOW METHODS - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def draw_json_workflow(layout):
        """JSON tools workflow guide - Enhanced visual"""
        scene = bpy.context.scene
        box = layout.box()
        box.scale_y = 1.03
        
        # Enhanced header
        row = box.row()
        row.scale_y = 1.15
        row.label(text="KISM JSON Import/Export Workflow", icon='FILE_SCRIPT')
        
        # Export and Import with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "json_export", "Export Assets", 'EXPORT',
            "Export Blender objects to JSON format",
            lambda col: NWN2WorkflowGuides._draw_json_export(col, scene)
        )
        
        NWN2WorkflowGuides._draw_collapsible_section(box, "json_import", "Import Assets", 'IMPORT',
            "Import previously exported JSON files",
            lambda col: NWN2WorkflowGuides._draw_json_import(col, scene)
        )
        
        # Advanced Operations with enhanced visuals
        NWN2WorkflowGuides._draw_collapsible_section(box, "json_advanced", "Advanced Operations", 'FILE_BLEND',
            "File management and processing tools",
            lambda col: NWN2WorkflowGuides._draw_json_advanced(col, scene)
        )

    @staticmethod
    def _draw_json_export(col, scene):
        """JSON export section - Enhanced visual"""
        # Export Tools with enhanced layout
        export_box = col.box()
        export_box.scale_y = 1.05
        
        export_box.label(text="Export Tools:", icon='EXPORT')
        
        # Model Export with better grouping
        model_box = export_box.box()
        model_box.scale_y = 0.95
        
        model_box.label(text="Model Export:", icon='MESH_DATA')
        
        action_box = model_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("kism.export_json_model", text="Export Selected Models", icon='EXPORT')
        
        info_box = model_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Select MESH objects first", icon='DOT')
        info_box.label(text="• Exports with parenting and transforms", icon='DOT')
        
        # Skeleton Export with better grouping
        skeleton_box = export_box.box()
        skeleton_box.scale_y = 0.95
        
        skeleton_box.label(text="Armature Export:", icon='ARMATURE_DATA')
        
        action_box = skeleton_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("kism.export_json_skeleton", text="Export Selected Armature", icon='EXPORT')
        
        info_box = skeleton_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Select ARMATURE object first", icon='DOT')
        info_box.label(text="• Includes bone hierarchy and weights", icon='DOT')
        
        # Custom Exports with better grouping
        custom_box = export_box.box()
        custom_box.scale_y = 0.95
        
        custom_box.label(text="Custom Exports:", icon='TOOL_SETTINGS')
        
        action_box = custom_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("kism.export_custom_race", text="Export Race Setup", icon='USER')
        row.operator("kism.export_custom_weapon", text="Export Weapon Setup", icon='TOOL_SETTINGS')
        
        info_box = custom_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Preserves complete scene structure", icon='DOT')
        info_box.label(text="• Includes empties and parenting", icon='DOT')
        
        # Export Settings with enhanced layout
        if hasattr(scene, 'kism_props'):
            settings_box = export_box.box()
            settings_box.scale_y = 0.95
            
            settings_box.label(text="Export Settings:", icon='SETTINGS')
            
            settings_area = settings_box.box()
            settings_area.scale_y = 0.9
            settings_area.prop(scene.kism_props, "export_scale", text="Scale")
            settings_area.prop(scene.kism_props, "export_selected_only", text="Selected Only")
            settings_area.prop(scene.kism_props, "export_precision", text="Precision")

    @staticmethod
    def _draw_json_import(col, scene):
        """JSON import section - Enhanced visual"""
        # File Management with enhanced layout
        manage_box = col.box()
        manage_box.scale_y = 1.05
        
        manage_box.label(text="File Management:", icon='FILE_FOLDER')
        
        # Check if properties exist
        if hasattr(scene, 'kism_props'):
            # Show loaded files if available with enhanced status
            if hasattr(scene.kism_props, 'loaded_json_files') and scene.kism_props.loaded_json_files:
                status_box = manage_box.box()
                status_box.scale_y = 0.95
                status_box.label(text=f"{len(scene.kism_props.loaded_json_files)} files loaded", icon='CHECKMARK')
            else:
                status_box = manage_box.box()
                status_box.scale_y = 0.95
                status_box.label(text="No JSON files loaded", icon='INFO')
        else:
            error_box = manage_box.box()
            error_box.alert = True
            error_box.scale_y = 0.9
            error_box.label(text="JSON tools not available", icon='ERROR')
        
        # Load JSON file button with enhanced styling
        action_box = manage_box.box()
        action_box.scale_y = 0.95
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("kism.load_json_file", text="Load JSON File", icon='IMPORT')

    @staticmethod
    def _draw_json_advanced(col, scene):
        """JSON advanced section - Enhanced visual"""
        # File Processing with enhanced layout
        process_box = col.box()
        process_box.scale_y = 1.05
        
        process_box.label(text="File Processing:", icon='FILE_BLEND')
        
        # Merge operations with better grouping
        merge_box = process_box.box()
        merge_box.scale_y = 0.95
        
        merge_box.label(text="Merge Operations:", icon='MOD_BOOLEAN')
        
        action_box = merge_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row()
        row.scale_y = 1.1
        row.operator("kism.merge_selected_json", text="Merge Selected Files", icon='FILE_BLEND')
        
        info_box = merge_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Combine multiple JSON files into one", icon='DOT')
        info_box.label(text="• Preserves all object relationships", icon='DOT')
        
        # Batch operations with better grouping
        batch_box = process_box.box()
        batch_box.scale_y = 0.95
        
        batch_box.label(text="Batch Operations:", icon='SEQ_SEQUENCER')
        
        action_box = batch_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("kism.batch_export", text="Batch Export Selection", icon='EXPORT')
        row.operator("kism.batch_import", text="Batch Import Folder", icon='IMPORT')
        
        info_box = batch_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Process multiple files at once", icon='DOT')
        info_box.label(text="• Maintains file structure", icon='DOT')
        
        # Utility tools with better grouping
        util_box = process_box.box()
        util_box.scale_y = 0.95
        
        util_box.label(text="Utility Tools:", icon='TOOL_SETTINGS')
        
        action_box = util_box.box()
        action_box.scale_y = 0.9
        
        row = action_box.row(align=True)
        row.scale_y = 1.1
        row.operator("kism.validate_json_structure", text="Validate JSON Structure", icon='CHECKMARK')
        row.operator("kism.cleanup_scene", text="Cleanup Scene", icon='BRUSH_DATA')
        
        info_box = util_box.box()
        info_box.scale_y = 0.9
        info_box.label(text="• Check for structural issues", icon='DOT')
        info_box.label(text="• Remove temporary objects", icon='DOT')
        
        # Workflow tips with enhanced layout
        col.separator(factor=0.8)
        tips_box = col.box()
        tips_box.scale_y = 1.05
        
        tips_box.label(text="🎯 Workflow Tips:", icon='LIGHT')
        
        tips_area = tips_box.box()
        tips_area.scale_y = 0.9
        
        tips_col = tips_area.column(align=True)
        tips_col.scale_y = 0.9
        tips_col.label(text="1. Load JSON files first", icon='IMPORT')
        tips_col.label(text="2. Use dropdowns to select files", icon='DOWNARROW_HLT')
        tips_col.label(text="3. Import with correct scale settings", icon='ARROW_LEFTRIGHT')
        tips_col.label(text="4. Use merge for batch operations", icon='FILE_BLEND')

# =========================================================================
# HELPER METHODS FOR 2DA INTEGRATION - ENHANCED VISUAL
# =========================================================================

    @staticmethod
    def safe_get_file_data(scene, file_type):
        """Safely get file data with fallback - Enhanced visual"""
        try:
            # Check if the property exists and file is loaded
            if hasattr(scene, f"{file_type}_data"):
                file_data = getattr(scene, f"{file_type}_data")
                if hasattr(file_data, 'file_loaded') and file_data.file_loaded:
                    return file_data
            return None
        except Exception as e:
            print(f"Error getting file data for {file_type}: {e}")
            return None

    @staticmethod
    def get_column_tooltip(file_type, column_name):
        """Get tooltip text for a column based on file type - Enhanced visual"""
        if not TWODA_TOOLS_AVAILABLE:
            return f"No tooltip available - 2DA tools not loaded\nColumn: {column_name}"
        
        try:
            # Use the imported column info classes
            if file_type == 'placeables':
                col_info = PlaceablesColumnInfo.get_column_info(column_name)
                return f"{col_info['description']}\n\nPurpose: {col_info['purpose']}"
            elif file_type == 'appearance':
                col_info = AppearanceColumnInfo.get_column_info(column_name)
                return f"{col_info['description']}\n\nPurpose: {col_info['purpose']}"
            elif file_type == 'wingmodel':
                col_info = WingColumnInfo.get_column_info(column_name)
                return f"{col_info['description']}\n\nPurpose: {col_info['purpose']}"
            elif file_type == 'tailmodel':
                col_info = TailColumnInfo.get_column_info(column_name)
                return f"{col_info['description']}\n\nPurpose: {col_info['purpose']}"
            elif file_type == 'baseitem':  # ADDED THIS CASE
                col_info = BaseitemColumnInfo.get_column_info(column_name)
                return f"{col_info['description']}\n\nPurpose: {col_info['purpose']}"
            else:
                return f"Column: {column_name}\nNo specific description available for this file type."
        except Exception as e:
            return f"Error loading tooltip: {str(e)}\nColumn: {column_name}"

# =========================================================================
# MAIN PANEL
# =========================================================================

class NWN2_PT_main_panel(Panel):
    """NWN2 Extended Blender Tools - Main Navigation"""
    bl_label = "NWN2 Extended Blender Tools"
    bl_idname = "NWN2_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "NWN2 Tools"
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        try:
            # Main tool selection
            self.draw_tool_selection(context, layout)
            
            # Selected tool panel
            layout.separator(factor=1.0)
            self.draw_tool_panel(context, layout)
            
        except Exception as e:
            self.draw_error(layout, f"Panel Error: {str(e)}")
    
    def draw_tool_selection(self, context, layout):
        """Main tool category selection with different pipeline workflows"""
        scene = context.scene
        
        # Add a property for workflow mode if it doesn't exist
        if not hasattr(scene, 'nwn2_workflow_mode'):
            bpy.types.Scene.nwn2_workflow_mode = bpy.props.EnumProperty(
                name="Workflow Pipeline",
                description="Select which workflow pipeline to display",
                items=[
                    ('ALL', 'All', 'Show all tool tabs'),
                    ('PLACEABLES', 'Placeables', 'Placeables creation workflow'),
                    ('ANIMATION', 'Animation', 'Animation pipeline workflow'),
                    ('CREATURE', 'Creature Conversion', 'Creature conversion pipeline'),
                    ('EQUIPMENT', 'Equipment Manager', 'Equipment management pipeline'),
                ],
                default='ALL'
            )
        
        container = layout.box()
        # REMOVED: container.scale_y = 1.1
        
        # Header with Workflow mode selector
        header = container.row()
        # REMOVED: header.scale_y = 1.15
        header.label(text="NWN2 Workflow Pipeline", icon='WORKSPACE')
        
        # Mode selector on the right
        mode_selector = header.row()
        mode_selector.alignment = 'RIGHT'
        # REMOVED: mode_selector.scale_y = 1.1
        mode_selector.prop(scene, "nwn2_workflow_mode", text="")
        
        container.separator(factor=0.5)
        
        # Define tabs based on workflow mode
        workflow_mode = scene.nwn2_workflow_mode
        
        # Define all possible tabs
        all_tabs = {
            'MODEL': ('MESH_DATA', 'Model', 'Model import and export'),
            'MATERIAL': ('MATERIAL', 'Material', 'Material setup'),
            'TWODA': ('TEXT', '2DA', '2DA file editing'),
            'ANIMATION': ('ANIM', 'Animation', 'Animation tools'),
            'RETARGETING': ('ARMATURE_DATA', 'Retargeting', 'Retargeting tools'),
            'EQUIPMENT': ('OUTLINER_OB_ARMATURE', 'Equipment', 'Equipment tools'),
            'MOVEMENT': ('ANIM_DATA', 'Movement', 'Movement tools'),
            'REVERSE': ('CONSTRAINT', 'Reverse', 'Reverse tools'),
            'JSON': ('FILE_SCRIPT', 'JSON', 'JSON tools'),
        }
        
        # Define which tabs to show for each workflow
        workflow_tabs = {
            'ALL': ['MODEL', 'MATERIAL', 'TWODA', 'ANIMATION', 'RETARGETING', 'EQUIPMENT', 'MOVEMENT', 'REVERSE', 'JSON'],
            'PLACEABLES': ['MODEL', 'MATERIAL', 'TWODA'],
            'ANIMATION': ['ANIMATION', 'RETARGETING', 'MOVEMENT', 'REVERSE'],
            'CREATURE': ['RETARGETING', 'MODEL', 'MATERIAL', 'ANIMATION', 'TWODA'],
            'EQUIPMENT': ['EQUIPMENT', 'MODEL', 'MATERIAL', 'TWODA'],
        }
        
        # Get tabs for current workflow
        tab_ids = workflow_tabs.get(workflow_mode, workflow_tabs['ALL'])
        main_tabs = [(tab_id, all_tabs[tab_id][0], all_tabs[tab_id][1], all_tabs[tab_id][2]) for tab_id in tab_ids]
        
        # Draw tabs based on count
        if len(main_tabs) <= 4:
            # Single row for few tabs
            tabs_row = container.row(align=True)
            # REMOVED: tabs_row.scale_y = 1.5
            # REMOVED: tabs_row.scale_x = 1.2
            
            for tab_id, tab_icon, tab_name, tab_tip in main_tabs:
                col = tabs_row.column(align=True)
                # REMOVED: col.scale_y = 1.0
                
                is_active = (scene.nwn2_active_tool == tab_id)
                
                # Tab button
                tab_button = col.operator(
                    "wm.context_set_enum",
                    text="",
                    icon=tab_icon,
                    depress=is_active
                )
                tab_button.data_path = "scene.nwn2_active_tool"
                tab_button.value = tab_id
                
                # Tab label below icon
                label_row = col.row()
                # REMOVED: label_row.scale_y = 0.8
                label_row.alignment = 'CENTER'
                label_row.label(text=tab_name)
                
                # Active indicator
                if is_active:
                    active_row = col.row()
                    # REMOVED: active_row.scale_y = 0.7
                    active_row.alignment = 'CENTER'
                    active_row.label(text="Active", icon='RADIOBUT_ON')
                
                # Add spacing between tabs (except last)
                if tab_id != main_tabs[-1][0]:
                    tabs_row.separator(factor=2.0)
        else:
            # Grid layout for many tabs
            grid = container.grid_flow(row_major=True, columns=5, even_columns=True, even_rows=True, align=True)
            # REMOVED: grid.scale_y = 1.3
            
            for tab_id, tab_icon, tab_name, tab_tip in main_tabs:
                col = grid.column(align=True)
                # REMOVED: col.scale_y = 1.0
                
                is_active = (scene.nwn2_active_tool == tab_id)
                
                # Tab button
                tab_button = col.operator(
                    "wm.context_set_enum",
                    text="",
                    icon=tab_icon,
                    depress=is_active
                )
                tab_button.data_path = "scene.nwn2_active_tool"
                tab_button.value = tab_id
                
                # Tab label below icon
                label_row = col.row()
                # REMOVED: label_row.scale_y = 0.8
                label_row.alignment = 'CENTER'
                label_row.label(text=tab_name)
                
                # Active indicator
                if is_active:
                    active_row = col.row()
                    # REMOVED: active_row.scale_y = 0.7
                    active_row.alignment = 'CENTER'
                    active_row.label(text="Active", icon='RADIOBUT_ON')
        
        container.separator(factor=0.8)
        
        # Show active tab description
        active_tab_desc = {
            'MODEL': 'Model import, cleanup, and export tools',
            'MATERIAL': 'Material setup and texture export',
            'TWODA': '2DA file editing and synchronization',
            'ANIMATION': 'Animation import and export tools',
            'RETARGETING': 'Animation retargeting tools',
            'EQUIPMENT': 'Character equipment management',
            'MOVEMENT': 'Character movement animation tools',
            'REVERSE': 'Reverse movement tools',
            'JSON': 'KISM JSON import/export tools',
        }
        
        desc_box = container.box()
        desc_row = desc_box.row()
        # REMOVED: desc_row.scale_y = 1.1
        
        active_tab = scene.nwn2_active_tool
        
        # Show workflow description and active tab info
        workflow_desc = {
            'ALL': 'All available tools',
            'PLACEABLES': 'Placeables creation: Model, Material, 2DA',
            'ANIMATION': 'Animation pipeline: Animation, Retargeting, Movement, Reverse',
            'CREATURE': 'Creature conversion: Retargeting, Model, Material, Animation, 2DA',
            'EQUIPMENT': 'Equipment management: Equipment, Model, Material, 2DA',
        }
        
        desc_text = f"{workflow_desc.get(workflow_mode, 'Select a workflow pipeline')}"
        if active_tab in active_tab_desc:
            desc_text += f" | Active: {active_tab_desc[active_tab]}"
        
        desc_row.label(text=desc_text, icon='INFO')

    def draw_tool_panel(self, context, layout):
        """Draw the selected tool panel with workflow guides"""
        scene = context.scene
        
        # Check if active_tool property exists and has a valid value
        if not hasattr(scene, 'nwn2_active_tool'):
            # Property not registered yet, show default
            self.draw_warning(layout, "Loading tools...")
            return
            
        active_tool = scene.nwn2_active_tool
        
        try:
            # Main content box - JUST THE WORKFLOW GUIDE
            main_box = layout.box()
            
            # Workflow methods for each tool - UPDATED WITH ALL NEW TABS
            workflow_methods = {
                'MODEL': NWN2WorkflowGuides.draw_model_workflow,
                'MATERIAL': NWN2WorkflowGuides.draw_material_workflow,
                'ANIMATION': NWN2WorkflowGuides.draw_animation_workflow,
                'RETARGETING': NWN2WorkflowGuides.draw_retargeting_workflow,
                'TWODA': NWN2WorkflowGuides.draw_twoda_workflow,
                'EQUIPMENT': NWN2WorkflowGuides.draw_equipment_workflow,
                'MOVEMENT': NWN2WorkflowGuides.draw_movement_workflow,
                'REVERSE': NWN2WorkflowGuides.draw_reverse_workflow,
                'JSON': NWN2WorkflowGuides.draw_json_workflow,
            }
            
            workflow_drawer = workflow_methods.get(active_tool)
            if workflow_drawer:
                workflow_drawer(main_box)
            else:
                # If active_tool has an invalid value, default to MODEL
                NWN2WorkflowGuides.draw_model_workflow(main_box)
                
        except Exception as e:
            # Provide more detailed error information
            error_box = layout.box()
            error_box.label(text=f"Tool Error ({active_tool}): {str(e)}", icon='ERROR')
            error_box.label(text="Properties available:", icon='INFO')
            
            # List available properties for debugging
            for attr in dir(scene):
                if not attr.startswith('_') and not callable(getattr(scene, attr)):
                    error_box.label(text=f"  - {attr}", icon='DOT')
    
    def draw_warning(self, layout, text):
        """Consistent warning display"""
        row = layout.row()
        row.alert = True
        row.label(text=text, icon='ERROR')
        return row
    
    def draw_error(self, layout, text):
        """Consistent error display"""
        row = layout.row()
        row.alert = True
        row.label(text=text, icon='ERROR')
        return row

# ==============================================
# CUSTOM WORKFLOW OPERATORS
# ==============================================

class NWN2_OT_add_custom_stage(bpy.types.Operator):
    """Add a stage to custom workflow"""
    bl_idname = "nwn2.add_custom_stage"
    bl_label = "Add Custom Stage"
    
    def execute(self, context):
        # This would add configuration logic for custom workflows
        self.report({'INFO'}, "Custom stage configuration would go here")
        return {'FINISHED'}

class NWN2_OT_reset_custom_workflow(bpy.types.Operator):
    """Reset custom workflow to default"""
    bl_idname = "nwn2.reset_custom_workflow"
    bl_label = "Reset Custom Workflow"
    
    def execute(self, context):
        # Reset custom workflow view
        self.report({'INFO'}, "Custom workflow reset")
        return {'FINISHED'}

# ==============================================
# REGISTRATION - UPDATED WITH FLOWCHART FEATURES
# ==============================================

def register():
    print("=== Registering NWN2 Extended Blender Tools ===")
    
    # FIRST: Register all PropertyGroup classes
    print("Registering PropertyGroup classes...")
    property_groups = [
        AnimationListItem,
        AnimationFileListItem,
        BoneListItem,
        DynamicProperties,
        MDBGR2FileItem,
        TWODA_OT_ShowTooltip,
    ]
    
    # Add AP creation properties if available
    if EQUIPMENT_TOOLS_AVAILABLE:
        try:
            property_groups.append(APCreationProperties)
            property_groups.append(APSceneProperties)
            print("  ✓ Equipment AP classes available for registration")
        except Exception as e:
            print(f"  ✗ Could not add AP classes: {e}")
    
    for cls in property_groups:
        try:
            bpy.utils.register_class(cls)
            print(f"  ✓ Registered PropertyGroup: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to register {cls.__name__}: {e}")
    
    # Register custom workflow operators
    print("Registering custom workflow operators...")
    custom_operators = [
        NWN2_OT_add_custom_stage,
        NWN2_OT_reset_custom_workflow,
    ]
    
    for cls in custom_operators:
        try:
            bpy.utils.register_class(cls)
            print(f"  ✓ Registered operator: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to register {cls.__name__}: {e}")
    
    # Register all collapsible section properties
    collapsible_sections = [
        # Model workflow sections
        "show_mdb_gr2_import_section",
        "show_object_renaming_section", 
        "show_model_prepare_section",
        "show_model_tools_section",
        "show_model_folders_section",
        
        # Material workflow sections
        "show_material_setup_section",
        "show_material_folders_section",
        "show_material_tools_section",

        # Retopology workflow sections
        "show_material_retopology_section",
        "show_retopology_modifiers_section",
        "show_retopology_baking_section",
        
        # Merge Texture workflow sections
        "show_material_merge_texture_section",
        "show_merge_texture_objects_section",
        "show_merge_texture_uv_section",
        "show_merge_texture_texture_section",
        "show_merge_texture_baking_section",

        # Animation workflow sections
        "show_animation_import_section",
        "show_animation_export_section",
        "show_animation_management_section",
        
        # Retargeting workflow sections
        "show_retarget_connect_section",
        "show_retarget_manage_section",
        "show_source_vertex_section",
        "show_source_bones_section",
        "show_source_controls_section",
        "show_target_rotation_section",
        "show_target_parenting_section",
        
        # 2DA workflow sections
        "show_twoda_files_section",
        "show_twoda_editor_section",
        "show_twoda_sync_section",
        
        # Equipment workflow sections
        "show_equipment_setup_section",
        "show_equipment_import_section",
        "show_equipment_organization_section",
        "show_equipment_custom_section",
        "show_ap_creation_section",
        
        # Movement workflow sections
        "show_movement_presets_section",
        "show_movement_settings_section",
        "show_movement_tools_section",
        
        # Reverse workflow sections
        "show_reverse_settings_section",
        "show_reverse_workflow_section",
        
        # JSON workflow sections
        "show_json_export_section",
        "show_json_import_section",
        "show_json_advanced_section",
    ]
    
    print(f"Registering {len(collapsible_sections)} collapsible section properties...")
    for prop_name in collapsible_sections:
        # Force recreation with default=False for ALL sections
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
            print(f"  ⚡ Force recreating: {prop_name}")
        
        setattr(bpy.types.Scene, prop_name, bpy.props.BoolProperty(default=False))
        print(f"  ✓ Registered: {prop_name}")
    
    # Register operator classes
    classes_to_register = [
        NWN2_PT_main_panel,
        NWN2_OT_ScrollImportList,
        NWN2_OT_ScrollAnimationList,
        NWN2_OT_select_import_folder,
        NWN2_OT_select_model_export_folder,
        NWN2_OT_select_material_export_folder,
        NWN2_OT_select_animation_import_folder,
        NWN2_OT_select_animation_export_folder,
        TWODA_OT_ShowTooltip,
    ]
    
    for cls in classes_to_register:
        try:
            bpy.utils.register_class(cls)
            print(f"  ✓ Registered class: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to register {cls.__name__}: {e}")

    # Register MDB/GR2 import properties
    bpy.types.Scene.mdb_gr2_import_directory = StringProperty(
        name="Import Directory",
        subtype='DIR_PATH',
        default="",
        description="Directory containing MDB and GR2 files"
    )
    
    bpy.types.Scene.mdb_gr2_file_collection = CollectionProperty(type=MDBGR2FileItem)
    bpy.types.Scene.mdb_gr2_file_index = IntProperty(default=0)
    
    # Scroll and UI scale properties
    bpy.types.Scene.mdb_gr2_scroll_index = IntProperty(
        name="Scroll Index",
        default=0,
        min=0,
        description="Current page index for file list"
    )
    
    bpy.types.Scene.mdb_gr2_scroll_height = IntProperty(
        name="Items per Page",
        default=5,
        min=1,
        max=20,
        description="Number of files to show per page"
    )
    
    bpy.types.Scene.mdb_gr2_ui_scale = FloatProperty(
        name="UI Scale",
        default=1.0,
        min=0.5,
        max=2.0,
        description="Scale of the file list items"
    )

    # Custom selection storage
    bpy.types.Scene.mdb_gr2_selection_flags = {}

    # Register dynamic_props pointer property
    bpy.types.Scene.dynamic_props = PointerProperty(type=DynamicProperties)
    
    # Main tool selection enum - WITH FLOWCHART VIEW PROPERTY
    print("Registering flowchart properties...")
    
    # Updated tool selection property with PLACEABLES added
    bpy.types.Scene.nwn2_active_tool = EnumProperty(
        name="Active Tool",
        description="Select which tool category to display",
        items=[
            ('MODEL', 'Model Tools', 'Model export and transform tools', 'MESH_DATA', 0),
            ('MATERIAL', 'Material Tools', 'Material and texture tools', 'MATERIAL', 1),
            ('ANIMATION', 'Animation Tools', 'Animation import/export tools', 'ANIM', 2),
            ('RETARGETING', 'Retargeting Tools', 'Animation retargeting tools', 'ARMATURE_DATA', 3),
            ('TWODA', '2DA Tools', 'NWN2 2DA file editor', 'TEXT', 4),
            ('EQUIPMENT', 'Equipment Tools', 'Character equipment management', 'OUTLINER_OB_ARMATURE', 5),
            ('MOVEMENT', 'Movement Tools', 'Character movement animation tools', 'ANIM_DATA', 6),
            ('REVERSE', 'Reverse Tools', 'Reverse movement tools', 'CONSTRAINT', 7),
            ('JSON', 'JSON Tools', 'KISM JSON import/export tools', 'FILE_SCRIPT', 8),
        ],
        default='MODEL'
    )
    
    # Workflow mode property with all pipelines
    bpy.types.Scene.nwn2_workflow_mode = EnumProperty(
        name="Workflow Pipeline",
        description="Select which workflow pipeline to display",
        items=[
            ('ALL', 'All', 'Show all tool tabs'),
            ('PLACEABLES', 'Placeables', 'Placeables creation workflow'),
            ('ANIMATION', 'Animation', 'Animation pipeline workflow'),
            ('CREATURE', 'Creature Conversion', 'Creature conversion pipeline'),
            ('EQUIPMENT', 'Equipment Manager', 'Equipment management pipeline'),
        ],
        default='ALL'
    )

    print("  ✓ Registered NWN2 workflow pipeline properties")

    
    # Object Renaming Properties
    bpy.types.Scene.nwn2_rename_type = EnumProperty(
        name="Item Type",
        description="Select the item type",
        items=[
            ('Head', 'Head', 'Head'),
            ('Body', 'Body', 'Body'),
            ('Helm', 'Helm', 'Helm'),
            ('Eye', 'Eye', 'Eye'),
            ('Hair', 'Hair', 'Hair'),
            ('Boots', 'Boots', 'Boots'),
            ('Belt', 'Belt', 'Belt'),
            ('Gloves', 'Gloves', 'Gloves'),
            ('Cloak', 'Cloak', 'Cloak'),
            ('Custom', 'Custom', 'Enter custom type name'),
        ],
        default='Head'
    )

    bpy.types.Scene.nwn2_rename_custom_type = StringProperty(
        name="Custom Type",
        description="Enter custom item type name",
        default="Custom",
        maxlen=32
    )

    bpy.types.Scene.nwn2_rename_prefix = StringProperty(
        name="Prefix",
        description="Prefix for naming (e.g., PFX)",
        default="PFX",
        maxlen=16
    )

    bpy.types.Scene.nwn2_rename_numeric = StringProperty(
        name="Number",
        description="Starting number (digits only)",
        default="01",
        maxlen=4
    )

    bpy.types.Scene.nwn2_rename_sequential = BoolProperty(
        name="Sequential",
        description="Use sequential numbering (01, 02, 03...)",
        default=True
    )

    bpy.types.Scene.nwn2_rename_letter = EnumProperty(
        name="Letter",
        description="Letter suffix type for non-sequential naming",
        items=[
            ('C', 'C (C2, C3, ...)', 'C suffix without leading zero'),
            ('L', 'L (L02, L03, ...)', 'L suffix with leading zero'),
        ],
        default='C'
    )


        # ANIMATION PROPERTIES

    # ANIMATION PROPERTIES
    print("Registering animation properties...")
    bpy.types.Scene.animation_import_directory = StringProperty(
        name="Animation Import Directory",
        description="Directory to import animations from",
        default="",
        subtype='DIR_PATH'
    )
    
    bpy.types.Scene.animation_export_directory = StringProperty(
        name="Animation Export Directory",
        description="Directory to export animations to",
        default="",
        subtype='DIR_PATH'
    )
    
    bpy.types.Scene.animation_file_collection = CollectionProperty(type=AnimationFileListItem)
    bpy.types.Scene.animation_file_index = IntProperty(default=0)
    
    bpy.types.Scene.animation_list_collection = CollectionProperty(type=AnimationListItem)
    bpy.types.Scene.animation_list_index = IntProperty(default=0)
    
    # Animation UI properties (matching MDB/GR2 pattern)
    bpy.types.Scene.animation_scroll_index = IntProperty(
        name="Animation Scroll Index",
        default=0,
        min=0,
        description="Current page index for animation file list"
    )
    
    bpy.types.Scene.animation_scroll_height = IntProperty(
        name="Animation Items per Page",
        default=5,
        min=1,
        max=20,
        description="Number of animation files to show per page"
    )
    
    bpy.types.Scene.animation_ui_scale = FloatProperty(
        name="Animation UI Scale",
        default=1.0,
        min=0.5,
        max=2.0,
        description="Scale of the animation file list items"
    )
    
    # Animation selection storage (matching MDB/GR2 pattern)
    bpy.types.Scene.animation_selection_flags = {}
    
    # Animation search and sort
    bpy.types.Scene.animation_search_filter = StringProperty(
        name="Search Animations",
        description="Filter animations by name",
        default=""
    )
    
    bpy.types.Scene.animation_sort_alphabetical = BoolProperty(
        name="Sort Alphabetically",
        description="Sort animations alphabetically",
        default=True
    )
    
    # Animation display options
    bpy.types.Scene.display_all_animations = BoolProperty(
        name="Display Full Animation Names",
        description="Display all animations without filtering",
        default=False
    )
    
    # Animation export settings
    bpy.types.Scene.animation_suffix = StringProperty(
        name="Animation Export Name",
        description="Suffix for exported animation names",
        default=""
    )
    
    # Bake progress
    bpy.types.Scene.bake_progress = FloatProperty(
        name="Bake Progress",
        description="Progress of current bake operation",
        default=0.0,
        min=0.0,
        max=100.0
    )
    
    # RETARGETING PROPERTIES
    print("Registering retargeting properties...")
    
    # Retargeting properties
    bpy.types.Scene.show_armature_constraints = BoolProperty(default=False)
    bpy.types.Scene.selected_armature = StringProperty()
    bpy.types.Scene.active_constraint_prefix = StringProperty()
    
    # Try to register BONE_UL_List from retargeting tools if available
    if RETARGETING_TOOLS_AVAILABLE:
        try:
            bpy.utils.register_class(BONE_UL_List)
            print("  ✓ Registered BONE_UL_List class")
        except Exception as e:
            print(f"  ✗ Failed to register BONE_UL_List: {e}")
    else:
        try:
            bpy.utils.register_class(BONE_UL_List)
            print("  ✓ Created fallback BONE_UL_List")
        except Exception as e:
            print(f"  ✗ Failed to create fallback BONE_UL_List: {e}")
    
    # 2DA PROPERTIES
    print("Registering 2DA properties...")
    
    # 2DA properties
    bpy.types.Scene.twoda_active_tab = EnumProperty(
        name="2DA File Type",
        description="Select which 2DA file to edit",
        items=[
            ('placeables', 'Placeables', 'Edit placeables.2da file'),
            ('appearance', 'Appearance', 'Edit appearance.2da file'),
            ('wingmodel', 'Wing Model', 'Edit wingmodel.2da file'),
            ('tailmodel', 'Tail Model', 'Edit tailmodel.2da file'),
            ('baseitem', 'Base Items', 'Edit baseitems.2da file'),
        ],
        default='placeables'
    )
    
    # Ensure row_details_expanded property exists
    bpy.types.Scene.row_details_expanded = BoolProperty(
        name="Show Row Details",
        description="Show detailed row properties for editing",
        default=False
    )
    
    # EQUIPMENT PROPERTIES
    print("Registering equipment properties...")
    
    # Register AP creation properties pointer if available
    if EQUIPMENT_TOOLS_AVAILABLE:
        try:
            bpy.types.Scene.ap_creation_props = PointerProperty(type=APCreationProperties)
            bpy.types.Scene.ap_scene_props = PointerProperty(type=APSceneProperties)
            print("  ✓ Registered AP creation properties")
        except Exception as e:
            print(f"  ✗ Failed to register AP properties: {e}")
    
    # Register 2DA UI list if available
    if TWODA_TOOLS_AVAILABLE:
        try:
            bpy.utils.register_class(NWN2_UL_2DAList)
            print("  ✓ Registered NWN2_UL_2DAList")
        except Exception as e:
            print(f"  ✗ Failed to register NWN2_UL_2DAList: {e}")
    
    print("✓ All properties registered")
    
    # Set initial value after registration to ensure it's set
    def set_initial_value():
        """Set initial value after registration"""
        try:
            scene = bpy.context.scene
            if hasattr(scene, 'nwn2_active_tool'):
                # Ensure it has a valid value
                valid_tools = ['MODEL', 'MATERIAL', 'ANIMATION', 'RETARGETING', 
                             'TWODA', 'EQUIPMENT', 'MOVEMENT', 'REVERSE', 'JSON']
                if scene.nwn2_active_tool not in valid_tools:
                    scene.nwn2_active_tool = 'MODEL'
                    print("✓ Set default active tool to MODEL")
            
            # Set default flowchart view if it exists
            if hasattr(scene, 'nwn2_flowchart_view'):
                if scene.nwn2_flowchart_view not in ['ALL', 'MODELING', 'ANIMATION', 'GAME_INTEGRATION', 'CUSTOM']:
                    scene.nwn2_flowchart_view = 'ALL'
                    print("✓ Set default flowchart view to ALL")
            
        except Exception as e:
            print(f"Error setting initial value: {e}")
    
    # Run after a short delay
    bpy.app.timers.register(set_initial_value, first_interval=0.5)
    print("=== Registration Complete ===")

# ==============================================
# UNREGISTRATION - UPDATED WITH FLOWCHART FEATURES
# ==============================================

def unregister():
    print("=== Unregistering NWN2 Extended Blender Tools ===")
    
    # Unregister the custom workflow operators FIRST
    print("Unregistering custom workflow operators...")
    custom_operators = [
        NWN2_OT_add_custom_stage,
        NWN2_OT_reset_custom_workflow,
    ]
    
    for cls in custom_operators:
        try:
            bpy.utils.unregister_class(cls)
            print(f"  ✓ Unregistered operator: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to unregister {cls.__name__}: {e}")
    
    # Unregister the other operators
    operators_to_unregister = [
        NWN2_OT_select_import_folder,
        NWN2_OT_select_model_export_folder,
        NWN2_OT_select_material_export_folder,
        NWN2_OT_select_animation_import_folder,
        NWN2_OT_select_animation_export_folder,
        NWN2_OT_ScrollImportList,
        NWN2_OT_ScrollAnimationList,
        TWODA_OT_ShowTooltip,
    ]
    
    for cls in operators_to_unregister:
        try:
            bpy.utils.unregister_class(cls)
            print(f"  ✓ Unregistered class: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to unregister {cls.__name__}: {e}")
    
    # Unregister classes from this file
    classes_to_unregister = [
        NWN2_PT_main_panel,
        DynamicProperties,
        MDBGR2FileItem,
        AnimationListItem,
        AnimationFileListItem,
        BoneListItem,
    ]
    
    for cls in classes_to_unregister:
        try:
            bpy.utils.unregister_class(cls)
            print(f"  ✓ Unregistered class: {cls.__name__}")
        except Exception as e:
            print(f"  ✗ Failed to unregister {cls.__name__}: {e}")

    # Unregister MDB/GR2 import properties
    mdb_properties = [
        'mdb_gr2_import_directory',
        'mdb_gr2_file_collection',
        'mdb_gr2_file_index',
        'mdb_gr2_scroll_index',
        'mdb_gr2_scroll_height',
        'mdb_gr2_ui_scale',
        'mdb_gr2_selection_flags'
    ]
    
    for prop_name in mdb_properties:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
            print(f"  ✓ Removed property: {prop_name}")
    
    # Unregister animation properties
    animation_properties = [
        'animation_import_directory',
        'animation_export_directory',
        'animation_file_collection',
        'animation_file_index',
        'animation_list_collection',
        'animation_list_index',
        'animation_scroll_index',
        'animation_scroll_height',
        'animation_ui_scale',
        'animation_selection_flags',
        'animation_search_filter',
        'animation_sort_alphabetical',
        'display_all_animations',
        'animation_suffix',
        'bake_progress'
    ]
    
    for prop_name in animation_properties:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
            print(f"  ✓ Removed property: {prop_name}")
    
    # Unregister retargeting properties
    retargeting_properties = [
        'show_armature_constraints',
        'selected_armature',
        'active_constraint_prefix'
    ]
    
    for prop_name in retargeting_properties:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
            print(f"  ✓ Removed property: {prop_name}")
    
    # Unregister 2DA properties
    twoda_properties = [
        'twoda_active_tab',
        'row_details_expanded',
    ]
    
    for prop_name in twoda_properties:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
            print(f"  ✓ Removed property: {prop_name}")
    
    # Unregister equipment properties
    if hasattr(bpy.types.Scene, 'ap_creation_props'):
        del bpy.types.Scene.ap_creation_props
        print(f"  ✓ Removed property: ap_creation_props")
    
    if hasattr(bpy.types.Scene, 'ap_scene_props'):
        del bpy.types.Scene.ap_scene_props
        print(f"  ✓ Removed property: ap_scene_props")
    
    # Unregister dynamic properties
    if hasattr(bpy.types.Scene, 'dynamic_props'):
        del bpy.types.Scene.dynamic_props
        print(f"  ✓ Removed property: dynamic_props")
    
    # NEW: Unregister flowchart view property
    if hasattr(bpy.types.Scene, 'nwn2_flowchart_view'):
        del bpy.types.Scene.nwn2_flowchart_view
        print(f"  ✓ Removed property: nwn2_flowchart_view")
    
    # Clean up all other properties
    properties_to_remove = [
        'nwn2_active_tool',
        # Object renaming properties
        'nwn2_rename_prefix', 'nwn2_rename_numeric', 'nwn2_rename_type',
        'nwn2_rename_sequential', 'nwn2_rename_letter',
    ]
    
    # Add collapsible section properties to remove
    collapsible_sections = [
        # Model workflow sections
        'show_mdb_gr2_import_section', 'show_object_renaming_section', 'show_model_prepare_section',
        'show_model_tools_section', 'show_model_folders_section',
        
        # Material workflow sections
        'show_material_setup_section', 'show_material_folders_section', 'show_material_tools_section',

        # Retopology workflow sections
        'show_material_retopology_section', 'show_retopology_modifiers_section', 'show_retopology_baking_section',
        
        # Merge Texture workflow sections
        'show_material_merge_texture_section', 'show_merge_texture_objects_section', 'show_merge_texture_uv_section',
        'show_merge_texture_texture_section', 'show_merge_texture_baking_section',

        # Animation workflow sections
        'show_animation_import_section', 'show_animation_export_section', 'show_animation_management_section',
        
        # Retargeting workflow sections
        'show_retarget_connect_section', 'show_retarget_manage_section',
        'show_source_vertex_section', 'show_source_bones_section', 'show_source_controls_section',
        'show_target_rotation_section', 'show_target_parenting_section',
        
        # 2DA workflow sections
        'show_twoda_files_section', 'show_twoda_editor_section', 'show_twoda_sync_section',
        
        # Equipment workflow sections
        'show_equipment_setup_section', 'show_equipment_import_section', 'show_equipment_organization_section',
        'show_equipment_custom_section', 'show_ap_creation_section',
        
        # Movement workflow sections
        'show_movement_presets_section', 'show_movement_settings_section', 'show_movement_tools_section',
        
        # Reverse workflow sections
        'show_reverse_settings_section', 'show_reverse_workflow_section',
        
        # JSON workflow sections
        'show_json_export_section', 'show_json_import_section', 'show_json_advanced_section',
    ]
    
    properties_to_remove.extend(collapsible_sections)
    
    for prop_name in properties_to_remove:
        if hasattr(bpy.types.Scene, prop_name):
            try:
                delattr(bpy.types.Scene, prop_name)
                print(f"  ✓ Removed property: {prop_name}")
            except:
                pass
    
    # Unregister BONE_UL_List if it exists
    try:
        bpy.utils.unregister_class(BONE_UL_List)
        print("  ✓ Unregistered BONE_UL_List")
    except:
        pass
    
    # Unregister NWN2_UL_2DAList if it exists
    try:
        bpy.utils.unregister_class(NWN2_UL_2DAList)
        print("  ✓ Unregistered NWN2_UL_2DAList")
    except:
        pass
    
    print("=== Unregistration Complete ===")

if __name__ == "__main__":
    register()