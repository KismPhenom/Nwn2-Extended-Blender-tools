# Standard library imports
import os

# Blender imports
import bpy
from bpy.props import StringProperty
from bpy.types import Operator

# ==============================================
# TEXTURE EXPORT OPERATORS
# ==============================================

class WM_OT_ExportTextures(bpy.types.Operator):
    bl_idname = "wm.export_textures"
    bl_label = "Export Textures"
    bl_description = "Export all textures as DDS and reconnect them using the predefined export folder"

    def execute(self, context):
        if not hasattr(context.scene, 'dynamic_props'):
            self.report({'ERROR'}, "Dynamic properties not initialized. Please reload the addon.")
            return {'CANCELLED'}
            
        export_dir = bpy.path.abspath(context.scene.dynamic_props.material_export_folder)

        print(f"Material Tools DEBUG: Texture export path: {export_dir}")
        print(f"Material Tools DEBUG: Path exists: {os.path.exists(export_dir)}")
        print(f"Material Tools DEBUG: Is directory: {os.path.isdir(export_dir)}")

        if not export_dir or not os.path.isdir(export_dir):
            self.report({'ERROR'}, f"Export folder is invalid: {export_dir}")
            return {'CANCELLED'}

        # Store original image data
        texture_data = []
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            for mat_slot in obj.material_slots:
                mat = mat_slot.material
                if not mat or not mat.use_nodes:
                    continue

                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        img = node.image
                        texture_data.append({
                            'node': node,
                            'image': img,
                            'colorspace': img.colorspace_settings.name,
                            'original_path': img.filepath if img.filepath else ""
                        })

        # Export process
        exported = 0
        failed = []
        
        for data in texture_data:
            node = data['node']
            img = data['image']
            colorspace = data['colorspace']
            original_path = data['original_path']

            try:
                if not (img.packed_file or img.filepath):
                    failed.append(f"{img.name} (no source data)")
                    continue

                # Prepare export path
                dds_filename = f"{os.path.splitext(img.name)[0]}.dds"
                dds_path = os.path.join(export_dir, dds_filename)

                # Set DDS format if available
                if hasattr(img, 'dds_props') and hasattr(img.dds_props, 'dxgi_format'):
                    img.dds_props.dxgi_format = 'BC3_UNORM'

                # Ensure proper context for image.save_as
                area = None
                for w in context.window_manager.windows:
                    for a in w.screen.areas:
                        if a.type == 'IMAGE_EDITOR':
                            area = a
                            break
                    if area:
                        break

                if area:
                    old_image = area.spaces.active.image
                    area.spaces.active.image = img
                    context.view_layer.update()

                # Export DDS
                try:
                    img.save_render(filepath=dds_path, quality=90)
                    exported += 1
                    print(f"Material Tools DEBUG: Successfully exported {dds_filename}")
                except Exception as e:
                    failed.append(f"{img.name} (export failed: {str(e)})")
                    print(f"Material Tools DEBUG: Export failed for {img.name}: {str(e)}")
                    continue

                # Restore previous image in editor (if modified)
                if area and old_image:
                    area.spaces.active.image = old_image

                # Delete original texture if it's not from an existing file
                if not original_path or img.packed_file:
                    bpy.data.images.remove(img, do_unlink=True)

                # Reconnect texture
                if dds_filename in bpy.data.images:
                    new_img = bpy.data.images[dds_filename]
                else:
                    new_img = bpy.data.images.load(dds_path)
                    new_img.name = dds_filename

                # Restore settings
                new_img.colorspace_settings.name = colorspace
                node.image = new_img

            except Exception as e:
                failed.append(f"{img.name} ({str(e)})")
                print(f"Material Tools DEBUG: Exception for {img.name}: {str(e)}")

        # Report results
        if exported:
            msg = f"Exported {exported} textures"
            if failed:
                msg += f", failed: {', '.join(failed)}"
            self.report({'INFO'}, msg)
        else:
            self.report({'WARNING'}, "No textures exported" + (f" ({', '.join(failed)})" if failed else ""))

        return {'FINISHED'}

class WM_OT_SelectExportFolder(bpy.types.Operator):
    bl_idname = "wm.select_export_folder"
    bl_label = "Choose Export Folder"
    bl_description = "Select the folder where textures and models will be exported"

    directory: bpy.props.StringProperty(subtype='DIR_PATH')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if self.directory:
            # Convert Blender relative path to absolute path
            if self.directory.startswith('//'):
                abs_path = bpy.path.abspath(self.directory)
            else:
                abs_path = self.directory
            
            # Ensure it's a valid directory
            if os.path.isdir(abs_path):
                if hasattr(context.scene, 'nwn2_export_props'):
                    context.scene.nwn2_export_props.export_texture_path = abs_path
                if hasattr(context.scene, 'dynamic_props'):
                    context.scene.dynamic_props.material_export_folder = abs_path
                self.report({'INFO'}, f"Export folder set to: {abs_path}")
            else:
                self.report({'ERROR'}, f"Invalid directory: {abs_path}")
        return {'FINISHED'}

# ==============================================
# MATERIAL TOOLS
# ==============================================

class NWN2_OT_AddPrincipledBSDFSetup(bpy.types.Operator):
    bl_idname = "nwn2.add_principled_bsdf_setup"

    bl_label = "Add Basic Material Setup"
    bl_description = "Add a basic material setup with Diffuse and Normal maps"

    def execute(self, context):
        obj = context.object

        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "No mesh object selected")
            return {'CANCELLED'}

        # Get or create material
        if not obj.data.materials:
            mat = bpy.data.materials.new(name="Material")
            obj.data.materials.append(mat)
        else:
            mat = obj.data.materials[0]

        # Ensure material uses nodes
        if not mat.use_nodes:
            mat.use_nodes = True

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        # Clear existing nodes
        nodes.clear()

        # Create output node
        output_node = nodes.new(type='ShaderNodeOutputMaterial')
        output_node.location = (600, 0)

        # Create Principled BSDF node
        principled_node = nodes.new(type='ShaderNodeBsdfPrincipled')
        principled_node.location = (300, 0)
        principled_node.width = 300
        principled_node.height = 300
        links.new(principled_node.outputs['BSDF'], output_node.inputs['Surface'])

        # Diffuse/Base Color texture (top)
        diffuse_tex = nodes.new(type='ShaderNodeTexImage')
        diffuse_tex.location = (-600, 200)
        diffuse_tex.label = "Diffuse Map"
        links.new(diffuse_tex.outputs['Color'], principled_node.inputs['Base Color'])

        # Normal Map (bottom)
        normal_tex = nodes.new(type='ShaderNodeTexImage')
        normal_tex.location = (-600, -200)
        normal_tex.label = "Normal Map"
        
        normal_map = nodes.new(type='ShaderNodeNormalMap')
        normal_map.location = (-300, -200)
        links.new(normal_tex.outputs['Color'], normal_map.inputs['Color'])
        links.new(normal_map.outputs['Normal'], principled_node.inputs['Normal'])

        self.report({'INFO'}, "Basic material setup added with Diffuse and Normal maps")
        return {'FINISHED'}

class NWN2_OT_ConvertToPrincipled(bpy.types.Operator):
    bl_idname = "nwn2.convert_to_principled"
    bl_label = "Convert to Basic Material"
    bl_description = "Convert selected objects' materials to basic setup with Diffuse and Normal maps"
    bl_options = {'REGISTER', 'UNDO'}

    def detect_texture_role(self, tex_node):
        """Detect texture type from label, name, and image filename."""
        tags = []
        if tex_node.label:
            tags.append(tex_node.label.lower())
        tags.append(tex_node.name.lower())
        if tex_node.image:
            tags.append(os.path.basename(tex_node.image.filepath).lower())

        tags = ' '.join(tags)

        if "normal" in tags or "bump" in tags:
            return "Normal"
        elif "diffuse" in tags or "base" in tags or "color" in tags:
            return "Diffuse"
        else:
            # Default to Diffuse for any other texture
            return "Diffuse"

    def organize_nodes(self, ntree, bsdf, x_start=-1000, y_start=300, x_step=300, y_step=-300):
        """Organize nodes with only Diffuse and Normal maps"""
        nodes = ntree.nodes
        
        # Fixed positions for output and BSDF
        output = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if output:
            output.location = (x_start + x_step * 3, y_start)
        bsdf.location = (x_start + x_step * 2, y_start)

        # Categorize texture nodes
        tex_nodes = [n for n in nodes if isinstance(n, bpy.types.ShaderNodeTexImage)]
        diffuse_nodes = []
        normal_nodes = []
        
        for tex_node in tex_nodes:
            role = self.detect_texture_role(tex_node)
            if role == "Normal":
                normal_nodes.append(tex_node)
            else:  # Default to Diffuse
                diffuse_nodes.append(tex_node)

        # Position Diffuse nodes
        for i, tex_node in enumerate(diffuse_nodes):
            tex_node.location = (x_start, y_start + i * y_step)
            
        # Position Normal nodes below Diffuse nodes
        normal_y = y_start + len(diffuse_nodes) * y_step - 100
        for i, tex_node in enumerate(normal_nodes):
            tex_node.location = (x_start, normal_y + i * y_step)
            
            # Position connected normal map nodes
            for link in ntree.links:
                if link.from_node == tex_node and link.to_node.type == 'NORMAL_MAP':
                    link.to_node.location = (tex_node.location.x + x_step, tex_node.location.y)

    def connect_texture(self, tex_node, role, bsdf, links, ntree):
        if role == "Normal":
            normal_map = ntree.nodes.new('ShaderNodeNormalMap')
            links.new(tex_node.outputs['Color'], normal_map.inputs['Color'])
            links.new(normal_map.outputs['Normal'], bsdf.inputs['Normal'])
        else:  # Default to Diffuse
            links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])

    def convert_material_to_principled(self, mat):
        if not mat.use_nodes:
            mat.use_nodes = True

        ntree = mat.node_tree
        nodes = ntree.nodes
        links = ntree.links

        # Clear existing nodes except textures and output
        tex_nodes = [n for n in nodes if isinstance(n, bpy.types.ShaderNodeTexImage)]
        output_node = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
        
        # Remove all non-essential nodes
        for node in list(nodes):
            if node not in tex_nodes and node != output_node:
                nodes.remove(node)

        # Create output if it doesn't exist
        if not output_node:
            output_node = nodes.new('ShaderNodeOutputMaterial')

        # Create Principled BSDF
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        links.new(bsdf.outputs['BSDF'], output_node.inputs['Surface'])

        # Process all textures - only connect Diffuse and Normal
        for tex_node in tex_nodes:
            role = self.detect_texture_role(tex_node)
            self.connect_texture(tex_node, role, bsdf, links, ntree)

        # Organize all nodes neatly
        self.organize_nodes(ntree, bsdf)

    def execute(self, context):
        def convert_selected_object_materials():
            for obj in bpy.context.selected_objects:
                if not hasattr(obj.data, "materials"):
                    continue
                for mat in obj.data.materials:
                    if mat:
                        self.convert_material_to_principled(mat)

        # Run the conversion
        try:
            convert_selected_object_materials()
            self.report({'INFO'}, "Successfully converted materials to basic setup")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Conversion failed: {str(e)}")
            return {'CANCELLED'}

# ==============================================
# ADDITIONAL MATERIAL OPERATORS (Optional - if you need them)
# ==============================================

class MATERIAL_OT_CleanMaterials(bpy.types.Operator):
    """Clean unused materials from the scene"""
    bl_idname = "material.clean_materials"
    bl_label = "Clean Unused Materials"
    bl_description = "Remove all unused materials from the scene"
    
    def execute(self, context):
        # Get all materials currently in use
        used_materials = set()
        for obj in bpy.data.objects:
            if hasattr(obj.data, 'materials'):
                for mat in obj.data.materials:
                    if mat:
                        used_materials.add(mat)
        
        # Remove unused materials
        removed_count = 0
        for mat in list(bpy.data.materials):
            if mat not in used_materials and mat.users == 0:
                bpy.data.materials.remove(mat)
                removed_count += 1
        
        self.report({'INFO'}, f"Removed {removed_count} unused materials")
        return {'FINISHED'}

class MATERIAL_OT_ReloadTextures(bpy.types.Operator):
    """Reload all textures in the scene"""
    bl_idname = "material.reload_textures"
    bl_label = "Reload All Textures"
    bl_description = "Reload all image textures from disk"
    
    def execute(self, context):
        reloaded_count = 0
        for image in bpy.data.images:
            if image.filepath and os.path.exists(bpy.path.abspath(image.filepath)):
                image.reload()
                reloaded_count += 1
        
        self.report({'INFO'}, f"Reloaded {reloaded_count} textures")
        return {'FINISHED'}

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    # Texture export operators
    WM_OT_SelectExportFolder,
    WM_OT_ExportTextures,
    # Material tools
    NWN2_OT_AddPrincipledBSDFSetup,
    NWN2_OT_ConvertToPrincipled,
    # Additional material operators (optional)
    MATERIAL_OT_CleanMaterials,
    MATERIAL_OT_ReloadTextures,
)

def register():
    """Register all material tools classes"""
    # Register all classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
            print(f"Material Tools: Registered {cls.__name__}")
        except Exception as e:
            print(f"Material Tools: Failed to register {cls.__name__}: {e}")

def unregister():
    """Unregister all material tools classes"""
    # Unregister all classes
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
            print(f"Material Tools: Unregistered {cls.__name__}")
        except:
            pass

# Only register if running as a script
if __name__ == "__main__":
    register()