# Standard library imports
import os
from typing import Optional

# Blender imports
import bpy
from bpy.props import (
    StringProperty, BoolProperty, IntProperty, 
    FloatProperty, PointerProperty, EnumProperty, CollectionProperty
)
from bpy.types import Panel, Operator, PropertyGroup
from bpy_extras.io_utils import ExportHelper

# ==============================================
# PROPERTY GROUPS
# ==============================================

class NWN2ExportProperties(PropertyGroup):
    """Property group for NWN2 export settings"""
    export_texture_path: StringProperty(
        name="Texture Export Path",
        description="Directory path for exporting textures",
        default="",
        subtype='DIR_PATH'
    )
    
    animation_suffix: StringProperty(
        name="Animation Suffix",
        description="Suffix to append to exported animation names",
        default=""
    )
    
    export_directory: StringProperty(
        name="Export Directory",
        description="Base directory for all exports",
        default="",
        subtype='DIR_PATH'
    )

class MDBGR2FileItem(PropertyGroup):
    """Property group for MDB/GR2 file items"""
    name: StringProperty(name="File Name")
    filepath: StringProperty(name="File Path")
    file_type: StringProperty(name="File Type")  # "MDB" or "GR2"

# ==============================================
# OBJECT RENAMING OPERATORS
# ==============================================

class NWN2_OT_RenameObjectWithPrefix(Operator):
    """Rename selected objects with prefix pattern"""
    bl_idname = "nwn2.rename_with_prefix"
    bl_label = "Apply Rename"
    bl_description = "Rename object, mesh data, and material with current prefix settings"
    
    def execute(self, context):
        if not context.selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        # Get settings from scene properties
        scene = context.scene
        start_number = scene.nwn2_rename_numeric
        prefix_text = scene.nwn2_rename_prefix
        item_type = scene.nwn2_rename_type
        custom_type = scene.nwn2_rename_custom_type
        use_sequential = scene.nwn2_rename_sequential
        letter_suffix = scene.nwn2_rename_letter
        
        # Validate numeric input
        if not start_number.isdigit():
            self.report({'ERROR'}, "Starting number must contain only digits")
            return {'CANCELLED'}
        
        # Determine which type to use
        if item_type == 'Custom':
            type_to_use = custom_type
        else:
            type_to_use = item_type
        
        renamed_count = 0
        current_number = int(start_number)
        
        for i, obj in enumerate(context.selected_objects):
            # Format the new name
            if use_sequential:
                # Sequential numbering: 01, 02, 03, etc.
                numeric_part = f"{current_number:02d}"
                base_name = f"{prefix_text.upper()}_{type_to_use}{numeric_part}"
                current_number += 1
                new_name = base_name
                
            elif letter_suffix and i > 0:
                # Letter suffix numbering: only for objects after the first one
                if letter_suffix.upper() == 'C':
                    # C suffix: no leading zero, starts at 2
                    suffix_number = i + 1
                    numeric_part = f"{suffix_number}"
                else:
                    # L suffix: with leading zero, starts at 2  
                    suffix_number = i + 1
                    numeric_part = f"{suffix_number:02d}"
                
                base_name = f"{prefix_text.upper()}_{type_to_use}{start_number}_{letter_suffix.upper()}{numeric_part}"
                new_name = base_name
                
            else:
                # First object or no letter suffix - use base name
                base_name = f"{prefix_text.upper()}_{type_to_use}{start_number}"
                new_name = base_name
            
            # Rename the object
            obj.name = new_name
            
            # Rename mesh data to match exactly
            if obj.type == 'MESH' and obj.data:
                obj.data.name = new_name  # Mesh data gets identical name
            
            # Handle materials
            if obj.type == 'MESH':
                # Ensure object has at least one material slot
                if not obj.material_slots:
                    obj.data.materials.append(None)  # Add empty slot if none exist
                
                # Process each material slot
                for mat_index, mat_slot in enumerate(obj.material_slots):
                    if mat_slot.material:
                        # Material exists - rename it
                        # Check if material is shared with other objects
                        users = mat_slot.material.users
                        if users > 1:
                            # Shared material - create unique copy before renaming
                            new_mat = mat_slot.material.copy()
                            obj.material_slots[mat_index].material = new_mat
                            new_mat.name = new_name
                        else:
                            # Unique material - rename directly
                            mat_slot.material.name = new_name
                    else:
                        # No material in this slot - create new one
                        new_mat = bpy.data.materials.new(name=new_name)
                        obj.material_slots[mat_index].material = new_mat
            
            renamed_count += 1
        
        self.report({'INFO'}, f"Renamed {renamed_count} objects")
        return {'FINISHED'}

class NWN2_OT_ExtractFromSelection(Operator):
    """Extract prefix pattern from selected objects"""
    bl_idname = "nwn2.extract_prefix_from_selection"
    bl_label = "Extract Pattern"
    bl_description = "Extract naming pattern from selected objects"
    
    def execute(self, context):
        if not context.selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        scene = context.scene
        first_obj = context.selected_objects[0]
        
        # Extract pattern from existing name
        if '_' in first_obj.name:
            parts = first_obj.name.split('_')
            if len(parts) >= 2:
                scene.nwn2_rename_prefix = '_'.join(parts[:-1]).lower()
                
                last_part = parts[-1]
                for item_type in ['Head', 'Body', 'Helm', 'Eye', 'Hair', 'Boots', 'Belt', 'Gloves', 'Cloak']:
                    if last_part.startswith(item_type):
                        scene.nwn2_rename_type = item_type
                        remaining = last_part[len(item_type):]
                        if '_' in remaining:
                            suffix_parts = remaining.split('_')
                            if len(suffix_parts) == 2 and suffix_parts[1][:1].isalpha():
                                scene.nwn2_rename_numeric = suffix_parts[0]
                                scene.nwn2_rename_letter = suffix_parts[1][:1]
                            else:
                                scene.nwn2_rename_numeric = remaining
                        else:
                            scene.nwn2_rename_numeric = remaining
                        break
        
        self.report({'INFO'}, "Pattern extracted from selection")
        return {'FINISHED'}

# ==============================================
# MODEL EXPORT OPERATORS
# ==============================================

class NWN2_OT_ExportModel(bpy.types.Operator):
    bl_idname = "wm.export_model"
    bl_label = "Export Model"
    bl_description = "Export selected model(s) as NWN2 .MDB using the model export folder"

    def execute(self, context):
        if not hasattr(context.scene, 'dynamic_props'):
            self.report({'ERROR'}, "Dynamic properties not initialized. Please reload the addon.")
            return {'CANCELLED'}
            
        export_dir = bpy.path.abspath(context.scene.dynamic_props.model_export_folder)

        print(f"DEBUG: Model export path: {export_dir}")
        print(f"DEBUG: Path exists: {os.path.exists(export_dir)}")
        print(f"DEBUG: Is directory: {os.path.isdir(export_dir)}")

        if not export_dir or not os.path.isdir(export_dir):
            self.report({'ERROR'}, "Invalid export folder. Please select one first.")
            return {'CANCELLED'}

        if not context.selected_objects or not context.active_object:
            self.report({'ERROR'}, "No selected object or active object to name the export.")
            return {'CANCELLED'}

        # Store the original active object BEFORE any operations
        original_active = context.active_object
        original_active_name = original_active.name
        print(f"DEBUG: Original active object: {original_active_name}")
        
        # Store all selected objects
        original_selection = list(context.selected_objects)
        print(f"DEBUG: Original selection: {[obj.name for obj in original_selection]}")

        # Check transforms
        for obj in original_selection:
            if obj.type == 'MESH':
                warnings = []

                if any(abs(val) > 1e-4 for val in obj.location):
                    warnings.append("Location is not zeroed out")
                if any(abs(val) > 1e-4 for val in obj.rotation_euler):
                    warnings.append("Rotation is not zeroed out")
                if any(abs(val - 1.0) > 1e-4 for val in obj.scale):
                    warnings.append("Scale is not zeroed out")

                if warnings:
                    error_msg = f"Please apply transforms before exporting for model '{obj.name}': "
                    error_msg += ", ".join(warnings)
                    self.report({'ERROR'}, error_msg)
                    return {'CANCELLED'}

                if obj.parent and obj.parent.type == 'ARMATURE':
                    armature = obj.parent
                    armature_warnings = []

                    if any(abs(val) > 1e-4 for val in armature.location):
                        armature_warnings.append("Location is not zeroed out")
                    if any(abs(val) > 1e-4 for val in armature.rotation_euler):
                        armature_warnings.append("Rotation is not zeroed out")
                    if any(abs(val - 1.0) > 1e-4 for val in armature.scale):
                        armature_warnings.append("Scale is not zeroed out")

                    if armature_warnings:
                        error_msg = f"Please apply transforms to armature '{armature.name}' before exporting: "
                        error_msg += ", ".join(armature_warnings)
                        self.report({'ERROR'}, error_msg)
                        return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')  # Ensure we're in OBJECT mode

        # Rename mesh data and active material
        for obj in original_selection:
            if obj.type == 'MESH':
                obj_name = obj.name

                # Rename mesh data block
                if obj.data.name != obj_name:
                    obj.data.name = obj_name

                # Ensure an active material is set
                if obj.active_material is None and obj.material_slots:
                    obj.active_material_index = 0

                # Rename active material to match object name
                if obj.active_material and obj.active_material.name != obj_name:
                    obj.active_material.name = obj_name

        # Limit vertex groups to 4 weights per vertex
        for obj in original_selection:
            if obj.type == 'MESH' and obj.vertex_groups:
                # Clear selection and select only this object
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                bpy.ops.object.vertex_group_limit_total(limit=4)

        # Restore original selection and active object
        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selection:
            obj.select_set(True)
        context.view_layer.objects.active = original_active
        
        print(f"DEBUG: Restored active object to: {context.active_object.name}")

        # Export using the original active object's name
        export_path = os.path.join(export_dir, original_active_name + ".mdb")

        print(f"DEBUG: Final export path: {export_path}")

        # Make sure the export operator exists
        if hasattr(bpy.ops, 'export_scene.nwn2mdk_mdb'):
            try:
                # Ensure we're still in OBJECT mode with correct selection
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Double-check selection before export
                if context.active_object != original_active:
                    context.view_layer.objects.active = original_active
                
                bpy.ops.export_scene.nwn2mdk_mdb(
                    filepath=export_path,
                    use_selection=True
                )
                
                # Final restoration of active object
                context.view_layer.objects.active = original_active
                
                self.report({'INFO'}, f"Exported model as: {original_active_name}.mdb")
                print(f"DEBUG: Export completed successfully")
                print(f"DEBUG: Active object after export: {context.active_object.name}")
                
            except Exception as e:
                # Check if there's a log.txt file and read it
                log_file = os.path.join(export_dir, "log.txt")
                error_message = str(e)
                vertex_weight_error = False
                
                if os.path.exists(log_file):
                    try:
                        with open(log_file, 'r') as f:
                            log_content = f.read()
                            
                            # Check for vertex weight errors
                            if "Vertex has no weights" in log_content:
                                vertex_weight_error = True
                                error_message = "Fix Weights of Selected vertices"
                                
                                # Count how many vertex weight errors
                                weight_error_count = log_content.count("Vertex has no weights")
                                error_message = f"Fix Weights of Selected vertices ({weight_error_count} vertices have no weights)"
                                
                                # Select all vertices without weights for the user to fix
                                # First, find which mesh object(s) might have the issue
                                for obj in original_selection:
                                    if obj.type == 'MESH':
                                        # Select the object and enter edit mode
                                        bpy.ops.object.select_all(action='DESELECT')
                                        obj.select_set(True)
                                        context.view_layer.objects.active = obj
                                        
                                        # Enter edit mode and select all vertices (we can't know which specific ones)
                                        bpy.ops.object.mode_set(mode='EDIT')
                                        bpy.ops.mesh.select_all(action='SELECT')
                                        
                                        # Show a message about how to fix weights
                                        self.report({'WARNING'}, f"Selected all vertices in '{obj.name}' for weight painting")
                                        
                                        # Restore object mode but keep selection
                                        bpy.ops.object.mode_set(mode='OBJECT')
                                        
                            # Also check for other specific errors
                            elif "ERROR:" in log_content:
                                # Get the last ERROR line
                                error_lines = [line for line in log_content.split('\n') if "ERROR:" in line]
                                if error_lines:
                                    # Look for specific error types
                                    for line in error_lines:
                                        if "transform" in line.lower() or "location" in line.lower() or "rotation" in line.lower() or "scale" in line.lower():
                                            error_message = line.replace("ERROR: ", "")
                                            break
                                        elif "MDB not generated" in line:
                                            # Get a more specific error if available
                                            for error_line in error_lines:
                                                if error_line and "ERROR:" in error_line and "MDB not generated" not in error_line:
                                                    error_message = error_line.replace("ERROR: ", "")
                                                    break
                                            break
                                    else:
                                        # If no specific error found, use the last error
                                        error_message = error_lines[-1].replace("ERROR: ", "")
                    except Exception as log_error:
                        print(f"DEBUG: Failed to read log file: {str(log_error)}")
                
                if vertex_weight_error:
                    # For vertex weight errors, we need to prompt the user to fix them
                    # We've already selected the problematic mesh and entered edit mode
                    # Now show the error and cancel
                    self.report({'ERROR'}, error_message)
                    print(f"DEBUG: Vertex weight error detected: {error_message}")
                    return {'CANCELLED'}
                else:
                    # For other errors, show the error message
                    self.report({'ERROR'}, f"Export failed: {error_message}")
                    print(f"DEBUG: Export failed: {error_message}")
                    return {'CANCELLED'}
                
        else:
            self.report({'ERROR'}, "NWN2 MDB export operator not available")
            return {'CANCELLED'}

        return {'FINISHED'}

class NWN2_OT_SelectModelExportFolder(bpy.types.Operator):
    """Select folder for model exports"""
    bl_idname = "nwn2.select_model_export_folder"
    bl_label = "Choose Model Export Folder"
    bl_description = "Select the folder where models will be exported"
    
    directory: StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        if self.directory:
            # Convert Blender relative path to absolute path
            if self.directory.startswith('//'):
                abs_path = bpy.path.abspath(self.directory)
            else:
                abs_path = self.directory
            
            # Ensure it's a valid directory
            if os.path.isdir(abs_path):
                if hasattr(context.scene, 'dynamic_props'):
                    context.scene.dynamic_props.model_export_folder = abs_path
                    self.report({'INFO'}, f"Model export folder set to: {abs_path}")
                else:
                    self.report({'ERROR'}, "Dynamic properties not initialized")
            else:
                self.report({'ERROR'}, f"Invalid directory: {abs_path}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# ==============================================
# TRANSFORM TOOLS
# ==============================================

class NWN2_OT_ApplyAllTransforms(bpy.types.Operator):
    bl_idname = "nwn2.apply_all_transforms"
    bl_label = "Apply All Transforms"
    bl_description = "Apply all transforms (location, rotation, scale) to the selected object"

    def execute(self, context):
        obj = context.object

        if obj:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            self.report({'INFO'}, "All transforms applied")
        else:
            self.report({'WARNING'}, "No object selected")

        return {'FINISHED'}

class NWN2_OT_WeightTransfer(bpy.types.Operator):
    bl_idname = "nwn2.weight_transfer"
    bl_label = "Weight Transfer"
    bl_description = "Transfer vertex weights from one object to another using Data Transfer Modifier"

    def execute(self, context):
        # Ensure exactly two objects are selected
        if len(context.selected_objects) != 2:
            self.report({'WARNING'}, "Please select exactly two objects.")
            return {'CANCELLED'}
        
        # Get the selected objects
        selected_objects = context.selected_objects
        
        # Assume the active object is the one to which we want to add the modifier
        target_object = context.view_layer.objects.active
        # The other selected object is the source
        source_object = [obj for obj in selected_objects if obj != target_object][0]
        
        # Check if both objects are mesh or armature
        if target_object.type in {'MESH', 'ARMATURE'} and source_object.type in {'MESH', 'ARMATURE'}:
            # Add a Data Transfer Modifier to the target object
            bpy.ops.object.modifier_add(type='DATA_TRANSFER')
            
            # Configure the modifier
            modifier = target_object.modifiers[-1]
            modifier.name = "Data Transfer Modifier"
            modifier.object = source_object  # Set the source object
            
            # Ensure Vertex Data is checked
            modifier.use_vert_data = True
            modifier.data_types_verts = {'VGROUP_WEIGHTS'}  # Set to transfer vertex group weights
            modifier.vert_mapping = 'POLYINTERP_NEAREST'  # Set vertex mapping to nearest
            
            # Move the modifier to index 0
            bpy.ops.object.modifier_move_to_index(modifier=modifier.name, index=0)
            
            # Perform data layout transfer and apply the modifier
            bpy.ops.object.datalayout_transfer(modifier=modifier.name)
            bpy.ops.object.modifier_apply(modifier=modifier.name)

            self.report({'INFO'}, f"Data Transfer Modifier added to {target_object.name}, using {source_object.name} as the source, and applied.")
        else:
            self.report({'WARNING'}, "Both objects must be of type MESH or ARMATURE.")

        return {'FINISHED'}

# ==============================================
# ARMATURE TOOLS OPERATOR
# ==============================================

class NWN2_OT_SetupArmature(bpy.types.Operator):
    """Export armature as NWN2 skeleton file"""
    bl_idname = "object.setup_armature"
    bl_label = "Export Armature as Skeleton"
    bl_description = "Export selected armature as NWN2 skeleton file (.MDB or .GR2)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'ARMATURE':
            self.report({'WARNING'}, "Please select an armature object")
            return {'CANCELLED'}
        
        # Check if we have the export folder set
        if not hasattr(context.scene, 'dynamic_props'):
            self.report({'ERROR'}, "Dynamic properties not initialized")
            return {'CANCELLED'}
            
        export_dir = bpy.path.abspath(context.scene.dynamic_props.model_export_folder)
        
        if not export_dir or not os.path.isdir(export_dir):
            self.report({'ERROR'}, "Invalid export folder. Please set Model Export Folder first.")
            return {'CANCELLED'}
        
        armature = context.active_object
        armature_name = armature.name
        
        print(f"DEBUG: Exporting armature '{armature_name}' to: {export_dir}")
        
        # CHECK 1: Armature must have at least one bone
        if not armature.data.bones:
            self.report({'ERROR'}, "Armature has no bones")
            return {'CANCELLED'}
        
        # CHECK 2: Get root bone name (bone without parent)
        root_bones = [bone for bone in armature.data.bones if not bone.parent]
        if not root_bones:
            self.report({'ERROR'}, "Armature has no root bone (all bones have parents)")
            return {'CANCELLED'}
        
        root_bone = root_bones[0]
        root_bone_name = root_bone.name
        
        # CHECK 3: Armature name must match root bone name
        if armature_name != root_bone_name:
            self.report({'ERROR'}, f"Skeleton name is not equal to root bone name: {armature_name} != {root_bone_name}")
            return {'CANCELLED'}
        
        # CHECK 4: Check if transforms are zeroed out
        transform_warnings = []
        
        # Check location
        if any(abs(val) > 1e-4 for val in armature.location):
            transform_warnings.append("Location is not zeroed out")
        
        # Check rotation
        if any(abs(val) > 1e-4 for val in armature.rotation_euler):
            transform_warnings.append("Rotation is not zeroed out")
        
        # Check scale
        if any(abs(val - 1.0) > 1e-4 for val in armature.scale):
            transform_warnings.append("Scale is not zeroed out")
        
        if transform_warnings:
            error_msg = "Please apply transforms before exporting: "
            error_msg += ", ".join(transform_warnings)
            self.report({'ERROR'}, error_msg)
            return {'CANCELLED'}
        
        # Store original selection
        original_selection = list(context.selected_objects)
        original_active = context.active_object
        
        # First ensure armature is selected and active
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        context.view_layer.objects.active = armature
        
        # Store original pose position
        bpy.ops.object.mode_set(mode='POSE')
        pose_position_backup = armature.data.pose_position
        
        # SWITCH TO REST POSITION for export
        armature.data.pose_position = 'REST'
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Export path - use .gr2 extension for skeleton
        export_path = os.path.join(export_dir, armature_name + ".gr2")
        print(f"DEBUG: Export path: {export_path}")
        
        # Make sure the export operator exists - using GR2 exporter
        if hasattr(bpy.ops, 'export_scene.nwn2mdk_gr2'):
            try:
                # Export with skeleton settings
                bpy.ops.export_scene.nwn2mdk_gr2(
                    filepath=export_path,
                    check_existing=False,
                    use_selection=True,
                    data_type='SKEL'  # Correct parameter for skeleton export
                )
                
                # RESTORE TO ORIGINAL POSE POSITION
                bpy.ops.object.mode_set(mode='POSE')
                armature.data.pose_position = pose_position_backup
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Restore original selection
                bpy.ops.object.select_all(action='DESELECT')
                for obj in original_selection:
                    obj.select_set(True)
                context.view_layer.objects.active = original_active
                
                # Check if file was created
                if os.path.exists(export_path):
                    file_size = os.path.getsize(export_path)
                    self.report({'INFO'}, f"Exported skeleton '{armature_name}' as {os.path.basename(export_path)} ({file_size} bytes)")
                    print(f"DEBUG: Skeleton export successful: {export_path}")
                else:
                    self.report({'WARNING'}, f"Export completed but file not found: {export_path}")
                    
            except Exception as export_error:
                # RESTORE TO ORIGINAL POSE POSITION even on error
                bpy.ops.object.mode_set(mode='POSE')
                armature.data.pose_position = pose_position_backup
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Restore original selection
                bpy.ops.object.select_all(action='DESELECT')
                for obj in original_selection:
                    obj.select_set(True)
                context.view_layer.objects.active = original_active
                
                # Check if there's a log.txt file and read it
                log_file = os.path.join(export_dir, "log.txt")
                error_message = str(export_error)
                
                if os.path.exists(log_file):
                    try:
                        with open(log_file, 'r') as f:
                            log_content = f.read()
                            # Look for error messages in the log
                            if "ERROR:" in log_content:
                                # Get the last ERROR line
                                error_lines = [line for line in log_content.split('\n') if "ERROR:" in line]
                                if error_lines:
                                    error_message = error_lines[-1].replace("ERROR: ", "")
                    except:
                        pass
                
                self.report({'ERROR'}, f"Skeleton export failed: {error_message}")
                print(f"DEBUG: Skeleton export error: {error_message}")
                return {'CANCELLED'}
        else:
            self.report({'ERROR'}, "NWN2 GR2 export operator not available")
            return {'CANCELLED'}
        
        self.report({'INFO'}, f"Exported armature as skeleton")
        
        return {'FINISHED'}

# ==============================================
# PANEL TOOLS OPERATORS
# ==============================================

class NWN2_OT_CleanupMesh(bpy.types.Operator):
    """Cleanup mesh by removing duplicate vertices and faces"""
    bl_idname = "mesh.cleanup_mesh"
    bl_label = "Cleanup Mesh"
    bl_description = "Remove duplicate vertices and faces - essential before editing any mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object")
            return {'CANCELLED'}

        # Switch to Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Select all geometry
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Remove duplicate vertices
        bpy.ops.mesh.remove_doubles()
        
        # Delete loose geometry
        bpy.ops.mesh.delete_loose()
        
        # Switch back to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        self.report({'INFO'}, "Mesh cleanup completed")
        return {'FINISHED'}

class NWN2_OT_MergeByDistance(bpy.types.Operator):
    """Merge vertices by distance to fix overlapping geometry"""
    bl_idname = "mesh.remove_doubles"
    bl_label = "Merge by Distance"
    bl_description = "Merge vertices within specified distance - fixes overlapping geometry"
    bl_options = {'REGISTER', 'UNDO'}

    distance: FloatProperty(
        name="Merge Distance",
        description="Maximum distance between vertices to merge",
        default=0.001,
        min=0.0,
        max=1.0
    )

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object")
            return {'CANCELLED'}

        # Switch to Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Select all vertices
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Remove doubles with specified distance
        bpy.ops.mesh.remove_doubles(threshold=self.distance)
        
        # Switch back to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        self.report({'INFO'}, f"Vertices merged within {self.distance} units")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class NWN2_OT_ResetNormals(bpy.types.Operator):
    """Reset normals to make them consistent"""
    bl_idname = "mesh.normals_make_consistent"
    bl_label = "Reset Vectors"
    bl_description = "Make normals consistent - fixes flipped normals"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object")
            return {'CANCELLED'}

        # Switch to Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Select all geometry
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Make normals consistent (inside/outside)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        
        # Switch back to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        self.report({'INFO'}, "Normals reset to consistent orientation")
        return {'FINISHED'}

class NWN2_OT_SetNormalsFromFaces(bpy.types.Operator):
    """Set normals from face orientation"""
    bl_idname = "mesh.set_normals_from_faces"
    bl_label = "Set from Faces"
    bl_description = "Align normals to face orientation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object")
            return {'CANCELLED'}

        # Switch to Edit Mode
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Select all geometry
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Set normals from faces
        bpy.ops.mesh.set_normals_from_faces()
        
        # Switch back to Object Mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        self.report({'INFO'}, "Normals set from face orientation")
        return {'FINISHED'}

class NWN2_OT_ApplyAllTransformsExtended(bpy.types.Operator):
    """Apply all transforms (location, rotation, scale)"""
    bl_idname = "object.apply_all_transforms"
    bl_label = "Apply Transforms"
    bl_description = "Apply all transforms to selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Store active object
        active_obj = context.active_object
        
        # Apply transforms to all selected objects
        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        # Restore active object
        context.view_layer.objects.active = active_obj
        
        self.report({'INFO'}, f"Applied transforms to {len(context.selected_objects)} objects")
        return {'FINISHED'}

class NWN2_OT_SetOrigin(bpy.types.Operator):
    """Set origin to geometry or 3D cursor"""
    bl_idname = "object.origin_set"
    bl_label = "Set Origin"
    bl_description = "Set object origin to geometry or 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    type: EnumProperty(
        name="Origin Type",
        description="Where to set the origin",
        items=[
            ('GEOMETRY_ORIGIN', 'Geometry', 'Set origin to geometry center'),
            ('CURSOR', '3D Cursor', 'Set origin to 3D cursor'),
        ],
        default='GEOMETRY_ORIGIN'
    )

    def execute(self, context):
        if not context.active_object:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}

        # Set origin based on type
        if self.type == 'GEOMETRY_ORIGIN':
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            self.report({'INFO'}, "Origin set to geometry center")
        elif self.type == 'CURSOR':
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            self.report({'INFO'}, "Origin set to 3D cursor")
        
        return {'FINISHED'}

# ==============================================
# MDB/GR2 IMPORT OPERATORS
# ==============================================

class OBJECT_OT_ImportMDBGR2File(Operator):
    bl_idname = "object.import_mdb_gr2_file"
    bl_label = "Import Selected File"
    bl_description = "Import the currently selected MDB or GR2 file"
    
    def execute(self, context):
        try:
            scene = context.scene
            if scene.mdb_gr2_file_index < 0 or scene.mdb_gr2_file_index >= len(scene.mdb_gr2_file_collection):
                self.report({'ERROR'}, "No file selected")
                return {'CANCELLED'}

            item = scene.mdb_gr2_file_collection[scene.mdb_gr2_file_index]
            filepath = item.filepath

            if not os.path.exists(filepath):
                self.report({'ERROR'}, f"File not found: {filepath}")
                return {'CANCELLED'}

            # Import using the NWN2 MDK importer
            bpy.ops.import_scene.nwn2mdk(
                filepath=filepath,
                files=[{'name': os.path.basename(filepath)}]
            )
            self.report({'INFO'}, f"Imported {item.file_type}: {item.name}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import file: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_ToggleFileSelection(Operator):
    bl_idname = "object.toggle_file_selection"
    bl_label = "Toggle File Selection"
    bl_description = "Toggle selection of this file"
    
    index: IntProperty()
    
    def execute(self, context):
        scene = context.scene
        
        if self.index < 0 or self.index >= len(scene.mdb_gr2_file_collection):
            return {'CANCELLED'}
        
        item = scene.mdb_gr2_file_collection[self.index]
        
        # Toggle selection
        if item.name in scene.mdb_gr2_selection_flags:
            scene.mdb_gr2_selection_flags[item.name] = not scene.mdb_gr2_selection_flags[item.name]
        else:
            scene.mdb_gr2_selection_flags[item.name] = True
        
        # Update active index
        scene.mdb_gr2_file_index = self.index
        
        return {'FINISHED'}

class OBJECT_OT_ImportSelectedMDBGR2Files(Operator):
    bl_idname = "object.import_selected_mdb_gr2_files"
    bl_label = "Import Checked Files"
    bl_description = "Import all checked MDB and GR2 files"
    
    def execute(self, context):
        try:
            scene = context.scene
            selected_files = []
            
            # Get selected files from selection flags
            for item in scene.mdb_gr2_file_collection:
                if scene.mdb_gr2_selection_flags.get(item.name, False):
                    selected_files.append(item)
            
            if not selected_files:
                self.report({'ERROR'}, "No files selected. Click checkboxes to select files.")
                return {'CANCELLED'}

            imported_count = 0
            for item in selected_files:
                try:
                    if os.path.exists(item.filepath):
                        bpy.ops.import_scene.nwn2mdk(
                            filepath=item.filepath,
                            files=[{'name': os.path.basename(item.filepath)}]
                        )
                        imported_count += 1
                        print(f"Imported: {item.name}")
                except Exception as e:
                    print(f"Failed to import {item.name}: {e}")

            self.report({'INFO'}, f"Imported {imported_count}/{len(selected_files)} files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import files: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_SelectAllMDBGR2Files(Operator):
    bl_idname = "object.select_all_mdb_gr2_files"
    bl_label = "Select All"
    bl_description = "Select all files in the list"
    
    def execute(self, context):
        scene = context.scene
        for item in scene.mdb_gr2_file_collection:
            scene.mdb_gr2_selection_flags[item.name] = True
        return {'FINISHED'}

class OBJECT_OT_DeselectAllMDBGR2Files(Operator):
    bl_idname = "object.deselect_all_mdb_gr2_files"
    bl_label = "Deselect All"
    bl_description = "Deselect all files in the list"
    
    def execute(self, context):
        scene = context.scene
        scene.mdb_gr2_selection_flags.clear()
        return {'FINISHED'}

class OBJECT_OT_ImportAllMDBGR2Files(Operator):
    bl_idname = "object.import_all_mdb_gr2_files"
    bl_label = "Import All Files"
    bl_description = "Import all MDB and GR2 files from the selected directory"

    def execute(self, context):
        try:
            scene = context.scene
            folder_path = scene.mdb_gr2_import_directory
            
            if not folder_path or not os.path.isdir(folder_path):
                self.report({'ERROR'}, "Invalid directory path")
                return {'CANCELLED'}

            # Get all MDB and GR2 files
            supported_files = []
            
            for file in os.listdir(folder_path):
                file_lower = file.lower()
                if file_lower.endswith('.mdb') or file_lower.endswith('.gr2'):
                    supported_files.append(file)

            total_files = len(supported_files)
            
            if total_files == 0:
                self.report({'WARNING'}, "No MDB or GR2 files found in directory")
                return {'CANCELLED'}

            # Import all files using the same importer
            imported_count = 0
            for file in supported_files:
                try:
                    filepath = os.path.join(folder_path, file)
                    bpy.ops.import_scene.nwn2mdk(
                        filepath=filepath,
                        files=[{'name': file}]
                    )
                    imported_count += 1
                except Exception as e:
                    print(f"Failed to import {file}: {e}")

            self.report({'INFO'}, f"Imported {imported_count}/{total_files} files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import files: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_RefreshMDBGR2FileList(Operator):
    bl_idname = "object.refresh_mdb_gr2_file_list"
    bl_label = "Refresh File List"
    bl_description = "Refresh the list of MDB and GR2 files in the directory"

    def execute(self, context):
        try:
            scene = context.scene
            folder_path = scene.mdb_gr2_import_directory
            
            if not folder_path or not os.path.isdir(folder_path):
                self.report({'ERROR'}, "Invalid directory path")
                return {'CANCELLED'}

            # Clear existing collection
            scene.mdb_gr2_file_collection.clear()
            scene.mdb_gr2_selection_flags.clear()

            # Get all files and sort them before adding to collection
            files = []
            for file in os.listdir(folder_path):
                file_lower = file.lower()
                if file_lower.endswith('.mdb') or file_lower.endswith('.gr2'):
                    files.append(file)
            
            # Sort files alphabetically
            files.sort(key=lambda x: x.lower())
            
            # Populate collection with sorted files
            for file in files:
                item = scene.mdb_gr2_file_collection.add()
                item.name = file
                item.filepath = os.path.join(folder_path, file)
                item.file_type = "MDB" if file.lower().endswith('.mdb') else "GR2"
            
            # Reset selection index
            scene.mdb_gr2_file_index = 0
            
            self.report({'INFO'}, f"Found {len(scene.mdb_gr2_file_collection)} files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to refresh file list: {str(e)}")
            return {'CANCELLED'}

class OBJECT_OT_CleanupCollections(Operator):
    bl_idname = "object.cleanup_mdb_gr2_collections"
    bl_label = "Cleanup Collections"
    bl_description = "Clean up and organize imported objects into collections"
    
    def execute(self, context):
        try:
            scene = context.scene
            
            # Create main collection for imported objects
            main_collection = bpy.data.collections.get("Imported MDB/GR2")
            if not main_collection:
                main_collection = bpy.data.collections.new("Imported MDB/GR2")
                bpy.context.scene.collection.children.link(main_collection)
            
            # Find all objects that might be from MDB/GR2 imports
            imported_objects = []
            for obj in bpy.data.objects:
                # Look for objects that are likely from MDB/GR2 imports
                if obj.type in ['MESH', 'ARMATURE']:
                    # Check if object is not already in our main collection
                    if main_collection.name not in [col.name for col in obj.users_collection]:
                        imported_objects.append(obj)
            
            # Move objects to main collection
            for obj in imported_objects:
                # Remove from current collections
                for collection in obj.users_collection:
                    collection.objects.unlink(obj)
                # Add to main collection
                main_collection.objects.link(obj)
            
            # Clean up empty collections
            collections_to_remove = []
            for collection in bpy.data.collections:
                if collection.name != "Imported MDB/GR2" and len(collection.objects) == 0:
                    collections_to_remove.append(collection)
            
            for collection in collections_to_remove:
                bpy.data.collections.remove(collection)
            
            self.report({'INFO'}, f"Organized {len(imported_objects)} objects into collections")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to cleanup collections: {str(e)}")
            return {'CANCELLED'}

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    NWN2ExportProperties,
    MDBGR2FileItem,
    # Model export operators
    NWN2_OT_ExportModel,
    NWN2_OT_SelectModelExportFolder,
    # Transform tools
    NWN2_OT_ApplyAllTransforms,
    NWN2_OT_WeightTransfer,
    # Armature tools
    NWN2_OT_SetupArmature,
    # Panel tools
    NWN2_OT_CleanupMesh,
    NWN2_OT_MergeByDistance,
    NWN2_OT_ResetNormals,
    NWN2_OT_SetNormalsFromFaces,
    NWN2_OT_ApplyAllTransformsExtended,
    NWN2_OT_SetOrigin,
    # Object Renaming Operators
    NWN2_OT_RenameObjectWithPrefix,
    NWN2_OT_ExtractFromSelection,
    # MDB/GR2 Import Operators
    OBJECT_OT_ImportMDBGR2File,
    OBJECT_OT_ToggleFileSelection,
    OBJECT_OT_ImportSelectedMDBGR2Files,
    OBJECT_OT_SelectAllMDBGR2Files,
    OBJECT_OT_DeselectAllMDBGR2Files,
    OBJECT_OT_ImportAllMDBGR2Files,
    OBJECT_OT_RefreshMDBGR2FileList,
    OBJECT_OT_CleanupCollections,
)

def register():
    """Register all model tools classes and properties"""
    # First register all classes
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
            print(f"Model Tools: Registered {cls.__name__}")
        except Exception as e:
            print(f"Model Tools: Failed to register {cls.__name__}: {e}")
    
    # Then register the scene properties
    try:
        bpy.types.Scene.nwn2_export_props = PointerProperty(type=NWN2ExportProperties)
        print("Model Tools: Registered nwn2_export_props")
    except Exception as e:
        print(f"Model Tools: Failed to register nwn2_export_props: {e}")
    
    # Register MDB/GR2 import properties
    try:
        bpy.types.Scene.mdb_gr2_import_directory = StringProperty(
            name="Import Directory",
            subtype='DIR_PATH',
            default="",
            description="Directory containing MDB and GR2 files"
        )
        
        bpy.types.Scene.mdb_gr2_file_collection = CollectionProperty(type=MDBGR2FileItem)
        bpy.types.Scene.mdb_gr2_file_index = IntProperty(default=0)
        
        # Custom selection storage
        bpy.types.Scene.mdb_gr2_selection_flags = {}
        print("Model Tools: Registered MDB/GR2 import properties")
    except Exception as e:
        print(f"Model Tools: Failed to register MDB/GR2 import properties: {e}")

def unregister():
    """Unregister all model tools classes and properties"""
    # First remove the scene properties
    try:
        del bpy.types.Scene.nwn2_export_props
        print("Model Tools: Unregistered nwn2_export_props")
    except:
        pass
    
    # Remove MDB/GR2 import properties
    try:
        del bpy.types.Scene.mdb_gr2_import_directory
        del bpy.types.Scene.mdb_gr2_file_collection
        del bpy.types.Scene.mdb_gr2_file_index
        del bpy.types.Scene.mdb_gr2_selection_flags
        print("Model Tools: Unregistered MDB/GR2 import properties")
    except:
        pass
    
    # Then unregister all classes
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
            print(f"Model Tools: Unregistered {cls.__name__}")
        except:
            pass

if __name__ == "__main__":
    register()