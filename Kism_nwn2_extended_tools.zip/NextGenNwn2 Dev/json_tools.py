# Standard library imports
import os
import json
import datetime
import re
import shutil
from typing import List, Dict, Tuple, Optional, Any, Set

# Blender imports
import bpy
from mathutils import Vector, Matrix
from bpy.props import (
    StringProperty, BoolProperty, IntProperty, FloatProperty, 
    FloatVectorProperty, EnumProperty, PointerProperty, CollectionProperty
)
from bpy.types import Panel, Operator, PropertyGroup, UIList
from bpy_extras.io_utils import ImportHelper, ExportHelper

# ==============================================
# PROPERTY GROUPS
# ==============================================

class KISM_JSONFileComponent(PropertyGroup):
    """Component of a merged JSON file"""
    name: StringProperty(name="Name")
    filepath: StringProperty(name="File Path", subtype='FILE_PATH')
    file_type: StringProperty(name="Type")
    timestamp: StringProperty(name="Timestamp")
    display_name: StringProperty(name="Display Name")

class KISM_JSONFileItem(PropertyGroup):
    """Represents a loaded JSON file or merged collection"""
    name: StringProperty(name="Name")
    filepath: StringProperty(name="File Path", subtype='FILE_PATH')
    file_type: StringProperty(name="Type")  # 'MODEL', 'SKELETON', or 'MERGED'
    timestamp: StringProperty(name="Timestamp")
    is_merged: BoolProperty(name="Is Merged", default=False)
    merged_components: CollectionProperty(type=KISM_JSONFileComponent)
    
    def verify_type(self):
        """Verify and correct the file type if needed"""
        if not self.is_merged and os.path.exists(self.filepath):
            try:
                with open(self.filepath, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        if 'bones' in data or ('metadata' in data and 'skeletons' in data):
                            self.file_type = 'SKELETON'
                        elif 'vertices' in data or ('metadata' in data and 'models' in data):
                            self.file_type = 'MODEL'
                    elif isinstance(data, list) and data and 'vertices' in data[0]:
                        self.file_type = 'MODEL'
            except (json.JSONDecodeError, IOError):
                pass

class KISM_Properties(PropertyGroup):
    # UI Display Properties
    show_file_manager: BoolProperty(name="Show File Manager", default=False)
    show_quick_import: BoolProperty(name="Show Quick Import", default=False)
    show_attachments: BoolProperty(name="Show Attachments", default=False)
    show_advanced: BoolProperty(name="Show Advanced Options", default=False)

    # File Management
    loaded_json_files: CollectionProperty(type=KISM_JSONFileItem)
    active_json_index: IntProperty(default=0)
    
    # Import/Export Settings
    import_scale: FloatProperty(name="Scale", default=1.0, min=0.001, max=1000.0)
    export_scale: FloatProperty(name="Scale", default=1.0, min=0.001, max=1000.0)
    export_selected_only: BoolProperty(name="Selected Only", default=True)
    export_children: BoolProperty(name="Include Children", default=True)
    export_precision: IntProperty(name="Precision", default=6, min=1, max=8)
    preserve_vertex_data: BoolProperty(name="Preserve Vertex Data", default=True)
    
    # Attachment System
    auto_attach_mode: BoolProperty(
        name="Auto-Attach Mode",
        default=False,
        description="Enable automatic weapon attachment to AP points"
    )
    highlight_ap_points: BoolProperty(
        name="Highlight AP Points",
        default=True,
        description="Visually highlight compatible attachment points",
        update=lambda self, context: self.update_ap_highlight()
    )
    constraint_strength: FloatProperty(
        name="Constraint Strength",
        default=1.0,
        min=0.0,
        max=1.0,
        description="Influence of the attachment constraints"
    )
    selected_ap_point: StringProperty(
        name="Selected AP Point",
        default="",
        description="Currently selected attachment point"
    )
    
    # AP Visual Settings
    ap_highlight_color: FloatVectorProperty(
        name="AP Highlight Color",
        subtype='COLOR',
        size=4,
        default=(1.0, 0.2, 0.2, 0.7),
        min=0.0,
        max=1.0,
        description="Color for highlighting attachment points"
    )
    ap_size: FloatProperty(
        name="AP Display Size",
        default=0.1,
        min=0.01,
        max=1.0,
        description="Visual size of attachment point empties"
    )
    
    # File Selection Dropdowns
    available_skeletons: EnumProperty(
        name="Available Skeletons",
        items=lambda self, context: self.get_available_files(context, 'SKELETON'),
    )
    available_models: EnumProperty(
        name="Available Models",
        items=lambda self, context: self.get_available_files(context, 'MODEL'),
    )
    available_races: EnumProperty(
        name="Available Races",
        items=lambda self, context: self.get_filtered_race_files(context),
    )
    available_weapons: EnumProperty(
        name="Available Weapons",
        items=lambda self, context: self.get_filtered_weapon_files(context),
    )
    
    # AP System Properties
    available_armatures: EnumProperty(
        name="Available Armatures",
        items=lambda self, context: self.get_available_armatures(context),
        update=lambda self, context: self.update_filtered_aps(context)
    )
    filtered_aps: EnumProperty(
        name="Filtered APs",
        items=lambda self, context: self.get_filtered_aps(context),
        update=lambda self, context: self.on_ap_selected(context)
    )

    # File Processing Methods
    def get_available_files(self, context, file_type):
        """Get files filtered by type, excluding attachment files"""
        items = []
        seen_files = set()
        
        for item in self.loaded_json_files:
            base_name = os.path.basename(item.filepath)
            if base_name.startswith(('Race_', 'Weapon_')):
                continue
                
            if item.is_merged:
                for component in item.merged_components:
                    comp_base = os.path.basename(component.filepath)
                    if comp_base.startswith(('Race_', 'Weapon_')):
                        continue
                    if component.file_type == file_type:
                        display = component.display_name or os.path.splitext(component.name)[0]
                        items.append((component.filepath, display, ""))
            elif item.file_type == file_type:
                display = os.path.splitext(item.name)[0]
                items.append((item.filepath, display, ""))
        
        return items or [('NONE', f"No {file_type} files", "")]

    def get_filtered_race_files(self, context):
        """Get only Race_ prefixed files, organized by type"""
        return self._get_filtered_attachment_files('Race_', "No Race Files")

    def get_filtered_weapon_files(self, context):
        """Get only Weapon_ prefixed files, organized by type"""
        return self._get_filtered_attachment_files('Weapon_', "No Weapon Files")

    def _get_filtered_attachment_files(self, prefix, empty_message):
        """Generic method for filtering attachment files"""
        type_dict = {}
        
        for item in self.loaded_json_files:
            if item.is_merged:
                for component in item.merged_components:
                    self._process_attachment_file(component, prefix, type_dict)
            else:
                self._process_attachment_file(item, prefix, type_dict)
                
        return self._format_attachment_items(type_dict, empty_message)

    def _process_attachment_file(self, item, prefix, type_dict):
        base_name = os.path.basename(item.filepath)
        if not base_name.startswith(prefix):
            return
            
        parts = base_name[len(prefix):].replace('.json', '').split('_')
        if not parts:
            return
            
        main_type = parts[0]
        sub_type = ' '.join(parts[1:]) if len(parts) > 1 else ''
        
        if main_type not in type_dict:
            type_dict[main_type] = []
            
        type_dict[main_type].append({
            'filepath': item.filepath,
            'sub_type': sub_type
        })

    def _format_attachment_items(self, type_dict, empty_message):
        items = []
        for main_type, variants in type_dict.items():
            for variant in variants:
                display = f"{variant['sub_type']} {main_type}" if variant['sub_type'] else main_type
                items.append((variant['filepath'], display, ""))
        
        return items or [('NONE', empty_message, "")]

    # AP Management Methods
    def get_available_armatures(self, context):
        """Get unique armature suffixes from AP empties"""
        armatures = {'ALL': "All Armatures"}
        
        for obj in bpy.data.objects:
            if obj.name.startswith("AP_") and obj.type == 'EMPTY':
                parts = obj.name.split('_')
                if len(parts) >= 3:
                    armatures[parts[-1]] = parts[-1]
        
        return [(k, v, f"Filter by {v} armature" if k != 'ALL' else "Show all attachment points") 
               for k, v in sorted(armatures.items())]

    def get_filtered_aps(self, context):
        """Get APs filtered by selected armature suffix with cleaned display names"""
        items = []
        armature_filter = self.available_armatures
        
        for obj in bpy.data.objects:
            if obj.name.startswith("AP_") and obj.type == 'EMPTY':
                parts = obj.name.split('_')
                if len(parts) < 3:
                    continue
                    
                if armature_filter != 'ALL' and parts[-1] != armature_filter:
                    continue
                    
                # Format display name based on AP naming convention
                if len(parts) == 4:  # AP_Part_Side_Armature
                    display = f"{parts[1]} ({parts[2]})"
                elif len(parts) == 3:  # AP_Part_Armature
                    display = parts[1]
                else:
                    display = obj.name
                    
                items.append((obj.name, display, f"Attachment Point: {obj.name}"))
        
        return items or [('NONE', "No APs Found", "Create empties named AP_Part_Side_Armature or AP_Part_Armature")]

    def on_ap_selected(self, context):
        """When AP is selected from dropdown"""
        if self.filtered_aps != 'NONE':
            self.selected_ap_point = self.filtered_aps
            self.update_ap_highlight()

    def update_ap_highlight(self):
        """Update AP highlighting based on settings"""
        if not self.highlight_ap_points:
            return
            
        # Reset all AP visuals first
        for obj in bpy.data.objects:
            if obj.name.startswith("AP_"):
                obj.color = (1, 1, 1, 1)
                obj.show_in_front = False
                obj.empty_display_size = self.ap_size
        
        # Highlight selected AP if valid
        ap = bpy.data.objects.get(self.selected_ap_point)
        if ap and self.highlight_ap_points:
            ap.color = self.ap_highlight_color
            ap.show_in_front = True
            ap.empty_display_size = self.ap_size * 1.2

    def attach_weapon_to_ap(self, context):
        """Handles weapon/armor/head to AP attachment with named constraints"""
        obj = context.active_object
        if not obj or not (obj.name.startswith("Weapon_") or obj.name.startswith("Armor_") or obj.name.startswith("Head_")):
            self.report({'ERROR'}, "Select a valid weapon, armor, or head object")
            return False

        if self.filtered_aps == 'NONE' or not bpy.data.objects.get(self.filtered_aps):
            self.report({'ERROR'}, "No valid attachment point selected")
            return False

        ap_empty = bpy.data.objects[self.filtered_aps]
        
        # Remove existing constraints
        self.remove_existing_attachment_constraints(obj)

        # Add new constraints
        copy_loc = obj.constraints.new('COPY_LOCATION')
        copy_loc.name = "AttachmentPointLocation"
        copy_loc.target = ap_empty

        copy_rot = obj.constraints.new('COPY_ROTATION')
        copy_rot.name = "AttachmentPointRotation"
        copy_rot.target = ap_empty
        copy_rot.mix_mode = 'ADD'

        # Store attachment info
        obj["kism_attached_ap"] = ap_empty.name
        ap_empty["kism_attached_weapon"] = obj.name

        self.report({'INFO'}, f"Attached {obj.name} to {ap_empty.name}")
        return True

    def remove_existing_attachment_constraints(self, obj):
        """Remove any existing named attachment constraints"""
        for c in list(obj.constraints):  # Create a copy for safe iteration
            if c.name in {"AttachmentPointLocation", "AttachmentPointRotation"}:
                obj.constraints.remove(c)

# ==============================================
# JSON OPERATORS
# ==============================================

class KISM_OT_LoadJsonFile(Operator, ImportHelper):
    bl_idname = "kism.load_json_file"
    bl_label = "Load JSON File"
    bl_description = "Load JSON file for import"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    
    file_type: EnumProperty(
        name="File Type",
        description="Force file type or auto-detect",
        items=[
            ('MODEL', "Model", "Import as model data"),
            ('SKELETON', "Skeleton", "Import as skeleton/armature"),
            ('AUTO', "Auto-detect", "Detect file type automatically"),
        ],
        default='AUTO'
    )
    
    def execute(self, context):
        props = context.scene.kism_props
        filename = os.path.basename(self.filepath)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        
        # Check if file is merged
        is_merged = False
        try:
            with open(self.filepath, 'r') as f:
                data = json.load(f)
                is_merged = isinstance(data, dict) and 'metadata' in data and 'original_components' in data['metadata']
        except:
            pass
        
        if is_merged:
            # Handle merged file
            components = data['metadata']['original_components']
            
            # Remove existing entries with same components
            for i in reversed(range(len(props.loaded_json_files))):
                item = props.loaded_json_files[i]
                if item.is_merged and item.filepath == self.filepath:
                    props.loaded_json_files.remove(i)
                else:
                    for comp in components:
                        if item.filepath == comp['filepath']:
                            props.loaded_json_files.remove(i)
                            break
            
            # Add merged file entry
            merged_item = props.loaded_json_files.add()
            merged_item.name = filename
            merged_item.filepath = self.filepath
            merged_item.file_type = 'MERGED'
            merged_item.is_merged = True
            merged_item.timestamp = timestamp
            
            # Add components
            for comp in components:
                component = merged_item.merged_components.add()
                component.name = comp['name']
                component.filepath = comp['filepath']
                component.file_type = comp['file_type']  # Preserve original type
                component.timestamp = comp.get('timestamp', timestamp)
                component.display_name = comp.get('display_name', os.path.splitext(comp['name'])[0])
            
            self.report({'INFO'}, f"Loaded merged file with {len(components)} components")
        else:
            # Handle regular file - remove existing entry first
            for i in reversed(range(len(props.loaded_json_files))):
                item = props.loaded_json_files[i]
                if os.path.basename(item.filepath) == filename and not item.is_merged:
                    props.loaded_json_files.remove(i)
            
            # Determine file type
            if self.file_type == 'AUTO':
                file_type = self.detect_file_type(self.filepath)
            else:
                file_type = self.file_type
            
            # Add new entry
            item = props.loaded_json_files.add()
            item.name = filename
            item.filepath = self.filepath
            item.file_type = file_type
            item.timestamp = timestamp
            item.verify_type()  # Double-check the type
        
        props.active_json_index = len(props.loaded_json_files) - 1
        return {'FINISHED'}
    
    def detect_file_type(self, filepath):
        """Auto-detect if file contains model or skeleton data"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    if 'bones' in data or ('metadata' in data and 'skeletons' in data):
                        return 'SKELETON'
                    elif 'vertices' in data or ('metadata' in data and 'models' in data):
                        return 'MODEL'
                elif isinstance(data, list) and len(data) > 0:
                    if 'vertices' in data[0]:
                        return 'MODEL'
                    elif 'head' in data[0] and 'tail' in data[0]:  # Bone data
                        return 'SKELETON'
        except:
            pass
        return 'MODEL'  # Default fallback

class KISM_OT_RemoveJsonFile(Operator):
    bl_idname = "kism.remove_json_file"
    bl_label = "Remove JSON File"
    bl_description = "Remove selected JSON file from the list"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        props = context.scene.kism_props
        return len(props.loaded_json_files) > 0
    
    def execute(self, context):
        props = context.scene.kism_props
        index = props.active_json_index
        
        if 0 <= index < len(props.loaded_json_files):
            filename = props.loaded_json_files[index].name
            props.loaded_json_files.remove(index)
            self.report({'INFO'}, f"Removed {filename}")
            
            if index >= len(props.loaded_json_files):
                props.active_json_index = max(0, len(props.loaded_json_files) - 1)
        
        return {'FINISHED'}

class KISM_OT_ClearAllFiles(Operator):
    bl_idname = "kism.clear_all_files"
    bl_label = "Clear All"
    bl_description = "Remove all loaded JSON files"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.kism_props
        count = len(props.loaded_json_files)
        props.loaded_json_files.clear()
        self.report({'INFO'}, f"Removed {count} files")
        return {'FINISHED'}

class KISM_OT_MergeJsonFiles(Operator, ExportHelper):
    bl_idname = "kism.merge_json_files"
    bl_label = "Merge JSON Files"
    bl_description = "Combine multiple JSON files into one while preserving original structure"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    
    merge_mode: EnumProperty(
        name="Merge Mode",
        items=[
            ('MODELS', "Models Only", "Only merge model files"),
            ('SKELETONS', "Skeletons Only", "Only merge skeleton files"),
            ('ALL', "Everything", "Merge all compatible files"),
        ],
        default='ALL'
    )
    
    preserve_structure: BoolProperty(
        name="Preserve Structure",
        description="Keep original file structure for reimporting",
        default=True
    )
    
    def execute(self, context):
        props = context.scene.kism_props
        merged_data = {
            'metadata': {
                'generator': 'KISM Tools',
                'version': '1.0',
                'merged_at': datetime.datetime.now().isoformat(),
                'source_files': [],
                'original_components': []
            },
            'models': [],
            'skeletons': []
        }
        
        original_components = []
        
        for item in props.loaded_json_files:
            if not os.path.exists(item.filepath):
                continue
                
            # Filter by merge mode
            if self.merge_mode == 'MODELS' and item.file_type != 'MODEL':
                continue
            if self.merge_mode == 'SKELETONS' and item.file_type != 'SKELETON':
                continue
                
            try:
                with open(item.filepath, 'r') as f:
                    data = json.load(f)
                    merged_data['metadata']['source_files'].append(item.name)
                    
                    # Store original component info
                    component_info = {
                        'name': item.name,
                        'display_name': os.path.splitext(item.name)[0],  # Remove extension for cleaner display
                        'filepath': item.filepath,
                        'file_type': item.file_type,
                        'timestamp': item.timestamp
                    }
                    original_components.append(component_info)
                    
                    target_array = (
                        merged_data['models'] if item.file_type == 'MODEL' 
                        else merged_data['skeletons']
                    )
                    
                    if isinstance(data, list):
                        for obj in data:
                            if isinstance(obj, dict):
                                target_array.append(obj)
                    elif isinstance(data, dict):
                        target_array.append(data)
                        
            except Exception as e:
                self.report({'WARNING'}, f"Skipped {item.name}: {str(e)}")
                continue
        
        if self.preserve_structure:
            merged_data['metadata']['original_components'] = original_components
        
        try:
            with open(self.filepath, 'w') as f:
                json.dump(merged_data, f, indent=2)
            
            if self.preserve_structure:
                merged_item = props.loaded_json_files.add()
                merged_item.name = os.path.basename(self.filepath)
                merged_item.filepath = self.filepath
                merged_item.file_type = 'MERGED'
                merged_item.is_merged = True
                merged_item.timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
                
                for comp in original_components:
                    component = merged_item.merged_components.add()
                    component.name = comp['name']
                    component.display_name = comp['display_name']
                    component.filepath = comp['filepath']
                    component.file_type = comp['file_type']
                    component.timestamp = comp['timestamp']
            
            self.report({'INFO'}, f"Merged {len(original_components)} files")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

class KISM_OT_ImportModel(Operator):
    bl_idname = "kism.import_model"
    bl_label = "Import Model"
    bl_description = "Import the selected model file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.kism_props
        
        if props.available_models == 'NONE':
            self.report({'ERROR'}, "No model file selected")
            return {'CANCELLED'}
            
        filepath = props.available_models
        
        try:
            # Load JSON data
            with open(filepath, 'r') as f:
                import_data = json.load(f)
            
            # Handle different file formats
            if isinstance(import_data, dict):
                # Check if it's a merged file
                if 'models' in import_data:
                    import_data = import_data['models']
                elif 'metadata' in import_data and 'original_components' in import_data['metadata']:
                    # Try to load components
                    models = []
                    for comp in import_data['metadata']['original_components']:
                        if comp.get('file_type') == 'MODEL' and os.path.exists(comp['filepath']):
                            try:
                                with open(comp['filepath'], 'r') as comp_file:
                                    comp_data = json.load(comp_file)
                                    if isinstance(comp_data, list):
                                        models.extend(comp_data)
                                    elif isinstance(comp_data, dict):
                                        models.append(comp_data)
                            except:
                                continue
                    import_data = models
                else:
                    # Single object in dict format
                    import_data = [import_data]
            
            # Ensure import_data is a list
            if not isinstance(import_data, list):
                import_data = [import_data]
            
            # Create collection
            collection_name = "KISM_Imported_Models"
            if collection_name in bpy.data.collections:
                collection = bpy.data.collections[collection_name]
            else:
                collection = bpy.data.collections.new(collection_name)
                bpy.context.scene.collection.children.link(collection)
            
            created_objects = []
            object_map = {}
            
            # First pass: create all objects
            for obj_data in import_data:
                if not isinstance(obj_data, dict):
                    continue
                    
                try:
                    obj_name = obj_data.get('name', 'KISM_Object')
                    obj_type = obj_data.get('type', 'MESH')
                    
                    # Clean up existing object
                    if obj_name in bpy.data.objects:
                        old_obj = bpy.data.objects[obj_name]
                        bpy.data.objects.remove(old_obj, do_unlink=True)
                    
                    if obj_type == 'MESH' and 'vertices' in obj_data:
                        # Create mesh
                        mesh_name = f"{obj_name}_Mesh"
                        if mesh_name in bpy.data.meshes:
                            bpy.data.meshes.remove(bpy.data.meshes[mesh_name])
                        
                        mesh = bpy.data.meshes.new(mesh_name)
                        
                        # Import geometry
                        vertices = [Vector(v) * props.import_scale for v in obj_data['vertices']]
                        faces = obj_data.get('polygons', [])
                        
                        if len(vertices) > 0:
                            mesh.from_pydata(vertices, [], faces)
                            
                            # Apply smooth shading
                            if obj_data.get('smooth_shading', False):
                                for poly in mesh.polygons:
                                    poly.use_smooth = True
                            
                            mesh.update()
                        
                        obj = bpy.data.objects.new(obj_name, mesh)
                    else:
                        # Create empty
                        obj = bpy.data.objects.new(obj_name, None)
                    
                    # Apply transform
                    if 'matrix_world' in obj_data:
                        matrix_data = obj_data['matrix_world']
                        if len(matrix_data) == 16:
                            matrix = Matrix([matrix_data[i*4:(i+1)*4] for i in range(4)])
                            # Apply scale to translation
                            for i in range(3):
                                matrix[i][3] *= props.import_scale
                            obj.matrix_world = matrix
                    
                    # Link to collection
                    collection.objects.link(obj)
                    created_objects.append(obj)
                    object_map[obj_name] = obj
                    
                except Exception as e:
                    print(f"Error creating object {obj_data.get('name', 'unknown')}: {str(e)}")
                    continue
            
            # Second pass: set up parenting
            for obj_data in import_data:
                if not isinstance(obj_data, dict):
                    continue
                    
                obj_name = obj_data.get('name')
                if not obj_name or obj_name not in object_map:
                    continue
                    
                obj = object_map[obj_name]
                parent_name = obj_data.get('parent')
                
                if parent_name and parent_name in object_map:
                    parent_obj = object_map[parent_name]
                    obj.parent = parent_obj
                    
                    # Handle bone parenting
                    if obj_data.get('parent_type') == 'BONE':
                        obj.parent_type = 'BONE'
                        obj.parent_bone = obj_data.get('parent_bone', '')
                    
                    # Apply parent inverse matrix
                    if 'matrix_parent_inverse' in obj_data:
                        matrix_data = obj_data['matrix_parent_inverse']
                        if len(matrix_data) == 16:
                            matrix = Matrix([matrix_data[i*4:(i+1)*4] for i in range(4)])
                            obj.matrix_parent_inverse = matrix
            
            # Select imported objects
            bpy.ops.object.select_all(action='DESELECT')
            for obj in created_objects:
                obj.select_set(True)
            if created_objects:
                bpy.context.view_layer.objects.active = created_objects[0]
            
            self.report({'INFO'}, f"Imported {len(created_objects)} objects from {os.path.basename(filepath)}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {str(e)}")
            return {'CANCELLED'}

class KISM_OT_ImportSkeleton(Operator):
    bl_idname = "kism.import_skeleton"
    bl_label = "Import Skeleton"
    bl_description = "Import the selected skeleton file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.kism_props
        
        if props.available_skeletons == 'NONE':
            self.report({'ERROR'}, "No skeleton file selected")
            return {'CANCELLED'}
            
        # DIRECT IMPLEMENTATION INSTEAD OF CALLING NON-EXISTENT OPERATOR
        filepath = props.available_skeletons
        
        try:
            # Load JSON data
            with open(filepath, 'r') as f:
                skeleton_data = json.load(f)

            # Handle merged files
            if isinstance(skeleton_data, dict) and 'metadata' in skeleton_data:
                if 'skeletons' in skeleton_data:
                    skeleton_data = skeleton_data['skeletons'][0]
                elif 'bones' not in skeleton_data:
                    self.report({'ERROR'}, "No skeleton data found")
                    return {'CANCELLED'}

            # Get original name or generate new one
            armature_name = skeleton_data.get('armature', {}).get('original_name', 'Imported_Armature')
            
            # Create armature
            armature_data = bpy.data.armatures.new(armature_name)
            armature_obj = bpy.data.objects.new(armature_name, armature_data)
            
            # Link to collection
            collection = bpy.data.collections.get("Armatures") or bpy.data.collections.new("Armatures")
            if collection.name not in bpy.context.scene.collection.children:
                bpy.context.scene.collection.children.link(collection)
            collection.objects.link(armature_obj)

            # Create bones
            bpy.context.view_layer.objects.active = armature_obj
            bpy.ops.object.mode_set(mode='EDIT')
            bone_map = {}

            for bone_data in skeleton_data.get('bones', []):
                bone = armature_data.edit_bones.new(bone_data['name'])
                bone.head = Vector(bone_data['head']) * props.import_scale
                bone.tail = Vector(bone_data['tail']) * props.import_scale
                bone.roll = bone_data.get('roll', 0)
                bone.use_connect = bone_data.get('use_connect', False)
                bone_map[bone.name] = bone

            # Set parenting
            for bone_data in skeleton_data.get('bones', []):
                if bone_data['name'] in bone_map and bone_data.get('parent') in bone_map:
                    bone_map[bone_data['name']].parent = bone_map[bone_data['parent']]
                    bone_map[bone_data['name']].use_connect = bone_data.get('use_connect', False)

            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'INFO'}, f"Imported {armature_name} with {len(bone_map)} bones")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import skeleton: {str(e)}")
            return {'CANCELLED'}

class KISM_OT_ImportWeapon(Operator):
    bl_idname = "kism.import_weapon"
    bl_label = "Import Selected Weapon"
    bl_description = "Import weapon with proper naming and empty parent structure"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.kism_props
        
        if props.available_weapons == 'NONE':
            self.report({'ERROR'}, "No weapon selected in dropdown")
            return {'CANCELLED'}
            
        filepath = props.available_weapons
        
        try:
            # Load JSON data
            with open(filepath, 'r') as f:
                json_data = json.load(f)
            
            # Get weapon name from filename (remove "Weapon_" prefix and .json extension)
            weapon_name = os.path.splitext(os.path.basename(filepath))[0]
            if weapon_name.startswith("Weapon_"):
                weapon_name = weapon_name[7:]  # Remove "Weapon_" prefix
            
            # Create collection for weapon
            collection = bpy.data.collections.new(f"Weapon_{weapon_name}")
            bpy.context.scene.collection.children.link(collection)
            
            # Create parent empty
            empty = bpy.data.objects.new(f"Weapon_{weapon_name}_Empty", None)
            collection.objects.link(empty)
            
            # Import objects based on data format
            if isinstance(json_data, dict) and 'metadata' in json_data:
                # New weapon format with metadata
                if 'models' in json_data:
                    for model in json_data['models']:
                        self._create_weapon_mesh(model, collection, empty, props.import_scale)
                elif 'meshes' in json_data:
                    for mesh_data in json_data['meshes']:
                        self._create_weapon_mesh(mesh_data, collection, empty, props.import_scale)
                
                # Set empty transform if specified
                if 'parent_empty' in json_data and 'matrix_world' in json_data['parent_empty']:
                    matrix = Matrix([json_data['parent_empty']['matrix_world'][i*4:(i+1)*4] for i in range(4)])
                    for i in range(3):
                        matrix[i][3] *= props.import_scale
                    empty.matrix_world = matrix
                    
                # Import constraints for parent empty
                if 'parent_empty' in json_data and 'constraints' in json_data['parent_empty']:
                    self._import_constraints(empty, json_data['parent_empty']['constraints'])
                    
            elif isinstance(json_data, list):
                # Legacy format - array of models
                for obj_data in json_data:
                    self._create_weapon_mesh(obj_data, collection, empty, props.import_scale)
            elif isinstance(json_data, dict):
                # Single model format
                self._create_weapon_mesh(json_data, collection, empty, props.import_scale)
            
            self.report({'INFO'}, f"Imported weapon: {weapon_name}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import weapon: {str(e)}")
            return {'CANCELLED'}
    
    def _create_weapon_mesh(self, mesh_data, collection, parent_empty, scale):
        """Create a weapon mesh object with proper naming and parenting"""
        if not mesh_data or not isinstance(mesh_data, dict) or 'vertices' not in mesh_data:
            return
            
        # Get mesh name (use original if available, otherwise generate from weapon name)
        mesh_name = mesh_data.get('name', f"{parent_empty.name.replace('_Empty', '')}_Mesh")
        
        # Clean up existing mesh if it exists
        if mesh_name in bpy.data.objects:
            old_obj = bpy.data.objects[mesh_name]
            if old_obj.data and old_obj.data.users == 1:
                bpy.data.meshes.remove(old_obj.data)
            bpy.data.objects.remove(old_obj)
        
        # Create new mesh
        mesh = bpy.data.meshes.new(mesh_name)
        
        try:
            # Create geometry
            vertices = [Vector(v) * scale for v in mesh_data['vertices']]
            faces = mesh_data.get('polygons', [])
            mesh.from_pydata(vertices, [], faces)
            
            # Create object
            obj = bpy.data.objects.new(mesh_name, mesh)
            collection.objects.link(obj)
            
            # Apply transform if specified
            if 'matrix_world' in mesh_data:
                matrix = Matrix([mesh_data['matrix_world'][i*4:(i+1)*4] for i in range(4)])
                for i in range(3):
                    matrix[i][3] *= scale
                obj.matrix_world = matrix
            
            # Parent to empty
            obj.parent = parent_empty
            if 'matrix_parent_inverse' in mesh_data:
                obj.matrix_parent_inverse = Matrix([mesh_data['matrix_parent_inverse'][i*4:(i+1)*4] for i in range(4)])
            
            # Apply smooth shading
            if mesh_data.get('smooth_shading', False):
                for poly in mesh.polygons:
                    poly.use_smooth = True
            
            # Apply materials if specified
            if 'materials' in mesh_data and 'material_indices' in mesh_data:
                for mat_name in mesh_data['materials']:
                    if mat_name in bpy.data.materials:
                        mesh.materials.append(bpy.data.materials[mat_name])
                
                for poly, mat_idx in zip(mesh.polygons, mesh_data['material_indices']):
                    if mat_idx < len(mesh.materials):
                        poly.material_index = mat_idx
            
            # Import constraints if they exist
            if 'constraints' in mesh_data:
                self._import_constraints(obj, mesh_data['constraints'])
            
            mesh.update()
            
        except Exception as e:
            print(f"Error creating weapon mesh {mesh_name}: {str(e)}")
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    def _import_constraints(self, obj, constraints_data):
        """Import constraints for an object"""
        if not constraints_data or not isinstance(constraints_data, list):
            return
            
        for constraint_data in constraints_data:
            try:
                # Create constraint
                constraint = obj.constraints.new(constraint_data['type'])
                constraint.name = constraint_data.get('name', constraint.type)
                constraint.mute = constraint_data.get('mute', False)
                constraint.influence = constraint_data.get('influence', 1.0)
                
                # Set target if exists
                if 'target' in constraint_data and constraint_data['target'] in bpy.data.objects:
                    constraint.target = bpy.data.objects[constraint_data['target']]
                
                # Set constraint-specific properties
                if constraint.type == 'COPY_LOCATION':
                    constraint.use_x = constraint_data.get('use_x', True)
                    constraint.use_y = constraint_data.get('use_y', True)
                    constraint.use_z = constraint_data.get('use_z', True)
                    constraint.invert_x = constraint_data.get('invert_x', False)
                    constraint.invert_y = constraint_data.get('invert_y', False)
                    constraint.invert_z = constraint_data.get('invert_z', False)
                    constraint.use_offset = constraint_data.get('use_offset', False)
                elif constraint.type == 'COPY_ROTATION':
                    constraint.use_x = constraint_data.get('use_x', True)
                    constraint.use_y = constraint_data.get('use_y', True)
                    constraint.use_z = constraint_data.get('use_z', True)
                    constraint.invert_x = constraint_data.get('invert_x', False)
                    constraint.invert_y = constraint_data.get('invert_y', False)
                    constraint.invert_z = constraint_data.get('invert_z', False)
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                    constraint.use_offset = constraint_data.get('use_offset', False)
                elif constraint.type == 'COPY_TRANSFORMS':
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                elif constraint.type == 'CHILD_OF':
                    constraint.use_location_x = constraint_data.get('use_location_x', True)
                    constraint.use_location_y = constraint_data.get('use_location_y', True)
                    constraint.use_location_z = constraint_data.get('use_location_z', True)
                    constraint.use_rotation_x = constraint_data.get('use_rotation_x', True)
                    constraint.use_rotation_y = constraint_data.get('use_rotation_y', True)
                    constraint.use_rotation_z = constraint_data.get('use_rotation_z', True)
                    constraint.use_scale_x = constraint_data.get('use_scale_x', True)
                    constraint.use_scale_y = constraint_data.get('use_scale_y', True)
                    constraint.use_scale_z = constraint_data.get('use_scale_z', True)
                elif constraint.type == 'TRACK_TO':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                    constraint.up_axis = constraint_data.get('up_axis', 'UP_Z')
                    constraint.use_target_z = constraint_data.get('use_target_z', False)
                elif constraint.type == 'LOCKED_TRACK':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                    constraint.lock_axis = constraint_data.get('lock_axis', 'LOCK_Y')
                elif constraint.type == 'DAMPED_TRACK':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                elif constraint.type == 'STRETCH_TO':
                    constraint.bulge = constraint_data.get('bulge', 1.0)
                    constraint.bulge_min = constraint_data.get('bulge_min', 1.0)
                    constraint.bulge_max = constraint_data.get('bulge_max', 1.0)
                    constraint.bulge_smooth = constraint_data.get('bulge_smooth', 0.0)
                    constraint.volume = constraint_data.get('volume', 'NO_VOLUME')
                    constraint.keep_axis = constraint_data.get('keep_axis', 'PLANE_X')
                elif constraint.type == 'TRANSFORM':
                    constraint.map_from = constraint_data.get('map_from', 'LOCATION')
                    constraint.map_to = constraint_data.get('map_to', 'LOCATION')
                    constraint.from_min_x = constraint_data.get('from_min_x', 0.0)
                    constraint.from_max_x = constraint_data.get('from_max_x', 1.0)
                    constraint.from_min_y = constraint_data.get('from_min_y', 0.0)
                    constraint.from_max_y = constraint_data.get('from_max_y', 1.0)
                    constraint.from_min_z = constraint_data.get('from_min_z', 0.0)
                    constraint.from_max_z = constraint_data.get('from_max_z', 1.0)
                    constraint.to_min_x = constraint_data.get('to_min_x', 0.0)
                    constraint.to_max_x = constraint_data.get('to_max_x', 1.0)
                    constraint.to_min_y = constraint_data.get('to_min_y', 0.0)
                    constraint.to_max_y = constraint_data.get('to_max_y', 1.0)
                    constraint.to_min_z = constraint_data.get('to_min_z', 0.0)
                    constraint.to_max_z = constraint_data.get('to_max_z', 1.0)
                    constraint.use_motion_extrapolate = constraint_data.get('use_motion_extrapolate', False)
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                elif constraint.type == 'LIMIT_LOCATION':
                    constraint.use_min_x = constraint_data.get('use_min_x', False)
                    constraint.use_min_y = constraint_data.get('use_min_y', False)
                    constraint.use_min_z = constraint_data.get('use_min_z', False)
                    constraint.use_max_x = constraint_data.get('use_max_x', False)
                    constraint.use_max_y = constraint_data.get('use_max_y', False)
                    constraint.use_max_z = constraint_data.get('use_max_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                elif constraint.type == 'LIMIT_ROTATION':
                    constraint.use_limit_x = constraint_data.get('use_limit_x', False)
                    constraint.use_limit_y = constraint_data.get('use_limit_y', False)
                    constraint.use_limit_z = constraint_data.get('use_limit_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                elif constraint.type == 'LIMIT_SCALE':
                    constraint.use_min_x = constraint_data.get('use_min_x', False)
                    constraint.use_min_y = constraint_data.get('use_min_y', False)
                    constraint.use_min_z = constraint_data.get('use_min_z', False)
                    constraint.use_max_x = constraint_data.get('use_max_x', False)
                    constraint.use_max_y = constraint_data.get('use_max_y', False)
                    constraint.use_max_z = constraint_data.get('use_max_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                    
            except Exception as e:
                print(f"Failed to import constraint {constraint_data.get('name', 'unknown')}: {str(e)}")

class KISM_OT_ExportJsonModel(Operator, ExportHelper):
    bl_idname = "kism.export_json_model"
    bl_label = "Export Model"
    bl_description = "Export selected objects to JSON file (preserves parenting and vertex weights)"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    
    export_selected_only: BoolProperty(
        name="Selected Only",
        description="Export only selected objects",
        default=True
    )
    
    export_children: BoolProperty(
        name="Include Children",
        description="Include all children of selected objects",
        default=True
    )
    
    precision: IntProperty(
        name="Precision",
        description="Number of decimal places to round to",
        default=6,
        min=1,
        max=8
    )
    
    preserve_vertex_data: BoolProperty(
        name="Preserve Vertex Data",
        description="Include vertex colors and weights in export",
        default=True
    )
    
    def execute(self, context):
        # Get objects to export
        if self.export_selected_only:
            objects_to_export = context.selected_objects.copy()
            if self.export_children:
                children = []
                for obj in objects_to_export:
                    children.extend(self.get_all_children(obj))
                objects_to_export.extend(children)
                # Remove duplicates
                objects_to_export = list(set(objects_to_export))
        else:
            objects_to_export = [obj for obj in bpy.data.objects if obj.name.startswith("KISM_")]
        
        if not objects_to_export:
            self.report({'ERROR'}, "No objects selected for export")
            return {'CANCELLED'}
        
        export_data = []
        
        for obj in objects_to_export:
            try:
                # Basic object data
                obj_data = {
                    'name': obj.name,
                    'type': obj.type,
                    'matrix_world': self.round_matrix(obj.matrix_world),
                }
                
                # Parenting data
                if obj.parent:
                    obj_data['parent'] = obj.parent.name
                    obj_data['parent_type'] = obj.parent_type
                    if obj.parent_type == 'BONE' and obj.parent_bone:
                        obj_data['parent_bone'] = obj.parent_bone
                    obj_data['matrix_parent_inverse'] = self.round_matrix(obj.matrix_parent_inverse)
                
                # Mesh-specific data
                if obj.type == 'MESH' and obj.data:
                    mesh = obj.data
                    obj_data.update({
                        'vertices': [self.round_vector(v.co) for v in mesh.vertices],
                        'polygons': [list(p.vertices) for p in mesh.polygons],
                        'smooth_shading': any(poly.use_smooth for poly in mesh.polygons)
                    })
                    
                    # Vertex weights
                    if self.preserve_vertex_data and obj.vertex_groups:
                        weight_data = []
                        for vert in mesh.vertices:
                            vert_weights = {}
                            for group in vert.groups:
                                if group.weight > 0.0001:  # Only store meaningful weights
                                    group_name = obj.vertex_groups[group.group].name
                                    vert_weights[group_name] = round(group.weight, self.precision)
                            
                            if vert_weights:
                                weight_data.append({
                                    'vertex_index': vert.index,
                                    'weights': vert_weights
                                })
                        
                        if weight_data:
                            obj_data['vertex_weights'] = weight_data
                
                export_data.append(obj_data)
                
            except Exception as e:
                print(f"Error exporting {obj.name}: {str(e)}")
                continue
        
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(os.path.abspath(self.filepath)), exist_ok=True)
            
            # Write to file
            with open(self.filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            self.report({'INFO'}, f"Exported {len(export_data)} objects to {os.path.basename(self.filepath)}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}
    
    def get_all_children(self, obj):
        """Get all children recursively"""
        children = []
        for child in obj.children:
            children.append(child)
            children.extend(self.get_all_children(child))
        return children
    
    def round_vector(self, vector):
        return [round(x, self.precision) for x in vector]
    
    def round_matrix(self, matrix):
        if matrix is None:
            return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
        return [round(x, self.precision) for row in matrix for x in row]

class KISM_OT_ExportJsonSkeleton(Operator, ExportHelper):
    bl_idname = "kism.export_json_skeleton"
    bl_label = "Export Skeleton"
    bl_description = "Export armature with bone hierarchy, weights, and original name preservation"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_rest_pose: BoolProperty(
        name="Export Rest Pose",
        description="Include rest pose transformations",
        default=True
    )
    
    export_bone_properties: BoolProperty(
        name="Export Bone Properties", 
        description="Include bone roll, inheritance, and other properties",
        default=True
    )
    
    export_weights: BoolProperty(
        name="Export Vertex Weights",
        description="Include vertex weight data for child meshes",
        default=True
    )
    
    precision: IntProperty(
        name="Precision",
        description="Number of decimal places in export",
        default=6,
        min=1,
        max=8
    )
    
    include_metadata: BoolProperty(
        name="Include Metadata",
        description="Add export information to file",
        default=True
    )

    def execute(self, context):
        # Get selected armature
        armature = next((obj for obj in context.selected_objects if obj.type == 'ARMATURE'), None)
        if not armature:
            self.report({'ERROR'}, "No armature selected")
            return {'CANCELLED'}

        # Store original state
        original_mode = armature.mode
        original_active = context.view_layer.objects.active
        
        # Prepare export data
        skeleton_data = {
            'armature': {
                'original_name': armature.name,  # Explicitly store original name
                'name': armature.name,
                'matrix_world': self.round_matrix(armature.matrix_world)
            },
            'bones': [],
            'metadata': {
                'generator': "Blender KISM Tools",
                'version': "1.3",
                'blender_version': bpy.app.version_string,
                'export_time': datetime.datetime.now().isoformat()
            } if self.include_metadata else None
        }

        # Export bone data
        bpy.ops.object.mode_set(mode='EDIT')
        for bone in armature.data.edit_bones:
            bone_data = {
                'name': bone.name,
                'head': self.round_vector(bone.head),
                'tail': self.round_vector(bone.tail),
                'parent': bone.parent.name if bone.parent else None,
                'roll': round(bone.roll, self.precision),
                'use_connect': bone.use_connect,
                'matrix_local': self.round_matrix(bone.matrix)
            }
            
            if self.export_bone_properties:
                bone_data.update({
                    'use_inherit_rotation': bone.use_inherit_rotation,
                    'use_local_location': bone.use_local_location,
                    'inherit_scale': bone.inherit_scale,
                    'use_deform': bone.use_deform,
                    'bbone_segments': bone.bbone_segments,
                    'hide': bone.hide
                })
            
            skeleton_data['bones'].append(bone_data)

        # Export rest pose if enabled
        if self.export_rest_pose:
            bpy.ops.object.mode_set(mode='POSE')
            skeleton_data['rest_pose'] = [{
                'name': bone.name,
                'matrix': self.round_matrix(bone.matrix),
                'location': self.round_vector(bone.location),
                'rotation_quaternion': self.round_vector(bone.rotation_quaternion),
                'scale': self.round_vector(bone.scale),
                'rotation_mode': bone.rotation_mode
            } for bone in armature.pose.bones]

        # Export weights if enabled
        if self.export_weights:
            skeleton_data['vertex_weights'] = {}
            for obj in (obj for obj in bpy.data.objects if obj.parent == armature and obj.type == 'MESH'):
                weight_data = {}
                for vgroup in obj.vertex_groups:
                    if vgroup.name in armature.data.bones:
                        weights = []
                        for vert in obj.data.vertices:
                            for group in vert.groups:
                                if group.group == vgroup.index and group.weight > 0:
                                    weights.append({
                                        'vertex_index': vert.index,
                                        'weight': round(group.weight, self.precision)
                                    })
                        if weights:
                            weight_data[vgroup.name] = weights
                if weight_data:
                    skeleton_data['vertex_weights'][obj.name] = weight_data

        # Restore state and save file
        bpy.ops.object.mode_set(mode=original_mode)
        context.view_layer.objects.active = original_active
        
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
            with open(self.filepath, 'w') as f:
                json.dump(skeleton_data, f, indent=2)
            self.report({'INFO'}, f"Exported {armature.name} with {len(skeleton_data['bones'])} bones")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}
    
    def round_vector(self, vector):
        return [round(x, self.precision) for x in vector]
    
    def round_matrix(self, matrix):
        return [round(x, self.precision) for row in matrix for x in row]

class KISM_OT_ExportCustomWeapon(Operator, ExportHelper):
    bl_idname = "kism.export_custom_weapon"
    bl_label = "Export Custom Weapon"
    bl_description = "Export weapon with empty parent and child meshes"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_mode: EnumProperty(
        name="Export Mode",
        items=[
            ('FULL', "Full", "Export everything (empty parent, meshes)"),
            ('GEOMETRY_ONLY', "Geometry Only", "Export only mesh data"),
        ],
        default='FULL'
    )
    
    export_materials: BoolProperty(
        name="Export Materials",
        description="Include material assignments",
        default=True
    )
    
    export_constraints: BoolProperty(
        name="Export Constraints",
        description="Include constraint data",
        default=True
    )
    
    include_children: BoolProperty(
        name="Include Children",
        description="Export all child objects of selected items",
        default=True
    )
    
    precision: IntProperty(
        name="Precision",
        description="Number of decimal places",
        default=6,
        min=1,
        max=8
    )

    def execute(self, context):
        export_data = {
            'metadata': {
                'type': 'CUSTOM_WEAPON',
                'version': '1.0',
                'export_time': datetime.datetime.now().isoformat(),
                'generator': 'KISM Tools',
                'blender_version': bpy.app.version_string
            },
            'parent_empty': None,
            'meshes': []
        }

        try:
            # Get all selected objects and their children if enabled
            selected_objects = self._get_export_objects(context)
            
            if not selected_objects:
                self.report({'ERROR'}, "No valid objects selected")
                return {'CANCELLED'}

            # Find and export parent empty first
            parent_empty = next((obj for obj in selected_objects if obj.type == 'EMPTY'), None)
            if parent_empty and self.export_mode == 'FULL':
                export_data['parent_empty'] = {
                    'name': parent_empty.name,
                    'original_name': parent_empty.name,
                    'matrix_world': self._round_matrix(parent_empty.matrix_world)
                }
                
                # Export constraints for parent empty
                if self.export_constraints and parent_empty.constraints:
                    export_data['parent_empty']['constraints'] = self._export_constraints(parent_empty)
                
                export_data['metadata']['empty_name'] = parent_empty.name

            # Export meshes
            for obj in selected_objects:
                if obj.type == 'MESH':
                    mesh_data = self._export_mesh(obj)
                    if mesh_data:
                        # Export constraints for meshes
                        if self.export_constraints and obj.constraints:
                            mesh_data['constraints'] = self._export_constraints(obj)
                        export_data['meshes'].append(mesh_data)

            # Write to file with Weapon_ prefix
            filename = os.path.basename(self.filepath)
            if not filename.startswith("Weapon_"):
                dirname = os.path.dirname(self.filepath)
                self.filepath = os.path.join(dirname, f"Weapon_{filename}")

            with open(self.filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            self.report({'INFO'}, f"Successfully exported weapon: {len(export_data['meshes'])} meshes")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Weapon export failed: {str(e)}")
            return {'CANCELLED'}

    def _export_constraints(self, obj):
        """Export all constraints for an object"""
        constraints_data = []
        for constraint in obj.constraints:
            constraint_data = {
                'name': constraint.name,
                'type': constraint.type,
                'mute': constraint.mute,
                'influence': constraint.influence,
                'is_valid': constraint.is_valid
            }
            
            # Export target if exists
            if constraint.target:
                constraint_data['target'] = constraint.target.name
                
            # Export specific constraint properties based on type
            if constraint.type == 'COPY_LOCATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_ROTATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'mix_mode': constraint.mix_mode,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_TRANSFORMS':
                constraint_data.update({
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'CHILD_OF':
                constraint_data.update({
                    'use_location_x': constraint.use_location_x,
                    'use_location_y': constraint.use_location_y,
                    'use_location_z': constraint.use_location_z,
                    'use_rotation_x': constraint.use_rotation_x,
                    'use_rotation_y': constraint.use_rotation_y,
                    'use_rotation_z': constraint.use_rotation_z,
                    'use_scale_x': constraint.use_scale_x,
                    'use_scale_y': constraint.use_scale_y,
                    'use_scale_z': constraint.use_scale_z
                })
            elif constraint.type == 'TRACK_TO':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'up_axis': constraint.up_axis,
                    'use_target_z': constraint.use_target_z
                })
            elif constraint.type == 'LOCKED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'lock_axis': constraint.lock_axis
                })
            elif constraint.type == 'DAMPED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis
                })
            elif constraint.type == 'STRETCH_TO':
                constraint_data.update({
                    'bulge': constraint.bulge,
                    'bulge_min': constraint.bulge_min,
                    'bulge_max': constraint.bulge_max,
                    'bulge_smooth': constraint.bulge_smooth,
                    'volume': constraint.volume,
                    'keep_axis': constraint.keep_axis
                })
            elif constraint.type == 'TRANSFORM':
                constraint_data.update({
                    'map_from': constraint.map_from,
                    'map_to': constraint.map_to,
                    'from_min_x': constraint.from_min_x,
                    'from_max_x': constraint.from_max_x,
                    'from_min_y': constraint.from_min_y,
                    'from_max_y': constraint.from_max_y,
                    'from_min_z': constraint.from_min_z,
                    'from_max_z': constraint.from_max_z,
                    'to_min_x': constraint.to_min_x,
                    'to_max_x': constraint.to_max_x,
                    'to_min_y': constraint.to_min_y,
                    'to_max_y': constraint.to_max_y,
                    'to_min_z': constraint.to_min_z,
                    'to_max_z': constraint.to_max_z,
                    'use_motion_extrapolate': constraint.use_motion_extrapolate,
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'LIMIT_LOCATION':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_ROTATION':
                constraint_data.update({
                    'use_limit_x': constraint.use_limit_x,
                    'use_limit_y': constraint.use_limit_y,
                    'use_limit_z': constraint.use_limit_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_SCALE':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'ACTION':
                constraint_data.update({
                    'action': constraint.action.name if constraint.action else None,
                    'frame_start': constraint.frame_start,
                    'frame_end': constraint.frame_end,
                    'mix_mode': constraint.mix_mode,
                    'eval_time': constraint.eval_time
                })
            elif constraint.type == 'FOLLOW_PATH':
                constraint_data.update({
                    'forward_axis': constraint.forward_axis,
                    'up_axis': constraint.up_axis,
                    'follow_curve': constraint.follow_curve,
                    'radius': constraint.radius,
                    'use_fixed_location': constraint.use_fixed_location,
                    'offset_factor': constraint.offset_factor
                })
            elif constraint.type == 'PIVOT':
                constraint_data.update({
                    'rotation_range': constraint.rotation_range,
                    'use_relative_location': constraint.use_relative_location
                })
            elif constraint.type == 'SHRINKWRAP':
                constraint_data.update({
                    'wrap_method': constraint.wrap_method,
                    'wrap_mode': constraint.wrap_mode,
                    'distance': constraint.distance,
                    'use_project_z': constraint.use_project_z
                })
            elif constraint.type == 'CLAMP_TO':
                constraint_data.update({
                    'main_axis': constraint.main_axis,
                    'flag': constraint.flag,
                    'use_cyclic': constraint.use_cyclic,
                    'influence_scale': constraint.influence_scale
                })
            elif constraint.type == 'FLOOR':
                constraint_data.update({
                    'floor_location': constraint.floor_location,
                    'offset': constraint.offset,
                    'use_rotation': constraint.use_rotation,
                    'use_sticky': constraint.use_sticky
                })
            elif constraint.type == 'RIGID_BODY_JOINT':
                constraint_data.update({
                    'pivot_type': constraint.pivot_type,
                    'use_linked_collision': constraint.use_linked_collision,
                    'use_breaking': constraint.use_breaking,
                    'breaking_threshold': constraint.breaking_threshold
                })
            elif constraint.type == 'CAMERA_SOLVER':
                constraint_data.update({
                    'use_active_clip': constraint.use_active_clip
                })
            elif constraint.type == 'OBJECT_SOLVER':
                constraint_data.update({
                    'use_active_clip': constraint.use_active_clip
                })
            elif constraint.type == 'ARMATURE':
                constraint_data.update({
                    'use_deform_preserve_volume': constraint.use_deform_preserve_volume
                })
            
            constraints_data.append(constraint_data)
        
        return constraints_data

    def _get_export_objects(self, context):
        """Get all objects to export including children if enabled"""
        objects = set(context.selected_objects)
        
        if self.include_children:
            for obj in list(objects):  # Iterate over a copy
                objects.update(self._get_all_children(obj))
        
        # Filter only valid types
        return [obj for obj in objects if obj.type in {'EMPTY', 'MESH'}]

    def _get_all_children(self, obj):
        """Recursively get all children of an object"""
        children = []
        if not hasattr(obj, 'children'):
            return children
            
        for child in obj.children:
            children.append(child)
            children.extend(self._get_all_children(child))
        return children

    def _export_mesh(self, obj):
        """Export mesh data with materials and transforms"""
        if not obj or obj.type != 'MESH':
            return None

        mesh_data = {
            'name': obj.name,
            'original_name': obj.name,
            'matrix_world': self._round_matrix(obj.matrix_world),
            'vertices': [],
            'polygons': [],
            'smooth_shading': any(poly.use_smooth for poly in obj.data.polygons)
        }

        # Get evaluated mesh (with modifiers applied)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()

        # Export vertices and polygons
        mesh_data['vertices'] = [self._round_vector(v.co) for v in mesh.vertices]
        mesh_data['polygons'] = [list(p.vertices) for p in mesh.polygons]

        # Export materials if enabled
        if self.export_materials and mesh.materials:
            mesh_data['materials'] = [mat.name for mat in mesh.materials]
            mesh_data['material_indices'] = [p.material_index for p in mesh.polygons]

        # Export parenting information
        if obj.parent:
            mesh_data['parent'] = obj.parent.name
            if obj.parent_type == 'OBJECT' and obj.parent_bone:
                mesh_data['parent_bone'] = obj.parent_bone
                mesh_data['matrix_parent_inverse'] = self._round_matrix(obj.matrix_parent_inverse)

        # Clean up
        eval_obj.to_mesh_clear()
        return mesh_data

    def _round_vector(self, vector):
        """Round vector components to specified precision"""
        return [round(x, self.precision) for x in vector]
    
    def _round_matrix(self, matrix):
        """Round matrix components to specified precision"""
        return [round(x, self.precision) for row in matrix for x in row]

class KISM_OT_ExportCustomRace(Operator, ExportHelper):
    bl_idname = "kism.export_custom_race"
    bl_label = "Export Custom Race"
    bl_description = "Export race with complete error handling and JSON serialization"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_mode: EnumProperty(
        name="Export Mode",
        items=[
            ('FULL', "Full", "Export everything (armature, meshes, empties)"),
            ('GEOMETRY_ONLY', "Geometry Only", "Export only mesh data"),
            ('ARMATURE_ONLY', "Armature Only", "Export only armature data")
        ],
        default='FULL'
    )
    
    export_weights: BoolProperty(
        name="Export Vertex Weights",
        description="Include vertex weight data",
        default=True
    )
    
    export_empties: BoolProperty(
        name="Export Empties",
        description="Include empty objects",
        default=True
    )
    
    export_materials: BoolProperty(
        name="Export Materials",
        description="Include material assignments",
        default=True
    )
    
    export_constraints: BoolProperty(
        name="Export Constraints",
        description="Include constraint data with bone targets",
        default=True
    )
    
    include_children: BoolProperty(
        name="Include Children",
        description="Export all child objects of selected items",
        default=True
    )
    
    precision: IntProperty(
        name="Precision",
        description="Number of decimal places",
        default=6,
        min=1,
        max=8
    )

    def execute(self, context):
        export_data = {
            'metadata': {
                'type': 'CUSTOM_RACE',
                'version': '2.6',
                'export_time': datetime.datetime.now().isoformat(),
                'generator': 'KISM Tools',
                'blender_version': bpy.app.version_string
            },
            'armature': None,
            'meshes': [],
            'empties': []
        }

        try:
            # Get all selected objects and their children if enabled
            selected_objects = self._get_export_objects(context)
            
            if not selected_objects:
                self.report({'ERROR'}, "No valid objects selected")
                return {'CANCELLED'}

            # Find and export armature first (needed for parenting references)
            armature = next((obj for obj in selected_objects if obj.type == 'ARMATURE'), None)
            if armature:
                export_data['armature'] = self._export_armature(context, armature)
                export_data['metadata']['armature_name'] = armature.name

            # Export meshes
            if self.export_mode in {'FULL', 'GEOMETRY_ONLY'}:
                for obj in selected_objects:
                    if obj.type == 'MESH':
                        mesh_data = self._export_mesh(obj, armature)
                        if mesh_data:
                            # Export constraints for meshes
                            if self.export_constraints and obj.constraints:
                                mesh_data['constraints'] = self._export_constraints(obj)
                            export_data['meshes'].append(mesh_data)

            # Export empties
            if self.export_mode == 'FULL' and self.export_empties:
                for obj in selected_objects:
                    if obj.type == 'EMPTY':
                        empty_data = self._export_empty(obj, armature)
                        if empty_data:
                            # Export constraints for empties
                            if self.export_constraints and obj.constraints:
                                empty_data['constraints'] = self._export_constraints(obj)
                            export_data['empties'].append(empty_data)

            # Write to file
            with open(self.filepath, 'w') as f:
                json.dump(export_data, f, indent=2, cls=self.BlenderJSONEncoder)
            
            self.report({'INFO'}, f"Successfully exported: {len(export_data['meshes'])} meshes, {len(export_data['empties'])} empties")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

    def _export_constraints(self, obj):
        """Export all constraints for an object with bone target support"""
        constraints_data = []
        for constraint in obj.constraints:
            constraint_data = {
                'name': constraint.name,
                'type': constraint.type,
                'mute': constraint.mute,
                'influence': constraint.influence,
                'is_valid': constraint.is_valid
            }
            
            # Export target if exists
            if constraint.target:
                constraint_data['target'] = constraint.target.name
                
                # Export subtarget (bone name) if it exists - THIS IS THE KEY FIX
                if hasattr(constraint, 'subtarget') and constraint.subtarget:
                    constraint_data['subtarget'] = constraint.subtarget
            
            # Export space properties for bone constraints
            if hasattr(constraint, 'target_space'):
                constraint_data['target_space'] = constraint.target_space
            if hasattr(constraint, 'owner_space'):
                constraint_data['owner_space'] = constraint.owner_space
                
            # Export specific constraint properties based on type
            if constraint.type == 'COPY_LOCATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_ROTATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'mix_mode': constraint.mix_mode,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_TRANSFORMS':
                constraint_data.update({
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'CHILD_OF':
                constraint_data.update({
                    'use_location_x': constraint.use_location_x,
                    'use_location_y': constraint.use_location_y,
                    'use_location_z': constraint.use_location_z,
                    'use_rotation_x': constraint.use_rotation_x,
                    'use_rotation_y': constraint.use_rotation_y,
                    'use_rotation_z': constraint.use_rotation_z,
                    'use_scale_x': constraint.use_scale_x,
                    'use_scale_y': constraint.use_scale_y,
                    'use_scale_z': constraint.use_scale_z
                })
            elif constraint.type == 'TRACK_TO':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'up_axis': constraint.up_axis,
                    'use_target_z': constraint.use_target_z
                })
            elif constraint.type == 'LOCKED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'lock_axis': constraint.lock_axis
                })
            elif constraint.type == 'DAMPED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis
                })
            elif constraint.type == 'STRETCH_TO':
                constraint_data.update({
                    'bulge': constraint.bulge,
                    'bulge_min': constraint.bulge_min,
                    'bulge_max': constraint.bulge_max,
                    'bulge_smooth': constraint.bulge_smooth,
                    'volume': constraint.volume,
                    'keep_axis': constraint.keep_axis
                })
            elif constraint.type == 'TRANSFORM':
                constraint_data.update({
                    'map_from': constraint.map_from,
                    'map_to': constraint.map_to,
                    'from_min_x': constraint.from_min_x,
                    'from_max_x': constraint.from_max_x,
                    'from_min_y': constraint.from_min_y,
                    'from_max_y': constraint.from_max_y,
                    'from_min_z': constraint.from_min_z,
                    'from_max_z': constraint.from_max_z,
                    'to_min_x': constraint.to_min_x,
                    'to_max_x': constraint.to_max_x,
                    'to_min_y': constraint.to_min_y,
                    'to_max_y': constraint.to_max_y,
                    'to_min_z': constraint.to_min_z,
                    'to_max_z': constraint.to_max_z,
                    'use_motion_extrapolate': constraint.use_motion_extrapolate,
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'LIMIT_LOCATION':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_ROTATION':
                constraint_data.update({
                    'use_limit_x': constraint.use_limit_x,
                    'use_limit_y': constraint.use_limit_y,
                    'use_limit_z': constraint.use_limit_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_SCALE':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            
            constraints_data.append(constraint_data)
        
        return constraints_data

    def _get_export_objects(self, context):
        """Get all objects to export including children if enabled"""
        objects = set(context.selected_objects)
        
        if self.include_children:
            for obj in list(objects):  # Iterate over a copy
                objects.update(self._get_all_children(obj))
        
        # Filter only valid types
        return [obj for obj in objects if obj.type in {'ARMATURE', 'MESH', 'EMPTY'}]

    def _get_all_children(self, obj):
        """Recursively get all children of an object"""
        children = []
        if not hasattr(obj, 'children'):
            return children
            
        for child in obj.children:
            children.append(child)
            children.extend(self._get_all_children(child))
        return children

    def _export_armature(self, context, armature):
        """Export armature with bone hierarchy"""
        if not armature or armature.type != 'ARMATURE':
            return None

        armature_data = {
            'name': armature.name,
            'original_name': armature.name,
            'bones': [],
            'matrix_world': self._round_matrix(armature.matrix_world)
        }

        # Store current mode
        prev_mode = context.object.mode if context.object else 'OBJECT'
        prev_active = context.view_layer.objects.active
        
        try:
            # Enter edit mode to access bone data
            context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='EDIT')
            
            # Export bone data
            for bone in armature.data.edit_bones:
                bone_data = {
                    'name': bone.name,
                    'head': self._round_vector(bone.head),
                    'tail': self._round_vector(bone.tail),
                    'roll': round(bone.roll, self.precision),
                    'parent': bone.parent.name if bone.parent else None,
                    'use_connect': bone.use_connect,
                    'matrix': self._round_matrix(bone.matrix)
                }
                armature_data['bones'].append(bone_data)
                
        except Exception as e:
            self.report({'WARNING'}, f"Armature export partially failed: {str(e)}")
        finally:
            # Restore previous mode
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
            context.view_layer.objects.active = prev_active

        return armature_data

    def _export_mesh(self, mesh_obj, armature):
        """Export mesh data with weights and parenting"""
        if not mesh_obj or mesh_obj.type != 'MESH':
            return None

        mesh_data = None
        try:
            # Get evaluated mesh (with modifiers applied)
            depsgraph = bpy.context.evaluated_depsgraph_get()
            eval_obj = mesh_obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh()

            mesh_data = {
                'name': mesh_obj.name,
                'original_name': mesh_obj.name,
                'vertices': [self._round_vector(v.co) for v in mesh.vertices],
                'polygons': [list(p.vertices) for p in mesh.polygons],
                'matrix_world': self._round_matrix(mesh_obj.matrix_world),
                'smooth_shading': any(p.use_smooth for p in mesh.polygons)
            }

            # Export vertex weights if enabled and exists
            if self.export_weights and mesh_obj.vertex_groups:
                weight_data = []
                for vert in mesh.vertices:
                    vert_weights = {}
                    for group in vert.groups:
                        if group.weight > 0.0001:  # Skip negligible weights
                            group_name = mesh_obj.vertex_groups[group.group].name
                            vert_weights[group_name] = round(group.weight, self.precision)
                    
                    if vert_weights:
                        weight_data.append({
                            'vertex_index': vert.index,
                            'weights': vert_weights
                        })
                
                if weight_data:
                    mesh_data['vertex_weights'] = weight_data

            # Export materials if enabled
            if self.export_materials and mesh.materials:
                mesh_data['materials'] = [mat.name for mat in mesh.materials]
                mesh_data['material_indices'] = [p.material_index for p in mesh.polygons]

            # Export parenting information
            if mesh_obj.parent:
                mesh_data['parent'] = mesh_obj.parent.name
                
                if mesh_obj.parent_type == 'BONE' and mesh_obj.parent_bone:
                    mesh_data['parent_type'] = 'BONE'
                    mesh_data['parent_bone'] = mesh_obj.parent_bone
                    mesh_data['matrix_parent_inverse'] = self._round_matrix(mesh_obj.matrix_parent_inverse)

        except Exception as e:
            self.report({'WARNING'}, f"Mesh export failed for {mesh_obj.name}: {str(e)}")
        finally:
            if 'eval_obj' in locals() and 'mesh' in locals():
                eval_obj.to_mesh_clear()

        return mesh_data

    def _export_empty(self, empty_obj, armature):
        """Export empty object data"""
        if not empty_obj or empty_obj.type != 'EMPTY':
            return None

        empty_data = {
            'name': empty_obj.name,
            'original_name': empty_obj.name,
            'type': empty_obj.empty_display_type,
            'size': empty_obj.empty_display_size,
            'matrix_world': self._round_matrix(empty_obj.matrix_world)
        }

        # Export parenting
        if empty_obj.parent:
            empty_data['parent'] = empty_obj.parent.name
            
            if empty_obj.parent_type == 'BONE' and empty_obj.parent_bone:
                empty_data['parent_type'] = 'BONE'
                empty_data['parent_bone'] = empty_obj.parent_bone
                empty_data['matrix_parent_inverse'] = self._round_matrix(empty_obj.matrix_parent_inverse)

        return empty_data

    def _round_vector(self, vector):
        """Round vector components to specified precision"""
        if vector is None:
            return [0, 0, 0]
        return [round(x, self.precision) for x in vector]
    
    def _round_matrix(self, matrix):
        """Round matrix components to specified precision"""
        if matrix is None:
            return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
        return [round(x, self.precision) for row in matrix for x in row]

    class BlenderJSONEncoder(json.JSONEncoder):
        """Custom JSON encoder for Blender types"""
        def default(self, obj):
            if isinstance(obj, (Vector, Matrix)):
                return list(obj)
            elif hasattr(obj, 'to_list'):
                return obj.to_list()
            elif hasattr(obj, '__dict__'):
                return obj.__dict__
            return str(obj)

class KISM_OT_ImportRace(Operator):
    bl_idname = "kism.import_race"
    bl_label = "Import Race"
    bl_description = "Import race setup with robust error handling and exact naming"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.kism_props
        
        if props.available_races == 'NONE':
            self.report({'ERROR'}, "No race selected")
            return {'CANCELLED'}

        try:
            # Load JSON data with error handling
            with open(props.available_races, 'r') as f:
                data = json.load(f)
            
            if not isinstance(data, dict) or data.get('metadata', {}).get('type') != 'CUSTOM_RACE':
                self.report({'ERROR'}, "Invalid race file format")
                return {'CANCELLED'}

            # Get original armature name
            armature_data = data.get('armature', {})
            original_armature_name = armature_data.get('original_name', armature_data.get('name', 'Armature'))
            
            # Safely prepare scene
            self._safe_prepare_import(original_armature_name)

            # Create collection
            collection = self._create_collection(f"Race_{original_armature_name}")
            if not collection:
                return {'CANCELLED'}

            # Import armature first (required for parenting)
            armature_obj = self._import_armature(armature_data, collection, props.import_scale)
            if not armature_obj:
                bpy.data.collections.remove(collection)
                return {'CANCELLED'}

            # Import meshes with improved error handling
            imported_meshes = []
            for mesh_data in data.get('meshes', []):
                mesh_obj = self._import_mesh(mesh_data, collection, armature_obj, props.import_scale)
                if mesh_obj:
                    imported_meshes.append(mesh_obj.name)

            # Import empties
            for empty_data in data.get('empties', []):
                self._import_empty(empty_data, collection, armature_obj, props.import_scale)

            self.report({'INFO'}, f"Successfully imported {original_armature_name} with {len(imported_meshes)} meshes")
            return {'FINISHED'}

        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {str(e)}")
            return {'CANCELLED'}

    def _safe_prepare_import(self, armature_name):
        """Safely clean up existing objects before import"""
        try:
            # Remove existing armature object if it exists
            if armature_name in bpy.data.objects:
                obj = bpy.data.objects[armature_name]
                if obj.type == 'ARMATURE' and obj.data:
                    # Remove armature data if no other users
                    if obj.data.users == 1:
                        bpy.data.armatures.remove(obj.data)
                bpy.data.objects.remove(obj)
            
            # Remove orphaned armature data
            if armature_name in bpy.data.armatures and bpy.data.armatures[armature_name].users == 0:
                bpy.data.armatures.remove(bpy.data.armatures[armature_name])
        except:
            pass

    def _create_collection(self, name):
        """Safely create collection for imported assets"""
        try:
            # Remove existing collection if needed
            if name in bpy.data.collections:
                col = bpy.data.collections[name]
                # Unlink from all scenes
                for scene in bpy.data.scenes:
                    if col.name in scene.collection.children:
                        scene.collection.children.unlink(col)
                bpy.data.collections.remove(col)
            
            # Create new collection
            new_col = bpy.data.collections.new(name)
            bpy.context.scene.collection.children.link(new_col)
            return new_col
        except:
            self.report({'ERROR'}, "Failed to create collection")
            return None

    def _import_armature(self, armature_data, collection, scale):
        """Safely import armature with exact name preservation"""
        if not armature_data or not armature_data.get('bones'):
            self.report({'WARNING'}, "No valid armature data found")
            return None

        try:
            original_name = armature_data.get('original_name', armature_data.get('name', 'Armature'))
            
            # Create new armature with original name
            armature = bpy.data.armatures.new(original_name)
            armature_obj = bpy.data.objects.new(original_name, armature)
            collection.objects.link(armature_obj)

            # Store current context
            prev_active = bpy.context.view_layer.objects.active
            prev_mode = prev_active.mode if prev_active else 'OBJECT'

            # Set active object and enter edit mode
            bpy.context.view_layer.objects.active = armature_obj
            bpy.ops.object.mode_set(mode='EDIT')

            # Create bones
            bone_map = {}
            edit_bones = armature_obj.data.edit_bones
            for bone_data in armature_data.get('bones', []):
                bone_name = bone_data.get('name', 'Bone')
                try:
                    bone = edit_bones.new(bone_name)
                    bone.head = Vector(bone_data.get('head', [0, 0, 0])) * scale
                    bone.tail = Vector(bone_data.get('tail', [0, 0, 0.1])) * scale
                    bone.roll = bone_data.get('roll', 0)
                    bone.use_connect = bone_data.get('use_connect', False)
                    bone_map[bone_name] = bone
                except Exception as e:
                    print(f"Failed to create bone {bone_name}: {str(e)}")
                    continue

            # Set bone parenting
            for bone_data in armature_data.get('bones', []):
                bone_name = bone_data.get('name', 'Bone')
                parent_name = bone_data.get('parent')
                if parent_name in bone_map and bone_name in bone_map:
                    try:
                        bone_map[bone_name].parent = bone_map[parent_name]
                    except Exception as e:
                        print(f"Failed to parent bone {bone_name} to {parent_name}: {str(e)}")
                        continue

            # Restore previous mode
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.context.view_layer.objects.active = prev_active

            # Set transform if specified
            if 'matrix_world' in armature_data:
                try:
                    matrix = Matrix([armature_data['matrix_world'][i*4:(i+1)*4] for i in range(4)])
                    for i in range(3):
                        matrix[i][3] *= scale
                    armature_obj.matrix_world = matrix
                except Exception as e:
                    print(f"Failed to set armature transform: {str(e)}")

            return armature_obj

        except Exception as e:
            self.report({'ERROR'}, f"Armature import failed: {str(e)}")
            return None

    def _import_mesh(self, mesh_data, collection, armature_obj, scale):
        """Safely import mesh with exact name preservation and return the created object"""
        if not mesh_data or not mesh_data.get('vertices'):
            self.report({'WARNING'}, "Skipping mesh with no vertex data")
            return None

        mesh_obj = None
        try:
            original_name = mesh_data.get('original_name', mesh_data.get('name', 'Mesh'))
            
            # Clean up existing mesh if needed
            if original_name in bpy.data.objects:
                obj = bpy.data.objects[original_name]
                if obj.type == 'MESH' and obj.data and obj.data.users == 1:
                    bpy.data.meshes.remove(obj.data)
                bpy.data.objects.remove(obj)
            if original_name in bpy.data.meshes and bpy.data.meshes[original_name].users == 0:
                bpy.data.meshes.remove(bpy.data.meshes[original_name])

            # Create new mesh with original name
            mesh = bpy.data.meshes.new(original_name)
            mesh_obj = bpy.data.objects.new(original_name, mesh)
            collection.objects.link(mesh_obj)

            # Create geometry (vertices and faces)
            try:
                vertices = [Vector(v) * scale for v in mesh_data.get('vertices', [])]
                faces = mesh_data.get('polygons', [])
                mesh.from_pydata(vertices, [], faces)
                
                # Validate mesh
                if len(mesh.vertices) == 0:
                    raise ValueError("Mesh has no vertices after creation")
            except Exception as e:
                self.report({'WARNING'}, f"Mesh geometry creation failed for {original_name}: {str(e)}")
                bpy.data.objects.remove(mesh_obj)
                bpy.data.meshes.remove(mesh)
                return None

            # Set smooth shading
            if mesh_data.get('smooth_shading', False):
                for poly in mesh.polygons:
                    poly.use_smooth = True

            # Set transform if specified
            if 'matrix_world' in mesh_data:
                try:
                    matrix = Matrix([mesh_data['matrix_world'][i*4:(i+1)*4] for i in range(4)])
                    for i in range(3):
                        matrix[i][3] *= scale
                    mesh_obj.matrix_world = matrix
                except Exception as e:
                    print(f"Failed to set mesh transform for {original_name}: {str(e)}")

            # Apply weights if armature exists
            if armature_obj and 'vertex_weights' in mesh_data:
                self._apply_weights(mesh_obj, armature_obj, mesh_data['vertex_weights'])

            # Handle parenting
            if 'parent' in mesh_data and mesh_data['parent'] == armature_obj.name:
                self._parent_to_armature(mesh_obj, armature_obj, mesh_data)

            # Import constraints if they exist - THIS IS THE KEY FIX
            if 'constraints' in mesh_data:
                self._import_constraints(mesh_obj, mesh_data['constraints'])

            return mesh_obj

        except Exception as e:
            self.report({'WARNING'}, f"Mesh import failed for {mesh_data.get('name', 'unnamed')}: {str(e)}")
            if mesh_obj and mesh_obj.name in bpy.data.objects:
                bpy.data.objects.remove(mesh_obj)
            if 'mesh' in locals() and mesh.name in bpy.data.meshes:
                bpy.data.meshes.remove(mesh)
            return None

    def _import_empty(self, empty_data, collection, armature_obj, scale):
        """Safely import empty with exact name preservation"""
        if not empty_data:
            return

        try:
            original_name = empty_data.get('original_name', empty_data.get('name', 'Empty'))
            
            # Clean up existing empty if needed
            if original_name in bpy.data.objects:
                obj = bpy.data.objects[original_name]
                bpy.data.objects.remove(obj)

            # Create new empty with original name
            empty = bpy.data.objects.new(original_name, None)
            collection.objects.link(empty)

            # Set display properties
            empty.empty_display_type = empty_data.get('type', 'PLAIN_AXES')
            empty.empty_display_size = empty_data.get('size', 1.0) * scale

            # Parent to armature bone if specified
            if armature_obj and 'parent_bone' in empty_data:
                self._parent_to_armature(empty, armature_obj, empty_data)

            # Set transform if specified
            if 'matrix_world' in empty_data:
                try:
                    matrix = Matrix([empty_data['matrix_world'][i*4:(i+1)*4] for i in range(4)])
                    for i in range(3):
                        matrix[i][3] *= scale
                    empty.matrix_world = matrix
                except Exception as e:
                    print(f"Failed to set empty transform: {str(e)}")

            # Import constraints if they exist - THIS IS THE KEY FIX
            if 'constraints' in empty_data:
                self._import_constraints(empty, empty_data['constraints'])

        except Exception as e:
            self.report({'WARNING'}, f"Empty import failed: {str(e)}")

    def _import_constraints(self, obj, constraints_data):
        """Import constraints for an object with bone target support"""
        if not constraints_data or not isinstance(constraints_data, list):
            return
            
        for constraint_data in constraints_data:
            try:
                # Create constraint
                constraint = obj.constraints.new(constraint_data['type'])
                constraint.name = constraint_data.get('name', constraint.type)
                constraint.mute = constraint_data.get('mute', False)
                constraint.influence = constraint_data.get('influence', 1.0)
                
                # Set target if exists
                if 'target' in constraint_data and constraint_data['target'] in bpy.data.objects:
                    constraint.target = bpy.data.objects[constraint_data['target']]
                    
                    # Set subtarget (bone name) if it exists - THIS IS THE KEY FIX
                    if 'subtarget' in constraint_data and constraint_data['subtarget']:
                        constraint.subtarget = constraint_data['subtarget']
                
                # Set space properties for bone constraints
                if 'target_space' in constraint_data and hasattr(constraint, 'target_space'):
                    constraint.target_space = constraint_data['target_space']
                if 'owner_space' in constraint_data and hasattr(constraint, 'owner_space'):
                    constraint.owner_space = constraint_data['owner_space']
                
                # Set constraint-specific properties
                if constraint.type == 'COPY_LOCATION':
                    constraint.use_x = constraint_data.get('use_x', True)
                    constraint.use_y = constraint_data.get('use_y', True)
                    constraint.use_z = constraint_data.get('use_z', True)
                    constraint.invert_x = constraint_data.get('invert_x', False)
                    constraint.invert_y = constraint_data.get('invert_y', False)
                    constraint.invert_z = constraint_data.get('invert_z', False)
                    constraint.use_offset = constraint_data.get('use_offset', False)
                elif constraint.type == 'COPY_ROTATION':
                    constraint.use_x = constraint_data.get('use_x', True)
                    constraint.use_y = constraint_data.get('use_y', True)
                    constraint.use_z = constraint_data.get('use_z', True)
                    constraint.invert_x = constraint_data.get('invert_x', False)
                    constraint.invert_y = constraint_data.get('invert_y', False)
                    constraint.invert_z = constraint_data.get('invert_z', False)
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                    constraint.use_offset = constraint_data.get('use_offset', False)
                elif constraint.type == 'COPY_TRANSFORMS':
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                elif constraint.type == 'CHILD_OF':
                    constraint.use_location_x = constraint_data.get('use_location_x', True)
                    constraint.use_location_y = constraint_data.get('use_location_y', True)
                    constraint.use_location_z = constraint_data.get('use_location_z', True)
                    constraint.use_rotation_x = constraint_data.get('use_rotation_x', True)
                    constraint.use_rotation_y = constraint_data.get('use_rotation_y', True)
                    constraint.use_rotation_z = constraint_data.get('use_rotation_z', True)
                    constraint.use_scale_x = constraint_data.get('use_scale_x', True)
                    constraint.use_scale_y = constraint_data.get('use_scale_y', True)
                    constraint.use_scale_z = constraint_data.get('use_scale_z', True)
                elif constraint.type == 'TRACK_TO':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                    constraint.up_axis = constraint_data.get('up_axis', 'UP_Z')
                    constraint.use_target_z = constraint_data.get('use_target_z', False)
                elif constraint.type == 'LOCKED_TRACK':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                    constraint.lock_axis = constraint_data.get('lock_axis', 'LOCK_Y')
                elif constraint.type == 'DAMPED_TRACK':
                    constraint.track_axis = constraint_data.get('track_axis', 'TRACK_X')
                elif constraint.type == 'STRETCH_TO':
                    constraint.bulge = constraint_data.get('bulge', 1.0)
                    constraint.bulge_min = constraint_data.get('bulge_min', 1.0)
                    constraint.bulge_max = constraint_data.get('bulge_max', 1.0)
                    constraint.bulge_smooth = constraint_data.get('bulge_smooth', 0.0)
                    constraint.volume = constraint_data.get('volume', 'NO_VOLUME')
                    constraint.keep_axis = constraint_data.get('keep_axis', 'PLANE_X')
                elif constraint.type == 'TRANSFORM':
                    constraint.map_from = constraint_data.get('map_from', 'LOCATION')
                    constraint.map_to = constraint_data.get('map_to', 'LOCATION')
                    constraint.from_min_x = constraint_data.get('from_min_x', 0.0)
                    constraint.from_max_x = constraint_data.get('from_max_x', 1.0)
                    constraint.from_min_y = constraint_data.get('from_min_y', 0.0)
                    constraint.from_max_y = constraint_data.get('from_max_y', 1.0)
                    constraint.from_min_z = constraint_data.get('from_min_z', 0.0)
                    constraint.from_max_z = constraint_data.get('from_max_z', 1.0)
                    constraint.to_min_x = constraint_data.get('to_min_x', 0.0)
                    constraint.to_max_x = constraint_data.get('to_max_x', 1.0)
                    constraint.to_min_y = constraint_data.get('to_min_y', 0.0)
                    constraint.to_max_y = constraint_data.get('to_max_y', 1.0)
                    constraint.to_min_z = constraint_data.get('to_min_z', 0.0)
                    constraint.to_max_z = constraint_data.get('to_max_z', 1.0)
                    constraint.use_motion_extrapolate = constraint_data.get('use_motion_extrapolate', False)
                    constraint.mix_mode = constraint_data.get('mix_mode', 'REPLACE')
                elif constraint.type == 'LIMIT_LOCATION':
                    constraint.use_min_x = constraint_data.get('use_min_x', False)
                    constraint.use_min_y = constraint_data.get('use_min_y', False)
                    constraint.use_min_z = constraint_data.get('use_min_z', False)
                    constraint.use_max_x = constraint_data.get('use_max_x', False)
                    constraint.use_max_y = constraint_data.get('use_max_y', False)
                    constraint.use_max_z = constraint_data.get('use_max_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                elif constraint.type == 'LIMIT_ROTATION':
                    constraint.use_limit_x = constraint_data.get('use_limit_x', False)
                    constraint.use_limit_y = constraint_data.get('use_limit_y', False)
                    constraint.use_limit_z = constraint_data.get('use_limit_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                elif constraint.type == 'LIMIT_SCALE':
                    constraint.use_min_x = constraint_data.get('use_min_x', False)
                    constraint.use_min_y = constraint_data.get('use_min_y', False)
                    constraint.use_min_z = constraint_data.get('use_min_z', False)
                    constraint.use_max_x = constraint_data.get('use_max_x', False)
                    constraint.use_max_y = constraint_data.get('use_max_y', False)
                    constraint.use_max_z = constraint_data.get('use_max_z', False)
                    constraint.min_x = constraint_data.get('min_x', 0.0)
                    constraint.min_y = constraint_data.get('min_y', 0.0)
                    constraint.min_z = constraint_data.get('min_z', 0.0)
                    constraint.max_x = constraint_data.get('max_x', 0.0)
                    constraint.max_y = constraint_data.get('max_y', 0.0)
                    constraint.max_z = constraint_data.get('max_z', 0.0)
                    
            except Exception as e:
                print(f"Failed to import constraint {constraint_data.get('name', 'unknown')}: {str(e)}")

    def _parent_to_armature(self, obj, armature_obj, data):
        """Parent object to armature with bone if specified"""
        try:
            obj.parent = armature_obj
            
            if data.get('parent_type') == 'BONE' and data.get('parent_bone'):
                obj.parent_type = 'BONE'
                obj.parent_bone = data['parent_bone']
                
                if 'matrix_parent_inverse' in data:
                    try:
                        obj.matrix_parent_inverse = Matrix([data['matrix_parent_inverse'][i*4:(i+1)*4] for i in range(4)])
                    except:
                        pass
        except Exception as e:
            print(f"Failed to parent object {obj.name}: {str(e)}")

    def _apply_weights(self, mesh_obj, armature_obj, weight_data):
        """Safely apply vertex weights to mesh"""
        if not weight_data or not mesh_obj or not armature_obj:
            return

        try:
            # Add armature modifier if needed
            if 'Armature' not in mesh_obj.modifiers:
                mod = mesh_obj.modifiers.new('Armature', 'ARMATURE')
                mod.object = armature_obj

            # Create vertex groups and assign weights
            for weight_entry in weight_data:
                if not isinstance(weight_entry, dict):
                    continue
                    
                vert_idx = weight_entry.get('vertex_index')
                if vert_idx is None:
                    continue
                    
                for group_name, weight in weight_entry.get('weights', {}).items():
                    try:
                        # Create group if doesn't exist
                        if group_name not in mesh_obj.vertex_groups:
                            vg = mesh_obj.vertex_groups.new(name=group_name)
                        else:
                            vg = mesh_obj.vertex_groups[group_name]
                        
                        # Assign weight
                        vg.add([vert_idx], weight, 'REPLACE')
                    except Exception as e:
                        print(f"Failed to assign weight for {group_name}: {str(e)}")
                        continue

        except Exception as e:
            self.report({'WARNING'}, f"Weight application failed: {str(e)}")

class KISM_OT_AutoParentToBones(Operator):
    bl_idname = "kism.auto_parent_to_bones"
    bl_label = "Auto-Parent KISM to Bones"
    bl_description = "Parent all KISM objects to nearest bones in selected armature"
    bl_options = {'REGISTER', 'UNDO'}
    
    def find_closest_bone(self, armature, world_pos):
        """Find the closest bone to a world position"""
        if not armature or armature.type != 'ARMATURE':
            return None
            
        closest_bone = None
        min_distance = float('inf')
        
        for bone in armature.pose.bones:
            head = armature.matrix_world @ bone.head
            tail = armature.matrix_world @ bone.tail
            bone_vec = tail - head
            pos_vec = world_pos - head
            dot = pos_vec.dot(bone_vec)
            
            if dot <= 0:
                dist = (head - world_pos).length
            elif dot >= bone_vec.length_squared:
                dist = (tail - world_pos).length
            else:
                proj = head + (dot / bone_vec.length_squared) * bone_vec
                dist = (proj - world_pos).length
            
            if dist < min_distance:
                min_distance = dist
                closest_bone = bone.name
        
        return closest_bone
    
    def execute(self, context):
        armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'ERROR'}, "No armature selected")
            return {'CANCELLED'}
        
        armature = armatures[0]
        kism_objects = [obj for obj in bpy.data.objects if obj.name.startswith("KISM_")]
        if not kism_objects:
            self.report({'ERROR'}, "No KISM_ objects found")
            return {'CANCELLED'}

        original_mode = armature.mode
        original_active = context.view_layer.objects.active
        original_selection = context.selected_objects.copy()
        bpy.ops.object.mode_set(mode='OBJECT')
        
        success_count = 0
        
        for obj in kism_objects:
            try:
                original_matrix = obj.matrix_world.copy()
                world_pos = original_matrix.translation
                bone_name = self.find_closest_bone(armature, world_pos)
                if not bone_name:
                    continue
                
                obj.parent = None
                obj.matrix_parent_inverse = Matrix()
                obj.parent = armature
                obj.parent_type = 'BONE'
                obj.parent_bone = bone_name
                
                bpy.context.view_layer.update()
                
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone:
                    bone_matrix = armature.matrix_world @ pose_bone.matrix
                    obj.matrix_parent_inverse = bone_matrix.inverted()
                
                obj.matrix_world = original_matrix
                success_count += 1
                
            except Exception as e:
                print(f"Error parenting {obj.name}: {str(e)}")
                continue
        
        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selection:
            obj.select_set(True)
        context.view_layer.objects.active = original_active
        bpy.ops.object.mode_set(mode=original_mode)
        
        self.report({'INFO'}, f"Parented {success_count}/{len(kism_objects)} KISM objects")
        return {'FINISHED'}

class KISM_OT_AttachObjectToAP(Operator):
    bl_idname = "kism.attach_object_ap"
    bl_label = "Attach Object to AP"
    bl_description = "Link object to AP using constraints only"
    
    ap_name: StringProperty(name="AP Target")

    def execute(self, context):
        obj = context.active_object
        ap_empty = bpy.data.objects.get(self.ap_name)

        # Validation
        if not obj or not obj.name.startswith(("Weapon_", "Armor_")):
            self.report({'ERROR'}, "Select a Weapon_ or Armor_ object")
            return {'CANCELLED'}
            
        if not ap_empty:
            self.report({'ERROR'}, f"AP '{self.ap_name}' not found")
            return {'CANCELLED'}

        # Clean existing constraints
        obj.constraints.clear()

        # Create new constraints
        copy_loc = obj.constraints.new('COPY_LOCATION')
        copy_loc.target = ap_empty
        copy_rot = obj.constraints.new('COPY_ROTATION') 
        copy_rot.target = ap_empty

        self.report({'INFO'}, f"Constrained {obj.name} to {ap_empty.name}")
        return {'FINISHED'}

class KISM_OT_DetachObjectAP(Operator):
    bl_idname = "kism.detach_object_ap"
    bl_label = "Remove Attachment"
    bl_description = "Clear all attachment constraints"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj or not obj.name.startswith(("Weapon_", "Armor_")):
            self.report({'ERROR'}, "Select a Weapon_ or Armor_ object")
            return {'CANCELLED'}
        
        # Remove only attachment constraints
        for c in reversed(obj.constraints):
            if c.type in {'COPY_LOCATION', 'COPY_ROTATION'}:
                obj.constraints.remove(c)
        
        self.report({'INFO'}, f"Detached {obj.name}")
        return {'FINISHED'}

# ==============================================
# UI - LIST
# ==============================================

class KISM_UL_JSONFilesList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        
        if item.is_merged:
            # Display merged files differently
            row.label(text=item.name, icon='FILE_BLEND')
            row.label(text=f"{len(item.merged_components)} components")
        else:
            # Regular file display
            icon = 'FILE' if item.file_type == 'MODEL' else 'ARMATURE_DATA'
            row.label(text=item.name, icon=icon)
        
        row.label(text=item.timestamp)

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    KISM_JSONFileComponent,
    KISM_JSONFileItem,
    KISM_Properties,
    KISM_UL_JSONFilesList,
    KISM_OT_LoadJsonFile,
    KISM_OT_RemoveJsonFile,
    KISM_OT_ClearAllFiles,
    KISM_OT_MergeJsonFiles,
    KISM_OT_ImportModel,
    KISM_OT_ImportSkeleton,
    KISM_OT_ImportRace,
    KISM_OT_ImportWeapon,
    KISM_OT_ExportJsonModel,
    KISM_OT_ExportJsonSkeleton,
    KISM_OT_ExportCustomRace,
    KISM_OT_ExportCustomWeapon,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.kism_props = PointerProperty(type=KISM_Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.kism_props

if __name__ == "__main__":
    register()
    bl_idname = "kism.export_custom_race"
    bl_label = "Export Custom Race"
    bl_description = "Export race with complete error handling and JSON serialization"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_mode: EnumProperty(
        name="Export Mode",
        items=[
            ('FULL', "Full", "Export everything (armature, meshes, empties)"),
            ('GEOMETRY_ONLY', "Geometry Only", "Export only mesh data"),
            ('ARMATURE_ONLY', "Armature Only", "Export only armature data")
        ],
        default='FULL'
    )
    
    export_weights: BoolProperty(
        name="Export Vertex Weights",
        description="Include vertex weight data",
        default=True
    )
    
    export_empties: BoolProperty(
        name="Export Empties",
        description="Include empty objects",
        default=True
    )
    
    export_materials: BoolProperty(
        name="Export Materials",
        description="Include material assignments",
        default=True
    )
    
    export_constraints: BoolProperty(
        name="Export Constraints",
        description="Include constraint data",
        default=True
    )
    
    include_children: BoolProperty(
        name="Include Children",
        description="Export all child objects of selected items",
        default=True
    )
    
    precision: IntProperty(
        name="Precision",
        description="Number of decimal places",
        default=6,
        min=1,
        max=8
    )

    def execute(self, context):
        export_data = {
            'metadata': {
                'type': 'CUSTOM_RACE',
                'version': '2.6',
                'export_time': datetime.datetime.now().isoformat(),
                'generator': 'KISM Tools',
                'blender_version': bpy.app.version_string
            },
            'armature': None,
            'meshes': [],
            'empties': []
        }

        try:
            # Get all selected objects and their children if enabled
            selected_objects = self._get_export_objects(context)
            
            if not selected_objects:
                self.report({'ERROR'}, "No valid objects selected")
                return {'CANCELLED'}

            # Find and export armature first (needed for parenting references)
            armature = next((obj for obj in selected_objects if obj.type == 'ARMATURE'), None)
            if armature:
                export_data['armature'] = self._export_armature(context, armature)
                export_data['metadata']['armature_name'] = armature.name

            # Export meshes
            if self.export_mode in {'FULL', 'GEOMETRY_ONLY'}:
                for obj in selected_objects:
                    if obj.type == 'MESH':
                        mesh_data = self._export_mesh(obj, armature)
                        if mesh_data:
                            # Export constraints for meshes
                            if self.export_constraints and obj.constraints:
                                mesh_data['constraints'] = self._export_constraints(obj)
                            export_data['meshes'].append(mesh_data)

            # Export empties
            if self.export_mode == 'FULL' and self.export_empties:
                for obj in selected_objects:
                    if obj.type == 'EMPTY':
                        empty_data = self._export_empty(obj, armature)
                        if empty_data:
                            # Export constraints for empties
                            if self.export_constraints and obj.constraints:
                                empty_data['constraints'] = self._export_constraints(obj)
                            export_data['empties'].append(empty_data)

            # Write to file
            with open(self.filepath, 'w') as f:
                json.dump(export_data, f, indent=2, cls=self.BlenderJSONEncoder)
            
            self.report({'INFO'}, f"Successfully exported: {len(export_data['meshes'])} meshes, {len(export_data['empties'])} empties")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

    def _export_constraints(self, obj):
        """Export all constraints for an object"""
        constraints_data = []
        for constraint in obj.constraints:
            constraint_data = {
                'name': constraint.name,
                'type': constraint.type,
                'mute': constraint.mute,
                'influence': constraint.influence,
                'is_valid': constraint.is_valid
            }
            
            # Export target if exists
            if constraint.target:
                constraint_data['target'] = constraint.target.name
                
            # Export specific constraint properties based on type
            if constraint.type == 'COPY_LOCATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_ROTATION':
                constraint_data.update({
                    'use_x': constraint.use_x,
                    'use_y': constraint.use_y,
                    'use_z': constraint.use_z,
                    'invert_x': constraint.invert_x,
                    'invert_y': constraint.invert_y,
                    'invert_z': constraint.invert_z,
                    'mix_mode': constraint.mix_mode,
                    'use_offset': constraint.use_offset
                })
            elif constraint.type == 'COPY_TRANSFORMS':
                constraint_data.update({
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'CHILD_OF':
                constraint_data.update({
                    'use_location_x': constraint.use_location_x,
                    'use_location_y': constraint.use_location_y,
                    'use_location_z': constraint.use_location_z,
                    'use_rotation_x': constraint.use_rotation_x,
                    'use_rotation_y': constraint.use_rotation_y,
                    'use_rotation_z': constraint.use_rotation_z,
                    'use_scale_x': constraint.use_scale_x,
                    'use_scale_y': constraint.use_scale_y,
                    'use_scale_z': constraint.use_scale_z
                })
            elif constraint.type == 'TRACK_TO':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'up_axis': constraint.up_axis,
                    'use_target_z': constraint.use_target_z
                })
            elif constraint.type == 'LOCKED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis,
                    'lock_axis': constraint.lock_axis
                })
            elif constraint.type == 'DAMPED_TRACK':
                constraint_data.update({
                    'track_axis': constraint.track_axis
                })
            elif constraint.type == 'STRETCH_TO':
                constraint_data.update({
                    'bulge': constraint.bulge,
                    'bulge_min': constraint.bulge_min,
                    'bulge_max': constraint.bulge_max,
                    'bulge_smooth': constraint.bulge_smooth,
                    'volume': constraint.volume,
                    'keep_axis': constraint.keep_axis
                })
            elif constraint.type == 'TRANSFORM':
                constraint_data.update({
                    'map_from': constraint.map_from,
                    'map_to': constraint.map_to,
                    'from_min_x': constraint.from_min_x,
                    'from_max_x': constraint.from_max_x,
                    'from_min_y': constraint.from_min_y,
                    'from_max_y': constraint.from_max_y,
                    'from_min_z': constraint.from_min_z,
                    'from_max_z': constraint.from_max_z,
                    'to_min_x': constraint.to_min_x,
                    'to_max_x': constraint.to_max_x,
                    'to_min_y': constraint.to_min_y,
                    'to_max_y': constraint.to_max_y,
                    'to_min_z': constraint.to_min_z,
                    'to_max_z': constraint.to_max_z,
                    'use_motion_extrapolate': constraint.use_motion_extrapolate,
                    'mix_mode': constraint.mix_mode
                })
            elif constraint.type == 'LIMIT_LOCATION':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_ROTATION':
                constraint_data.update({
                    'use_limit_x': constraint.use_limit_x,
                    'use_limit_y': constraint.use_limit_y,
                    'use_limit_z': constraint.use_limit_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'LIMIT_SCALE':
                constraint_data.update({
                    'use_min_x': constraint.use_min_x,
                    'use_min_y': constraint.use_min_y,
                    'use_min_z': constraint.use_min_z,
                    'use_max_x': constraint.use_max_x,
                    'use_max_y': constraint.use_max_y,
                    'use_max_z': constraint.use_max_z,
                    'min_x': constraint.min_x,
                    'min_y': constraint.min_y,
                    'min_z': constraint.min_z,
                    'max_x': constraint.max_x,
                    'max_y': constraint.max_y,
                    'max_z': constraint.max_z
                })
            elif constraint.type == 'ACTION':
                constraint_data.update({
                    'action': constraint.action.name if constraint.action else None,
                    'frame_start': constraint.frame_start,
                    'frame_end': constraint.frame_end,
                    'mix_mode': constraint.mix_mode,
                    'eval_time': constraint.eval_time
                })
            elif constraint.type == 'FOLLOW_PATH':
                constraint_data.update({
                    'forward_axis': constraint.forward_axis,
                    'up_axis': constraint.up_axis,
                    'follow_curve': constraint.follow_curve,
                    'radius': constraint.radius,
                    'use_fixed_location': constraint.use_fixed_location,
                    'offset_factor': constraint.offset_factor
                })
            elif constraint.type == 'PIVOT':
                constraint_data.update({
                    'rotation_range': constraint.rotation_range,
                    'use_relative_location': constraint.use_relative_location
                })
            elif constraint.type == 'SHRINKWRAP':
                constraint_data.update({
                    'wrap_method': constraint.wrap_method,
                    'wrap_mode': constraint.wrap_mode,
                    'distance': constraint.distance,
                    'use_project_z': constraint.use_project_z
                })
            elif constraint.type == 'CLAMP_TO':
                constraint_data.update({
                    'main_axis': constraint.main_axis,
                    'flag': constraint.flag,
                    'use_cyclic': constraint.use_cyclic,
                    'influence_scale': constraint.influence_scale
                })
            elif constraint.type == 'FLOOR':
                constraint_data.update({
                    'floor_location': constraint.floor_location,
                    'offset': constraint.offset,
                    'use_rotation': constraint.use_rotation,
                    'use_sticky': constraint.use_sticky
                })
            elif constraint.type == 'RIGID_BODY_JOINT':
                constraint_data.update({
                    'pivot_type': constraint.pivot_type,
                    'use_linked_collision': constraint.use_linked_collision,
                    'use_breaking': constraint.use_breaking,
                    'breaking_threshold': constraint.breaking_threshold
                })
            elif constraint.type == 'CAMERA_SOLVER':
                constraint_data.update({
                    'use_active_clip': constraint.use_active_clip
                })
            elif constraint.type == 'OBJECT_SOLVER':
                constraint_data.update({
                    'use_active_clip': constraint.use_active_clip
                })
            elif constraint.type == 'ARMATURE':
                constraint_data.update({
                    'use_deform_preserve_volume': constraint.use_deform_preserve_volume
                })
            
            constraints_data.append(constraint_data)
        
        return constraints_data

    def _get_export_objects(self, context):
        """Get all objects to export including children if enabled"""
        objects = set(context.selected_objects)
        
        if self.include_children:
            for obj in list(objects):  # Iterate over a copy
                objects.update(self._get_all_children(obj))
        
        # Filter only valid types
        return [obj for obj in objects if obj.type in {'ARMATURE', 'MESH', 'EMPTY'}]

    def _get_all_children(self, obj):
        """Recursively get all children of an object (backward compatible)"""
        children = []
        if not hasattr(obj, 'children'):
            return children
            
        for child in obj.children:
            children.append(child)
            children.extend(self._get_all_children(child))
        return children

    def _export_armature(self, context, armature):
        """Export armature with bone hierarchy"""
        if not armature or armature.type != 'ARMATURE':
            return None

        armature_data = {
            'name': armature.name,
            'original_name': armature.name,
            'bones': [],
            'matrix_world': self._round_matrix(armature.matrix_world)
        }

        # Store current mode
        prev_mode = context.object.mode if context.object else 'OBJECT'
        prev_active = context.view_layer.objects.active
        
        try:
            # Enter edit mode to access bone data
            context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='EDIT')
            
            # Export bone data
            for bone in armature.data.edit_bones:
                bone_data = {
                    'name': bone.name,
                    'head': self._round_vector(bone.head),
                    'tail': self._round_vector(bone.tail),
                    'roll': round(bone.roll, self.precision),
                    'parent': bone.parent.name if bone.parent else None,
                    'use_connect': bone.use_connect,
                    'matrix': self._round_matrix(bone.matrix)
                }
                armature_data['bones'].append(bone_data)
                
        except Exception as e:
            self.report({'WARNING'}, f"Armature export partially failed: {str(e)}")
        finally:
            # Restore previous mode
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')
            context.view_layer.objects.active = prev_active

        return armature_data

    def _export_mesh(self, mesh_obj, armature):
        """Export mesh data with weights and parenting"""
        if not mesh_obj or mesh_obj.type != 'MESH':
            return None

        mesh_data = None
        try:
            # Get evaluated mesh (with modifiers applied)
            depsgraph = bpy.context.evaluated_depsgraph_get()
            eval_obj = mesh_obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh()

            mesh_data = {
                'name': mesh_obj.name,
                'original_name': mesh_obj.name,
                'vertices': [self._round_vector(v.co) for v in mesh.vertices],
                'polygons': [list(p.vertices) for p in mesh.polygons],
                'matrix_world': self._round_matrix(mesh_obj.matrix_world),
                'smooth_shading': any(p.use_smooth for p in mesh.polygons)
            }

            # Export vertex weights if enabled and exists
            if self.export_weights and mesh_obj.vertex_groups:
                weight_data = []
                for vert in mesh.vertices:
                    vert_weights = {}
                    for group in vert.groups:
                        if group.weight > 0.0001:  # Skip negligible weights
                            group_name = mesh_obj.vertex_groups[group.group].name
                            vert_weights[group_name] = round(group.weight, self.precision)
                    
                    if vert_weights:
                        weight_data.append({
                            'vertex_index': vert.index,
                            'weights': vert_weights
                        })
                
                if weight_data:
                    mesh_data['vertex_weights'] = weight_data

            # Export materials if enabled
            if self.export_materials and mesh.materials:
                mesh_data['materials'] = [mat.name for mat in mesh.materials]
                mesh_data['material_indices'] = [p.material_index for p in mesh.polygons]

            # Export parenting information
            if mesh_obj.parent:
                mesh_data['parent'] = mesh_obj.parent.name
                
                if mesh_obj.parent_type == 'BONE' and mesh_obj.parent_bone:
                    mesh_data['parent_type'] = 'BONE'
                    mesh_data['parent_bone'] = mesh_obj.parent_bone
                    mesh_data['matrix_parent_inverse'] = self._round_matrix(mesh_obj.matrix_parent_inverse)

        except Exception as e:
            self.report({'WARNING'}, f"Mesh export failed for {mesh_obj.name}: {str(e)}")
        finally:
            if 'eval_obj' in locals() and 'mesh' in locals():
                eval_obj.to_mesh_clear()

        return mesh_data

    def _export_empty(self, empty_obj, armature):
        """Export empty object data"""
        if not empty_obj or empty_obj.type != 'EMPTY':
            return None

        empty_data = {
            'name': empty_obj.name,
            'original_name': empty_obj.name,
            'type': empty_obj.empty_display_type,
            'size': empty_obj.empty_display_size,
            'matrix_world': self._round_matrix(empty_obj.matrix_world)
        }

        # Export parenting
        if empty_obj.parent:
            empty_data['parent'] = empty_obj.parent.name
            
            if empty_obj.parent_type == 'BONE' and empty_obj.parent_bone:
                empty_data['parent_type'] = 'BONE'
                empty_data['parent_bone'] = empty_obj.parent_bone
                empty_data['matrix_parent_inverse'] = self._round_matrix(empty_obj.matrix_parent_inverse)

        return empty_data

    def _round_vector(self, vector):
        """Round vector components to specified precision"""
        if vector is None:
            return [0, 0, 0]
        return [round(x, self.precision) for x in vector]
    
    def _round_matrix(self, matrix):
        """Round matrix components to specified precision"""
        if matrix is None:
            return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
        return [round(x, self.precision) for row in matrix for x in row]

    class BlenderJSONEncoder(json.JSONEncoder):
        """Custom JSON encoder for Blender types"""
        def default(self, obj):
            if isinstance(obj, (Vector, Matrix)):
                return list(obj)
            elif hasattr(obj, 'to_list'):
                return obj.to_list()
            elif hasattr(obj, '__dict__'):
                return obj.__dict__
            return str(obj)    