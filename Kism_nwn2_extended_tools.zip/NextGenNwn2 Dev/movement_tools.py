import bpy
import mathutils
from mathutils import Vector

class NWN2MovementProperties(bpy.types.PropertyGroup):
    """Properties for NWN2 movement system"""
    
    # Movement type switch
    movement_type: bpy.props.EnumProperty(
        name="Movement Type",
        description="Type of movement for the empty",
        items=[
            ('WALK', "Walk", "Use walk speed (2.2 m/s)"),
            ('RUN', "Run", "Use run speed (based on MOVERATE)"),
        ],
        default='RUN'
    )
    
    # Direct NWN2 parameter inputs
    moverate: bpy.props.FloatProperty(
        name="MOVERATE",
        description="Movement speed in m/s",
        default=4.5,
        min=0.1,
        max=20.0
    )
    
    walkdist: bpy.props.FloatProperty(
        name="WALKDIST",
        description="Distance to switch from run to walk (meters)",
        default=1.6,
        min=0.1,
        max=10.0
    )
    
    rundist: bpy.props.FloatProperty(
        name="RUNDIST", 
        description="Distance to switch from walk to run (meters)",
        default=3.2,
        min=0.1,
        max=10.0
    )
    
    perspace: bpy.props.FloatProperty(
        name="PERSPACE",
        description="Personal space radius (meters)",
        default=0.3,
        min=0.1,
        max=5.0
    )
    
    animation_length: bpy.props.IntProperty(
        name="Animation Frames",
        description="Length of animation in frames",
        default=24,
        min=1,
        max=240
    )
    
    path_multiplier: bpy.props.FloatProperty(
        name="Path Multiplier",
        description="Multiply the movement path length",
        default=1.0,
        min=0.1,
        max=10.0
    )
    
    show_calculations: bpy.props.BoolProperty(
        name="Show Calculations",
        description="Display detailed NWN2 movement calculations",
        default=True
    )
    
    # Path settings
    path_resolution: bpy.props.IntProperty(
        name="Path Resolution",
        description="Number of control points per cycle",
        default=4,
        min=2,
        max=20
    )
    
    auto_smooth_path: bpy.props.BoolProperty(
        name="Auto Smooth Path",
        description="Automatically smooth the path curves",
        default=True
    )
    
    # Custom preset properties
    custom_preset_name: bpy.props.StringProperty(
        name="Preset Name",
        description="Name for your custom preset",
        default="My Preset"
    )

class NWN2_OT_CreateMovement(bpy.types.Operator):
    """Create NWN2 movement animation with editable path"""
    bl_idname = "nwn2.create_movement"
    bl_label = "Create NWN2 Movement"
    bl_description = "Create a new NWN2 movement animation with custom name and cycles"
    bl_options = {'REGISTER', 'UNDO'}
    
    empty_name: bpy.props.StringProperty(
        name="Empty Name",
        description="Name for the movement empty",
        default="NWN2_Movement"
    )
    
    cycle_count: bpy.props.IntProperty(
        name="Number of Cycles",
        description="Number of animation cycles to create",
        default=1,
        min=1,
        max=100
    )
    
    def invoke(self, context, event):
        # Show popup dialog for name and cycle count
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "empty_name")
        layout.prop(self, "cycle_count")
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        # Use direct input values
        run_speed = nwn2_props.moverate
        walk_speed = 2.2  # Standard NWN2 walk speed
        frames_per_cycle = nwn2_props.animation_length
        cycle_count = self.cycle_count
        path_resolution = nwn2_props.path_resolution
        
        # Choose speed based on movement type
        if nwn2_props.movement_type == 'WALK':
            speed = walk_speed
            speed_type = "Walk"
        else:
            speed = run_speed
            speed_type = "Run"
        
        # Calculate distance for ONE cycle with multiplier
        base_distance = speed * (frames_per_cycle / 24.0)
        distance_per_cycle = base_distance * nwn2_props.path_multiplier
        
        # Clear existing NWN2 empties
        for obj in bpy.data.objects:
            if obj.name.startswith("NWN2_Movement"):
                bpy.data.objects.remove(obj, do_unlink=True)
        
        # Create curve for the movement path - STRAIGHT ALONG Y AXIS starting at 0
        curve_data = bpy.data.curves.new(name=f"{self.empty_name}_Path", type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.resolution_u = 2
        
        # Create BEZIER spline for proper Follow Path constraint
        spline = curve_data.splines.new('BEZIER')
        spline.bezier_points.add(path_resolution - 1)  # Add points for resolution
        
        # Calculate points along STRAIGHT Y axis starting at 0
        for i in range(path_resolution):
            point = spline.bezier_points[i]
            # STRAIGHT line along Y axis, X=0, Z=0
            y_pos = (i / (path_resolution - 1)) * distance_per_cycle * cycle_count
            
            # Set point coordinates - STRAIGHT line at X=0, Z=0
            point.co = Vector((0, y_pos, 0))
            
            # Make handles straight for linear movement
            point.handle_left_type = 'VECTOR'
            point.handle_right_type = 'VECTOR'
            point.handle_left = Vector((0, y_pos, 0))
            point.handle_right = Vector((0, y_pos, 0))
        
        # Create curve object at origin
        curve_obj = bpy.data.objects.new(f"{self.empty_name}_Path", curve_data)
        curve_obj.location = (0, 0, 0)
        context.collection.objects.link(curve_obj)
        
        # Create new empty at start of path (0,0,0)
        bpy.ops.object.empty_add(type='SINGLE_ARROW', location=(0, 0, 0))
        empty = context.active_object
        empty.name = self.empty_name
        
        # Set rotation to point forward along Y axis
        empty.rotation_euler = (0, 0, 0)
        
        # Clear any existing animation data
        if empty.animation_data:
            empty.animation_data_clear()
        
        # Create animation data
        if not empty.animation_data:
            empty.animation_data_create()
        
        # Add follow path constraint with proper settings
        follow_constraint = empty.constraints.new(type='FOLLOW_PATH')
        follow_constraint.target = curve_obj
        follow_constraint.forward_axis = 'FORWARD_Y'
        follow_constraint.up_axis = 'UP_Z'
        follow_constraint.use_curve_follow = True
        
        # Calculate total path length and animation timing
        total_distance = distance_per_cycle * cycle_count
        total_frames = frames_per_cycle * cycle_count
        
        # CRITICAL: Enable path animation and set up evaluation time animation
        curve_data.use_path = True
        curve_data.path_duration = total_frames
        
        # CRITICAL: Create animation data for the curve
        if not curve_data.animation_data:
            curve_data.animation_data_create()
        
        # Create animation action for the curve
        curve_action = bpy.data.actions.new(name=f"{self.empty_name}_Path_Action")
        curve_data.animation_data.action = curve_action
        
        # CRITICAL: Animate the curve's evaluation time from 0 to total_frames
        # This is what makes the Follow Path constraint work
        for i in range(cycle_count + 1):
            frame = (i * frames_per_cycle) + 1
            eval_time = i * frames_per_cycle  # Evaluation time in frames
            
            # Set evaluation time and keyframe it
            curve_data.eval_time = eval_time
            curve_data.keyframe_insert(data_path="eval_time", frame=frame)
        
        # Set linear interpolation for constant speed
        if curve_data.animation_data and curve_data.animation_data.action:
            for fcurve in curve_data.animation_data.action.fcurves:
                if 'eval_time' in fcurve.data_path:
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = 'LINEAR'
        
        # Set scene frame range to show the entire animation
        if cycle_count > 0:
            scene.frame_start = 1
            scene.frame_end = int(total_frames)
            scene.frame_current = 1
        
        # Report with detailed info
        actual_speed = total_distance / (total_frames / 24.0)  # m/s
        self.report({'INFO'}, f"Created {speed_type} movement '{self.empty_name}': {cycle_count} cycles, {total_distance:.1f}m total, {total_frames} frames, speed: {speed} m/s")
        return {'FINISHED'}

class NWN2_OT_ExtendPath(bpy.types.Operator):
    """Extend existing movement path with more cycles"""
    bl_idname = "nwn2.extend_path"
    bl_label = "Extend Movement Path"
    bl_description = "Add more cycles to an existing movement path"
    bl_options = {'REGISTER', 'UNDO'}
    
    additional_cycles: bpy.props.IntProperty(
        name="Additional Cycles",
        description="Number of cycles to add",
        default=1,
        min=1,
        max=50
    )
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        # Find movement empty and its path
        movement_empty = None
        path_curve = None
        
        for obj in context.selected_objects:
            if obj.name.startswith("NWN2_Movement") and not obj.name.endswith("_Path"):
                movement_empty = obj
                # Find associated path
                for constraint in obj.constraints:
                    if constraint.type == 'FOLLOW_PATH' and constraint.target:
                        path_curve = constraint.target
                        break
                break
        
        if not movement_empty or not path_curve:
            self.report({'ERROR'}, "Select a NWN2 movement empty with path constraint")
            return {'CANCELLED'}
        
        # Get current animation data from curve
        curve_data = path_curve.data
        if not curve_data.animation_data or not curve_data.animation_data.action:
            self.report({'ERROR'}, "No animation data found on path curve")
            return {'CANCELLED'}
        
        # Get current cycle information from curve animation
        fcurves = curve_data.animation_data.action.fcurves
        eval_fcurves = [fc for fc in fcurves if 'eval_time' in fc.data_path]
        
        if not eval_fcurves:
            self.report({'ERROR'}, "No evaluation time animation found")
            return {'CANCELLED'}
        
        # Find current cycle count and frame length
        keyframe_points = eval_fcurves[0].keyframe_points
        if len(keyframe_points) < 2:
            self.report({'ERROR'}, "Invalid animation data")
            return {'CANCELLED'}
        
        # Calculate current cycles from the animation
        last_keyframe = keyframe_points[-1]
        last_frame = last_keyframe.co[0]
        frames_per_cycle = int(keyframe_points[1].co[0] - keyframe_points[0].co[0])
        current_cycles = int(last_frame / frames_per_cycle)
        
        # Extend the path curve
        spline = curve_data.splines[0]
        
        # Calculate extension parameters
        run_speed = nwn2_props.moverate
        walk_speed = 2.2
        speed = run_speed if nwn2_props.movement_type == 'RUN' else walk_speed
        base_distance = speed * (frames_per_cycle / 24.0)
        distance_per_cycle = base_distance * nwn2_props.path_multiplier
        
        # Get last point position and total current distance
        last_point = spline.bezier_points[-1]
        current_total_distance = last_point.co.y
        
        # FIXED: Calculate total new points needed
        total_new_points = self.additional_cycles * nwn2_props.path_resolution
        
        # Store current point count for reference
        current_point_count = len(spline.bezier_points)
        
        # Add points for additional cycles - STRAIGHT along Y axis
        for i in range(total_new_points):
            # Calculate which cycle and point we're on
            cycle_num = (i // nwn2_props.path_resolution)
            point_in_cycle = (i % nwn2_props.path_resolution)
            
            # Calculate position - STRAIGHT along Y axis
            # Add to the existing distance
            y_offset = ((cycle_num * nwn2_props.path_resolution + point_in_cycle) / nwn2_props.path_resolution) * distance_per_cycle
            y_pos = current_total_distance + y_offset
            
            # Add new point
            spline.bezier_points.add(1)
            point_index = current_point_count + i
            point = spline.bezier_points[point_index]
            
            # Set point position - STRAIGHT line at X=0, Z=0
            point.co = Vector((0, y_pos, 0))
            
            # Make handles straight for linear movement
            point.handle_left_type = 'VECTOR'
            point.handle_right_type = 'VECTOR'
            point.handle_left = Vector((0, y_pos, 0))
            point.handle_right = Vector((0, y_pos, 0))
        
        # Calculate new total values
        total_cycles = current_cycles + self.additional_cycles
        total_frames = total_cycles * frames_per_cycle
        
        # Update path duration
        curve_data.path_duration = int(total_frames)
        
        # Add animation for additional cycles
        for cycle in range(1, self.additional_cycles + 1):
            cycle_num = current_cycles + cycle
            frame = (cycle_num * frames_per_cycle) + 1
            eval_time = cycle_num * frames_per_cycle
            
            curve_data.eval_time = eval_time
            curve_data.keyframe_insert(data_path="eval_time", frame=frame)
        
        # Update scene frame range
        scene.frame_end = int(total_frames)
        
        # Set linear interpolation for new keyframes
        if curve_data.animation_data and curve_data.animation_data.action:
            for fcurve in curve_data.animation_data.action.fcurves:
                if 'eval_time' in fcurve.data_path:
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = 'LINEAR'
        
        # Calculate total distance for reporting
        total_distance = current_total_distance + (self.additional_cycles * distance_per_cycle)
        actual_speed = total_distance / (total_frames / 24.0)
        
        self.report({'INFO'}, f"Extended path by {self.additional_cycles} cycles, total: {total_cycles} cycles, {total_distance:.1f}m total, speed: {actual_speed:.1f} m/s")
        return {'FINISHED'}

class NWN2_OT_LoadPreset(bpy.types.Operator):
    """Load NWN2 race presets"""
    bl_idname = "nwn2.load_preset"
    bl_label = "Load Preset"
    bl_description = "Load predefined NWN2 movement presets"
    bl_options = {'REGISTER', 'UNDO'}


    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('HUMAN', "Human", "Human movement parameters"),
            ('DWARF', "Dwarf", "Dwarf movement parameters"), 
            ('HORSE', "Horse", "Horse movement parameters"),
        ]
    )
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        presets = {
            'HUMAN': {
                'moverate': 4.5,
                'walkdist': 1.6,
                'rundist': 3.2,
                'perspace': 0.3
            },
            'DWARF': {
                'moverate': 4.5, 
                'walkdist': 1.06,
                'rundist': 2.12,
                'perspace': 0.3
            },
            'HORSE': {
                'moverate': 6.5,
                'walkdist': 1.8,
                'rundist': 2.4, 
                'perspace': 0.8
            }
        }
        
        preset_data = presets[self.preset]
        nwn2_props.moverate = preset_data['moverate']
        nwn2_props.walkdist = preset_data['walkdist'] 
        nwn2_props.rundist = preset_data['rundist']
        nwn2_props.perspace = preset_data['perspace']
        
        self.report({'INFO'}, f"Loaded {self.preset} preset")
        return {'FINISHED'}

class NWN2_OT_SaveCustomPreset(bpy.types.Operator):
    """Save current settings as a custom preset"""
    bl_idname = "nwn2.save_custom_preset"
    bl_label = "Save Custom Preset"
    bl_description = "Save current movement settings as a custom preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        # Get or create the custom presets dictionary
        if not hasattr(scene, 'nwn2_custom_presets'):
            scene.nwn2_custom_presets = {}
        
        # Save current settings
        preset_name = nwn2_props.custom_preset_name
        scene.nwn2_custom_presets[preset_name] = {
            'moverate': nwn2_props.moverate,
            'walkdist': nwn2_props.walkdist,
            'rundist': nwn2_props.rundist,
            'perspace': nwn2_props.perspace
        }
        
        self.report({'INFO'}, f"Saved custom preset: {preset_name}")
        return {'FINISHED'}

class NWN2_OT_LoadCustomPreset(bpy.types.Operator):
    """Load a custom preset"""
    bl_idname = "nwn2.load_custom_preset"
    bl_label = "Load Custom Preset"
    bl_description = "Load a custom movement preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_name: bpy.props.StringProperty(name="Preset Name")
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        if hasattr(scene, 'nwn2_custom_presets') and self.preset_name in scene.nwn2_custom_presets:
            preset_data = scene.nwn2_custom_presets[self.preset_name]
            nwn2_props.moverate = preset_data['moverate']
            nwn2_props.walkdist = preset_data['walkdist']
            nwn2_props.rundist = preset_data['rundist']
            nwn2_props.perspace = preset_data['perspace']
            
            self.report({'INFO'}, f"Loaded custom preset: {self.preset_name}")
        else:
            self.report({'WARNING'}, f"Preset '{self.preset_name}' not found")
        
        return {'FINISHED'}

class NWN2_OT_DeleteCustomPreset(bpy.types.Operator):
    """Delete a custom preset"""
    bl_idname = "nwn2.delete_custom_preset"
    bl_label = "Delete Custom Preset"
    bl_description = "Delete a custom movement preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    preset_name: bpy.props.StringProperty(name="Preset Name")
    
    def execute(self, context):
        scene = context.scene
        
        if hasattr(scene, 'nwn2_custom_presets') and self.preset_name in scene.nwn2_custom_presets:
            del scene.nwn2_custom_presets[self.preset_name]
            self.report({'INFO'}, f"Deleted custom preset: {self.preset_name}")
        else:
            self.report({'WARNING'}, f"Preset '{self.preset_name}' not found")
        
        return {'FINISHED'}

class NWN2_OT_ClearMovement(bpy.types.Operator):
    """Clear all NWN2 movement animations"""
    bl_idname = "nwn2.clear_movement"
    bl_label = "Clear NWN2 Movement"
    bl_description = "Clear all NWN2 movement animations and objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Find and remove NWN2 movement objects
        removed_count = 0
        for obj in bpy.data.objects:
            if obj.name.startswith("NWN2_Movement"):
                bpy.data.objects.remove(obj, do_unlink=True)
                removed_count += 1
        
        self.report({'INFO'}, f"Removed {removed_count} movement objects")
        return {'FINISHED'}

class NWN2_OT_DuplicateKeyframes(bpy.types.Operator):
    """Duplicate movement keyframes to create cycles"""
    bl_idname = "nwn2.duplicate_keyframes"
    bl_label = "Duplicate Keyframes"
    bl_description = "Duplicate existing keyframes to create additional cycles"
    bl_options = {'REGISTER', 'UNDO'}
    
    duplicate_count: bpy.props.IntProperty(
        name="Duplicate Count",
        description="Number of times to duplicate the keyframes",
        default=1,
        min=1,
        max=10
    )
    
    def execute(self, context):
        scene = context.scene
        nwn2_props = scene.nwn2_movement_props
        
        # Find movement empty and its path
        movement_empty = None
        path_curve = None
        
        for obj in context.selected_objects:
            if obj.name.startswith("NWN2_Movement") and not obj.name.endswith("_Path"):
                movement_empty = obj
                # Find associated path
                for constraint in obj.constraints:
                    if constraint.type == 'FOLLOW_PATH' and constraint.target:
                        path_curve = constraint.target
                        break
                break
        
        if not movement_empty or not path_curve:
            self.report({'ERROR'}, "Select a NWN2 movement empty with path constraint")
            return {'CANCELLED'}
        
        # Get animation data from curve
        curve_data = path_curve.data
        if not curve_data.animation_data or not curve_data.animation_data.action:
            self.report({'ERROR'}, "No animation data found on path curve")
            return {'CANCELLED'}
        
        # Get original keyframes from curve animation
        fcurves = curve_data.animation_data.action.fcurves
        eval_fcurves = [fc for fc in fcurves if 'eval_time' in fc.data_path]
        
        if not eval_fcurves:
            self.report({'ERROR'}, "No evaluation time animation found")
            return {'CANCELLED'}
        
        original_keyframes = []
        for keyframe in eval_fcurves[0].keyframe_points:
            original_keyframes.append((keyframe.co[0], keyframe.co[1]))
        
        if len(original_keyframes) < 2:
            self.report({'ERROR'}, "Not enough keyframes to duplicate")
            return {'CANCELLED'}
        
        # Calculate cycle length and offset
        frame_start = original_keyframes[0][0]
        frame_end = original_keyframes[-1][0]
        cycle_length = frame_end - frame_start
        value_offset = original_keyframes[-1][1] - original_keyframes[0][1]
        
        # FIXED: Also extend the physical path geometry
        spline = curve_data.splines[0]
        current_point_count = len(spline.bezier_points)
        last_point = spline.bezier_points[-1]
        current_distance = last_point.co.y
        
        # Calculate distance per cycle for path extension
        run_speed = nwn2_props.moverate
        walk_speed = 2.2
        speed = run_speed if nwn2_props.movement_type == 'RUN' else walk_speed
        base_distance = speed * (cycle_length / 24.0)
        distance_per_cycle = base_distance * nwn2_props.path_multiplier
        
        # Extend the path geometry for each duplicate cycle
        for cycle in range(1, self.duplicate_count + 1):
            # Add new points for this cycle
            for i in range(nwn2_props.path_resolution):
                # Skip the first point of each cycle (it's the same as last point of previous cycle)
                if i == 0 and cycle > 1:
                    continue
                    
                # Calculate new position
                y_pos = current_distance + (cycle * distance_per_cycle * (i / nwn2_props.path_resolution))
                
                # Add new point
                spline.bezier_points.add(1)
                point_index = len(spline.bezier_points) - 1
                point = spline.bezier_points[point_index]
                
                point.co = Vector((0, y_pos, 0))
                point.handle_left_type = 'VECTOR'
                point.handle_right_type = 'VECTOR'
                point.handle_left = Vector((0, y_pos, 0))
                point.handle_right = Vector((0, y_pos, 0))
        
        # Duplicate keyframes
        for i in range(1, self.duplicate_count + 1):
            frame_offset = i * cycle_length
            value_increment = i * value_offset
            
            for frame, value in original_keyframes:
                if frame == frame_start and i > 0:
                    continue  # Skip first frame of duplicates (already exists)
                
                new_frame = frame + frame_offset
                new_value = value + value_increment
                
                curve_data.eval_time = new_value
                curve_data.keyframe_insert(data_path="eval_time", frame=new_frame)
        
        # Update scene frame range
        new_frame_end = int(frame_end + (self.duplicate_count * cycle_length))
        scene.frame_end = new_frame_end
        
        # Update path duration
        curve_data.path_duration = new_frame_end
        
        # Set linear interpolation for new keyframes
        if curve_data.animation_data and curve_data.animation_data.action:
            for fcurve in curve_data.animation_data.action.fcurves:
                if 'eval_time' in fcurve.data_path:
                    for keyframe in fcurve.keyframe_points:
                        keyframe.interpolation = 'LINEAR'
        
        self.report({'INFO'}, f"Duplicated {self.duplicate_count} times, extended to {scene.frame_end} frames")
        return {'FINISHED'}

# Registration
movement_classes = (
    NWN2MovementProperties,
    NWN2_OT_CreateMovement,
    NWN2_OT_ExtendPath,
    NWN2_OT_LoadPreset,
    NWN2_OT_SaveCustomPreset,
    NWN2_OT_LoadCustomPreset,
    NWN2_OT_DeleteCustomPreset,
    NWN2_OT_ClearMovement,
    NWN2_OT_DuplicateKeyframes,
)

def register_movement_system():
    for cls in movement_classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.nwn2_movement_props = bpy.props.PointerProperty(type=NWN2MovementProperties)
    
    # Initialize custom presets storage if it doesn't exist
    if not hasattr(bpy.types.Scene, 'nwn2_custom_presets'):
        bpy.types.Scene.nwn2_custom_presets = {}

def unregister_movement_system():
    for cls in movement_classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.nwn2_movement_props
    
    # Clean up custom presets storage
    if hasattr(bpy.types.Scene, 'nwn2_custom_presets'):
        del bpy.types.Scene.nwn2_custom_presets

if __name__ == "__main__":
    register_movement_system()