bl_info = {
    "name": "NWN2 Extended Blender Tools",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (4, 3, 2),
    "location": "View3D > UI > NWN2 Tools",
    "description": "Neverwinter Nights 2 modeling and export tools",
    "category": "3D View",
}

import bpy
import traceback

class NWN2ModuleManager:
    """Manages module registration with dependency tracking and error handling."""
    
    def __init__(self):
        # Define modules with their registration functions and dependencies
        self.modules = {
            'model_tools': {
                'func': 'register', 
                'deps': [],
                'description': 'Basic NWN2 model tools'
            },
            'material_tools': {
                'func': 'register', 
                'deps': [],
                'description': 'Material and texture tools'
            },
            'animation_tools': {
                'func': 'register', 
                'deps': ['model_tools'],
                'description': 'Animation tools for NWN2'
            },
            'retargeting_tools': {
                'func': 'register', 
                'deps': ['animation_tools'],
                'description': 'Animation retargeting tools'
            },
            'terrain_tools': {
                'func': 'register_map_system', 
                'deps': [],
                'description': 'Terrain and map creation tools'
            },
            'movement_tools': {
                'func': 'register_movement_system', 
                'deps': [],
                'description': 'Movement system tools'
            },
            'json_tools': {
                'func': 'register', 
                'deps': [],
                'description': 'JSON import/export tools'
            },
            'equipment_tools': {
                'func': 'register', 
                'deps': ['model_tools'],
                'description': 'Equipment and attachment tools'
            },
            'twoda_tools': {
                'func': 'register', 
                'deps': ['json_tools'],
                'description': '2DA file utilities'
            },
            'reverse_movement_tools': {
                'func': 'register', 
                'deps': ['movement_tools'],
                'description': 'Reverse movement calculation tools'
            },
            # NEW MODULES ADDED HERE
            'terrain_tools': {
                'func': 'register_map_system', 
                'deps': [],
                'description': 'Terrain and map creation tools'
            },
            'merge_texture_tools': {
                'func': 'register', 
                'deps': [],
                'description': 'Texture merging and optimization tools'
            },
            'retopology_tools': {
                'func': 'register', 
                'deps': [],
                'description': 'Mesh optimization and retopology tools'
            },
            # END NEW MODULES
            'panel': {
                'func': 'register', 
                'deps': [],
                'description': 'UI panel'
            }
        }
        self.registered_modules = []
        self.failed_modules = []
        
    def _safe_import_and_register(self, module_name, register_func):
        """Safely import and register a module with detailed error reporting."""
        try:
            # Import the module
            full_module_name = f"{__name__}.{module_name}"
            module = __import__(full_module_name, fromlist=[register_func])
            
            # Check if module has the required function
            if not hasattr(module, register_func):
                return False, f"Function '{register_func}' not found in module"
            
            # Execute the registration function
            getattr(module, register_func)()
            return True, "Registration successful"
            
        except ModuleNotFoundError as e:
            # Check if it's a missing dependency
            error_str = str(e)
            if "No module named" in error_str:
                try:
                    missing_module = error_str.split("'")[1]
                    return False, f"Missing module: {missing_module}"
                except:
                    return False, f"Module not found: {error_str}"
            return False, f"Module not found: {error_str}"
            
        except ImportError as e:
            return False, f"Import error: {str(e)}"
            
        except Exception as e:
            error_msg = str(e)
            # Get a clean traceback for debugging
            tb = traceback.format_exc()
            # Limit traceback size for cleaner output
            if "Traceback" in tb:
                lines = tb.split('\n')
                # Show first few lines of traceback
                short_tb = '\n'.join(lines[:8])
                return False, f"{error_msg}\n{short_tb}"
            return False, error_msg
    
    def _register_module(self, module_name, depth=0):
        """Register a single module and its dependencies (recursive)."""
        # Prevent circular dependencies
        if depth > 10:
            return False, "Dependency depth exceeded (circular dependency suspected)"
        
        # Check if already registered
        if module_name in self.registered_modules:
            return True, "Already registered"
        
        # Check if module exists in our definition
        if module_name not in self.modules:
            return False, f"Module '{module_name}' not defined"
        
        module_info = self.modules[module_name]
        indent = "  " * depth
        
        # Register dependencies first
        for dep in module_info['deps']:
            if dep not in self.registered_modules:
                success, msg = self._register_module(dep, depth + 1)
                if not success:
                    return False, f"Dependency '{dep}' failed: {msg}"
        
        # Register the module itself
        print(f"{indent}📦 Registering {module_name}...")
        success, message = self._safe_import_and_register(module_name, module_info['func'])
        
        if success:
            self.registered_modules.append(module_name)
            print(f"{indent}  ✓ {module_info['description']}")
            return True, "Registration successful"
        else:
            self.failed_modules.append((module_name, message))
            print(f"{indent}  ✗ Failed: {message}")
            return False, message
    
    def register_all(self):
        """Register all modules with dependency resolution."""
        print("=" * 60)
        print("NWN2 Extended Blender Tools - Module Registration")
        print("=" * 60)
        
        self.registered_modules = []
        self.failed_modules = []
        
        # Try to register all modules
        for module_name in self.modules.keys():
            if module_name not in self.registered_modules:
                self._register_module(module_name)
        
        # Print summary
        self._print_summary()
        
        return len(self.failed_modules) == 0
    
    def unregister_all(self):
        """Unregister all modules in reverse order."""
        print("\n" + "=" * 60)
        print("NWN2 Extended Blender Tools - Module Unregistration")
        print("=" * 60)
        
        # Unregister in reverse order including new modules
        reverse_modules = [
            ('panel', 'unregister'),
            ('retopology_tools', 'unregister'),  # NEW
            ('merge_texture_tools', 'unregister'),  # NEW
            ('terrain_tools', 'unregister_map_system'),  # Already exists
            ('reverse_movement_tools', 'unregister'),
            ('twoda_tools', 'unregister'),
            ('equipment_tools', 'unregister'),
            ('json_tools', 'unregister'),
            ('movement_tools', 'unregister_movement_system'),
            ('terrain_tools', 'unregister_map_system'),
            ('retargeting_tools', 'unregister'),
            ('animation_tools', 'unregister'),
            ('material_tools', 'unregister'),
            ('model_tools', 'unregister'),
        ]
        
        unregistered_count = 0
        failed_unregisters = []
        
        for module_name, unregister_func in reverse_modules:
            try:
                # Only try to unregister if we have the module
                module = __import__(f"{__name__}.{module_name}", fromlist=[unregister_func])
                getattr(module, unregister_func)()
                unregistered_count += 1
                print(f"  ✓ Unregistered {module_name}")
            except ModuleNotFoundError:
                print(f"  ⚠ Module {module_name} not found (may not have been registered)")
            except AttributeError as e:
                print(f"  ⚠ Function {unregister_func} not found in {module_name}")
            except Exception as e:
                error_msg = str(e)
                failed_unregisters.append((module_name, error_msg))
                print(f"  ✗ Failed to unregister {module_name}: {error_msg}")
        
        # Print unregistration summary
        print(f"\nUnregistration Summary:")
        print(f"  Successfully unregistered: {unregistered_count}/{len(reverse_modules)}")
        if failed_unregisters:
            print(f"  Failed to unregister:")
            for module_name, error in failed_unregisters:
                print(f"    • {module_name}: {error}")
        
        print("=" * 60)
    
    def _print_summary(self):
        """Print a registration summary."""
        total_modules = len(self.modules)
        success_count = len(self.registered_modules)
        fail_count = len(self.failed_modules)
        
        print("\n" + "-" * 60)
        print("REGISTRATION SUMMARY")
        print("-" * 60)
        print(f"Total modules defined: {total_modules}")
        print(f"Successfully registered: {success_count}")
        print(f"Failed to register: {fail_count}")
        
        if success_count > 0:
            print(f"\n✅ Registered modules:")
            for module in self.registered_modules:
                desc = self.modules[module]['description']
                print(f"  • {module}: {desc}")
        
        if fail_count > 0:
            print(f"\n❌ Failed modules:")
            for module_name, error in self.failed_modules:
                desc = self.modules.get(module_name, {}).get('description', 'No description')
                print(f"  • {module_name}: {desc}")
                # Print error with indentation
                error_lines = str(error).split('\n')
                for line in error_lines[:3]:  # Show first 3 lines of error
                    if line.strip():
                        print(f"      {line}")
                if len(error_lines) > 3:
                    print(f"      ... (error truncated)")
        
        print("-" * 60)
        
        if fail_count == 0:
            print("✨ All modules registered successfully!")
        else:
            print(f"⚠ {fail_count} module(s) failed. Some features may be unavailable.")

def check_blender_version():
    """Check if Blender version is compatible."""
    import bpy
    
    # Minimum required version
    min_version = (4, 3, 0)
    current_version = bpy.app.version
    
    if current_version < min_version:
        print("❌ VERSION INCOMPATIBILITY DETECTED")
        print(f"   Required: Blender {min_version[0]}.{min_version[1]}.{min_version[2]}+")
        print(f"   Current:  Blender {current_version[0]}.{current_version[1]}.{current_version[2]}")
        print("\n   Please update Blender to use this addon.")
        return False
    
    # Optional: Check for maximum version (if needed)
    max_version = (5, 0, 0)  # Example: Not tested beyond 5.0
    if current_version >= max_version:
        print("⚠ VERSION WARNING")
        print(f"   This addon is tested up to Blender {max_version[0]}.{max_version[1]}.{max_version[2]}")
        print(f"   Current version: {current_version[0]}.{current_version[1]}.{current_version[2]}")
        print("   Some features may not work correctly.")
    
    return True

def register():
    """Register the NWN2 Extended Blender Tools addon."""
    print("\n" + "=" * 60)
    print("Initializing NWN2 Extended Blender Tools")
    print("=" * 60)
    
    # Check version compatibility
    if not check_blender_version():
        print("\nAddon registration aborted due to version incompatibility.")
        return
    
    # Create and use the module manager
    global module_manager
    module_manager = NWN2ModuleManager()
    
    # Register all modules
    success = module_manager.register_all()
    
    if success:
        print("\n✅ NWN2 Extended Blender Tools registered successfully!")
        print("   Access tools in: View3D > UI > NWN2 Tools")
    else:
        print("\n⚠ NWN2 Extended Blender Tools registered with errors.")
        print("   Some features may be unavailable.")
    
    print("=" * 60)

def unregister():
    """Unregister the NWN2 Extended Blender Tools addon."""
    # Check if module_manager exists
    if 'module_manager' in globals():
        module_manager.unregister_all()
        print("\n✅ NWN2 Extended Blender Tools unregistered successfully!")
    else:
        # Fallback to original unregister logic if module_manager doesn't exist
        print("\nUnregistering NWN2 Extended Blender Tools (fallback method)...")
        modules = [
            ('panel', 'unregister'),
            ('retopology_tools', 'unregister'),  # NEW
            ('merge_texture_tools', 'unregister'),  # NEW
            ('terrain_tools', 'unregister_map_system'),  # Already exists
            ('reverse_movement_tools', 'unregister'),
            ('twoda_tools', 'unregister'),
            ('equipment_tools', 'unregister'),
            ('json_tools', 'unregister'),
            ('movement_tools', 'unregister_movement_system'),
            ('terrain_tools', 'unregister_map_system'),
            ('retargeting_tools', 'unregister'),
            ('animation_tools', 'unregister'),
            ('material_tools', 'unregister'),
            ('model_tools', 'unregister'),
        ]
        
        for module_name, unregister_func in modules:
            try:
                module = __import__(f"{__name__}.{module_name}", fromlist=[unregister_func])
                getattr(module, unregister_func)()
                print(f"  Unregistered {module_name}")
            except Exception as e:
                print(f"  Warning: Failed to unregister {module_name}: {str(e)}")
        
        print("Unregistration complete.")
    
    print("=" * 60)

# Test function for development
def test_registration():
    """Test function to verify module registration without actually registering in Blender."""
    print("Testing module registration...")
    
    # Create a test manager
    test_manager = NWN2ModuleManager()
    
    # Test each module individually
    for module_name in test_manager.modules.keys():
        print(f"\nTesting {module_name}:")
        success, message = test_manager._register_module(module_name)
        if success:
            print(f"  ✓ Test passed")
        else:
            print(f"  ✗ Test failed: {message}")
    
    print("\nTest complete.")

# Optional: Add debug mode
DEBUG_MODE = False

if __name__ == "__main__":
    # This allows testing the registration logic from command line
    # (though it won't actually work without Blender's Python environment)
    print("NWN2 Tools module loaded in standalone mode.")
    print("To use in Blender, install as an addon.")