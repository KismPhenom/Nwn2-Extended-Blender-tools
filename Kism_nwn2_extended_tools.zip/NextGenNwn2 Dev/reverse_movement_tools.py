import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import BoolProperty, PointerProperty

class ReverseMovementProps(PropertyGroup):
    use_x: BoolProperty(name="X", default=True)
    use_y: BoolProperty(name="Y", default=True)
    use_z: BoolProperty(name="Z", default=True)
    invert_x: BoolProperty(name="Invert X", default=True)
    invert_y: BoolProperty(name="Invert Y", default=True)
    invert_z: BoolProperty(name="Invert Z", default=True)

class RM_OT_create_reverse_empty(Operator):
    bl_idname = "rm.create_reverse_empty"
    bl_label = "Create Reverse Empty"
    bl_description = "Create reverse movement empty"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        scene = context.scene
        props = scene.reverse_movement_props
        obj = context.active_object
        
        # Get root bone
        root_bone = None
        for bone in obj.data.bones:
            if not bone.parent:
                root_bone = bone
                break
        
        if not root_bone:
            self.report({'ERROR'}, "No root bone found")
            return {'CANCELLED'}
        
        # Create empty
        empty_name = f"{obj.name}_Reverse_Movement"
        
        # Delete if exists
        old_empty = bpy.data.objects.get(empty_name)
        if old_empty:
            bpy.data.objects.remove(old_empty)
        
        # Create new empty
        mesh = bpy.data.meshes.new("CircleMesh")
        bm = bmesh.new()
        bmesh.ops.create_circle(bm, segments=32, radius=0.5)
        bm.to_mesh(mesh)
        bm.free()
        
        empty_obj = bpy.data.objects.new(empty_name, mesh)
        bpy.context.collection.objects.link(empty_obj)
        empty_obj.location = (0, 0, 0)
        
        # Get animation range
        start_frame = scene.frame_start
        end_frame = scene.frame_end
        current_frame = scene.frame_current
        
        # Get initial position
        scene.frame_set(start_frame)
        bpy.context.view_layer.update()
        pose_bone = obj.pose.bones[root_bone.name]
        bone_matrix = obj.matrix_world @ pose_bone.matrix
        start_pos = bone_matrix.to_translation()
        
        # Process frames
        for frame in range(start_frame, end_frame + 1):
            scene.frame_set(frame)
            bpy.context.view_layer.update()
            
            pose_bone = obj.pose.bones[root_bone.name]
            bone_matrix = obj.matrix_world @ pose_bone.matrix
            current_pos = bone_matrix.to_translation()
            
            # Calculate movement
            movement = current_pos - start_pos
            reverse_movement = Vector((0, 0, 0))
            
            if props.use_x:
                reverse_movement.x = -movement.x if props.invert_x else movement.x
            if props.use_y:
                reverse_movement.y = -movement.y if props.invert_y else movement.y
            if props.use_z:
                reverse_movement.z = -movement.z if props.invert_z else movement.z
            
            # Keyframe empty
            empty_obj.location = reverse_movement
            empty_obj.keyframe_insert(data_path="location", frame=frame)
        
        scene.frame_set(current_frame)
        self.report({'INFO'}, "Reverse empty created!")
        return {'FINISHED'}

class RM_OT_update_reverse_empty(Operator):
    bl_idname = "rm.update_reverse_empty"
    bl_label = "Update Reverse Empty"
    bl_description = "Update reverse movement empty"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        scene = context.scene
        props = scene.reverse_movement_props
        obj = context.active_object
        
        # Get root bone
        root_bone = None
        for bone in obj.data.bones:
            if not bone.parent:
                root_bone = bone
                break
        
        if not root_bone:
            self.report({'ERROR'}, "No root bone found")
            return {'CANCELLED'}
        
        # Find empty
        empty_name = f"{obj.name}_Reverse_Movement"
        empty_obj = bpy.data.objects.get(empty_name)
        
        if not empty_obj:
            self.report({'ERROR'}, "No empty found - create one first")
            return {'CANCELLED'}
        
        # Clear existing animation
        if empty_obj.animation_data:
            empty_obj.animation_data_clear()
        empty_obj.location = (0, 0, 0)
        
        # Get animation range
        start_frame = scene.frame_start
        end_frame = scene.frame_end
        current_frame = scene.frame_current
        
        # Get initial position
        scene.frame_set(start_frame)
        bpy.context.view_layer.update()
        pose_bone = obj.pose.bones[root_bone.name]
        bone_matrix = obj.matrix_world @ pose_bone.matrix
        start_pos = bone_matrix.to_translation()
        
        # Process frames
        for frame in range(start_frame, end_frame + 1):
            scene.frame_set(frame)
            bpy.context.view_layer.update()
            
            pose_bone = obj.pose.bones[root_bone.name]
            bone_matrix = obj.matrix_world @ pose_bone.matrix
            current_pos = bone_matrix.to_translation()
            
            # Calculate movement
            movement = current_pos - start_pos
            reverse_movement = Vector((0, 0, 0))
            
            if props.use_x:
                reverse_movement.x = -movement.x if props.invert_x else movement.x
            if props.use_y:
                reverse_movement.y = -movement.y if props.invert_y else movement.y
            if props.use_z:
                reverse_movement.z = -movement.z if props.invert_z else movement.z
            
            # Keyframe empty
            empty_obj.location = reverse_movement
            empty_obj.keyframe_insert(data_path="location", frame=frame)
        
        scene.frame_set(current_frame)
        self.report({'INFO'}, "Reverse empty updated!")
        return {'FINISHED'}

class RM_OT_clear_reverse_constraint(Operator):
    bl_idname = "rm.clear_reverse_constraint"
    bl_label = "Clear Reverse Constraint"
    bl_description = "Clear reverse movement constraint"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        obj = context.active_object
        empty_name = f"{obj.name}_Reverse_Movement"
        empty_obj = bpy.data.objects.get(empty_name)
        
        if empty_obj:
            if empty_obj.animation_data:
                empty_obj.animation_data_clear()
            empty_obj.location = (0, 0, 0)
            self.report({'INFO'}, "Reverse constraint cleared!")
        else:
            self.report({'WARNING'}, "No empty found")
        
        return {'FINISHED'}

class RM_OT_delete_reverse_empty(Operator):
    bl_idname = "rm.delete_reverse_empty"
    bl_label = "Delete Empty"
    bl_description = "Delete the reverse movement empty"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        obj = context.active_object
        empty_name = f"{obj.name}_Reverse_Movement"
        empty_obj = bpy.data.objects.get(empty_name)
        
        if empty_obj:
            bpy.data.objects.remove(empty_obj)
            self.report({'INFO'}, "Reverse empty deleted!")
        else:
            self.report({'WARNING'}, "No empty found")
        
        return {'FINISHED'}

classes = (
    ReverseMovementProps,
    RM_OT_create_reverse_empty,
    RM_OT_update_reverse_empty,
    RM_OT_clear_reverse_constraint,
    RM_OT_delete_reverse_empty,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.reverse_movement_props = PointerProperty(type=ReverseMovementProps)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.reverse_movement_props