# Standard library imports
import os
import re
from typing import List, Dict, Tuple, Optional, Any, Set

# Blender imports
import bpy
from bpy.props import (
    StringProperty, BoolProperty, IntProperty, 
    EnumProperty, PointerProperty, CollectionProperty
)
from bpy.types import Panel, Operator, PropertyGroup, UIList

# ==============================================
# 2DA CONSTANTS & CONFIGURATION
# ==============================================

class TwoDAConstants:
    """Centralized constants and configurations for the 2DA Editor."""
    
    # Supported 2DA files configuration
    FILE_CONFIGS: Dict[str, Dict[str, Any]] = {
        "placeables": {
            "filename": "placeables.2DA",
            "sync_operator": "twoda.sync_placeable",
            "sync_label": "Sync Placeable",
            "sync_description": "Toggle synchronization for placeable data (matches NWN2_ModelName)",
            "defaults": {
                "Label": "****",
                "StrRef": "****",
                "PlaceableModelType": "0",
                "Fade": "1",
                "NWN2_ModelName": "****",
                "NWN2_LowGore": "****",
                "NWN2_PartsCount": "0",
                "NWN2_Skeleton": "****",
                "AttachedModelName": "****",
                "DefaultDoor": "****",
                "DefaultAccessory": "****",
                "IsAccessory": "****",
                "ModelName": "0",
                "LightColor": "RESERVED",
                "LightOffsetX": "****",
                "LightOffsetY": "****",
                "LightOffsetZ": "****",
                "SoundAppType": "****",
                "ShadowSize": "****",
                "BodyBag": "****",
                "LowGore": "****",
                "Reflection": "****",
                "InterfacePT": "****",
                "BlockLOS": "****",
                "SELECTION_SIZE": "****",
            },
            "identifier_attr": "NWN2_ModelName",
            "object_type": {'MESH'},
            "required_selection": (0, 1),
            "icon": "CUBE",
            "row_display_attr": "Label"
        },
        "appearance": {
            "filename": "appearance.2DA",
            "sync_operator": "twoda.sync_appearance",
            "sync_label": "Sync Appearance",
            "sync_description": "Toggle synchronization for appearance data (matches NWN2_Skeleton_File)",
            "defaults": {
                "LABEL": "****",
                "STRING_REF": "****",
                "BodyType": "0",
                "Segments": "0",
                "NWN2_Scale_X": "1",
                "NWN2_Scale_Y": "1",
                "NWN2_Scale_Z": "1",
                "AnimationSpeed": "0",
                "NWN2_Model_Body": "****",
                "NWN2_Model_Helm": "****",
                "NWN2_Model_Head": "****",
                "NWN2_Model_Hair": "****",
                "NWN2_Head_Skeleton": "****",
                "NWN2_Skeleton_File": "****",
                "NWN2_AccessorySize": "1",
                "NWN2_AccessoryType": "****",
                "ToolsetUseStubModel": "0",
                "Mount": "0",
                "NAME": "****",
                "RACE": "****",
                "ENVMAP": "****",
                "NWN2_BLOODTYPE": "****",
                "MODELTYPE": "****",
                "WEAPONVISUALSCALE": "1",
                "WEAPONATTACKDISTANCESCALE": "1",
                "WING_TAIL_SCALE": "****",
                "HELMET_SCALE_M": "****",
                "HELMET_SCALE_F": "****",
                "MOVERATE": "****",
                "WALKDIST": "****",
                "RUNDIST": "****",
                "PERSPACE": "****",
                "CREPERSPACE": "****",
                "HEIGHT": "****",
                "HITDIST": "****",
                "PREFATCKDIST": "****",
                "TARGETHEIGHT": "****",
                "ABORTONPARRY": "****",
                "RACIALTYPE": "****",
                "HASLEGS": "****",
                "HASARMS": "****",
                "PORTRAIT": "****",
                "SIZECATEGORY": "****",
                "PERCEPTIONDIST": "****",
                "FOOTSTEPTYPE": "****",
                "SOUNDAPPTYPE": "****",
                "HEADTRACK": "****",
                "HEAD_ARC_H": "****",
                "HEAD_ARC_V": "****",
                "HEAD_NAME": "****",
                "BODY_BAG": "****",
                "TARGETABLE": "1",
                "SELECTION_CAPSULE": "****",
                "SELECTION_SIZE": "****",
                "SEF": "****",
            },
            "identifier_attr": "NWN2_Skeleton_File",
            "object_type": {'ARMATURE'},
            "required_selection": (1, 0),
            "icon": "ARMATURE_DATA",
            "row_display_attr": "LABEL"
        },
        "wingmodel": {
            "filename": "wingmodel.2DA",
            "sync_operator": "twoda.sync_wingmodel",
            "sync_label": "Sync Wingmodel",
            "sync_description": "Sync wing model data from selected objects (2 armatures + 1 mesh)",
            "defaults": {
                "LABEL": "****",
                "StringRef": "****",
                "NWN2_ModelName": "****",
                "NWN2_Skeleton_File": "****",
                "NWN2_BaseAnims": "****",
                "MODEL": "****",
            },
            "identifier_attr": "NWN2_BaseAnims",
            "object_type": {'ARMATURE', 'MESH'},
            "required_selection": (2, 1),
            "icon": "MOD_ARMATURE",
            "row_display_attr": "LABEL"
        },
        "tailmodel": {
            "filename": "tailmodel.2DA",
            "sync_operator": "twoda.sync_tailmodel",
            "sync_label": "Sync Tailmodel",
            "sync_description": "Sync tail model data from selected objects (2 armatures + 1 mesh)",
            "defaults": {
                "LABEL": "****",
                "StringRef": "****",
                "NWN2_ModelName": "****",
                "NWN2_Skeleton_File": "****",
                "NWN2_BaseAnims": "****",
                "MODEL": "****",
            },
            "identifier_attr": "NWN2_BaseAnims",
            "object_type": {'ARMATURE', 'MESH'},
            "required_selection": (2, 1),
            "icon": "MOD_ARMATURE",
            "row_display_attr": "LABEL"
        },
        "baseitem": {
            "filename": "baseitems.2DA",
            "sync_operator": "twoda.sync_baseitem",
            "sync_label": "Sync Base Item",
            "sync_description": "Sync base item data from selected mesh objects",
            "defaults": {
                "index": "0",
                "Name": "****",
                "label": "****",
                "InvSlotWidth": "0",
                "InvSlotHeight": "0",
                "EquipableSlots": "0",
                "CanRotateIcon": "0",
                "ModelType": "0",
                "NWN2_Anim": "0",
                "ItemClass": "0",
                "GenderSpecific": "0",
                "Part1EnvMap": "0",
                "Part2EnvMap": "0",
                "Part3EnvMap": "0",
                "DefaultModel": "****",
                "NWN2_DefaultIcon": "****",
                "DefaultIcon": "****",
                "Container": "0",
                "WeaponWield": "0",
                "WeaponType": "0",
                "WeaponSize": "0",
                "RangedWeapon": "****",
                "PrefAttackDist": "1.0",
                "MinRange": "0",
                "MaxRange": "0",
                "NumDice": "0",
                "DieToRoll": "0",
                "CritThreat": "20",
                "CritHitMult": "2",
                "Category": "0",
                "BaseCost": "0",
                "Stacking": "1",
                "ItemMultiplier": "1.0",
                "Description": "****",
                "InvSoundType": "0",
                "MaxProps": "0",
                "MinProps": "0",
                "PropColumn": "0",
                "StorePanel": "0",
                "ReqFeat0": "****",
                "ReqFeat1": "****",
                "ReqFeat2": "****",
                "ReqFeat3": "****",
                "ReqFeat4": "****",
                "ReqFeat5": "****",
                "AC_Enchant": "0",
                "BaseAC": "0",
                "ArmorCheckPen": "0",
                "BaseItemStatRef": "****",
                "ChargesStarting": "0",
                "RotateOnGround": "0",
                "TenthLBS": "0",
                "WeaponMatType": "0",
                "AmmunitionType": "0",
                "QBBehaviour": "****",
                "ArcaneSpellFailure": "0",
                "%AnimSlashL": "0",
                "%AnimSlashR": "0",
                "%AnimSlashS": "0",
                "StorePanelSort": "0",
                "ILRStackSize": "1",
                "FEATImprCrit": "0",
                "FEATWpnFocus": "0",
                "FEATWpnSpec": "0",
                "FEATEpicDevCrit": "0",
                "FEATEpicWpnFocus": "0",
                "FEATEpicWpnSpec": "0",
                "FEATOverWhCrit": "0",
                "FEATWpnOfChoice": "0",
                "FEATGrtrWpnFocus": "0",
                "FEATGrtrWpnSpec": "0",
                "FEATPowerCrit": "0",
                "GMaterialType": "0",
                "BaseItemSortOrder": "0"
            },
            "identifier_attr": "label",
            "object_type": {'MESH'},
            "required_selection": (0, 1),
            "icon": "SHADERFX",
            "row_display_attr": "label"
        }
    }

    @classmethod
    def get_file_types(cls) -> List[str]:
        """Get list of supported file types."""
        return list(cls.FILE_CONFIGS.keys())

    @classmethod
    def get_config(cls, file_type: str) -> Dict[str, Any]:
        """Get configuration for a specific file type."""
        return cls.FILE_CONFIGS.get(file_type, {})
    
    @classmethod
    def get_file_info(cls, file_type: str) -> Tuple[str, str]:
        """Get filename and display name for a file type."""
        config = cls.get_config(file_type)
        return config.get("filename", ""), config.get("sync_label", "")
    
    @classmethod
    def get_sync_operator_info(cls, file_type: str) -> Tuple[str, str, str]:
        """Get operator info for a file type."""
        config = cls.get_config(file_type)
        return (
            config.get("sync_operator", ""),
            config.get("sync_label", ""),
            config.get("sync_description", "")
        )
    
    @classmethod
    def get_object_requirements(cls, file_type: str) -> Tuple[Set[str], Tuple[int, int]]:
        """Get object type and selection requirements for a file type."""
        config = cls.get_config(file_type)
        return (
            config.get("object_type", set()),
            config.get("required_selection", (0, 0))
        )
    
    @classmethod
    def get_display_attributes(cls, file_type: str) -> Tuple[str, str]:
        """Get icon and display attribute for a file type."""
        config = cls.get_config(file_type)
        return config.get("icon", "QUESTION"), config.get("row_display_attr", "RowNumber")
    
    @classmethod
    def get_default_values(cls, file_type: str) -> Dict[str, str]:
        """Get default values for a file type."""
        return cls.get_config(file_type).get("defaults", {})

# ==============================================
# PLACEABLES COLUMN DEFINITIONS
# ==============================================

class PlaceablesColumnInfo:
    """Complete information about placeables.2da columns"""
    
    COLUMN_DESCRIPTIONS = {
        "Label": {
            "description": "Unique identifier for the placeable",
            "purpose": "Used in scripts and toolset references (e.g., 'plc_crate01')",
            "icon": 'SORTALPHA'
        },
        "StrRef": {
            "description": "String reference for the placeable's name/description", 
            "purpose": "Links to dialog.tlk for localized text (hover tooltips)",
            "icon": 'FONT_DATA'
        },
        "PlaceableModelType": {
            "description": "Defines the object's behavior category",
            "purpose": "Determines interaction type (e.g., DOOR, CONTAINER, USEABLE)",
            "icon": 'MESH_CUBE'
        },
        "Fade": {
            "description": "Distance at which the model fades out",
            "purpose": "Optimizes rendering by hiding distant objects", 
            "icon": 'RESTRICT_VIEW_OFF'
        },
        "NWN2_ModelName": {
            "description": "Filename of the 3D model (.mdb or .gr2)",
            "purpose": "Specifies which model file to load (e.g., 'plc_crate01.mdb')",
            "icon": 'FILE_3D'
        },
        "NWN2_LowGore": {
            "description": "Low-violence variant of the model",
            "purpose": "Used in regions with censorship (e.g., bloodless corpses)",
            "icon": 'MOD_DECIM'
        },
        "NWN2_PartsCount": {
            "description": "Number of sub-meshes in the model", 
            "purpose": "For complex models (e.g., a chandelier with multiple parts)",
            "icon": 'MOD_ARRAY'
        },
        "NWN2_Skeleton": {
            "description": "Skeleton file for animated placeables",
            "purpose": "Required for doors, machinery, or other moving objects",
            "icon": 'ARMATURE_DATA'
        },
        "AttachedModelName": {
            "description": "Additional models attached to this one",
            "purpose": "Used for placeables with dynamic parts (e.g., a torch with flames)",
            "icon": 'LINKED'
        },
        "DefaultDoor": {
            "description": "Marks a default door model",
            "purpose": "Used if no specific door model is assigned in the toolset", 
            "icon": 'MESH_MONKEY'
        },
        "DefaultAccessory": {
            "description": "Default item attached (e.g., a key or torch)",
            "purpose": "Automatically links an accessory (rarely used)",
            "icon": 'LIGHT'
        },
        "IsAccessory": {
            "description": "If 1, the model is an add-on (not standalone)",
            "purpose": "Prevents the model from being placed alone (e.g., wall decorations)",
            "icon": 'PINNED'
        },
        "ModelName": {
            "description": "Legacy model reference (unused in NWN2)",
            "purpose": "Reserved for backward compatibility (likely empty)",
            "icon": 'LIBRARY_DATA_BROKEN'
        },
        "LightColor": {
            "description": "RGB color of emitted light (if any)",
            "purpose": "Used for light sources (e.g., 255,255,255 for white light)",
            "icon": 'LIGHT'
        },
        "LightOffsetX": {
            "description": "X position offset for the light source",
            "purpose": "Adjusts where the light emits from (e.g., a lantern's flame position)",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "LightOffsetY": {
            "description": "Y position offset for the light source", 
            "purpose": "Adjusts where the light emits from (e.g., a lantern's flame position)",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "LightOffsetZ": {
            "description": "Z position offset for the light source",
            "purpose": "Adjusts where the light emits from (e.g., a lantern's flame position)", 
            "icon": 'ORIENTATION_GLOBAL'
        },
        "SoundAppType": {
            "description": "Sound set assigned to the placeable",
            "purpose": "Triggers sounds (e.g., DOOR_OPEN, CHEST_UNLOCK)",
            "icon": 'SPEAKER'
        },
        "ShadowSize": {
            "description": "Size of the shadow cast",
            "purpose": "0 = no shadow, 1 = small, 2 = large, etc.",
            "icon": 'MATSHADER'
        },
        "BodyBag": {
            "description": "If 1, acts as a lootable corpse container", 
            "purpose": "Used for enemies/containers with loot (e.g., 'plc_bodybag')",
            "icon": 'MESH_CYLINDER'
        },
        "LowGore": {
            "description": "Generic low-gore flag",
            "purpose": "Alternative to NWN2_LowGore (varies by game version)",
            "icon": 'MOD_DECIM'
        },
        "Reflection": {
            "description": "Controls reflective surfaces",
            "purpose": "0 = none, 1 = metallic/water reflections", 
            "icon": 'MATSHADER'
        },
        "InterfacePT": {
            "description": "Unknown (possibly legacy/unused)",
            "purpose": "May relate to UI interaction in older builds",
            "icon": 'QUESTION'
        },
        "BlockLOS": {
            "description": "If 1, blocks line of sight for AI/stealth",
            "purpose": "Affects pathfinding and detection (e.g., walls block vision)",
            "icon": 'RESTRICT_VIEW_OFF'
        },
        "SELECTION_SIZE": {
            "description": "Clickable/hitbox radius",
            "purpose": "Larger values make the object easier to click in-game",
            "icon": 'SELECT_SET'
        }
    }
    
    @classmethod
    def get_column_info(cls, column_name):
        """Get information for a specific column"""
        return cls.COLUMN_DESCRIPTIONS.get(column_name, {
            "description": "Unknown column",
            "purpose": "No information available",
            "icon": 'QUESTION'
        })
    
    @classmethod
    def get_all_columns(cls):
        """Get all available column names"""
        return list(cls.COLUMN_DESCRIPTIONS.keys())

# ==============================================
# APPEARANCE COLUMN DEFINITIONS
# ==============================================

class AppearanceColumnInfo:
    """Complete information about appearance.2da columns"""
    
    COLUMN_DESCRIPTIONS = {
        "INDEX": {
            "description": "A unique numerical identifier for the appearance",
            "purpose": "The row number; used as the internal reference for a creature's appearance",
            "icon": 'LINENUMBERS_ON'
        },
        "LABEL": {
            "description": "A unique text identifier for the appearance",
            "purpose": "A human-readable name used for reference in the toolset (e.g., HALFELF_M01)",
            "icon": 'SORTALPHA'
        },
        "STRING_REF": {
            "description": "String Reference number for the appearance name",
            "purpose": "Points to an entry in dialog.tlk for the appearance's name. If empty, the LABEL is used",
            "icon": 'FONT_DATA'
        },
        "BodyType": {
            "description": "Legacy type defining if the model is single or multi-part",
            "purpose": "0 = Single mesh (used for NWN2). 1 = Multi-part (NWN1 legacy)",
            "icon": 'MESH_DATA'
        },
        "Segments": {
            "description": "Legacy count for the number of model parts",
            "purpose": "Always 0 for NWN2, as it uses single mesh models",
            "icon": 'MOD_ARRAY'
        },
        "NWN2_Scale_X": {
            "description": "Scaling factor for the model's width",
            "purpose": "Pre-scales the creature model, its weapons, and accessories on the X-axis",
            "icon": 'AXIS_SIDE'
        },
        "NWN2_Scale_Y": {
            "description": "Scaling factor for the model's depth",
            "purpose": "Pre-scales the creature model, its weapons, and accessories on the Y-axis",
            "icon": 'AXIS_FRONT'
        },
        "NWN2_Scale_Z": {
            "description": "Scaling factor for the model's height",
            "purpose": "Pre-scales the creature model, its weapons, and accessories on the Z-axis",
            "icon": 'AXIS_TOP'
        },
        "AnimationSpeed": {
            "description": "Multiplier for the creature's animation playback speed",
            "purpose": "Affects how fast or slow the creature's animations (like walking) play",
            "icon": 'PLAY'
        },
        "NWN2_Model_Body": {
            "description": "Filename of the main body model resource",
            "purpose": "Specifies the .GR2 file for the creature's body (e.g., hm_m_body). A ? is replaced with M/F based on gender",
            "icon": 'USER'
        },
        "NWN2_Model_Helm": {
            "description": "Filename of the helmet model resource",
            "purpose": "Specifies the .GR2 file for the creature's helmet. A ? is replaced with M/F based on gender",
            "icon": 'MATSHADER'
        },
        "NWN2_Model_Head": {
            "description": "Filename of the head model resource",
            "purpose": "Specifies the .GR2 file for the creature's head. A ? is replaced with M/F based on gender",
            "icon": 'USER'
        },
        "NWN2_Model_Hair": {
            "description": "Filename of the hair model resource",
            "purpose": "Specifies the .GR2 file for the creature's hair. A ? is replaced with M/F based on gender",
            "icon": 'CURVES'
        },
        "NWN2_Head_Skeleton": {
            "description": "Filename for a specific head skeleton",
            "purpose": "Used for appearances where the head uses a different skeleton than the body",
            "icon": 'BONE_DATA'
        },
        "NWN2_Skeleton_File": {
            "description": "Filename of the main skeleton file",
            "purpose": "Specifies the .GR2 skeleton file that controls the model's animation rig",
            "icon": 'ARMATURE_DATA'
        },
        "NWN2_AccessorySize": {
            "description": "Defines the size category for accessories",
            "purpose": "Likely used to scale accessories like shoulderpads or belts appropriately for the creature size",
            "icon": 'FULLSCREEN_ENTER'
        },
        "NWN2_AccessoryType": {
            "description": "Defines the type of accessories used",
            "purpose": "Likely used to filter which accessory models are compatible with this appearance",
            "icon": 'LINKED'
        },
        "ToolsetUseStubModel": {
            "description": "Toggles a simple model in the toolset",
            "purpose": "If 1, may use a low-detail model in the toolset for better performance",
            "icon": 'MOD_DECIM'
        },
        "Mount": {
            "description": "Legacy column for the NWN1 mount system",
            "purpose": "Unused in NWN2",
            "icon": 'LIBRARY_DATA_BROKEN'
        },
        "NAME": {
            "description": "A fixed, unique game identifier for the appearance",
            "purpose": "A string used by the game engine as the definitive name for this appearance entry",
            "icon": 'SORTALPHA'
        },
        "RACE": {
            "description": "A single-letter code for the appearance's race",
            "purpose": "Used for racial determination (e.g., H for Human/Half-Elf, D for Dwarf, c_* for creatures)",
            "icon": 'COMMUNITY'
        },
        "ENVMAP": {
            "description": "Legacy column for environment mapping",
            "purpose": "Unused in NWN2, as the engine does not support this feature",
            "icon": 'MATSHADER'
        },
        "NWN2_BLOODTYPE": {
            "description": "Reference to a row in nwn2_bloodtypes.2da",
            "purpose": "Defines which visual blood effect (SEF file) is used when the creature is injured",
            "icon": 'MOD_PARTICLES'
        },
        "MODELTYPE": {
            "description": "Legacy column defining the animation set type from NWN1",
            "purpose": "Unused in NWN2's animation system (e.g., P for Player, S for Simple)",
            "icon": 'ANIM'
        },
        "WEAPONVISUALSCALE": {
            "description": "Scaling factor for wielded weapon models",
            "purpose": "Counteracts the model's scale so weapons look correctly sized (e.g., set to 2.0 on a halfling)",
            "icon": 'ORIENTATION_GIMBAL'
        },
        "WEAPONATTACKDISTANCESCALE": {
            "description": "Scaling factor for weapon attack range",
            "purpose": "Adjusts the weapon's PrefAttackDist from baseitems.2da to match the visual scaling",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "WING_TAIL_SCALE": {
            "description": "Scaling factor for wing and tail models",
            "purpose": "Applies to any wing or tail models attached to the creature's skeleton",
            "icon": 'FULLSCREEN_ENTER'
        },
        "HELMET_SCALE_M": {
            "description": "Scaling factor for male helmet models",
            "purpose": "Allows separate scaling of helmets for male models",
            "icon": 'USER'
        },
        "HELMET_SCALE_F": {
            "description": "Scaling factor for female helmet models",
            "purpose": "Allows separate scaling of helmets for female models",
            "icon": 'USER'
        },
        "MOVERATE": {
            "description": "Legacy reference to creaturespeed.2da for movement",
            "purpose": "Unused in NWN2; movement speeds are handled elsewhere",
            "icon": 'ANIM_DATA'
        },
        "WALKDIST": {
            "description": "Legacy value for distance per walk step",
            "purpose": "Unused in NWN2; animation-driven",
            "icon": 'ANIM_DATA'
        },
        "RUNDIST": {
            "description": "Legacy value for distance per run step",
            "purpose": "Unused in NWN2; animation-driven",
            "icon": 'ANIM_DATA'
        },
        "PERSPACE": {
            "description": "Legacy value for personal space radius",
            "purpose": "Unused in NWN2; pathfinding is handled differently",
            "icon": 'MESH_CIRCLE'
        },
        "CREPERSPACE": {
            "description": "Legacy value for others' space radius around this creature",
            "purpose": "Unused in NWN2; pathfinding is handled differently",
            "icon": 'MESH_CIRCLE'
        },
        "HEIGHT": {
            "description": "Legacy value for creature height",
            "purpose": "Unused in NWN2; determined by model and scale",
            "icon": 'AXIS_TOP'
        },
        "HITDIST": {
            "description": "Legacy value for preferred hit distance",
            "purpose": "Unused in NWN2; determined by weapon range and animation",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "PREFATCKDIST": {
            "description": "Legacy value for preferred attack distance",
            "purpose": "Unused in NWN2; determined by weapon range and animation",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "TARGETHEIGHT": {
            "description": "Legacy value for target height",
            "purpose": "Unused in NWN2",
            "icon": 'AXIS_TOP'
        },
        "ABORTONPARRY": {
            "description": "Legacy flag to abort animation on parry",
            "purpose": "Unused in NWN2",
            "icon": 'CANCEL'
        },
        "RACIALTYPE": {
            "description": "Reference to a row in racialtypes.2da",
            "purpose": "Defines the creature's racial type for gameplay rules and effects",
            "icon": 'COMMUNITY'
        },
        "HASLEGS": {
            "description": "Flag for whether the model has legs",
            "purpose": "1 = Yes, 0 = No. May be used for animation or footstep selection",
            "icon": 'MOD_DYNAMICPAINT'
        },
        "HASARMS": {
            "description": "Flag for whether the model has arms",
            "purpose": "1 = Yes, 0 = No. May be used for animation selection",
            "icon": 'MOD_DYNAMICPAINT'
        },
        "PORTRAIT": {
            "description": "Filename of the default portrait",
            "purpose": "Specifies the portrait image file to use for creatures with this appearance",
            "icon": 'IMAGE_DATA'
        },
        "SIZECATEGORY": {
            "description": "Reference to a row in creaturesize.2da",
            "purpose": "Defines the creature's size for combat modifiers (AC, Attack) and rules",
            "icon": 'FULLSCREEN_ENTER'
        },
        "PERCEPTIONDIST": {
            "description": "Reference to a row in ranges.2da",
            "purpose": "Intended to set the creature's default visual perception range, but may be unused",
            "icon": 'VIEWZOOM'
        },
        "FOOTSTEPTYPE": {
            "description": "Reference to a row in footstepsounds.2da",
            "purpose": "Determines which footstep sound set to use on different terrain types",
            "icon": 'SOUND'
        },
        "SOUNDAPPTYPE": {
            "description": "Reference to a sound set",
            "purpose": "Defines the creature's sound set (voice, attack grunts, etc.)",
            "icon": 'SPEAKER'
        },
        "HEADTRACK": {
            "description": "Legacy flag for head tracking",
            "purpose": "Unused in NWN2",
            "icon": 'VIEW3D'
        },
        "HEAD_ARC_H": {
            "description": "Legacy value for horizontal head arc",
            "purpose": "Unused in NWN2",
            "icon": 'ORIENTATION_GIMBAL'
        },
        "HEAD_ARC_V": {
            "description": "Legacy value for vertical head arc",
            "purpose": "Unused in NWN2",
            "icon": 'ORIENTATION_GIMBAL'
        },
        "HEAD_NAME": {
            "description": "Legacy name of the head bone",
            "purpose": "Unused in NWN2",
            "icon": 'BONE_DATA'
        },
        "BODY_BAG": {
            "description": "Reference to a row in bodybag.2da",
            "purpose": "Determines the corpse model or loot container that appears when the creature dies",
            "icon": 'MESH_CUBE'
        },
        "TARGETABLE": {
            "description": "Flag for whether the creature can be targeted",
            "purpose": "1 = Yes, 0 = No. May not function correctly in-game",
            "icon": 'RESTRICT_SELECT_OFF'
        },
        "SELECTION_CAPSULE": {
            "description": "Unknown (unused/legacy)",
            "purpose": "No specific purpose documented",
            "icon": 'MESH_CAPSULE'
        },
        "SELECTION_SIZE": {
            "description": "Unknown (unused/legacy)",
            "purpose": "No specific purpose documented",
            "icon": 'SELECT_SET'
        },
        "SEF": {
            "description": "Legacy column for Special Effect files",
            "purpose": "Unused in NWN2; replaced by the NWN2_BLOODTYPE system",
            "icon": 'MOD_PARTICLES'
        }
    }
    
    @classmethod
    def get_column_info(cls, column_name):
        """Get information for a specific column"""
        return cls.COLUMN_DESCRIPTIONS.get(column_name, {
            "description": "Unknown column",
            "purpose": "No information available",
            "icon": 'QUESTION'
        })
    
    @classmethod
    def get_all_columns(cls):
        """Get all available column names"""
        return list(cls.COLUMN_DESCRIPTIONS.keys())

# ==============================================
# WING COLUMN DEFINITIONS
# ==============================================

class WingColumnInfo:
    """Complete information about wingmodel.2da columns"""
    
    COLUMN_DESCRIPTIONS = {
        "INDEX": {
            "description": "A unique numerical identifier for the wing type",
            "purpose": "The row number; used as the internal reference for a creature's wing appearance",
            "icon": 'LINENUMBERS_ON'
        },
        "LABEL": {
            "description": "A unique text identifier for the wing type",
            "purpose": "A human-readable name used for reference in the toolset (e.g., 'AngelWings', 'DragonWings')",
            "icon": 'SORTALPHA'
        },
        "StringRef": {
            "description": "String Reference number for the wing name",
            "purpose": "Points to an entry in dialog.tlk for the wing type's display name",
            "icon": 'FONT_DATA'
        },
        "NWN2_ModelName": {
            "description": "Filename of the wing model resource",
            "purpose": "Specifies the .MDB file for the wing model (e.g., wing_angel01.mdb)",
            "icon": 'FILE_3D'
        },
        "NWN2_Skeleton_File": {
            "description": "Filename of the skeleton file for wing animations",
            "purpose": "Specifies the skeleton file that controls the wing's bone rig and animations",
            "icon": 'ARMATURE_DATA'
        },
        "NWN2_BaseAnims": {
            "description": "Reference to the base animation set for the wings",
            "purpose": "Defines how the wings move (e.g., idle flap, flying motions, folding)",
            "icon": 'ANIM'
        },
        "MODEL": {
            "description": "Legacy model reference from NWN1",
            "purpose": "Maintained for backward compatibility; often contains the same value as NWN2_ModelName",
            "icon": 'LIBRARY_DATA_BROKEN'
        }
    }
    
    @classmethod
    def get_column_info(cls, column_name):
        """Get information for a specific column"""
        return cls.COLUMN_DESCRIPTIONS.get(column_name, {
            "description": "Unknown column",
            "purpose": "No information available",
            "icon": 'QUESTION'
        })
    
    @classmethod
    def get_all_columns(cls):
        """Get all available column names"""
        return list(cls.COLUMN_DESCRIPTIONS.keys())

# ==============================================
# TAIL COLUMN DEFINITIONS
# ==============================================

class TailColumnInfo:
    """Complete information about tailmodel.2da columns"""
    
    COLUMN_DESCRIPTIONS = {
        "INDEX": {
            "description": "A unique numerical identifier for the tail type",
            "purpose": "The row number; used as the internal reference for a creature's tail appearance",
            "icon": 'LINENUMBERS_ON'
        },
        "LABEL": {
            "description": "A unique text identifier for the tail type",
            "purpose": "A human-readable name used for reference in the toolset (e.g., 'Lizard', 'Bone', 'Devil')",
            "icon": 'SORTALPHA'
        },
        "StringRef": {
            "description": "String Reference number for the tail name",
            "purpose": "Points to an entry in dialog.tlk for the tail type's display name",
            "icon": 'FONT_DATA'
        },
        "NWN2_ModelName": {
            "description": "Filename of the tail model resource",
            "purpose": "Specifies the .MDB file for the tail model (e.g., c_reddragon_tail.mdb)",
            "icon": 'FILE_3D'
        },
        "NWN2_Skeleton_File": {
            "description": "Filename of the skeleton file for tail animations",
            "purpose": "Specifies the skeleton file that controls the tail's bone rig and animations",
            "icon": 'ARMATURE_DATA'
        },
        "NWN2_BaseAnims": {
            "description": "Reference to the base animation set for the tail",
            "purpose": "Defines how the tail moves (e.g., idle sway, combat lashes, running motions)",
            "icon": 'ANIM'
        },
        "MODEL": {
            "description": "Legacy model reference from NWN1",
            "purpose": "Maintained for backward compatibility; contains the legacy model name (e.g., c_tailliz, c_taildevil)",
            "icon": 'LIBRARY_DATA_BROKEN'
        }
    }
    
    @classmethod
    def get_column_info(cls, column_name):
        """Get information for a specific column"""
        return cls.COLUMN_DESCRIPTIONS.get(column_name, {
            "description": "Unknown column",
            "purpose": "No information available",
            "icon": 'QUESTION'
        })
    
    @classmethod
    def get_all_columns(cls):
        """Get all available column names"""
        return list(cls.COLUMN_DESCRIPTIONS.keys())

# ==============================================
# BASEITEM COLUMN DEFINITIONS
# ==============================================

class BaseitemColumnInfo:
    """Complete information about baseitems.2da columns"""
    
    COLUMN_DESCRIPTIONS = {
        "index": {
            "description": "Sequentially numbered row identifier",
            "purpose": "This field identifies the base item to humans reading the file. The game engine ignores this value and sequentially numbers records as it reads them.",
            "icon": 'LINENUMBERS_ON'
        },
        "Name": {
            "description": "String reference for item name",
            "purpose": "StringRef that indicates the name of the base item, as displayed in the game. If this entry is '****' then the 'label' column will be used instead.",
            "icon": 'FONT_DATA'
        },
        "label": {
            "description": "Descriptive name for human reference",
            "purpose": "Typically for human reference, but displayed in-game if Name is '****'. Spaces should be avoided (use underscores).",
            "icon": 'SORTALPHA'
        },
        "InvSlotWidth": {
            "description": "Inventory slot width (NOT USED IN NWN2)",
            "purpose": "This column is not used in Neverwinter Nights 2",
            "icon": 'PACKAGE'
        },
        "InvSlotHeight": {
            "description": "Inventory slot height (NOT USED IN NWN2)",
            "purpose": "This column is not used in Neverwinter Nights 2",
            "icon": 'PACKAGE'
        },
        "EquipableSlots": {
            "description": "Bitmask for equipable slots",
            "purpose": "Bit flag indicating inventory slots where item can be placed. See slot table for bit values.",
            "icon": 'MODIFIER'
        },
        "CanRotateIcon": {
            "description": "Icon rotation flag (unused)",
            "purpose": "Purpose unclear - likely unused in NWN2",
            "icon": 'ORIENTATION_GIMBAL'
        },
        "ModelType": {
            "description": "Model customization type",
            "purpose": "Code indicating how much the look can be customized:\n0 = simple item (icon/model pair)\n1 = colored item (cloaks/helms)\n2 = configurable item (3 parts)\n3 = armor",
            "icon": 'MESH_DATA'
        },
        "NWN2_Anim": {
            "description": "Weapon animation flag",
            "purpose": "Indicates if weapon has its own animation:\n0 = rigid\n1 = animated",
            "icon": 'ANIM'
        },
        "ItemClass": {
            "description": "Item classification",
            "purpose": "Name of the item's model classification",
            "icon": 'SHADERFX'
        },
        "GenderSpecific": {
            "description": "Gender appearance flag",
            "purpose": "Indicates if appearance changes based on gender:\n0 = no change\n1 = changes",
            "icon": 'USER'
        },
        "Part1EnvMap": {
            "description": "Alpha channel usage for part 1",
            "purpose": "How alpha channel for model part 1 is used:\n0 = transparency\n1 = reflectiveness",
            "icon": 'MATSHADER'
        },
        "Part2EnvMap": {
            "description": "Alpha channel usage for part 2",
            "purpose": "How alpha channel for model part 2 is used:\n0 = transparency\n1 = reflectiveness (ModelType 2 only)",
            "icon": 'MATSHADER'
        },
        "Part3EnvMap": {
            "description": "Alpha channel usage for part 3",
            "purpose": "How alpha channel for model part 3 is used:\n0 = transparency\n1 = reflectiveness (ModelType 2 only)",
            "icon": 'MATSHADER'
        },
        "DefaultModel": {
            "description": "Ground model filename",
            "purpose": "Model used when item is lying on the ground",
            "icon": 'MESH_CUBE'
        },
        "NWN2_DefaultIcon": {
            "description": "Default icon (unused)",
            "purpose": "Purpose unclear - likely unused in NWN2",
            "icon": 'IMAGE_DATA'
        },
        "DefaultIcon": {
            "description": "Default icon (unused)",
            "purpose": "Purpose unclear - likely unused in NWN2",
            "icon": 'IMAGE_DATA'
        },
        "Container": {
            "description": "Container capability flag",
            "purpose": "Indicates if item can contain other items:\n0 = not a container\n1 = is a container",
            "icon": 'CUBE'
        },
        "WeaponWield": {
            "description": "Animation set for wielding",
            "purpose": "Animation set used when equipped:\n0 = standard one-handed\n1 = not wieldable\n4 = two-handed\n5 = bow\n6 = crossbow\n7 = shield\n8 = double-sided\n9 = creature weapon\n10 = dart/sling\n11 = shuriken/throwing axe\n12 = spears\n13 = musical instruments",
            "icon": 'ANIM_DATA'
        },
        "WeaponType": {
            "description": "Damage type inflicted",
            "purpose": "Type of damage inflicted:\n1 = piercing\n2 = bludgeoning\n3 = slashing\n4 = piercing-slashing\n5 = bludgeoning-piercing",
            "icon": 'MODIFIER'
        },
        "WeaponSize": {
            "description": "Weapon size category",
            "purpose": "Size of the weapon:\n1 = tiny\n2 = small\n3 = medium\n4 = large",
            "icon": 'FULLSCREEN_ENTER'
        },
        "RangedWeapon": {
            "description": "Ammunition baseitem index",
            "purpose": "Row index of ammunition used, or '****' if not ranged weapon. If equals current row, item is its own ammunition.",
            "icon": 'ARROW_LEFTRIGHT'
        },
        "PrefAttackDist": {
            "description": "Preferred attack distance",
            "purpose": "Optimal distance for attacking with this weapon (in NWN2, this actually changes attack range)",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "MinRange": {
            "description": "Minimum range calculation",
            "purpose": "Ten times the minimum number of models for each part (ModelType 2 only)",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "MaxRange": {
            "description": "Maximum range calculation",
            "purpose": "Ten times the maximum number of models for each part (ModelType 2 only)",
            "icon": 'ORIENTATION_GLOBAL'
        },
        "NumDice": {
            "description": "Number of damage dice",
            "purpose": "Number of dice rolled for weapon damage",
            "icon": 'MOD_REMESH'
        },
        "DieToRoll": {
            "description": "Damage dice sides",
            "purpose": "Number of sides on damage dice",
            "icon": 'MOD_REMESH'
        },
        "CritThreat": {
            "description": "Critical threat range",
            "purpose": "Chance (out of 20) to threaten critical hit. Example: '2' means 19-20 threat range.",
            "icon": 'MODIFIER'
        },
        "CritHitMult": {
            "description": "Critical hit multiplier",
            "purpose": "Damage multiplier on critical hits",
            "icon": 'MODIFIER'
        },
        "Category": {
            "description": "Item category (unused)",
            "purpose": "Purpose unclear - likely unused in NWN2",
            "icon": 'SHADERFX'
        },
        "BaseCost": {
            "description": "Base gold piece value",
            "purpose": "Base value of an unenchanted item (in gold pieces)",
            "icon": 'MONKEY'
        },
        "Stacking": {
            "description": "Maximum stack size",
            "purpose": "Maximum number that can be stacked in one inventory icon (arrows=99, most items=1)",
            "icon": 'MOD_ARRAY'
        },
        "ItemMultiplier": {
            "description": "Cost multiplier",
            "purpose": "Multiplier for base value after enchantments are added. Used to reduce cost of stacked items like arrows.",
            "icon": 'MODIFIER'
        },
        "Description": {
            "description": "Default description StringRef",
            "purpose": "StringRef for default description. Used for items lacking specific descriptions.",
            "icon": 'TEXT'
        },
        "InvSoundType": {
            "description": "Inventory sound index",
            "purpose": "Index into inventorysnds.2da for inventory placement sound",
            "icon": 'SOUND'
        },
        "MaxProps": {
            "description": "Maximum properties count",
            "purpose": "Maximum 'cast spell' properties when designed in Toolset",
            "icon": 'MODIFIER'
        },
        "MinProps": {
            "description": "Minimum properties count",
            "purpose": "Minimum 'cast spell' properties when designed in Toolset",
            "icon": 'MODIFIER'
        },
        "PropColumn": {
            "description": "Properties column reference",
            "purpose": "Number indicating which column of itemprops.2da determines property types",
            "icon": 'PROPERTIES'
        },
        "StorePanel": {
            "description": "Store category panel",
            "purpose": "Where item appears in stores:\n0 = armor/clothing\n1 = weapons\n2 = potions/scrolls\n3 = wands/magic items\n4 = miscellaneous",
            "icon": 'SHOP'
        },
        "ReqFeat0": {
            "description": "Required proficiency feat 0",
            "purpose": "Index into feat.2da for proficiency feat. '****' = all proficient or armor.",
            "icon": 'SOLO_ON'
        },
        "ReqFeat1": {
            "description": "Required proficiency feat 1",
            "purpose": "Alternate proficiency feat (if not '****')",
            "icon": 'SOLO_ON'
        },
        "ReqFeat2": {
            "description": "Required proficiency feat 2",
            "purpose": "Alternate proficiency feat (if not '****')",
            "icon": 'SOLO_ON'
        },
        "ReqFeat3": {
            "description": "Required proficiency feat 3",
            "purpose": "Alternate proficiency feat (if not '****')",
            "icon": 'SOLO_ON'
        },
        "ReqFeat4": {
            "description": "Required proficiency feat 4",
            "purpose": "Alternate proficiency feat (if not '****')",
            "icon": 'SOLO_ON'
        },
        "ReqFeat5": {
            "description": "Required proficiency feat 5",
            "purpose": "Alternate proficiency feat (if not '****')",
            "icon": 'SOLO_ON'
        },
        "AC_Enchant": {
            "description": "Armor class bonus type",
            "purpose": "Type of AC bonus granted:\n0 = dodge\n1 = natural\n2 = armor\n3 = shield\n4 = deflection",
            "icon": 'MOD_ARMATURE'
        },
        "BaseAC": {
            "description": "Base armor class value",
            "purpose": "Armor class value before enchantments (not used for armor, only shields by default)",
            "icon": 'SHIELD'
        },
        "ArmorCheckPen": {
            "description": "Armor check penalty",
            "purpose": "Armor check penalty inherent to item (not used for armor, only shields by default)",
            "icon": 'MODIFIER'
        },
        "BaseItemStatRef": {
            "description": "Basic statistics StringRef",
            "purpose": "StringRef for basic statistics displayed when item is examined",
            "icon": 'TEXT'
        },
        "ChargesStarting": {
            "description": "Starting charges count",
            "purpose": "Starting number of charges by default",
            "icon": 'OUTLINER_DATA_LIGHTPROBE'
        },
        "RotateOnGround": {
            "description": "Ground rotation flag (unused)",
            "purpose": "Purpose unclear - likely unused in NWN2",
            "icon": 'ORIENTATION_GIMBAL'
        },
        "TenthLBS": {
            "description": "Weight in tenths of pounds",
            "purpose": "Ten times the weight in pounds",
            "icon": 'LIGHT'
        },
        "WeaponMatType": {
            "description": "Weapon sound material",
            "purpose": "Index into weaponsounds.2da for hit sounds",
            "icon": 'SOUND'
        },
        "AmmunitionType": {
            "description": "Ammunition type index",
            "purpose": "Index+1 into ammunitiontypes.2da:\n1 = arrow\n2 = bolt\n3 = bullet\n4 = dart\n5 = shuriken\n6 = throwing axe",
            "icon": 'OUTLINER_DATA_LIGHTPROBE'
        },
        "QBBehaviour": {
            "description": "Quickbar default use",
            "purpose": "Default use when assigned to quickbar:\n**** = no use\n1 = rods/instruments/wands/misc\n2 = potions/scrolls",
            "icon": 'NLA'
        },
        "ArcaneSpellFailure": {
            "description": "Arcane spell failure percentage",
            "purpose": "Percentage added to arcane spell failure chance (shields only by default)",
            "icon": 'MODIFIER'
        },
        "%AnimSlashL": {
            "description": "Left slash animation percentage",
            "purpose": "Chance (%) for left slash animation during attack",
            "icon": 'ANIM'
        },
        "%AnimSlashR": {
            "description": "Right slash animation percentage",
            "purpose": "Chance (%) for right slash animation during attack",
            "icon": 'ANIM'
        },
        "%AnimSlashS": {
            "description": "Straight slash animation percentage",
            "purpose": "Chance (%) for straight slash animation during attack",
            "icon": 'ANIM'
        },
        "StorePanelSort": {
            "description": "Store sort order",
            "purpose": "Order within store panel (StorePanel column)",
            "icon": 'SORTALPHA'
        },
        "ILRStackSize": {
            "description": "ILR stack size",
            "purpose": "Stack size for Item Level Restrictions calculation",
            "icon": 'MOD_ARRAY'
        },
        "FEATImprCrit": {
            "description": "Improved Critical feat",
            "purpose": "Index into feat.2da for Improved Critical feat",
            "icon": 'SOLO_ON'
        },
        "FEATWpnFocus": {
            "description": "Weapon Focus feat",
            "purpose": "Index into feat.2da for Weapon Focus feat",
            "icon": 'SOLO_ON'
        },
        "FEATWpnSpec": {
            "description": "Weapon Specialization feat",
            "purpose": "Index into feat.2da for Weapon Specialization feat",
            "icon": 'SOLO_ON'
        },
        "FEATEpicDevCrit": {
            "description": "Epic Devastating Critical feat",
            "purpose": "Index into feat.2da for Epic Devastating Critical (off by default)",
            "icon": 'SOLO_ON'
        },
        "FEATEpicWpnFocus": {
            "description": "Epic Weapon Focus feat",
            "purpose": "Index into feat.2da for Epic Weapon Focus feat",
            "icon": 'SOLO_ON'
        },
        "FEATEpicWpnSpec": {
            "description": "Epic Weapon Specialization feat",
            "purpose": "Index into feat.2da for Epic Weapon Specialization feat",
            "icon": 'SOLO_ON'
        },
        "FEATOverWhCrit": {
            "description": "Overwhelming Critical feat",
            "purpose": "Index into feat.2da for Overwhelming Critical feat",
            "icon": 'SOLO_ON'
        },
        "FEATWpnOfChoice": {
            "description": "Weapon of Choice feat",
            "purpose": "Index into feat.2da for Weapon Master's Weapon of Choice",
            "icon": 'SOLO_ON'
        },
        "FEATGrtrWpnFocus": {
            "description": "Greater Weapon Focus feat",
            "purpose": "Index into feat.2da for Greater Weapon Focus feat",
            "icon": 'SOLO_ON'
        },
        "FEATGrtrWpnSpec": {
            "description": "Greater Weapon Specialization feat",
            "purpose": "Index into feat.2da for Greater Weapon Specialization feat",
            "icon": 'SOLO_ON'
        },
        "FEATPowerCrit": {
            "description": "Power Critical feat",
            "purpose": "Index into feat.2da for Power Critical feat",
            "icon": 'SOLO_ON'
        },
        "GMaterialType": {
            "description": "Material type index",
            "purpose": "Index into iprp_materials.2da",
            "icon": 'MATERIAL'
        },
        "BaseItemSortOrder": {
            "description": "Inventory sort order",
            "purpose": "Sort order when player uses inventory sort button",
            "icon": 'SORTALPHA'
        }
    }
    
    # EquipableSlots bitmask values
    EQUIPABLE_SLOTS = {
        "Helmet": 0x00001,
        "Armor": 0x00002,
        "Boots": 0x00004,
        "Gloves": 0x00008,
        "Main hand": 0x00010,
        "Off-hand": 0x00020,
        "Cloak": 0x00040,
        "Rings": 0x00180,  # Note: This is actually 0x80 + 0x100 for ring slots
        "Amulet": 0x00200,
        "Belt": 0x00400,
        "Arrow": 0x00800,
        "Bullet": 0x01000,
        "Bolt": 0x02000,
        "Creature weapons": 0x1C000,
        "Creature armor": 0x20000
    }
    
    @classmethod
    def get_column_info(cls, column_name):
        """Get information for a specific column"""
        return cls.COLUMN_DESCRIPTIONS.get(column_name, {
            "description": "Unknown column",
            "purpose": "No information available",
            "icon": 'QUESTION'
        })
    
    @classmethod
    def get_all_columns(cls):
        """Get all available column names"""
        return list(cls.COLUMN_DESCRIPTIONS.keys())
    
    @classmethod
    def get_equipable_slots_info(cls):
        """Get information about equipable slots bitmask"""
        return cls.EQUIPABLE_SLOTS

# ==============================================
# PROPERTY GROUPS
# ==============================================

class TwoDARow(PropertyGroup):
    """Single row in a 2DA file"""
    index: IntProperty()

class TwoDAFileData(PropertyGroup):
    """Data for each 2DA file type"""
    rows: CollectionProperty(type=TwoDARow)
    active_index: IntProperty(name="Active Row Index", default=0)
    headers: StringProperty()
    file_loaded: BoolProperty(default=False)
    sync_active: BoolProperty(
        name="Sync Active",
        description="Automatically sync to selected objects when enabled",
        default=False
    )
    last_sync_name: StringProperty(
        name="Last Sync Name",
        description="Last synchronized object name",
        default=""
    )

# ==============================================
# FILE HANDLING
# ==============================================

class TwoDAFileHandler:
    """Handles loading, parsing and management of 2DA files."""
    
    @staticmethod
    def update_row_properties(headers: List[str]) -> None:
        """Dynamically add properties to TwoDARow based on headers."""
        for header in headers:
            if not hasattr(TwoDARow, header):
                setattr(TwoDARow, header, StringProperty(name=header))

    @staticmethod
    def load_2da_file(filepath: str, file_type: str) -> bool:
        """Load and parse a 2DA file, storing the original path"""
        try:
            scene = bpy.context.scene
            file_data = getattr(scene, f"{file_type}_data")
            file_data.rows.clear()
            file_data.sync_active = False
            file_data.last_sync_name = ""
            
            # Store original filepath for saving
            file_data.original_filepath = filepath

            with open(filepath, 'r', encoding='utf-8', errors='ignore') as file:
                lines = [line.strip() for line in file if line.strip()]

            if not lines:
                raise ValueError("File is empty")

            # Find header line (skip initial "2DA" lines)
            header_index = next(
                (i for i, line in enumerate(lines) if line and not line.startswith("2DA")),
                0
            )
            original_headers = lines[header_index].split()

            if not original_headers:
                raise ValueError("No headers found in file")

            # Construct full headers including implicit RowNumber
            headers = ["RowNumber"] + original_headers
            file_data.headers = ",".join(headers)
            TwoDAFileHandler.update_row_properties(headers)

            # Process data rows - use consistent 0-based indexing
            for i, line in enumerate(lines[header_index + 1:], start=0):
                values = line.split('\t') if '\t' in line else line.split()
                
                # Use 0-based indexing for both index and RowNumber
                row_number = str(i)  # Force 0-based indexing
                
                data_values = values[1:] if len(values) > 1 else []

                # Pad missing values with defaults
                while len(data_values) < len(original_headers):
                    data_values.append("****")

                row = file_data.rows.add()
                row.index = i
                row.RowNumber = row_number  # Use 0-based RowNumber

                # Set column values
                for j, header in enumerate(original_headers, start=0):
                    value = data_values[j] if j < len(data_values) else "****"
                    setattr(row, header, value)

            file_data.file_loaded = True
            file_data.active_index = 0

            # Ensure all rows have proper properties
            TwoDAFileHandler.ensure_row_properties(file_data, file_type)

            return True

        except Exception as e:
            print(f"Error loading 2DA file {filepath}: {str(e)}")
            return False

    @staticmethod
    def ensure_row_properties(file_data, file_type: str) -> None:
        """Ensure all rows have the proper properties based on headers and defaults."""
        config = TwoDAConstants.get_config(file_type)
        if not config:
            return
        
        headers = file_data.headers.split(',') if file_data.headers else []
        defaults = config.get("defaults", {})
        
        # Update row properties based on current headers
        TwoDAFileHandler.update_row_properties(headers)
        
        # Ensure all rows have all properties with defaults
        for row in file_data.rows:
            for header in headers:
                if header != "RowNumber" and not hasattr(row, header):
                    default_value = defaults.get(header, "****")
                    setattr(row, header, default_value)

# ==============================================
# SYNCHRONIZATION MANAGEMENT - FIXED VERSION
# ==============================================

class TwoDASyncManager:
    """Manages synchronization between Blender objects and 2DA files."""
    
    @staticmethod
    def disable_other_syncs(context, current_type: str) -> None:
        """Disable all other sync types except the current one."""
        scene = context.scene
        for file_type in TwoDAConstants.get_file_types():
            if file_type != current_type:
                file_data = getattr(scene, f"{file_type}_data")
                file_data.sync_active = False
                file_data.last_sync_name = ""

    @staticmethod
    def find_existing_entry(file_data, obj_name: str, identifier_attr: str) -> Optional[int]:
        """Check if object already exists in the 2DA file. Returns row index if found."""
        for i, row in enumerate(file_data.rows):
            if hasattr(row, identifier_attr) and getattr(row, identifier_attr) == obj_name:
                return i
        return None

    @staticmethod
    def create_new_entry(context, file_type: str, obj: bpy.types.Object, row_number: int = 0) -> bool:
        """
        Add a new entry to the 2DA file WITHOUT clearing existing data.
        Returns True if successful, False otherwise.
        """
        config = TwoDAConstants.get_config(file_type)
        if not config:
            return False

        file_data = getattr(context.scene, f"{file_type}_data")
        
        # CRITICAL FIX: Don't clear existing data, just ensure the row exists
        current_row_count = len(file_data.rows)
        
        # If the requested row number doesn't exist, add empty rows up to that point
        if row_number >= current_row_count:
            rows_to_add = (row_number - current_row_count) + 1
            
            for i in range(rows_to_add):
                new_row_index = current_row_count + i
                new_row = file_data.rows.add()
                new_row.index = new_row_index
                new_row.RowNumber = str(new_row_index)
                
                # Initialize with defaults for all headers
                headers = file_data.headers.split(',') if file_data.headers else []
                defaults = config.get("defaults", {})
                for header in headers:
                    if header != "RowNumber":
                        default_value = defaults.get(header, "****")
                        setattr(new_row, header, default_value)

        # Now get the target row and populate it with object data
        if row_number < len(file_data.rows):
            target_row = file_data.rows[row_number]
        else:
            return False

        # Set object-specific data - this preserves all other columns!
        if file_type == "placeables":
            TwoDASyncManager._set_placeable_data(target_row, obj)
        elif file_type == "appearance":
            TwoDASyncManager._set_appearance_data(target_row, obj)
        elif file_type == "wingmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_wingmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "tailmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_tailmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "baseitem":
            TwoDASyncManager._set_baseitem_data(target_row, obj)  # Use the method from TwoDASyncManager

        file_data.active_index = row_number
        file_data.last_sync_name = obj.name
        
        return True

    @staticmethod
    def update_existing_entry(context, file_type: str, obj: bpy.types.Object, row_index: int) -> bool:
        """
        Update an existing entry in the 2DA file.
        Returns True if successful, False otherwise.
        """
        config = TwoDAConstants.get_config(file_type)
        if not config:
            return False

        file_data = getattr(context.scene, f"{file_type}_data")
        
        if row_index < 0 or row_index >= len(file_data.rows):
            return False

        target_row = file_data.rows[row_index]

        # Update object-specific data
        if file_type == "placeables":
            TwoDASyncManager._set_placeable_data(target_row, obj)
        elif file_type == "appearance":
            TwoDASyncManager._set_appearance_data(target_row, obj)
        elif file_type == "wingmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_wingmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "tailmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_tailmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "baseitem":
            TwoDASyncManager._set_baseitem_data(target_row, obj)  # Use the method from TwoDASyncManager

        file_data.active_index = row_index
        file_data.last_sync_name = obj.name
        
        return True

    @staticmethod
    def update_existing_entry(context, file_type: str, obj: bpy.types.Object, row_index: int) -> bool:
        """
        Update an existing entry in the 2DA file.
        Returns True if successful, False otherwise.
        """
        config = TwoDAConstants.get_config(file_type)
        if not config:
            return False

        file_data = getattr(context.scene, f"{file_type}_data")
        
        if row_index < 0 or row_index >= len(file_data.rows):
            return False

        target_row = file_data.rows[row_index]

        # Update object-specific data
        if file_type == "placeables":
            TwoDASyncManager._set_placeable_data(target_row, obj)
        elif file_type == "appearance":
            TwoDASyncManager._set_appearance_data(target_row, obj)
        elif file_type == "wingmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_wingmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "tailmodel":
            selected = context.selected_objects
            armatures = [o for o in selected if o.type == 'ARMATURE']
            meshes = [o for o in selected if o.type == 'MESH']
            primary_arm = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else (armatures[0] if armatures else None)
            secondary_arm = [o for o in armatures if o != primary_arm][0] if len(armatures) > 1 else None
            mesh = meshes[0] if meshes else None
            TwoDASyncManager._set_tailmodel_data(target_row, primary_arm, secondary_arm, mesh)
        elif file_type == "baseitem":  # ADD THIS CASE
            TWODA_OT_SyncBaseitem._set_baseitem_data(target_row, obj)

        file_data.active_index = row_index
        file_data.last_sync_name = obj.name
        
        return True

    @staticmethod
    def _set_placeable_data(row, obj: bpy.types.Object) -> None:
        """Set placeable-specific data for the row with proper multi-mesh handling."""
        # Only update specific fields, preserve others
        row.Label = obj.name.removeprefix("PLC_")
        row.NWN2_ModelName = obj.name
        
        # Skeleton handling (uses object name if parented to armature)
        row.NWN2_Skeleton = obj.name if obj.parent and obj.parent.type == 'ARMATURE' else "****"

    @staticmethod
    def _set_appearance_data(row, obj: bpy.types.Object) -> None:
        """Set appearance-specific data for the row."""
        if obj.type != 'ARMATURE':
            return

        # Only update specific fields, preserve others
        row.NWN2_Skeleton_File = obj.name
        
        for child in obj.children:
            if child.type != 'MESH':
                continue
                
            child_name = child.name.lower()
            
            if child_name.endswith('_body01'):
                parts = child.name.split('_')
                if len(parts) >= 3:
                    row.NWN2_Model_Body = f"{parts[0]}_{parts[1]}"
            
            elif child_name.endswith('_helm01'):
                parts = child.name.split('_')
                if len(parts) >= 2:
                    base_name = f"{'_'.join(parts[:-1])}_helm"
                    row.NWN2_Model_Helm = base_name
                    row.NWN2_Head_Skeleton = obj.name
            
            elif child_name.endswith('_head01'):
                parts = child.name.split('_')
                if len(parts) >= 2:
                    base_name = f"{'_'.join(parts[:-1])}_head"
                    row.NWN2_Model_Head = base_name
                    row.NWN2_Head_Skeleton = obj.name
            
            elif child_name.endswith('_hair01'):
                parts = child.name.split('_')
                if len(parts) >= 2:
                    base_name = f"{'_'.join(parts[:-1])}_hair"
                    row.NWN2_Model_Hair = base_name

    @staticmethod
    def _set_wingmodel_data(row, primary_arm: bpy.types.Object, 
                        secondary_arm: bpy.types.Object, 
                        mesh: Optional[bpy.types.Object]) -> None:
        """Set wingmodel-specific data for the row."""

        base_anim_name = primary_arm.name  
        skeleton_name = secondary_arm.name  
        
        # Only update specific fields, preserve others
        row.NWN2_BaseAnims = base_anim_name
        row.NWN2_Skeleton_File = skeleton_name
        if mesh:
            row.NWN2_ModelName = mesh.name
            row.MODEL = mesh.name

    @staticmethod
    def _set_tailmodel_data(row, primary_arm: bpy.types.Object, 
                        secondary_arm: bpy.types.Object, 
                        mesh: Optional[bpy.types.Object]) -> None:
        """Set tailmodel-specific data for the row."""

        base_anim_name = primary_arm.name  
        skeleton_name = secondary_arm.name  
        
        # Only update specific fields, preserve others
        row.NWN2_BaseAnims = base_anim_name
        row.NWN2_Skeleton_File = skeleton_name
        if mesh:
            row.NWN2_ModelName = mesh.name
            row.MODEL = mesh.name

    @staticmethod
    def _set_baseitem_data(row, obj: bpy.types.Object) -> None:
        """Set baseitem-specific data for the row."""
        if obj.type != 'MESH':
            return
            
        # Only update specific fields, preserve others
        row.label = obj.name
        
        # Extract item type from name if possible
        obj_name_lower = obj.name.lower()
        
        # Try to identify item type from name patterns
        if any(weapon in obj_name_lower for weapon in ['sword', 'axe', 'mace', 'hammer', 'dagger']):
            row.itemClass = "0"  # Weapon
            # Determine weapon type
            if 'sword' in obj_name_lower:
                row.weaponType = "0"  # Sword
            elif 'axe' in obj_name_lower:
                row.weaponType = "1"  # Axe
            elif 'mace' in obj_name_lower or 'hammer' in obj_name_lower:
                row.weaponType = "2"  # Bludgeon
            elif 'dagger' in obj_name_lower:
                row.weaponType = "3"  # Dagger
        elif any(armor in obj_name_lower for armor in ['helmet', 'helm', 'armor', 'chest', 'plate']):
            row.itemClass = "1"  # Armor
            if 'helmet' in obj_name_lower or 'helm' in obj_name_lower:
                row.bodyVariation = "0"  # Head
            else:
                row.bodyVariation = "1"  # Body
        elif any(shield in obj_name_lower for shield in ['shield', 'buckler']):
            row.itemClass = "2"  # Shield
            row.bodyVariation = "2"  # Shield hand
        elif any(potion in obj_name_lower for potion in ['potion', 'vial', 'flask']):
            row.itemClass = "3"  # Potion
        elif any(scroll in obj_name_lower for scroll in ['scroll', 'parchment']):
            row.itemClass = "4"  # Scroll
        elif any(ring in obj_name_lower for ring in ['ring', 'band']):
            row.itemClass = "5"  # Ring
            row.bodyVariation = "3"  # Ring slot
        elif any(amulet in obj_name_lower for amulet in ['amulet', 'necklace', 'pendant']):
            row.itemClass = "6"  # Amulet
            row.bodyVariation = "4"  # Neck slot
        elif any(wand in obj_name_lower for wand in ['wand', 'rod', 'staff']):
            row.itemClass = "7"  # Wand/Staff
        elif any(misc in obj_name_lower for misc in ['key', 'book', 'gem', 'coin']):
            row.itemClass = "8"  # Miscellaneous
            
        # Model reference
        row.modelPart1 = obj.name
        
        # Set reasonable defaults for common attributes
        row.invSlotWidth = "1"
        row.invSlotHeight = "1"
        row.stackSize = "1"
        row.baseCost = "10"
        
        # For weapons, set some combat stats
        if hasattr(row, 'itemClass') and row.itemClass == "0":  # Weapon
            row.damageDice = "1d6"
            row.criticalThreat = "20"
            row.criticalMultiplier = "2"
            row.prefAttackDist = "1.0"

# ==============================================
# IMPROVED BASE OPERATOR CLASS - WITH ROW DIALOG
# ==============================================

class TwoDABaseOperator:
    """Base class for 2DA operators with row selection dialog."""
    
    row_number: IntProperty(name="Insert at Row", default=0, min=0)
    
    @classmethod
    def poll(cls, context) -> bool:
        """Default poll method that checks for active object."""
        return context.active_object is not None

    def invoke(self, context, event) -> set:
        """Show row number dialog when creating NEW entries."""
        config = self.get_config()
        if not config:
            self.report({'ERROR'}, "Invalid configuration")
            return {'CANCELLED'}
            
        file_type = config.get('file_type', '')
        file_data = getattr(context.scene, f"{file_type}_data", None)
        obj = context.active_object
        
        # Only show dialog if:
        # 1. There's an active object
        # 2. The object doesn't already exist in the 2DA
        # 3. We're not already syncing this object
        if (obj and file_data and 
            not TwoDASyncManager.find_existing_entry(
                file_data, obj.name, config.get("identifier_attr", "")
            ) and file_data.last_sync_name != obj.name):
            
            # Set default row number to next available row
            self.row_number = len(file_data.rows)
            return context.window_manager.invoke_props_dialog(self)
        
        # Otherwise, execute directly
        return self.execute(context)

    def draw(self, context) -> None:
        """Draw the row selection dialog."""
        layout = self.layout
        layout.label(text="Select row for new entry:")
        layout.prop(self, "row_number")
        
        # Show current row count for reference
        config = self.get_config()
        file_type = config.get('file_type', '')
        file_data = getattr(context.scene, f"{file_type}_data", None)
        if file_data:
            layout.label(text=f"Current rows: {len(file_data.rows)}", icon='INFO')

    def get_config(self) -> Dict[str, Any]:
        """Get the configuration for this operator's file type."""
        raise NotImplementedError("Subclasses must implement get_config")

    def validate_selection(self, context) -> Tuple[bool, str]:
        """Validate the current selection. Returns (success, message)."""
        config = self.get_config()
        if not config:
            return False, "Invalid configuration"
            
        obj = context.active_object
        
        if not obj:
            return False, "No active object selected"
        
        object_types = config.get("object_type", set())
        if obj.type not in object_types:
            return False, f"Select a {', '.join(object_types)} object"
        
        # Check for complex selection requirements (like wingmodel/tailmodel)
        if "required_selection" in config:
            armatures, meshes = config["required_selection"]
            selected = context.selected_objects
            actual_armatures = sum(1 for o in selected if o.type == 'ARMATURE')
            actual_meshes = sum(1 for o in selected if o.type == 'MESH')
            
            if actual_armatures != armatures or actual_meshes != meshes:
                return False, f"Select {armatures} armatures and {meshes} mesh"
        
        return True, ""

    def execute_auto_sync(self, context) -> set:
        """Handle sync operation with row selection support."""
        config = self.get_config()
        if not config:
            self.report({'ERROR'}, "Invalid configuration")
            return {'CANCELLED'}
            
        file_type = config.get('file_type', '')
        if not file_type:
            self.report({'ERROR'}, "Missing file type in configuration")
            return {'CANCELLED'}
            
        file_data = getattr(context.scene, f"{file_type}_data", None)
        if not file_data:
            self.report({'ERROR'}, f"Missing data for {file_type}")
            return {'CANCELLED'}
            
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "No active object selected")
            return {'CANCELLED'}

        # Validate selection
        is_valid, msg = self.validate_selection(context)
        if not is_valid:
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        # Enable sync
        TwoDASyncManager.disable_other_syncs(context, file_type)
        file_data.sync_active = True
        
        # Check for existing entry
        identifier_attr = config.get("identifier_attr", "")
        if not identifier_attr:
            self.report({'ERROR'}, "Missing identifier attribute in configuration")
            return {'CANCELLED'}
            
        existing_row = TwoDASyncManager.find_existing_entry(
            file_data, obj.name, identifier_attr
        )
        
        if existing_row is not None:
            # Update existing entry
            if not TwoDASyncManager.update_existing_entry(context, file_type, obj, existing_row):
                self.report({'ERROR'}, "Failed to update existing entry")
                return {'CANCELLED'}
            action = "updated"
            row_used = existing_row
        else:
            # Create new entry at specified row
            row_num = getattr(self, 'row_number', len(file_data.rows))
            
            # Ensure row number is valid
            if row_num < 0:
                row_num = 0
            if row_num > len(file_data.rows):
                row_num = len(file_data.rows)
                
            if not TwoDASyncManager.create_new_entry(context, file_type, obj, row_num):
                self.report({'ERROR'}, "Failed to create new entry")
                return {'CANCELLED'}
            action = "created"
            row_used = row_num
        
        file_data.last_sync_name = obj.name
        self.report({'INFO'}, f"{config.get('sync_label', 'Sync')} {action} at row {row_used}: {obj.name}")

        # Force UI update
        context.area.tag_redraw()
        return {'FINISHED'}

# ==============================================
# OPERATORS
# ==============================================

class TWODA_OT_SelectFolder(bpy.types.Operator):
    """Operator to load 2DA files from a directory."""
    bl_idname = "twoda.select_folder"
    bl_label = "Load 2DA Files from Folder"
    bl_description = "Load supported 2DA files from selected directory"

    directory: StringProperty(subtype="DIR_PATH")

    def invoke(self, context, event) -> set:
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context) -> set:
        loaded_files = 0
        for file_type in TwoDAConstants.get_file_types():
            config = TwoDAConstants.get_config(file_type)
            filepath = os.path.join(self.directory, config["filename"])
            if os.path.exists(filepath):
                if TwoDAFileHandler.load_2da_file(filepath, file_type):
                    loaded_files += 1

        if loaded_files == 0:
            self.report({'ERROR'}, "No supported 2DA files found in directory")
            return {'CANCELLED'}
        
        # Set first loaded file as active tab
        for file_type in TwoDAConstants.get_file_types():
            file_data = getattr(context.scene, f"{file_type}_data")
            if file_data.file_loaded:
                context.scene.twoda_active_tab = file_type
                break
                
        return {'FINISHED'}

class TWODA_OT_SyncPlaceable(bpy.types.Operator, TwoDABaseOperator):
    """Sync placeable data with selected objects - WITH ROW DIALOG"""
    bl_idname = "twoda.sync_placeable"
    bl_label = "Sync Placeable"
    bl_description = "Sync placeable data with selected mesh objects"

    def get_config(self) -> Dict[str, Any]:
        config = TwoDAConstants.get_config("placeables")
        config["file_type"] = "placeables"
        return config

    def execute(self, context) -> set:
        return self.execute_auto_sync(context)

class TWODA_OT_SyncAppearance(bpy.types.Operator, TwoDABaseOperator):
    """Sync appearance data with character armatures - WITH ROW DIALOG"""
    bl_idname = "twoda.sync_appearance"
    bl_label = "Sync Appearance"
    bl_description = "Sync appearance data with selected armature"

    def get_config(self) -> Dict[str, Any]:
        config = TwoDAConstants.get_config("appearance")
        config["file_type"] = "appearance"
        return config

    def execute(self, context) -> set:
        return self.execute_auto_sync(context)

class TWODA_OT_SyncWingmodel(bpy.types.Operator, TwoDABaseOperator):
    """Sync wing model data with selected armatures and mesh - WITH ROW DIALOG"""
    bl_idname = "twoda.sync_wingmodel"
    bl_label = "Sync Wingmodel"
    bl_description = "Sync wing model data from selected objects (2 armatures + 1 mesh)"

    def get_config(self) -> Dict[str, Any]:
        config = TwoDAConstants.get_config("wingmodel")
        config["file_type"] = "wingmodel"
        return config

    def execute(self, context) -> set:
        return self.execute_auto_sync(context)

class TWODA_OT_SyncTailmodel(bpy.types.Operator, TwoDABaseOperator):
    """Sync tail model data with selected armatures and mesh - WITH ROW DIALOG"""
    bl_idname = "twoda.sync_tailmodel"
    bl_label = "Sync Tailmodel"
    bl_description = "Sync tail model data from selected objects (2 armatures + 1 mesh)"

    def get_config(self) -> Dict[str, Any]:
        config = TwoDAConstants.get_config("tailmodel")
        config["file_type"] = "tailmodel"
        return config

    def execute(self, context) -> set:
        return self.execute_auto_sync(context)

class TWODA_OT_SyncBaseitem(bpy.types.Operator, TwoDABaseOperator):
    """Sync base item data with selected mesh objects - WITH ROW DIALOG"""
    bl_idname = "twoda.sync_baseitem"
    bl_label = "Sync Base Item"
    bl_description = "Sync base item data with selected mesh objects"

    def get_config(self) -> Dict[str, Any]:
        config = TwoDAConstants.get_config("baseitem")
        config["file_type"] = "baseitem"
        return config

    def execute(self, context) -> set:
        return self.execute_auto_sync(context)

class TWODA_OT_DeactivateSync(bpy.types.Operator):
    """Deactivate sync for the active 2DA file"""
    bl_idname = "twoda.deactivate_sync"
    bl_label = "Deactivate Sync"
    bl_description = "Deactivate synchronization for the current 2DA file"
    
    file_type: StringProperty()
    
    def execute(self, context):
        file_data = getattr(context.scene, f"{self.file_type}_data", None)
        if file_data:
            file_data.sync_active = False
            file_data.last_sync_name = ""
            self.report({'INFO'}, f"Sync deactivated for {self.file_type}")
        return {'FINISHED'}

class TWODA_OT_ApplyChanges(bpy.types.Operator):
    """Apply and save changes to the active 2DA file"""
    bl_idname = "twoda.apply_changes"
    bl_label = "Save Changes"
    bl_description = "Save all changes to the original 2DA file"
    
    @classmethod
    def poll(cls, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        return file_data.file_loaded
    
    def execute(self, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        config = TwoDAConstants.get_config(active_tab)
        
        if not file_data.file_loaded:
            self.report({'ERROR'}, "No 2DA file loaded")
            return {'CANCELLED'}
        
        # Try to save back to the original file location
        # You'll need to store the original filepath when loading
        if hasattr(file_data, 'original_filepath') and file_data.original_filepath:
            filepath = file_data.original_filepath
        else:
            # Fallback: ask for location
            return bpy.ops.twoda.export_file('INVOKE_DEFAULT')
        
        return self.save_2da_file(context, filepath)
    
    def save_2da_file(self, context, filepath):
        """Save 2DA data to file"""
        try:
            scene = context.scene
            active_tab = scene.twoda_active_tab
            file_data = getattr(scene, f"{active_tab}_data")
            
            # Get headers (excluding RowNumber if present)
            headers = [h for h in file_data.headers.split(',') if h and h != "RowNumber"]
            
            # Build file content with perfect NWN2 formatting
            content = [
                "2DA V2.0",
                "",
                "\t" + "\t".join(headers)  # Exactly one tab before headers
            ]
            
            # Add data rows
            for row_idx, row in enumerate(file_data.rows):
                row_values = [str(row_idx)]  # Row number
                row_values.extend(str(getattr(row, header, "****")) for header in headers)
                content.append("\t".join(row_values))
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            # Write file with proper newlines
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write("\n".join(content))
            
            self.report({'INFO'}, f"Successfully saved: {os.path.basename(filepath)}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Save failed: {str(e)}")
            return {'CANCELLED'}

class TWODA_OT_UndoChanges(bpy.types.Operator):
    """Undo all changes to the active 2DA file"""
    bl_idname = "twoda.undo_changes"
    bl_label = "Undo Changes"
    bl_description = "Reload the 2DA file to undo all changes"
    
    @classmethod
    def poll(cls, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        return file_data.file_loaded
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Are you sure you want to undo all changes?")
        layout.label(text="This will reload the original file.")
    
    def execute(self, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        config = TwoDAConstants.get_config(active_tab)
        
        if not config:
            self.report({'ERROR'}, "No active 2DA configuration")
            return {'CANCELLED'}
            
        # Find the original file path (this would need to be stored when loading)
        # For now, we'll just report that we can't undo without the original path
        self.report({'ERROR'}, "Original file path not stored - cannot undo")
        return {'CANCELLED'}

class TWODA_OT_NavigateRows(bpy.types.Operator):
    """Navigate through 2DA rows"""
    bl_idname = "twoda.navigate_rows"
    bl_label = "Navigate Rows"
    bl_description = "Navigate through 2DA rows"

    direction: bpy.props.EnumProperty(
        items=[
            ('UP', "Up", ""),
            ('DOWN', "Down", ""),
            ('NEXT_MATCH_UP', "Next Match Up", ""),
            ('NEXT_MATCH_DOWN', "Next Match Down", "")
        ]
    )
    
    def execute(self, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        _, display_attr = TwoDAConstants.get_display_attributes(active_tab)
        
        current_idx = file_data.active_index
        current_value = getattr(file_data.rows[current_idx], display_attr, "")
        
        if self.direction == 'UP' and current_idx > 0:
            file_data.active_index = current_idx - 1
        elif self.direction == 'DOWN' and current_idx < len(file_data.rows) - 1:
            file_data.active_index = current_idx + 1
        elif self.direction == 'NEXT_MATCH_UP':
            for i in range(current_idx - 1, -1, -1):
                if getattr(file_data.rows[i], display_attr, "") == current_value:
                    file_data.active_index = i
                    break
        elif self.direction == 'NEXT_MATCH_DOWN':
            for i in range(current_idx + 1, len(file_data.rows)):
                if getattr(file_data.rows[i], display_attr, "") == current_value:
                    file_data.active_index = i
                    break
        
        return {'FINISHED'}

class TWODA_OT_FilterRows(bpy.types.Operator):
    """Apply name filter to 2DA rows"""
    bl_idname = "twoda.filter_rows"
    bl_label = "Filter Rows"
    bl_description = "Filter 2DA rows based on text input"

    filter_text: bpy.props.StringProperty(name="Filter Text", default="")
    
    def execute(self, context):
        # Check if sync is active
        file_type = context.scene.twoda_active_tab
        file_data = getattr(context.scene, f"{file_type}_data")
        
        if file_data.sync_active:
            self.report({'WARNING'}, "Cannot filter while sync is active")
            return {'CANCELLED'}
        
        # The actual filtering is handled by the UIList's filter_items method
        return {'FINISHED'}

# ==============================================
# NEW OPERATORS FOR ROW MANAGEMENT
# ==============================================

class TWODA_OT_AddRow(bpy.types.Operator):
    """Add a new row to the active 2DA file"""
    bl_idname = "twoda.add_row"
    bl_label = "Add Row"
    bl_description = "Add a new row to the 2DA file"
    
    def execute(self, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        config = TwoDAConstants.get_config(active_tab)
        
        if not file_data.file_loaded:
            self.report({'ERROR'}, "No 2DA file loaded")
            return {'CANCELLED'}
        
        # Add new row
        new_row = file_data.rows.add()
        new_row.index = len(file_data.rows) - 1
        new_row.RowNumber = str(new_row.index)
        
        # Initialize with default values for all headers
        headers = file_data.headers.split(',') if file_data.headers else []
        defaults = config.get("defaults", {})
        for header in headers:
            if header != "RowNumber":
                default_value = defaults.get(header, "****")
                setattr(new_row, header, default_value)
        
        # Set as active
        file_data.active_index = new_row.index
        
        self.report({'INFO'}, f"Added row {new_row.index}")
        return {'FINISHED'}

class TWODA_OT_RemoveRow(bpy.types.Operator):
    """Remove the active row from the 2DA file"""
    bl_idname = "twoda.remove_row"
    bl_label = "Remove Row"
    bl_description = "Remove the active row from the 2DA file"
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Are you sure you want to remove this row?")
    
    def execute(self, context):
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        
        if not file_data.file_loaded:
            self.report({'ERROR'}, "No 2DA file loaded")
            return {'CANCELLED'}
        
        if len(file_data.rows) == 0:
            self.report({'ERROR'}, "No rows to remove")
            return {'CANCELLED'}
        
        # Remove the active row
        active_index = file_data.active_index
        if 0 <= active_index < len(file_data.rows):
            file_data.rows.remove(active_index)
            
            # Update indices for remaining rows
            for i, row in enumerate(file_data.rows):
                row.index = i
                row.RowNumber = str(i)
            
            # Adjust active index if needed
            if file_data.active_index >= len(file_data.rows):
                file_data.active_index = max(0, len(file_data.rows) - 1)
            
            self.report({'INFO'}, f"Removed row {active_index}")
        else:
            self.report({'ERROR'}, "Invalid row index")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class TWODA_OT_ExportFile(bpy.types.Operator):
    """Export the active 2DA file"""
    bl_idname = "twoda.export_file"
    bl_label = "Export 2DA File"
    bl_description = "Export the active 2DA file to disk"
    
    filepath: bpy.props.StringProperty(
        name="File Path",
        description="Path to save the 2DA file",
        subtype='FILE_PATH',
        default=""
    )
    
    filter_glob: bpy.props.StringProperty(
        default="*.2da",
        options={'HIDDEN'}
    )
    
    def invoke(self, context, event):
        # Set default filename based on active tab
        scene = context.scene
        active_tab = scene.twoda_active_tab
        config = TwoDAConstants.get_config(active_tab)
        
        if not config:
            self.report({'ERROR'}, "No active 2DA configuration")
            return {'CANCELLED'}
            
        # Set default path to NWN2 override directory with the configured filename
        nwn2_dir = os.path.expanduser("~/Documents/Neverwinter Nights 2/override")
        self.filepath = os.path.join(nwn2_dir, config["filename"])
        
        # Show file browser
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        # Validate filepath
        if not self.filepath:
            self.report({'ERROR'}, "No file selected")
            return {'CANCELLED'}
            
        # Ensure it has .2da extension
        if not self.filepath.lower().endswith('.2da'):
            self.filepath += '.2da'
        
        scene = context.scene
        active_tab = scene.twoda_active_tab
        file_data = getattr(scene, f"{active_tab}_data")
        
        if not file_data.file_loaded:
            self.report({'ERROR'}, "No 2DA file loaded")
            return {'CANCELLED'}
            
        try:
            # Get headers (excluding RowNumber if present)
            headers = [h for h in file_data.headers.split(',') if h and h != "RowNumber"]
            
            # Build file content with perfect NWN2 formatting
            content = [
                "2DA V2.0",
                "",
                "\t" + "\t".join(headers)  # Exactly one tab before headers
            ]
            
            # Add data rows
            for row_idx, row in enumerate(file_data.rows):
                row_values = [str(row_idx)]  # Row number
                row_values.extend(str(getattr(row, header, "****")) for header in headers)
                content.append("\t".join(row_values))
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
            
            # Write file with proper newlines
            with open(self.filepath, 'w', encoding='utf-8') as f:
                f.write("\n".join(content))
            
            self.report({'INFO'}, f"Successfully exported: {os.path.basename(self.filepath)}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}

# ==============================================
# TOOLTIP OPERATOR
# ==============================================

class TWODA_OT_ShowTooltip(bpy.types.Operator):
    """Show column description tooltip"""
    bl_idname = "twoda.show_tooltip"
    bl_label = "Column Description"
    bl_description = "Show column description"
    
    tooltip_text: StringProperty(name="Tooltip Text", default="")
    
    def execute(self, context):
        # This operator doesn't do anything, it's just for tooltips
        return {'FINISHED'}
    
    def invoke(self, context, event):
        # Show tooltip in popup
        return context.window_manager.invoke_popup(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Column Description", icon='INFO')
        layout.separator()
        
        # Split the tooltip text into lines
        lines = self.tooltip_text.split('\n')
        for line in lines:
            layout.label(text=line)

# ==============================================
# AUTO-SYNC UPDATE HANDLER
# ==============================================

class TwoDAAutoSyncHandler:
    """Handles automatic updates when sync is active and objects change."""
    
    _handler = None
    
    @classmethod
    def register(cls):
        """Register the auto-sync update handler."""
        if cls._handler is None:
            cls._handler = bpy.app.handlers.depsgraph_update_post.append(cls.auto_sync_update)
    
    @classmethod
    def unregister(cls):
        """Unregister the auto-sync update handler."""
        if cls._handler is not None:
            try:
                bpy.app.handlers.depsgraph_update_post.remove(cls._handler)
            except ValueError:
                pass
            cls._handler = None
    
    @classmethod
    def auto_sync_update(cls, scene, depsgraph):
        """Automatically update synced entries when objects change."""
        try:
            # Only update if there are changes to objects
            if not any(update.is_updated_geometry for update in depsgraph.updates):
                return
            
            # Check each file type for active sync
            for file_type in TwoDAConstants.get_file_types():
                file_data = getattr(scene, f"{file_type}_data", None)
                if not file_data or not file_data.sync_active:
                    continue
                
                # Find the object that's being synced
                obj_name = file_data.last_sync_name
                if not obj_name:
                    continue
                
                obj = bpy.data.objects.get(obj_name)
                if not obj:
                    continue
                
                # Check if object still exists and is selected
                if obj.name not in [o.name for o in bpy.context.selected_objects]:
                    # Object no longer selected, deactivate sync
                    file_data.sync_active = False
                    file_data.last_sync_name = ""
                    continue
                
                # Update the synced entry
                config = TwoDAConstants.get_config(file_type)
                identifier_attr = config.get("identifier_attr", "")
                existing_row = TwoDASyncManager.find_existing_entry(
                    file_data, obj.name, identifier_attr
                )
                
                if existing_row is not None:
                    TwoDASyncManager.update_existing_entry(bpy.context, file_type, obj, existing_row)
                    
        except Exception as e:
            # Silently fail to avoid breaking Blender
            print(f"Auto-sync update error: {e}")

# ==============================================
# UI LIST - FIXED SCROLLING VERSION
# ==============================================

class NWN2_UL_2DAList(bpy.types.UIList):
    """Custom UI list for displaying 2DA file rows with filtering and navigation."""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Get display info from config
            file_type = context.scene.twoda_active_tab
            icon, display_attr = TwoDAConstants.get_display_attributes(file_type)
            
            # Combined display showing icon, row number, and label
            row = layout.row()
            row.label(text="", icon=icon)
            
            # Show row number and display attribute in one line
            row_num = getattr(item, "RowNumber", str(index))
            display_value = getattr(item, display_attr, "****")
            
            # Apply filter highlight if active
            if hasattr(self, 'filter_name') and self.filter_name:
                if self.filter_name.lower() in display_value.lower():
                    row.alert = True
            
            row.label(text=f"{row_num}: {display_value}")
            
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text=f"Row {index}")
    
    def draw_filter(self, context, layout):
        """Draw the filter controls"""
        # Check if sync is active for the current tab
        file_type = context.scene.twoda_active_tab
        file_data = getattr(context.scene, f"{file_type}_data")
        
        # Only show filter controls if sync is not active
        if not file_data.sync_active:
            row = layout.row()
            
            # Filter input
            row.prop(self, "filter_name", text="")
            
            # Filter button
            filter_op = row.operator("twoda.filter_rows", text="", icon='FILTER')
            filter_op.filter_text = self.filter_name
            
            # Navigation buttons
            nav_row = layout.row(align=True)
            
            # Add/Remove buttons
            nav_row.operator("twoda.add_row", text="", icon='ADD')
            nav_row.operator("twoda.remove_row", text="", icon='REMOVE')
            
            # Move buttons
            move_row = nav_row.row(align=True)
            up_op = move_row.operator("twoda.navigate_rows", text="", icon='TRIA_UP')
            up_op.direction = 'UP'
            down_op = move_row.operator("twoda.navigate_rows", text="", icon='TRIA_DOWN')
            down_op.direction = 'DOWN'
            
            # Match buttons
            match_row = nav_row.row(align=True)
            match_up_op = match_row.operator("twoda.navigate_rows", text="", icon='TRIA_UP')
            match_up_op.direction = 'NEXT_MATCH_UP'
            match_down_op = match_row.operator("twoda.navigate_rows", text="", icon='TRIA_DOWN')
            match_down_op.direction = 'NEXT_MATCH_DOWN'
        else:
            # Show a message when sync is active
            layout.label(text="Filtering disabled during sync", icon='INFO')
    
    def filter_items(self, context, data, propname):
        """Filter items by name/label"""
        items = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list
        
        # Get display attribute for filtering
        file_type = context.scene.twoda_active_tab
        file_data = getattr(context.scene, f"{file_type}_data")
        
        # Only apply filtering if sync is not active
        if not file_data.sync_active:
            _, display_attr = TwoDAConstants.get_display_attributes(file_type)
            
            # Filter by name if filter is set
            if self.filter_name:
                filtered = helper_funcs.filter_items_by_name(
                    self.filter_name, self.bitflag_filter_item, items, 
                    "name", reverse=self.use_filter_sort_reverse
                )
            else:
                filtered = [self.bitflag_filter_item] * len(items)
            
            # Apply custom filtering based on display attribute
            if self.filter_name:
                for i, item in enumerate(items):
                    display_value = getattr(item, display_attr, "")
                    if self.filter_name.lower() not in display_value.lower():
                        filtered[i] = 0
        else:
            # No filtering when sync is active
            filtered = [self.bitflag_filter_item] * len(items)
        
        # No special ordering
        ordered = helper_funcs.sort_items_by_name(items, "name")
        
        return filtered, ordered

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    TwoDARow,
    TwoDAFileData,
    NWN2_UL_2DAList,
    TWODA_OT_SelectFolder,
    TWODA_OT_SyncPlaceable,
    TWODA_OT_SyncAppearance,
    TWODA_OT_SyncWingmodel,
    TWODA_OT_SyncBaseitem,
    TWODA_OT_SyncTailmodel,
    TWODA_OT_DeactivateSync,
    TWODA_OT_ApplyChanges,
    TWODA_OT_UndoChanges,
    TWODA_OT_NavigateRows,
    TWODA_OT_FilterRows,
    TWODA_OT_AddRow,
    TWODA_OT_RemoveRow,
    TWODA_OT_ExportFile,
    TWODA_OT_ShowTooltip,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register 2DA file type properties
    for file_type in TwoDAConstants.get_file_types():
        setattr(bpy.types.Scene, f"{file_type}_data", PointerProperty(type=TwoDAFileData))

    bpy.types.Scene.twoda_active_tab = EnumProperty(
        items=[(ft, TwoDAConstants.get_config(ft)["filename"], "")
               for ft in TwoDAConstants.get_file_types()],
        name="Active 2DA Tab",
        description="Currently selected 2DA file type",
        default="placeables"
    )

    bpy.types.Scene.row_details_expanded = BoolProperty(
        name="Row Details Expanded",
        description="Show row editing fields",
        default=False
    )
    
    # Register auto-sync handler
    TwoDAAutoSyncHandler.register()

def unregister():
    # Unregister auto-sync handler first
    TwoDAAutoSyncHandler.unregister()
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # Unregister 2DA file type properties
    for file_type in TwoDAConstants.get_file_types():
        if hasattr(bpy.types.Scene, f"{file_type}_data"):
            delattr(bpy.types.Scene, f"{file_type}_data")
    
    del bpy.types.Scene.twoda_active_tab
    del bpy.types.Scene.row_details_expanded

if __name__ == "__main__":
    register()