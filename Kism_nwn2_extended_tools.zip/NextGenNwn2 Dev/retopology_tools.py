import bpy
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       EnumProperty,
                       PointerProperty)
import time

# ==============================================
# RETOPOLOGY TOOLS SYSTEM - UPDATED WITH MODAL BAKE OPERATOR
# ==============================================

class Retopology_BakeSettings(PropertyGroup):
    """Property group for bake settings - Complete with all options"""
    bake_type: EnumProperty(
        name="Bake Type",
        description="Type of baking",
        items=[
            ('COMBINED', 'Combined', 'Bake combined textures'),
            ('AO', 'Ambient Occlusion', 'Bake ambient occlusion'),
            ('SHADOW', 'Shadow', 'Bake shadow maps'),
            ('POSITION', 'Position', 'Bake position maps'),
            ('NORMAL', 'Normal', 'Bake normal maps'),
            ('UV', 'UV', 'Bake UV maps'),
            ('ROUGHNESS', 'Roughness', 'Bake roughness maps'),
            ('EMIT', 'Emit', 'Bake emission maps'),
            ('ENVIRONMENT', 'Environment', 'Bake environment maps'),
            ('DIFFUSE', 'Diffuse', 'Bake diffuse maps'),
            ('GLOSSY', 'Glossy', 'Bake glossy maps'),
            ('TRANSMISSION', 'Transmission', 'Bake transmission maps'),
            ('METALLIC', 'Metallic', 'Bake metallic maps'),
        ],
        default='DIFFUSE'
    )
    
    bake_width: IntProperty(
        name="Width",
        description="Bake texture width",
        default=1024,
        min=32,
        max=8192
    )
    
    bake_height: IntProperty(
        name="Height",
        description="Bake texture height",
        default=1024,
        min=32,
        max=8192
    )
    
    bake_margin: IntProperty(
        name="Margin",
        description="Bake margin in pixels",
        default=16,
        min=0,
        max=64
    )
    
    margin_type: EnumProperty(
        name="Margin Type",
        description="Type of margin to use",
        items=[
            ('EXTEND', 'Extend', 'Extend existing pixels'),
            ('ADJACENT_FACES', 'Adjacent Faces', 'Adjacent faces'),
        ],
        default='EXTEND'
    )
    
    use_selected_to_active: BoolProperty(
        name="Selected to Active",
        description="Bake from selected objects to active object",
        default=False
    )
    
    use_cage: BoolProperty(
        name="Use Cage",
        description="Use cage for baking",
        default=False
    )
    
    cage_object: PointerProperty(
        name="Cage Object",
        description="Object to use as cage",
        type=bpy.types.Object
    )
    
    cage_extrusion: FloatProperty(
        name="Cage Extrusion",
        description="Extrusion for cage baking",
        default=0.0,
        min=0.0,
        max=10.0
    )
    
    max_ray_distance: FloatProperty(
        name="Max Ray Distance",
        description="Maximum ray distance for baking",
        default=0.0,
        min=0.0,
        max=1000.0
    )
    
    bake_samples: IntProperty(
        name="Samples",
        description="Number of samples for baking",
        default=16,
        min=1,
        max=1024
    )
    
    override_existing: BoolProperty(
        name="Override Existing",
        description="Override existing material when setting up PBR",
        default=True
    )
    
    # Bake target
    target: EnumProperty(
        name="Target",
        description="Where to output baked texture",
        items=[
            ('IMAGE_TEXTURES', 'Image Textures', 'Bake to image textures'),
            ('VERTEX_COLORS', 'Vertex Colors', 'Bake to vertex colors'),
        ],
        default='IMAGE_TEXTURES'
    )
    
    use_clear: BoolProperty(
        name="Clear Image",
        description="Clear image before baking",
        default=True
    )
    
    # View settings - updated for Blender 4.3+
    view_from: EnumProperty(
        name="View From",
        description="Direction from which to view the bake",
        items=[
            ('ACTIVE_CAMERA', 'Active Camera', 'Use active camera view'),
            ('ABOVE_SURFACE', 'Above Surface', 'View from above surface'),
        ],
        default='ACTIVE_CAMERA'
    )
    
    # Normal map specific settings
    normal_space: EnumProperty(
        name="Normal Space",
        description="Space for normal maps",
        items=[
            ('TANGENT', 'Tangent', 'Tangent space'),
            ('OBJECT', 'Object', 'Object space'),
            ('WORLD', 'World', 'World space'),
        ],
        default='TANGENT'
    )
    
    normal_r: EnumProperty(
        name="R",
        description="Swizzle for red channel",
        items=[
            ('POS_X', '+X', 'Positive X'),
            ('POS_Y', '+Y', 'Positive Y'),
            ('POS_Z', '+Z', 'Positive Z'),
            ('NEG_X', '-X', 'Negative X'),
            ('NEG_Y', '-Y', 'Negative Y'),
            ('NEG_Z', '-Z', 'Negative Z'),
        ],
        default='POS_X'
    )
    
    normal_g: EnumProperty(
        name="G",
        description="Swizzle for green channel",
        items=[
            ('POS_X', '+X', 'Positive X'),
            ('POS_Y', '+Y', 'Positive Y'),
            ('POS_Z', '+Z', 'Positive Z'),
            ('NEG_X', '-X', 'Negative X'),
            ('NEG_Y', '-Y', 'Negative Y'),
            ('NEG_Z', '-Z', 'Negative Z'),
        ],
        default='POS_Y'
    )
    
    normal_b: EnumProperty(
        name="B",
        description="Swizzle for blue channel",
        items=[
            ('POS_X', '+X', 'Positive X'),
            ('POS_Y', '+Y', 'Positive Y'),
            ('POS_Z', '+Z', 'Positive Z'),
            ('NEG_X', '-X', 'Negative X'),
            ('NEG_Y', '-Y', 'Negative Y'),
            ('NEG_Z', '-Z', 'Negative Z'),
        ],
        default='POS_Z'
    )
    
    # Combined bake settings
    use_pass_direct: BoolProperty(
        name="Direct",
        description="Include direct lighting",
        default=True
    )
    
    use_pass_indirect: BoolProperty(
        name="Indirect",
        description="Include indirect lighting",
        default=True
    )
    
    use_pass_diffuse: BoolProperty(
        name="Diffuse",
        description="Include diffuse contribution",
        default=True
    )
    
    use_pass_glossy: BoolProperty(
        name="Glossy",
        description="Include glossy contribution",
        default=True
    )
    
    use_pass_transmission: BoolProperty(
        name="Transmission",
        description="Include transmission contribution",
        default=True
    )
    
    use_pass_emit: BoolProperty(
        name="Emit",
        description="Include emission contribution",
        default=True
    )
    
    # Diffuse/Glossy/Transmission bake settings
    use_pass_color: BoolProperty(
        name="Color",
        description="Include color contribution",
        default=True
    )
    
    # Progress tracking
    bake_progress: IntProperty(
        name="Bake Progress",
        default=0,
        min=0,
        max=100,
        subtype='PERCENTAGE'
    )
    
    # Bake counter for modal operator
    bake_counter: IntProperty(
        name="Bake Counter",
        default=0
    )
    
    # Additional properties for compatibility with merge_texture_tools
    
    # Direct reference to margin property (for compatibility)
    margin: IntProperty(
        name="Margin",
        description="Bake margin in pixels (compatibility property)",
        default=16,
        min=0,
        max=64
    )
    
    # Batch bake support
    batch_bake: BoolProperty(
        name="Batch Bake",
        description="Bake multiple textures at once",
        default=False
    )
    
    # Texture format
    file_format: EnumProperty(
        name="File Format",
        description="Format for saved textures",
        items=[
            ('PNG', 'PNG', 'PNG format (lossless)'),
            ('JPEG', 'JPEG', 'JPEG format (compressed)'),
            ('TIFF', 'TIFF', 'TIFF format (high quality)'),
            ('OPEN_EXR', 'OpenEXR', 'OpenEXR format (HDR)'),
        ],
        default='PNG'
    )
    
    # Color depth
    color_depth: EnumProperty(
        name="Color Depth",
        description="Color depth for saved textures",
        items=[
            ('8', '8-bit', '8 bits per channel'),
            ('16', '16-bit', '16 bits per channel'),
            ('32', '32-bit', '32 bits per channel (float)'),
        ],
        default='8'
    )
    
    # Color mode
    color_mode: EnumProperty(
        name="Color Mode",
        description="Color mode for saved textures",
        items=[
            ('RGB', 'RGB', 'RGB color'),
            ('RGBA', 'RGBA', 'RGBA with alpha'),
            ('BW', 'BW', 'Black and white'),
        ],
        default='RGBA'
    )
    
    # Compression (for PNG)
    compression: IntProperty(
        name="Compression",
        description="Compression level for PNG files",
        default=15,
        min=0,
        max=100
    )
    
    # Quality (for JPEG)
    quality: IntProperty(
        name="Quality",
        description="Quality level for JPEG files",
        default=90,
        min=0,
        max=100
    )
    
    # EXR settings
    exr_codec: EnumProperty(
        name="EXR Codec",
        description="Compression codec for OpenEXR files",
        items=[
            ('NONE', 'None', 'No compression'),
            ('PXR24', 'Pxr24', 'Pxr24 compression'),
            ('ZIP', 'Zip', 'Zip compression'),
            ('ZIPS', 'Zips', 'Zips compression'),
            ('RLE', 'RLE', 'RLE compression'),
            ('DWAA', 'DWAA', 'DWAA compression'),
            ('DWAB', 'DWAB', 'DWAB compression'),
        ],
        default='ZIP'
    )
    
    # Preview settings
    show_preview: BoolProperty(
        name="Show Preview",
        description="Show preview of baked texture",
        default=True
    )
    
    preview_size: EnumProperty(
        name="Preview Size",
        description="Size of the preview image",
        items=[
            ('256', '256', '256x256 pixels'),
            ('512', '512', '512x512 pixels'),
            ('1024', '1024', '1024x1024 pixels'),
            ('FULL', 'Full', 'Full size'),
        ],
        default='512'
    )
    
    # Auto-save settings
    auto_save: BoolProperty(
        name="Auto Save",
        description="Automatically save baked textures",
        default=True
    )
    
    save_directory: StringProperty(
        name="Save Directory",
        description="Directory to save baked textures",
        subtype='DIR_PATH',
        default=""
    )
    
    # Naming convention
    naming_convention: EnumProperty(
        name="Naming Convention",
        description="Naming convention for saved textures",
        items=[
            ('OBJECT', 'Object Name', 'Use object name'),
            ('MATERIAL', 'Material Name', 'Use material name'),
            ('CUSTOM', 'Custom', 'Custom naming pattern'),
        ],
        default='OBJECT'
    )
    
    custom_name: StringProperty(
        name="Custom Name",
        description="Custom name for baked textures",
        default="baked_texture"
    )
    
    # Include suffix
    include_suffix: BoolProperty(
        name="Include Suffix",
        description="Include bake type as suffix",
        default=True
    )
    
    # Overwrite existing files
    overwrite_existing: BoolProperty(
        name="Overwrite Existing",
        description="Overwrite existing texture files",
        default=True
    )
    
    # Bake passes
    bake_passes: EnumProperty(
        name="Bake Passes",
        description="Which passes to bake",
        items=[
            ('SINGLE', 'Single', 'Bake single pass'),
            ('ALL', 'All', 'Bake all passes'),
            ('CUSTOM', 'Custom', 'Custom selection'),
        ],
        default='SINGLE'
    )
    
    # Custom passes selection
    bake_diffuse: BoolProperty(
        name="Diffuse",
        description="Bake diffuse pass",
        default=True
    )
    
    bake_normal: BoolProperty(
        name="Normal",
        description="Bake normal pass",
        default=True
    )
    
    bake_roughness: BoolProperty(
        name="Roughness",
        description="Bake roughness pass",
        default=True
    )
    
    bake_metallic: BoolProperty(
        name="Metallic",
        description="Bake metallic pass",
        default=False
    )
    
    bake_emission: BoolProperty(
        name="Emission",
        description="Bake emission pass",
        default=False
    )
    
    bake_alpha: BoolProperty(
        name="Alpha",
        description="Bake alpha pass",
        default=False
    )
    
    # UV layer selection
    uv_layer: StringProperty(
        name="UV Layer",
        description="UV layer to use for baking",
        default=""
    )
    
    # Active UV layer
    use_active_uv: BoolProperty(
        name="Use Active UV",
        description="Use active UV layer for baking",
        default=True
    )
    
    # Ray distance for baking
    ray_distance: FloatProperty(
        name="Ray Distance",
        description="Ray distance for baking",
        default=0.001,
        min=0.0,
        max=1.0,
        precision=4
    )
    
    # Bias for baking
    bias: FloatProperty(
        name="Bias",
        description="Bias for baking",
        default=0.001,
        min=0.0,
        max=1.0,
        precision=4
    )
    
    # Max polygon offset
    max_polygon_offset: FloatProperty(
        name="Max Polygon Offset",
        description="Maximum polygon offset for baking",
        default=0.1,
        min=0.0,
        max=10.0
    )
    
    # Use pixel center
    use_pixel_center: BoolProperty(
        name="Use Pixel Center",
        description="Use pixel center for sampling",
        default=False
    )
    
    # Use denoising
    use_denoising: BoolProperty(
        name="Use Denoising",
        description="Use denoising for cleaner bakes",
        default=False
    )
    
    # Denoising strength
    denoising_strength: FloatProperty(
        name="Denoising Strength",
        description="Strength of denoising",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    # Use adaptive sampling
    use_adaptive_sampling: BoolProperty(
        name="Use Adaptive Sampling",
        description="Use adaptive sampling for better performance",
        default=True
    )
    
    # Adaptive sampling threshold
    adaptive_sampling_threshold: FloatProperty(
        name="Adaptive Sampling Threshold",
        description="Threshold for adaptive sampling",
        default=0.01,
        min=0.0,
        max=0.1,
        precision=3
    )
    
    # Use tiling
    use_tiling: BoolProperty(
        name="Use Tiling",
        description="Use tiled baking for large textures",
        default=False
    )
    
    # Tile size
    tile_size: IntProperty(
        name="Tile Size",
        description="Size of tiles for tiled baking",
        default=512,
        min=128,
        max=2048
    )
    
    # Overlap between tiles
    tile_overlap: IntProperty(
        name="Tile Overlap",
        description="Overlap between tiles in pixels",
        default=8,
        min=0,
        max=64
    )
    
    # Performance settings
    use_gpu: BoolProperty(
        name="Use GPU",
        description="Use GPU for baking (if available)",
        default=True
    )
    
    # Memory limit
    memory_limit: IntProperty(
        name="Memory Limit",
        description="Memory limit for baking in MB",
        default=4096,
        min=256,
        max=32768
    )
    
    # Threads count
    threads_count: IntProperty(
        name="Threads",
        description="Number of threads to use for baking",
        default=0,
        min=0,
        max=64
    )
    
    # Verbose output
    verbose_output: BoolProperty(
        name="Verbose Output",
        description="Show detailed bake information",
        default=False
    )

class Retopology_DecimateSettings(PropertyGroup):
    """Property group for decimate settings"""
    decimate_ratio: FloatProperty(
        name="Ratio",
        description="Decimate ratio (0.0 to 1.0)",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3
    )
    
    decimate_type: EnumProperty(
        name="Decimate Type",
        description="Type of decimation",
        items=[
            ('COLLAPSE', 'Collapse', 'Edge collapse decimation'),
            ('UNSUBDIV', 'Un-Subdivide', 'Reverse subdivision'),
            ('DISSOLVE', 'Planar', 'Dissolve planar faces'),
        ],
        default='COLLAPSE'
    )
    
    use_collapse_triangulate: BoolProperty(
        name="Triangulate",
        description="Triangulate faces during collapse",
        default=True
    )
    
    use_symmetry: BoolProperty(
        name="Symmetry",
        description="Maintain symmetry during decimation",
        default=False
    )
    
    symmetry_axis: EnumProperty(
        name="Symmetry Axis",
        description="Axis for symmetry",
        items=[
            ('X', 'X', 'X axis symmetry'),
            ('Y', 'Y', 'Y axis symmetry'),
            ('Z', 'Z', 'Z axis symmetry'),
        ],
        default='X'
    )
    
    vertex_group: StringProperty(
        name="Vertex Group",
        description="Vertex group to influence decimation",
        default=""
    )
    
    vertex_group_factor: FloatProperty(
        name="Vertex Group Factor",
        description="Factor for vertex group influence",
        default=0.0,
        min=0.0,
        max=10.0
    )
    
    invert_vertex_group: BoolProperty(
        name="Invert Vertex Group",
        description="Invert vertex group influence",
        default=False
    )


class Retopology_DisplaceSettings(PropertyGroup):
    """Property group for displace settings"""
    displace_strength: FloatProperty(
        name="Strength",
        description="Displacement strength",
        default=1.0,
        min=-10.0,
        max=10.0
    )
    
    displace_midlevel: FloatProperty(
        name="Midlevel",
        description="Displacement midlevel",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    displace_direction: EnumProperty(
        name="Direction",
        description="Displacement direction",
        items=[
            ('X', 'X', 'X axis displacement'),
            ('Y', 'Y', 'Y axis displacement'),
            ('Z', 'Z', 'Z axis displacement'),
            ('NORMAL', 'Normal', 'Normal displacement'),
            ('RGB_TO_XYZ', 'RGB to XYZ', 'RGB to XYZ displacement'),
            ('CUSTOM_NORMAL', 'Custom Normal', 'Custom normal displacement'),
        ],
        default='NORMAL'
    )
    
    vertex_group: StringProperty(
        name="Vertex Group",
        description="Vertex group to influence displacement",
        default=""
    )
    
    vertex_group_strength: FloatProperty(
        name="Vertex Group Strength",
        description="Vertex group influence strength for displacement",
        default=1.0,
        min=0.0,
        max=10.0
    )
    
    use_vertex_coords: BoolProperty(
        name="Use Vertex Coordinates",
        description="Use vertex coordinates for displacement",
        default=False
    )
    
    texture_coords: EnumProperty(
        name="Texture Coordinates",
        description="Texture coordinate mapping",
        items=[
            ('LOCAL', 'Local', 'Local coordinates'),
            ('GLOBAL', 'Global', 'Global coordinates'),
            ('OBJECT', 'Object', 'Object coordinates'),
            ('UV', 'UV', 'UV coordinates'),
        ],
        default='LOCAL'
    )
    
    texture_coords_object: PointerProperty(
        name="Texture Object",
        description="Object for texture coordinates",
        type=bpy.types.Object
    )
    
    uv_layer: StringProperty(
        name="UV Layer",
        description="UV layer for texture coordinates",
        default=""
    )


# ----------------------------------------------------------
# Operator: Setup PBR Material
# ----------------------------------------------------------
class Retopology_OT_setup_pbr(Operator):
    bl_idname = "retopology.setup_pbr"
    bl_label = "Setup PBR Material"
    bl_description = "Setup PBR material with image textures. Creates new if none exists, overrides existing."
    
    def execute(self, context):
        # Get selected object
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        # Store original render engine
        original_engine = bpy.context.scene.render.engine
        
        # Ensure we're in Cycles for material setup
        if original_engine != 'CYCLES':
            bpy.context.scene.render.engine = 'CYCLES'
            self.report({'INFO'}, "Temporarily switched to Cycles for PBR setup")
        
        scene = context.scene
        bake_settings = scene.retopology_bake_settings
        
        # Create or override material based on settings
        material_name = "PBR_Material"
        
        # Check if object already has materials
        if obj.data.materials and bake_settings.override_existing:
            # Override existing material
            if len(obj.data.materials) > 0:
                # Get the first material slot
                mat_slot = obj.data.materials[0]
                
                # If the material is used elsewhere, create a new one
                if mat_slot and mat_slot.users > 1:
                    # Create a new material
                    mat = bpy.data.materials.new(name=material_name)
                    obj.data.materials[0] = mat
                    self.report({'INFO'}, "Created new material (existing was shared)")
                elif mat_slot:
                    # Reuse the existing material
                    mat = mat_slot
                    mat.name = material_name
                    self.report({'INFO'}, "Overriding existing material")
                else:
                    # Slot is None, create new
                    mat = bpy.data.materials.new(name=material_name)
                    obj.data.materials[0] = mat
                    self.report({'INFO'}, "Created new material in empty slot")
            else:
                # No materials, create new
                mat = bpy.data.materials.new(name=material_name)
                obj.data.materials.append(mat)
                self.report({'INFO'}, "Created new material")
        else:
            # Always create new material
            mat = bpy.data.materials.new(name=material_name)
            
            # Add to object (append to end of material list)
            if not obj.data.materials:
                obj.data.materials.append(mat)
            else:
                # Replace the first material slot
                obj.data.materials[0] = mat
            self.report({'INFO'}, "Created new material")
        
        # Enable use nodes
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # Clear existing nodes
        nodes.clear()
        
        # Create PBR shader nodes
        bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
        bsdf.location = (300, 300)
        bsdf.inputs['Roughness'].default_value = 0.5
        bsdf.inputs['Metallic'].default_value = 0.0
        
        output = nodes.new(type='ShaderNodeOutputMaterial')
        output.location = (500, 300)
        
        # Create texture coordinate and mapping nodes
        tex_coord = nodes.new(type='ShaderNodeTexCoord')
        tex_coord.location = (-800, 300)
        
        mapping = nodes.new(type='ShaderNodeMapping')
        mapping.location = (-600, 300)
        
        # Create base color texture node
        base_color_tex = nodes.new(type='ShaderNodeTexImage')
        base_color_tex.name = "BaseColor_ImageTexture"
        base_color_tex.label = "Base Color"
        base_color_tex.location = (-300, 450)
        base_color_tex.width = 300
        
        # Create normal map nodes
        normal_tex = nodes.new(type='ShaderNodeTexImage')
        normal_tex.name = "Normal_ImageTexture"
        normal_tex.label = "Normal Map"
        normal_tex.location = (-300, 100)
        normal_tex.width = 300
        
        normal_map = nodes.new(type='ShaderNodeNormalMap')
        normal_map.location = (50, 100)
        
        # Connect nodes
        links.new(tex_coord.outputs['UV'], mapping.inputs['Vector'])
        links.new(mapping.outputs['Vector'], base_color_tex.inputs['Vector'])
        links.new(mapping.outputs['Vector'], normal_tex.inputs['Vector'])
        
        links.new(base_color_tex.outputs['Color'], bsdf.inputs['Base Color'])
        links.new(normal_tex.outputs['Color'], normal_map.inputs['Color'])
        links.new(normal_map.outputs['Normal'], bsdf.inputs['Normal'])
        
        links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        # Create roughness and metallic nodes with visible controls
        roughness_value = nodes.new(type='ShaderNodeValue')
        roughness_value.name = "Roughness_Value"
        roughness_value.label = "Roughness"
        roughness_value.location = (-300, 200)
        roughness_value.outputs[0].default_value = 0.5
        links.new(roughness_value.outputs['Value'], bsdf.inputs['Roughness'])
        
        metallic_value = nodes.new(type='ShaderNodeValue')
        metallic_value.name = "Metallic_Value"
        metallic_value.label = "Metallic"
        metallic_value.location = (-300, 0)
        metallic_value.outputs[0].default_value = 0.0
        links.new(metallic_value.outputs['Value'], bsdf.inputs['Metallic'])
        
        # Organize nodes better
        for node in nodes:
            node.select = False
        
        # Restore original render engine if it was changed
        if original_engine != 'CYCLES':
            try:
                bpy.context.scene.render.engine = original_engine
                engine_name = "Eevee" if original_engine == 'BLENDER_EEVEE' else (
                    "Eevee Next" if original_engine == 'BLENDER_EEVEE_NEXT' else original_engine
                )
                self.report({'INFO'}, f"Restored {engine_name} render engine")
            except Exception as e:
                self.report({'WARNING'}, f"Could not restore render engine: {str(e)}")
        
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Clear Material Slots
# ----------------------------------------------------------
class Retopology_OT_clear_materials(Operator):
    bl_idname = "retopology.clear_materials"
    bl_label = "Clear Materials"
    bl_description = "Remove all material slots from selected object"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        # Clear all material slots
        obj.data.materials.clear()
        self.report({'INFO'}, "Cleared all material slots")
        
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Add New Material Slot
# ----------------------------------------------------------
class Retopology_OT_add_material_slot(Operator):
    bl_idname = "retopology.add_material_slot"
    bl_label = "Add Material Slot"
    bl_description = "Add a new empty material slot"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        # Add new empty material slot
        obj.data.materials.append(None)
        self.report({'INFO'}, "Added new material slot")
        
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Add Decimate Modifier
# ----------------------------------------------------------
class Retopology_OT_add_decimate_modifier(Operator):
    bl_idname = "retopology.add_decimate_modifier"
    bl_label = "Add Decimate Modifier"
    bl_description = "Add a decimate modifier to selected mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Check if decimate modifier already exists
        for mod in obj.modifiers:
            if mod.type == 'DECIMATE':
                self.report({'INFO'}, "Decimate modifier already exists")
                return {'FINISHED'}
        
        # Add decimate modifier
        decimate_mod = obj.modifiers.new(name="Decimate", type='DECIMATE')
        
        # Apply settings from property group
        scene = context.scene
        decimate_settings = scene.retopology_decimate_settings
        
        decimate_mod.ratio = decimate_settings.decimate_ratio
        decimate_mod.decimate_type = decimate_settings.decimate_type
        decimate_mod.use_collapse_triangulate = decimate_settings.use_collapse_triangulate
        decimate_mod.use_symmetry = decimate_settings.use_symmetry
        decimate_mod.symmetry_axis = decimate_settings.symmetry_axis
        
        # Set vertex group if specified
        if decimate_settings.vertex_group:
            decimate_mod.vertex_group = decimate_settings.vertex_group
            decimate_mod.invert_vertex_group = decimate_settings.invert_vertex_group
        decimate_mod.vertex_group_factor = decimate_settings.vertex_group_factor
        
        self.report({'INFO'}, "Added Decimate modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Update Decimate Modifier Settings
# ----------------------------------------------------------
class Retopology_OT_update_decimate_modifier(Operator):
    bl_idname = "retopology.update_decimate_modifier"
    bl_label = "Update Decimate Modifier"
    bl_description = "Update existing decimate modifier settings"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find decimate modifier
        decimate_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DECIMATE':
                decimate_mod = mod
                break
        
        if not decimate_mod:
            self.report({'ERROR'}, "No decimate modifier found")
            return {'CANCELLED'}
        
        # Apply settings from property group
        scene = context.scene
        decimate_settings = scene.retopology_decimate_settings
        
        decimate_mod.ratio = decimate_settings.decimate_ratio
        decimate_mod.decimate_type = decimate_settings.decimate_type
        decimate_mod.use_collapse_triangulate = decimate_settings.use_collapse_triangulate
        decimate_mod.use_symmetry = decimate_settings.use_symmetry
        decimate_mod.symmetry_axis = decimate_settings.symmetry_axis
        
        # Set vertex group if specified
        if decimate_settings.vertex_group:
            decimate_mod.vertex_group = decimate_settings.vertex_group
            decimate_mod.invert_vertex_group = decimate_settings.invert_vertex_group
        decimate_mod.vertex_group_factor = decimate_settings.vertex_group_factor
        
        self.report({'INFO'}, "Updated Decimate modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Apply Decimate Modifier
# ----------------------------------------------------------
class Retopology_OT_apply_decimate_modifier(Operator):
    bl_idname = "retopology.apply_decimate_modifier"
    bl_label = "Apply Decimate Modifier"
    bl_description = "Apply the decimate modifier to the mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find decimate modifier
        decimate_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DECIMATE':
                decimate_mod = mod
                break
        
        if not decimate_mod:
            self.report({'ERROR'}, "No decimate modifier found")
            return {'CANCELLED'}
        
        # Apply the modifier
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=decimate_mod.name)
        
        self.report({'INFO'}, "Applied Decimate modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Remove Decimate Modifier
# ----------------------------------------------------------
class Retopology_OT_remove_decimate_modifier(Operator):
    bl_idname = "retopology.remove_decimate_modifier"
    bl_label = "Remove Decimate Modifier"
    bl_description = "Remove the decimate modifier from the mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find decimate modifier
        decimate_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DECIMATE':
                decimate_mod = mod
                break
        
        if not decimate_mod:
            self.report({'ERROR'}, "No decimate modifier found")
            return {'CANCELLED'}
        
        # Remove the modifier
        obj.modifiers.remove(decimate_mod)
        
        self.report({'INFO'}, "Removed Decimate modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Add Displace Modifier
# ----------------------------------------------------------
class Retopology_OT_add_displace_modifier(Operator):
    bl_idname = "retopology.add_displace_modifier"
    bl_label = "Add Displace Modifier"
    bl_description = "Add a displace modifier to selected mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Check if displace modifier already exists
        for mod in obj.modifiers:
            if mod.type == 'DISPLACE':
                self.report({'INFO'}, "Displace modifier already exists")
                return {'FINISHED'}
        
        # Add displace modifier
        displace_mod = obj.modifiers.new(name="Displace", type='DISPLACE')
        
        # Apply settings from property group
        scene = context.scene
        displace_settings = scene.retopology_displace_settings
        
        displace_mod.strength = displace_settings.displace_strength
        displace_mod.mid_level = displace_settings.displace_midlevel
        displace_mod.direction = displace_settings.displace_direction
        displace_mod.space = displace_settings.texture_coords
        
        # Set vertex group if specified
        if displace_settings.vertex_group:
            displace_mod.vertex_group = displace_settings.vertex_group
        
        if displace_settings.texture_coords == 'OBJECT' and displace_settings.texture_coords_object:
            displace_mod.texture_coords_object = displace_settings.texture_coords_object
        
        if displace_settings.texture_coords == 'UV':
            displace_mod.uv_layer = displace_settings.uv_layer
        
        self.report({'INFO'}, "Added Displace modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Update Displace Modifier Settings
# ----------------------------------------------------------
class Retopology_OT_update_displace_modifier(Operator):
    bl_idname = "retopology.update_displace_modifier"
    bl_label = "Update Displace Modifier"
    bl_description = "Update existing displace modifier settings"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find displace modifier
        displace_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DISPLACE':
                displace_mod = mod
                break
        
        if not displace_mod:
            self.report({'ERROR'}, "No displace modifier found")
            return {'CANCELLED'}
        
        # Apply settings from property group
        scene = context.scene
        displace_settings = scene.retopology_displace_settings
        
        displace_mod.strength = displace_settings.displace_strength
        displace_mod.mid_level = displace_settings.displace_midlevel
        displace_mod.direction = displace_settings.displace_direction
        displace_mod.space = displace_settings.texture_coords
        
        # Set vertex group if specified
        if displace_settings.vertex_group:
            displace_mod.vertex_group = displace_settings.vertex_group
        
        if displace_settings.texture_coords == 'OBJECT' and displace_settings.texture_coords_object:
            displace_mod.texture_coords_object = displace_settings.texture_coords_object
        
        if displace_settings.texture_coords == 'UV':
            displace_mod.uv_layer = displace_settings.uv_layer
        
        self.report({'INFO'}, "Updated Displace modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Apply Displace Modifier
# ----------------------------------------------------------
class Retopology_OT_apply_displace_modifier(Operator):
    bl_idname = "retopology.apply_displace_modifier"
    bl_label = "Apply Displace Modifier"
    bl_description = "Apply the displace modifier to the mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find displace modifier
        displace_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DISPLACE':
                displace_mod = mod
                break
        
        if not displace_mod:
            self.report({'ERROR'}, "No displace modifier found")
            return {'CANCELLED'}
        
        # Apply the modifier
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=displace_mod.name)
        
        self.report({'INFO'}, "Applied Displace modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Remove Displace Modifier
# ----------------------------------------------------------
class Retopology_OT_remove_displace_modifier(Operator):
    bl_idname = "retopology.remove_displace_modifier"
    bl_label = "Remove Displace Modifier"
    bl_description = "Remove the displace modifier from the mesh"
    
    def execute(self, context):
        obj = context.active_object
        
        if not obj:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh")
            return {'CANCELLED'}
        
        # Find displace modifier
        displace_mod = None
        for mod in obj.modifiers:
            if mod.type == 'DISPLACE':
                displace_mod = mod
                break
        
        if not displace_mod:
            self.report({'ERROR'}, "No displace modifier found")
            return {'CANCELLED'}
        
        # Remove the modifier
        obj.modifiers.remove(displace_mod)
        
        self.report({'INFO'}, "Removed Displace modifier")
        return {'FINISHED'}

# ----------------------------------------------------------
# Operator: Bake Textures (Modal Version)
# ----------------------------------------------------------
class Retopology_OT_bake_textures(Operator):
    bl_idname = "retopology.bake_textures"
    bl_label = "Bake Textures"
    bl_description = "Bake textures based on current settings with progress tracking"
    
    _timer = None
    _original_render_engine = None
    _check_counter = 0
    _max_checks = 300  # Maximum number of checks (30 seconds at 0.1s interval)
    _bake_started = False
    _stored_metallic_data = {}
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            self._check_counter += 1
            
            # Safety timeout
            if self._check_counter >= self._max_checks:
                self.report({'ERROR'}, "Baking operation timed out after 30 seconds")
                self._cleanup(context)
                return {'CANCELLED'}
            
            # Check if baking has started
            if not self._bake_started:
                # Store and disable metallic for DIFFUSE bake
                if self.bake_type == 'DIFFUSE':
                    self._store_and_disable_metallic(context)
                
                # Start the bake operation
                try:
                    self._start_bake_operation(context)
                    self._bake_started = True
                    context.scene.retopology_bake_settings.bake_progress = 30
                except Exception as e:
                    self.report({'ERROR'}, f"Failed to start baking: {str(e)}")
                    self._cleanup(context)
                    return {'CANCELLED'}
            
            # Update progress while baking
            if context.scene.retopology_bake_settings.bake_progress < 90:
                context.scene.retopology_bake_settings.bake_progress += 1
            
            # Check for completion
            if self._check_bake_completion(context):
                self._cleanup(context)
                
                # Show completion message
                bake_type_name = self.bake_type.capitalize()
                self.report({'INFO'}, f"{bake_type_name} baking completed successfully!")
                return {'FINISHED'}
        
        return {'PASS_THROUGH'}
    
    def _store_and_disable_metallic(self, context):
        """Store and disable metallic nodes for DIFFUSE baking"""
        self._stored_metallic_data.clear()
        
        # Get active object
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return
        
        # Store metallic data for all materials
        for mat in obj.data.materials:
            if mat and mat.use_nodes:
                # Find Principled BSDF nodes
                for node in mat.node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        # Create a unique identifier for this node
                        node_id = (obj.name, mat.name, node.name)
                        
                        # Store original metallic value
                        original_value = node.inputs['Metallic'].default_value
                        self._stored_metallic_data[node_id] = {
                            'value': original_value,
                            'connections': None
                        }
                        
                        # Check if metallic is connected
                        metallic_input = node.inputs['Metallic']
                        if metallic_input.is_linked:
                            # Store connection info
                            link = metallic_input.links[0]
                            self._stored_metallic_data[node_id]['connections'] = {
                                'from_node': link.from_node.name,
                                'from_socket': link.from_socket.name
                            }
                            # Disconnect the metallic input
                            mat.node_tree.links.remove(link)
                        
                        # Set metallic to 0 for baking
                        node.inputs['Metallic'].default_value = 0.0
    
    def _restore_metallic_after_bake(self):
        """Restore metallic nodes to original state after baking"""
        for node_id, data in self._stored_metallic_data.items():
            obj_name, mat_name, node_name = node_id
            
            # Find the object
            obj = bpy.data.objects.get(obj_name)
            if obj and obj.type == 'MESH':
                # Find the material
                mat = bpy.data.materials.get(mat_name)
                if mat and mat.use_nodes:
                    # Find the Principled BSDF node
                    node = mat.node_tree.nodes.get(node_name)
                    if node and node.type == 'BSDF_PRINCIPLED':
                        # Restore original metallic value
                        node.inputs['Metallic'].default_value = data['value']
                        
                        # Restore connection if it existed
                        if data['connections']:
                            conn_info = data['connections']
                            from_node = mat.node_tree.nodes.get(conn_info['from_node'])
                            if from_node:
                                from_socket = None
                                for socket in from_node.outputs:
                                    if socket.name == conn_info['from_socket']:
                                        from_socket = socket
                                        break
                                if from_socket:
                                    # Check if metallic input is already connected
                                    metallic_input = node.inputs['Metallic']
                                    if not metallic_input.is_linked:
                                        mat.node_tree.links.new(
                                            from_socket,
                                            metallic_input
                                        )
        
        # Clear stored data
        self._stored_metallic_data.clear()
    
    def _start_bake_operation(self, context):
        """Start the bake operation"""
        scene = context.scene
        bake_settings = scene.retopology_bake_settings
        
        # Store original render engine
        self._original_render_engine = bpy.context.scene.render.engine
        
        # Switch to Cycles for baking
        bpy.context.scene.render.engine = 'CYCLES'
        bpy.context.scene.cycles.samples = bake_settings.bake_samples
        
        # Correct bake type mapping for Blender
        actual_bake_type = bake_settings.bake_type
        bake_type_mapping = {
            'METALLIC': 'EMIT',  # Metallic bakes as EMIT
        }
        actual_bake_type = bake_type_mapping.get(actual_bake_type, actual_bake_type)
        
        # Set image settings
        image_settings = bpy.context.scene.render.image_settings
        image_settings.file_format = 'PNG'
        image_settings.color_mode = 'RGBA'
        image_settings.color_depth = '8'
        
        # Prepare bake parameters using Blender's actual bake settings
        render_bake = bpy.context.scene.render.bake
        
        # Set margin settings
        render_bake.margin = bake_settings.bake_margin
        render_bake.margin_type = bake_settings.margin_type
        
        # Set selected to active settings
        render_bake.use_selected_to_active = bake_settings.use_selected_to_active
        if bake_settings.use_selected_to_active:
            render_bake.cage_extrusion = bake_settings.cage_extrusion
            render_bake.max_ray_distance = bake_settings.max_ray_distance
        
        # Set cage settings
        render_bake.use_cage = bake_settings.use_cage
        if bake_settings.use_cage:
            render_bake.cage_extrusion = bake_settings.cage_extrusion
            if bake_settings.cage_object:
                render_bake.cage_object = bake_settings.cage_object
        
        # Set target
        render_bake.target = bake_settings.target
        
        # Set view from
        try:
            render_bake.view_from = bake_settings.view_from
        except:
            render_bake.view_from = 'ACTIVE_CAMERA'
        
        # Set normal map settings
        if actual_bake_type == 'NORMAL':
            render_bake.normal_space = bake_settings.normal_space
            render_bake.normal_r = bake_settings.normal_r
            render_bake.normal_g = bake_settings.normal_g
            render_bake.normal_b = bake_settings.normal_b
        
        # Set influence settings for combined bake
        if actual_bake_type == 'COMBINED':
            render_bake.use_pass_direct = bake_settings.use_pass_direct
            render_bake.use_pass_indirect = bake_settings.use_pass_indirect
            render_bake.use_pass_diffuse = bake_settings.use_pass_diffuse
            render_bake.use_pass_glossy = bake_settings.use_pass_glossy
            render_bake.use_pass_transmission = bake_settings.use_pass_transmission
            render_bake.use_pass_emit = bake_settings.use_pass_emit
        
        # Set influence settings for diffuse/glossy/transmission
        if actual_bake_type in ['DIFFUSE', 'GLOSSY', 'TRANSMISSION']:
            render_bake.use_pass_direct = bake_settings.use_pass_direct
            render_bake.use_pass_indirect = bake_settings.use_pass_indirect
            render_bake.use_pass_color = bake_settings.use_pass_color
        
        # Prepare basic bake parameters
        bake_kwargs = {
            'type': actual_bake_type,
            'use_clear': bake_settings.use_clear,
        }
        
        # Perform bake
        bpy.ops.object.bake('INVOKE_DEFAULT', **bake_kwargs)
    
    def _check_bake_completion(self, context):
        """Check if baking is complete"""
        # Check scene bake settings
        try:
            # Try to get baking progress
            if hasattr(bpy.context.scene.render, 'is_bake_complete'):
                if not bpy.context.scene.render.is_bake_complete:
                    return False
        except:
            pass
        
        # Check for dirty images
        for img in bpy.data.images:
            if img.is_dirty:
                # Pack the image
                img.pack()
                context.scene.retopology_bake_settings.bake_counter += 1
                context.scene.retopology_bake_settings.bake_progress = 100
                return True
        
        return False
    
    def _cleanup(self, context):
        """Cleanup after baking"""
        # Restore metallic if needed
        if self.bake_type == 'DIFFUSE':
            self._restore_metallic_after_bake()
        
        # Restore original render engine
        if self._original_render_engine:
            try:
                bpy.context.scene.render.engine = self._original_render_engine
                engine_name = "Eevee" if self._original_render_engine == 'BLENDER_EEVEE' else (
                    "Eevee Next" if self._original_render_engine == 'BLENDER_EEVEE_NEXT' else self._original_render_engine
                )
                if self._original_render_engine != 'CYCLES':
                    self.report({'INFO'}, f"Render engine restored to {engine_name}")
            except Exception as e:
                self.report({'WARNING'}, f"Could not restore render engine: {str(e)}")
        
        # Remove timer
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        
        # Reset counters
        context.scene.retopology_bake_settings.bake_counter = 0
        context.scene.retopology_bake_settings.bake_progress = 0
        
        # Reset flags
        self._original_render_engine = None
        self._check_counter = 0
        self._bake_started = False
    
    def execute(self, context):
        # Check if object is selected
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object to bake")
            return {'CANCELLED'}
        
        # Check if object has materials
        if not obj.data.materials:
            self.report({'ERROR'}, "Selected object has no materials. Please setup PBR material first.")
            return {'CANCELLED'}
        
        # Store bake type
        self.bake_type = context.scene.retopology_bake_settings.bake_type
        
        # Reset counters
        context.scene.retopology_bake_settings.bake_counter = 0
        context.scene.retopology_bake_settings.bake_progress = 10
        
        # Setup modal timer
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}



# ----------------------------------------------------------
# Registration
# ----------------------------------------------------------
classes = (
    Retopology_BakeSettings,
    Retopology_DecimateSettings,
    Retopology_DisplaceSettings,
    Retopology_OT_setup_pbr,
    Retopology_OT_clear_materials,
    Retopology_OT_add_material_slot,
    Retopology_OT_add_decimate_modifier,
    Retopology_OT_update_decimate_modifier,
    Retopology_OT_apply_decimate_modifier,
    Retopology_OT_remove_decimate_modifier,
    Retopology_OT_add_displace_modifier,
    Retopology_OT_update_displace_modifier,
    Retopology_OT_apply_displace_modifier,
    Retopology_OT_remove_displace_modifier,
    Retopology_OT_bake_textures,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register scene properties for collapsible sections
    bpy.types.Scene.retopology_bake_settings = PointerProperty(type=Retopology_BakeSettings)
    bpy.types.Scene.retopology_decimate_settings = PointerProperty(type=Retopology_DecimateSettings)
    bpy.types.Scene.retopology_displace_settings = PointerProperty(type=Retopology_DisplaceSettings)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.retopology_bake_settings
    del bpy.types.Scene.retopology_decimate_settings
    del bpy.types.Scene.retopology_displace_settings
    register()