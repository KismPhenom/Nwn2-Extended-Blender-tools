# Standard library imports
import os
import re
import shutil
import datetime
from typing import List, Optional

# Blender imports
import bpy
from bpy.props import (
    StringProperty, BoolProperty, IntProperty, 
    EnumProperty, PointerProperty, CollectionProperty
)
from bpy.types import Operator, PropertyGroup, UIList

# ==============================================
# GLOBAL VARIABLES
# ==============================================

fbx_files_cache = []
cached_gr2_files = []

# ==============================================
# PROPERTY GROUPS (UPDATED)
# ==============================================

class AnimationListItem(PropertyGroup):
    """Property group for animation list items"""
    name: StringProperty(name="Animation Name")
    action: PointerProperty(type=bpy.types.Action)
    display_name: StringProperty(name="Display Name")
    full_name: StringProperty(name="Full Name")
    all_matching_actions: StringProperty(
        name="All Matching Actions",
        description="Comma-separated list of all action names that match this display name",
        default=""
    )
    armature_name: StringProperty(
        name="Armature Name", 
        description="Name of the armature this action belongs to",
        default=""
    )
    anim_display_name: StringProperty(name="Display Name")
    anim_full_name: StringProperty(name="Full Name")  
    anim_action: PointerProperty(type=bpy.types.Action)

# ==============================================
# UI LIST CLASSES (UPDATED)
# ==============================================

class ANIM_UL_actions_list(UIList):
    """UI List for displaying animations with filtered names"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        scene = context.scene
        display_all = getattr(scene, 'display_all_animations', False)
        
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            
            if display_all:
                row.label(text=item.display_name, icon='ARMATURE_DATA')
                if item.armature_name:
                    sub_row = row.row()
                    sub_row.alignment = 'RIGHT'
                    sub_row.label(text=item.armature_name, icon='BONE_DATA')
            else:
                row.label(text=item.display_name, icon='ACTION')
                if item.all_matching_actions:
                    action_count = len(item.all_matching_actions.split(','))
                    if action_count > 1:
                        sub_row = row.row()
                        sub_row.alignment = 'RIGHT'
                        sub_row.label(text=f"{action_count} armatures", icon='GROUP_BONE')
            
            if index == getattr(data, active_propname):
                row.label(text="", icon='RESTRICT_SELECT_OFF')
                
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            if display_all:
                layout.label(text="", icon='ARMATURE_DATA')
            else:
                layout.label(text="", icon='ACTION')


class ANIM_UL_file_list(UIList):
    """UI List for displaying animation files with checkboxes - UPDATED FOR PANEL COMPATIBILITY"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        scene = context.scene
        
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            
            # Checkbox for selection - UPDATED: Use panel.py's selection flags
            animation_selection_flags = getattr(scene, 'animation_selection_flags', {})
            is_selected = animation_selection_flags.get(item.name, False)
            icon_name = 'CHECKBOX_HLT' if is_selected else 'CHECKBOX_DEHLT'
            
            # Use operator to toggle selection - UPDATED: Use new operator name
            op = row.operator("anim.toggle_file_selection", text="", icon=icon_name, emboss=False)
            op.index = index
            
            # File name and type
            file_icon = 'FILE_3D' if item.file_type == 'FBX' else 'ARMATURE_DATA'
            row.label(text=item.name, icon=file_icon)
            
            # File type on the right
            sub = row.row()
            sub.alignment = 'RIGHT'
            sub.label(text=item.file_type)
            
            # Active indicator
            if index == getattr(data, active_propname):
                row.label(text="", icon='RESTRICT_SELECT_OFF')
                
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='FILE_BLEND')

# ==============================================

def safe_get_display_name(item):
    """Safely get display name from animation list item"""
    return getattr(item, 'display_name', 
           getattr(item, 'anim_display_name', 
           getattr(item, 'name', 'Unknown Animation')))

def safe_get_full_name(item):
    """Safely get full name from animation list item"""
    return getattr(item, 'full_name', 
           getattr(item, 'anim_full_name', 
           safe_get_display_name(item)))

def safe_get_action(item):
    """Safely get action from animation list item"""
    return getattr(item, 'action', 
           getattr(item, 'anim_action', None))

def update_display_all_animations(self, context):
    """Update the animation list when display mode changes"""
    update_animation_list_collection(context)

def update_animation_dropdown(self, context):
    """Generate items for animation dropdown"""
    action_names = set()
    display_all = context.scene.display_all_animations
    
    for action in bpy.data.actions:
        if action.name.startswith("Action"):
            continue

        action_name_parts = action.name.split('_')
        if len(action_name_parts) >= 6:
            filtered_name = '_'.join(action_name_parts[5:])
        elif len(action_name_parts) > 3:
            filtered_name = '_'.join(action_name_parts[3:])
        else:
            filtered_name = action.name
        
        if display_all:
            action_names.add(action.name)
        else:
            action_names.add(filtered_name)
    
    return [(name, name, "") for name in action_names]

def update_animation_suffix_from_list(self, context):
    """Update animation suffix when UI list selection changes - FIXED"""
    scene = context.scene
    
    if (hasattr(scene, 'animation_list_collection') and 
        scene.animation_list_collection and 
        0 <= scene.animation_list_index < len(scene.animation_list_collection)):
        
        item = scene.animation_list_collection[scene.animation_list_index]
        full_name = safe_get_full_name(item)
        parts = full_name.split('_')
        
        if len(parts) >= 6 and parts[2] == "skel" and parts[0] == parts[3]:
            # Pattern: P_HHM_skel_P_HHM_1hSS_run → 1hSS_run
            scene.animation_suffix = '_'.join(parts[5:])
            
        elif len(parts) >= 4 and parts[2] == "skel":
            # Pattern: P_HHM_skel_1hSS_run → 1hSS_run
            scene.animation_suffix = '_'.join(parts[3:])
            
        elif len(parts) >= 3:
            # Pattern: P_HHM_1hSS_run → 1hSS_run
            prefix = parts[0].lower()
            if prefix in ['p', 'c', 'w']:
                scene.animation_suffix = '_'.join(parts[2:])
            else:
                scene.animation_suffix = '_'.join(parts[2:])
        else:
            scene.animation_suffix = full_name

def update_animation_suffix(self, context):
    """Update animation suffix when dropdown selection changes - FIXED"""
    full_animation_name = context.scene.ApplyAnimation_dropdown
    parts = full_animation_name.split('_')
    
    # FIXED: Same pattern matching as above
    if len(parts) >= 6 and parts[2] == "skel" and parts[0] == parts[3]:
        # Pattern: P_HHM_skel_P_HHM_1hSS_run → 1hSS_run
        context.scene.animation_suffix = '_'.join(parts[5:])
        
    elif len(parts) >= 4 and parts[2] == "skel":
        # Pattern: P_HHM_skel_1hSS_run → 1hSS_run
        context.scene.animation_suffix = '_'.join(parts[3:])
        
    elif len(parts) >= 3:
        # Pattern: P_HHM_1hSS_run → 1hSS_run
        prefix = parts[0].lower()
        if prefix in ['p', 'c', 'w']:
            context.scene.animation_suffix = '_'.join(parts[2:])
        else:
            context.scene.animation_suffix = '_'.join(parts[2:])
    else:
        context.scene.animation_suffix = full_animation_name

# ==============================================
# ANIMATION LIST MANAGEMENT
# ==============================================

def update_animation_list_collection(context):
    """Update the animation list collection with proper display names - FIXED"""
    scene = context.scene
    display_all = getattr(scene, "display_all_animations", False)
    
    if hasattr(scene, 'animation_list_collection'):
        scene.animation_list_collection.clear()
    
    valid_actions = [act for act in bpy.data.actions if not act.name.startswith("Action")]
    
    if not valid_actions:
        if hasattr(scene, 'animation_suffix'):
            scene.animation_suffix = ""
        return
    
    if display_all:
        for action in valid_actions:
            armature_name = ""
            
            for obj in bpy.data.objects:
                if obj.type == 'ARMATURE':
                    if f"_{obj.name}_" in f"_{action.name}_" or action.name.endswith(f"_{obj.name}"):
                        armature_name = obj.name
                        break
            
            if not armature_name:
                if "_skel_" in action.name:
                    parts = action.name.split('_skel_')
                    if len(parts) > 1:
                        potential_armature = parts[0] + "_skel"
                        if bpy.data.objects.get(potential_armature):
                            armature_name = potential_armature
                elif action.name.startswith(("P_", "C_", "W_")):
                    action_parts = action.name.split('_')
                    if len(action_parts) >= 3:
                        potential_armature = '_'.join(action_parts[:3])
                        if bpy.data.objects.get(potential_armature):
                            armature_name = potential_armature
            
            if not armature_name:
                for obj in bpy.data.objects:
                    if obj.type == 'ARMATURE' and action.name.startswith(obj.name):
                        armature_name = obj.name
                        break
            
            item = scene.animation_list_collection.add()
            item.name = action.name
            item.display_name = action.name
            item.full_name = action.name
            item.action = action
            item.armature_name = armature_name
            item.all_matching_actions = action.name
            item.anim_display_name = action.name
            item.anim_full_name = action.name
            item.anim_action = action
    
    else:
        display_mapping = {}
        
        for action in valid_actions:
            action_name_parts = action.name.split('_')
            filtered_name = action.name
            
            # FIXED: Updated pattern matching to use parts[5:] instead of parts[4:]
            if len(action_name_parts) >= 6:
                if (action_name_parts[2] == "skel" and 
                    action_name_parts[0] == action_name_parts[3]):
                    filtered_name = '_'.join(action_name_parts[5:])  # FIXED: parts[5:] instead of parts[4:]
                elif action_name_parts[2] == "skel":
                    filtered_name = '_'.join(action_name_parts[3:])
            elif len(action_name_parts) >= 3:
                filtered_name = '_'.join(action_name_parts[2:])
            
            key = filtered_name
            
            if key not in display_mapping:
                display_mapping[key] = {
                    'display_name': filtered_name,
                    'full_name': action.name,
                    'action': action,
                    'armature_name': "",
                    'all_matching_actions': action.name
                }
            else:
                current_actions = display_mapping[key]['all_matching_actions']
                display_mapping[key]['all_matching_actions'] = current_actions + "," + action.name
        
        sorted_items = sorted(display_mapping.items(), 
                             key=lambda x: x[1]['display_name'].lower())
        
        for key, data in sorted_items:
            item = scene.animation_list_collection.add()
            item.name = key
            item.display_name = data['display_name']
            item.full_name = data['full_name']
            item.action = data['action']
            item.armature_name = data['armature_name']
            item.all_matching_actions = data['all_matching_actions']
            item.anim_display_name = data['display_name']
            item.anim_full_name = data['full_name']
            item.anim_action = data['action']
    
    if (scene.animation_list_collection and 
        hasattr(scene, 'animation_suffix') and 
        not scene.animation_suffix):
        first_item = scene.animation_list_collection[0]
        scene.animation_suffix = first_item.display_name

# ==============================================
# ANIMATION IMPORT/EXPORT FUNCTIONS
# ==============================================

def apply_animation_to_armatures(action_name, is_display_name=False):
    """Apply animation to armatures in Source Armature collection"""
    if not action_name:
        return
        
    collection_name = "Source Armature"
    collection = bpy.data.collections.get(collection_name)
    
    if not collection:
        return
    
    scene = bpy.context.scene
    display_all = getattr(scene, 'display_all_animations', False)
    applied_count = 0
    
    for obj in collection.objects:
        if obj.type == 'ARMATURE':
            if display_all:
                action = None
                for act in bpy.data.actions:
                    if act.name == action_name and obj.name in action_name:
                        action = act
                        break
                
                if action:
                    obj.animation_data_clear()
                    obj.animation_data_create()
                    obj.animation_data.action = action
                    adjust_animation_frames(action)
                    applied_count += 1
            else:
                found_action = None
                for act in bpy.data.actions:
                    if not act.name.startswith("Action"):
                        if obj.name in act.name and act.name.endswith(f"_{action_name}"):
                            found_action = act
                            break
                
                if found_action:
                    obj.animation_data_clear()
                    obj.animation_data_create()
                    obj.animation_data.action = found_action
                    adjust_animation_frames(found_action)
                    applied_count += 1

def adjust_animation_frames(action):
    """Adjust scene frame range to match animation"""
    if action:
        start_frame = min(keyframe.co[0] for curve in action.fcurves for keyframe in curve.keyframe_points)
        end_frame = max(keyframe.co[0] for curve in action.fcurves for keyframe in curve.keyframe_points)
        bpy.context.scene.frame_start = int(start_frame)
        bpy.context.scene.frame_end = int(end_frame)

def update_fbx_files_cache():
    """Update the global cache of FBX filenames"""
    global fbx_files_cache
    folder_path = bpy.context.scene.animation_import_directory  # UPDATED: Use new property name
    if not os.path.isdir(folder_path):
        return
    
    fbx_files_cache = [file.split('.')[0] for file in os.listdir(folder_path) if file.lower().endswith(".fbx")]

def get_fbx_files(folder):
    """Get list of FBX files in specified folder"""
    try:
        return [file.split('.')[0] for file in os.listdir(folder) if file.lower().endswith(".fbx")]
    except Exception as e:
        raise RuntimeError(f"Failed to get FBX files: {e}")

def get_gr2_files(folder):
    """Get list of GR2 files in specified folder, excluding skeleton files"""
    try:
        return [file for file in os.listdir(folder) if file.lower().endswith(".gr2") and '_skel' not in file]
    except Exception as e:
        raise RuntimeError(f"Failed to get GR2 files: {e}")

def delete_numerical_suffix_armatures(imported_armatures):
    """Remove duplicate armatures with numerical suffixes"""
    for obj in imported_armatures:
        if obj.type == 'ARMATURE' and re.search(r'\.\d{3}$', obj.name):
            bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.orphans_purge()

def import_gr2_file(filepath):
    """Import GR2 file and process its armatures and animations"""
    try:
        source_armature_collection = bpy.data.collections.get("Source Armature")
        if source_armature_collection is None:
            source_armature_collection = bpy.data.collections.new("Source Armature")
            bpy.context.scene.collection.children.link(source_armature_collection)

        pre_existing_armatures = {obj.name for obj in bpy.data.objects if obj.type == 'ARMATURE'}
        bpy.ops.import_scene.nwn2mdk(filepath=filepath, files=[{'name': os.path.basename(filepath)}])

        imported_armatures = [obj for obj in bpy.context.selected_objects if obj.type == 'ARMATURE' and obj.name not in pre_existing_armatures]

        for armature in imported_armatures:
            for collection in armature.users_collection:
                if collection.name != "Source Armature":
                    collection.objects.unlink(armature)
            
            if armature.name not in source_armature_collection.objects:
                source_armature_collection.objects.link(armature)

            if armature.animation_data and armature.animation_data.action:
                root_bone_name = None
                for bone in armature.data.bones:
                    if not bone.parent:
                        root_bone_name = bone.name
                        break

                action_name = os.path.splitext(os.path.basename(filepath))[0]
                if root_bone_name:
                    action_name = f"{root_bone_name}_{action_name}"
                armature.animation_data.action.name = action_name

        bpy.context.scene.frame_set(1)
        delete_numerical_suffix_armatures(imported_armatures)

    except Exception as e:
        print(f"Failed to import {filepath}: {e}")

def import_animation(fbx_path, start_frame, filename):
    """Import FBX animation and process its armatures"""
    imported_armatures = []
    max_end_frame = 0
    try:
        source_armature_collection = bpy.data.collections.get("Source Armature")
        if source_armature_collection is None:
            source_armature_collection = bpy.data.collections.new("Source Armature")
            bpy.context.scene.collection.children.link(source_armature_collection)

        pre_existing_armatures = {obj.name for obj in bpy.data.objects if obj.type == 'ARMATURE'}

        bpy.ops.import_scene.fbx(
            filepath=fbx_path,
            automatic_bone_orientation=True,
            use_custom_normals=False
        )

        armatures = [obj for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.name not in pre_existing_armatures]

        for armature in armatures:
            for collection in armature.users_collection:
                if collection.name != "Source Armature":
                    collection.objects.unlink(armature)
            
            if armature.name not in source_armature_collection.objects:
                source_armature_collection.objects.link(armature)

            if armature.animation_data and armature.animation_data.action:
                root_bone_name = None
                for bone in armature.data.bones:
                    if not bone.parent:
                        root_bone_name = bone.name
                        break
                if root_bone_name:
                    new_action_name = filename 
                    armature.animation_data.action.name = f"{root_bone_name}_{new_action_name}"

            imported_armatures.append(armature)

        bpy.context.scene.frame_set(start_frame)

        max_end_frame = max(
            (action.frame_range[1] for armature in imported_armatures
             if armature.animation_data and armature.animation_data.action
             for action in [armature.animation_data.action]),
            default=0
        )

        delete_numerical_suffix_armatures(imported_armatures)
        return max_end_frame

    except Exception as e:
        raise RuntimeError(f"Failed to import animation: {e}")

def import_all_animations(folder_path):
    """Import all FBX animations from specified folder"""
    max_end_frame = 0
    try:
        fbx_files = get_fbx_files(folder_path)
        for fbx_file in fbx_files:
            fbx_path = os.path.join(folder_path, fbx_file + ".fbx")
            file_max_end_frame = import_animation(fbx_path, 1, fbx_file)
            if file_max_end_frame > max_end_frame:
                max_end_frame = file_max_end_frame

        bpy.context.scene.frame_end = int(max_end_frame) if max_end_frame > 0 else bpy.context.scene.frame_start

    except Exception as e:
        raise RuntimeError(f"Failed to import animations: {e}")

def cleanup_orphaned_collections():
    """Remove empty collections that might be causing issues"""
    collections_to_remove = []
    
    for collection in bpy.data.collections:
        if collection.name in ["Source Armature", "Scene Collection", "RACES"]:
            continue
            
        if len(collection.objects) == 0:
            collections_to_remove.append(collection)
        else:
            all_objects_in_source = True
            source_armature_collection = bpy.data.collections.get("Source Armature")
            
            if source_armature_collection:
                for obj in collection.objects:
                    if obj.name not in source_armature_collection.objects:
                        all_objects_in_source = False
                        break
                
                if all_objects_in_source:
                    collections_to_remove.append(collection)
    
    for collection in collections_to_remove:
        try:
            bpy.data.collections.remove(collection)
        except Exception as e:
            print(f"Could not remove collection {collection.name}: {e}")

# ==============================================
# ANIMATION FILE IMPORT OPERATORS (UPDATED FOR PANEL)
# ==============================================

class ANIM_OT_RefreshAnimationFileList(Operator):
    bl_idname = "anim.refresh_animation_file_list"
    bl_label = "Refresh File List"
    bl_description = "Refresh the list of animation files in the directory"

    def execute(self, context):
        try:
            scene = context.scene
            folder_path = scene.animation_import_directory
            
            if not folder_path or not os.path.isdir(folder_path):
                self.report({'ERROR'}, "Invalid directory path")
                return {'CANCELLED'}

            # Clear existing collection
            scene.animation_file_collection.clear()
            
            # Clear selection flags - UPDATED: Use panel.py's property name
            scene.animation_selection_flags.clear()

            # Get all files and sort them
            files = []
            for file in os.listdir(folder_path):
                file_lower = file.lower()
                if file_lower.endswith('.fbx') or (file_lower.endswith('.gr2') and '_skel' not in file):
                    files.append(file)
            
            # Sort files alphabetically
            files.sort(key=lambda x: x.lower())
            
            # Populate collection with sorted files
            for file in files:
                item = scene.animation_file_collection.add()
                item.name = file
                item.filepath = os.path.join(folder_path, file)
                item.file_type = "FBX" if file.lower().endswith('.fbx') else "GR2"
            
            # Reset selection index
            scene.animation_file_index = 0
            
            self.report({'INFO'}, f"Found {len(scene.animation_file_collection)} animation files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to refresh file list: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_ToggleFileSelection(Operator):
    bl_idname = "anim.toggle_file_selection"
    bl_label = "Toggle File Selection"
    bl_description = "Toggle selection of this animation file - UPDATED FOR PANEL"
    
    index: IntProperty()
    
    def execute(self, context):
        scene = context.scene
        
        if self.index < 0 or self.index >= len(scene.animation_file_collection):
            return {'CANCELLED'}
        
        item = scene.animation_file_collection[self.index]
        
        # Toggle selection - UPDATED: Use panel.py's property name
        if item.name in scene.animation_selection_flags:
            scene.animation_selection_flags[item.name] = not scene.animation_selection_flags[item.name]
        else:
            scene.animation_selection_flags[item.name] = True
        
        # Update active index
        scene.animation_file_index = self.index
        
        return {'FINISHED'}

class ANIM_OT_ImportSelectedAnimationFiles(Operator):
    bl_idname = "anim.import_selected_animation_files"
    bl_label = "Import Checked Files"
    bl_description = "Import all checked animation files"
    
    def execute(self, context):
        try:
            scene = context.scene
            selected_files = []
            
            # Get selected files from selection flags - UPDATED: Use panel.py's property name
            for item in scene.animation_file_collection:
                if scene.animation_selection_flags.get(item.name, False):
                    selected_files.append(item)
            
            if not selected_files:
                self.report({'ERROR'}, "No files selected. Click checkboxes to select files.")
                return {'CANCELLED'}

            imported_count = 0
            for item in selected_files:
                try:
                    if os.path.exists(item.filepath):
                        if item.file_type == "FBX":
                            import_animation(item.filepath, 1, os.path.splitext(item.name)[0])
                        else:  # GR2
                            import_gr2_file(item.filepath)
                        imported_count += 1
                        print(f"Imported: {item.name}")
                except Exception as e:
                    print(f"Failed to import {item.name}: {e}")

            # Update animation list after import
            update_animation_list_collection(context)
            
            self.report({'INFO'}, f"Imported {imported_count}/{len(selected_files)} files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import files: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_ImportAllAnimationFiles(Operator):
    bl_idname = "anim.import_all_animation_files"
    bl_label = "Import All Files"
    bl_description = "Import all animation files from the selected directory"

    def execute(self, context):
        try:
            scene = context.scene
            folder_path = scene.animation_import_directory
            
            if not folder_path or not os.path.isdir(folder_path):
                self.report({'ERROR'}, "Invalid directory path")
                return {'CANCELLED'}

            # Get all FBX and GR2 files
            supported_files = []
            
            for file in os.listdir(folder_path):
                file_lower = file.lower()
                if file_lower.endswith('.fbx') or (file_lower.endswith('.gr2') and '_skel' not in file):
                    supported_files.append(file)

            total_files = len(supported_files)
            
            if total_files == 0:
                self.report({'WARNING'}, "No animation files found in directory")
                return {'CANCELLED'}

            # Import all files
            imported_count = 0
            for file in supported_files:
                try:
                    filepath = os.path.join(folder_path, file)
                    if file.lower().endswith('.fbx'):
                        import_animation(filepath, 1, os.path.splitext(file)[0])
                    else:  # GR2
                        import_gr2_file(filepath)
                    imported_count += 1
                except Exception as e:
                    print(f"Failed to import {file}: {e}")

            # Update animation list after import
            update_animation_list_collection(context)
            
            self.report({'INFO'}, f"Imported {imported_count}/{total_files} files")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import files: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_SelectAllAnimationFiles(Operator):
    bl_idname = "anim.select_all_animation_files"
    bl_label = "Select All"
    bl_description = "Select all files in the list"
    
    def execute(self, context):
        scene = context.scene
        for item in scene.animation_file_collection:
            scene.animation_selection_flags[item.name] = True  # UPDATED: Use panel.py's property name
        return {'FINISHED'}

class ANIM_OT_DeselectAllAnimationFiles(Operator):
    bl_idname = "anim.deselect_all_animation_files"
    bl_label = "Deselect All"
    bl_description = "Deselect all files in the list"
    
    def execute(self, context):
        scene = context.scene
        scene.animation_selection_flags.clear()  # UPDATED: Use panel.py's property name
        return {'FINISHED'}

class ANIM_OT_ImportSingleAnimationFile(Operator):
    bl_idname = "anim.import_single_animation_file"
    bl_label = "Import Selected File"
    bl_description = "Import the currently selected animation file"
    
    def execute(self, context):
        try:
            scene = context.scene
            if scene.animation_file_index < 0 or scene.animation_file_index >= len(scene.animation_file_collection):
                self.report({'ERROR'}, "No file selected")
                return {'CANCELLED'}

            item = scene.animation_file_collection[scene.animation_file_index]
            filepath = item.filepath

            if not os.path.exists(filepath):
                self.report({'ERROR'}, f"File not found: {filepath}")
                return {'CANCELLED'}

            # Import the file
            if item.file_type == "FBX":
                import_animation(filepath, 1, os.path.splitext(item.name)[0])
            else:  # GR2
                import_gr2_file(filepath)
                
            # Update animation list after import
            update_animation_list_collection(context)
            
            self.report({'INFO'}, f"Imported {item.file_type}: {item.name}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import file: {str(e)}")
            return {'CANCELLED'}

# ==============================================
# VISIBILITY-BASED EXPORT FUNCTIONS
# ==============================================

def get_visible_race_collections():
    """Get all visible collections within RACES that contain armatures"""
    races_collection = bpy.data.collections.get("RACES")
    if not races_collection:
        return {}
    
    visible_collections = {}
    
    def is_armature_visible(obj):
        return not obj.hide_viewport and not obj.hide_get()
    
    def process_collection(collection, parent_path=""):
        collections_found = {}
        
        visible_armatures = []
        for obj in collection.objects:
            if obj.type == 'ARMATURE' and obj.name.endswith('_skel') and is_armature_visible(obj):
                visible_armatures.append(obj.name)
        
        if visible_armatures:
            collection_path = f"{parent_path}/{collection.name}" if parent_path else collection.name
            collections_found[collection_path] = {
                'collection': collection,
                'armatures': visible_armatures,
                'folder_name': collection.name
            }
        
        for child_collection in collection.children:
            child_path = f"{parent_path}/{collection.name}" if parent_path else collection.name
            collections_found.update(process_collection(child_collection, child_path))
        
        return collections_found
    
    for race_collection in races_collection.children:
        visible_collections.update(process_collection(race_collection))
    
    return visible_collections

def prepare_collection_for_export(collection_data):
    """Select all visible armatures in a specific collection for export"""
    bpy.ops.object.select_all(action='DESELECT')
    
    collection = collection_data['collection']
    selected_count = 0
    
    for obj in collection.objects:
        if (obj.type == 'ARMATURE' and 
            obj.name.endswith('_skel') and 
            not obj.hide_viewport and 
            not obj.hide_get()):
            obj.select_set(True)
            selected_count += 1
    
    def select_from_child_collections(child_collection):
        nonlocal selected_count
        for obj in child_collection.objects:
            if (obj.type == 'ARMATURE' and 
                obj.name.endswith('_skel') and 
                not obj.hide_viewport and 
                not obj.hide_get()):
                obj.select_set(True)
                selected_count += 1
        
        for grandchild in child_collection.children:
            select_from_child_collections(grandchild)
    
    for child_collection in collection.children:
        select_from_child_collections(child_collection)
    
    if selected_count > 0:
        for obj in bpy.context.view_layer.objects:
            if obj.select_get() and obj.type == 'ARMATURE':
                bpy.context.view_layer.objects.active = obj
                break
    
    return selected_count > 0

# ==============================================
# ANIMATION MANAGEMENT OPERATORS
# ==============================================

class ANIM_OT_ToggleDisplayMode(Operator):
    bl_idname = "anim.toggle_display_mode"
    bl_label = "Toggle Display Mode"
    bl_description = "Toggle between full and filtered animation names"
    
    def execute(self, context):
        scene = context.scene
        # Toggle the value
        scene.display_all_animations = not scene.display_all_animations
        # Force update the animation list
        update_animation_list_collection(context)
        # Force UI refresh
        for area in context.screen.areas:
            if area.type == 'PROPERTIES':
                area.tag_redraw()
        return {'FINISHED'}

class ANIM_OT_ImportAllGR2Files(Operator):
    bl_idname = "anim.import_all_gr2_files"
    bl_label = "Import All GR2 Files"
    bl_description = "Import all GR2 animation files from the selected directory"

    def execute(self, context):
        try:
            folder_path = context.scene.animation_import_directory  # UPDATED: Use new property name
            if not os.path.isdir(folder_path):
                self.report({'ERROR'}, f"Directory not found: {folder_path}")
                return {'CANCELLED'}

            gr2_files = get_gr2_files(folder_path)
            
            if not gr2_files:
                self.report({'WARNING'}, "No GR2 files found in directory")
                return {'CANCELLED'}

            for gr2_file in gr2_files:
                filepath = os.path.join(folder_path, gr2_file)
                import_gr2_file(filepath)

            # Update the animation list after import
            update_animation_list_collection(context)
            
            self.report({'INFO'}, f"Imported {len(gr2_files)} GR2 files successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import GR2 files: {e}")
            return {'CANCELLED'}

class ANIM_OT_ImportAllAnimations(Operator):
    bl_idname = "anim.import_all_animations"
    bl_label = "Import All FBX Animations"
    bl_description = "Import all FBX animation files from the selected directory"

    def execute(self, context):
        try:
            folder_path = context.scene.animation_import_directory  # UPDATED: Use new property name
            if not os.path.isdir(folder_path):
                self.report({'ERROR'}, f"Directory not found: {folder_path}")
                return {'CANCELLED'}

            import_all_animations(folder_path)
            
            # Update the animation list after import
            update_animation_list_collection(context)
            
            self.report({'INFO'}, "All FBX animations imported successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import animations: {e}")
            return {'CANCELLED'}

class ANIM_OT_CleanupCollections(Operator):
    bl_idname = "anim.cleanup_collections"
    bl_label = "Cleanup Collections"
    bl_description = "Clean up duplicate collections and organize armatures properly"
    
    def execute(self, context):
        cleanup_orphaned_collections()
        
        # Reorganize all armatures into Source Armature collection ONLY
        source_armature_collection = bpy.data.collections.get("Source Armature")
        if not source_armature_collection:
            source_armature_collection = bpy.data.collections.new("Source Armature")
            bpy.context.scene.collection.children.link(source_armature_collection)
        
        # Move all armatures to Source Armature collection only
        for obj in bpy.data.objects:
            if obj.type == 'ARMATURE':
                # Remove from all current collections except RACES children
                for collection in obj.users_collection:
                    if collection.name != "Source Armature" and collection.name != "RACES" and collection.parent != bpy.data.collections.get("RACES"):
                        collection.objects.unlink(obj)
                # Add to source collection only if not already there
                if obj.name not in source_armature_collection.objects:
                    source_armature_collection.objects.link(obj)
        
        self.report({'INFO'}, "Collections cleaned up successfully")
        return {'FINISHED'}

class ANIM_OT_ApplyPrefix(Operator):
    bl_label = "Apply Prefix"
    bl_idname = "anim.apply_prefix"
    bl_description = "Apply prefix to all animation names"

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene.dynamic_props, 'my_text') and context.scene.dynamic_props.my_text != ""

    def execute(self, context):
        prefix = context.scene.dynamic_props.my_text
        for action in bpy.data.actions:
            if not action.name.startswith("Action"):
                action.name = prefix + action.name
        
        # Update the animation list after renaming
        update_animation_list_collection(context)
        
        self.report({'INFO'}, f"Prefix '{prefix}' applied to all animations")
        return {'FINISHED'}

class ANIM_OT_DeleteBakedAnimations(Operator):
    bl_label = "Delete Baked Animations"
    bl_idname = "anim.delete_baked_animations"
    bl_description = "Delete all animations with the prefix 'Action'"

    def execute(self, context):
        actions_to_remove = [action for action in bpy.data.actions if action.name.startswith("Action")]
        for action in actions_to_remove:
            bpy.data.actions.remove(action)
        
        # Update the animation list after deletion
        update_animation_list_collection(context)
        
        self.report({'INFO'}, f"Deleted {len(actions_to_remove)} baked animations")
        return {'FINISHED'}

class ANIM_OT_ApplyAnimationToArmatures(Operator):
    bl_idname = "anim.apply_animation_to_armatures"
    bl_label = "Apply Animation to Armatures"
    bl_description = "Apply the selected animation to armatures in the Source Armature collection"

    def execute(self, context):
        scene = context.scene
        action_name = None
        display_name = None
        
        # Check if we're using the UI list system
        if hasattr(scene, 'animation_list_collection') and scene.animation_list_collection:
            if 0 <= scene.animation_list_index < len(scene.animation_list_collection):
                item = scene.animation_list_collection[scene.animation_list_index]
                action_name = safe_get_full_name(item)
                display_name = safe_get_display_name(item)
        
        # Fallback to dropdown if UI list not available or no action selected
        if not action_name and hasattr(scene, 'ApplyAnimation_dropdown'):
            action_name = scene.ApplyAnimation_dropdown
            # For dropdown, we need to find the display name
            for item in scene.animation_list_collection:
                if item.full_name == action_name:
                    display_name = item.display_name
                    break
        
        if not action_name:
            self.report({'ERROR'}, "No animation selected")
            return {'CANCELLED'}
            
        try:
            # Get the current display mode
            display_all = getattr(scene, 'display_all_animations', False)
            
            if display_all:
                # FULL NAMES MODE: Apply specific action to matching armature only
                apply_animation_to_armatures(action_name, True)
            else:
                # FILTERED MODE: Apply filtered animation to ALL matching armatures
                apply_animation_to_armatures(display_name, False)
            
            # AUTO-UPDATE THE EXPORT NAME
            if display_name:
                scene.animation_suffix = display_name
            
            self.report({'INFO'}, f"Animation applied to armatures")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply animation: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_NextAnimation(Operator):
    bl_idname = "anim.next_animation"
    bl_label = "Next Animation"
    bl_description = "Navigate to the next animation in the list"
    
    def execute(self, context):
        scene = context.scene
        
        if not hasattr(scene, 'animation_list_collection') or not scene.animation_list_collection:
            self.report({'ERROR'}, "No animations available")
            return {'CANCELLED'}
        
        # Update index
        current_index = scene.animation_list_index
        next_index = (current_index + 1) % len(scene.animation_list_collection)
        scene.animation_list_index = next_index
        
        # Apply the animation with proper mode detection
        item = scene.animation_list_collection[next_index]
        display_all = getattr(scene, 'display_all_animations', False)
        
        if display_all:
            # Full names mode: apply specific action to matching armature
            apply_animation_to_armatures(item.full_name, True)
        else:
            # Filtered mode: apply filtered name to all matching armatures
            apply_animation_to_armatures(item.display_name, False)
        
        # Auto-update the export name
        scene.animation_suffix = item.display_name
        
        self.report({'INFO'}, f"Applied: {item.display_name}")
        return {'FINISHED'}

class ANIM_OT_PreviousAnimation(Operator):
    bl_idname = "anim.previous_animation"
    bl_label = "Previous Animation"
    bl_description = "Navigate to the previous animation in the list"
    
    def execute(self, context):
        scene = context.scene
        
        if not hasattr(scene, 'animation_list_collection') or not scene.animation_list_collection:
            self.report({'ERROR'}, "No animations available")
            return {'CANCELLED'}
        
        # Update index
        current_index = scene.animation_list_index
        previous_index = (current_index - 1) % len(scene.animation_list_collection)
        scene.animation_list_index = previous_index
        
        # Apply the animation with proper mode detection
        item = scene.animation_list_collection[previous_index]
        display_all = getattr(scene, 'display_all_animations', False)
        
        if display_all:
            # Full names mode: apply specific action to matching armature
            apply_animation_to_armatures(item.full_name, True)
        else:
            # Filtered mode: apply filtered name to all matching armatures
            apply_animation_to_armatures(item.display_name, False)
        
        # Auto-update the export name
        scene.animation_suffix = item.display_name
        
        self.report({'INFO'}, f"Applied: {item.display_name}")
        return {'FINISHED'}

class ANIM_OT_UpdateAnimationList(Operator):
    bl_idname = "anim.update_animation_list"
    bl_label = "Update Animation List"
    bl_description = "Update the animation list collection"
    
    def execute(self, context):
        update_animation_list_collection(context)
        self.report({'INFO'}, "Animation list updated")
        return {'FINISHED'}

# ==============================================
# ANIMATION BAKE/EXPORT OPERATORS
# ==============================================

class ANIM_OT_JustBakeOperator(Operator):
    bl_label = "Bake Animation"
    bl_idname = "anim.just_bake_operator"
    bl_description = "Bake current animation to keyframes"

    def execute(self, context):
        try:
            bpy.ops.nla.bake(
                frame_start=context.scene.frame_start,
                frame_end=context.scene.frame_end,
                only_selected=False, 
                visual_keying=True, 
                clear_constraints=False,
                bake_types={'POSE'}
            )
            self.report({'INFO'}, "Animation baked successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to bake animation: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_BakeAndExtractOperator(Operator):
    bl_label = "Bake and Export"
    bl_idname = "anim.bake_and_extract_operator"
    bl_description = "Bake animation and export to GR2 file for each visible race collection"

    def execute(self, context):
        if not context.scene.export_directory:
            self.report({'ERROR'}, "Export directory not specified!")
            return {'CANCELLED'}

        try:
            animation_name = context.scene.animation_suffix

            if animation_name.startswith("Armature_"):
                adjusted_animation_name = animation_name.split('_', 1)[-1]
            else:
                adjusted_animation_name = animation_name

            visible_collections = get_visible_race_collections()
            
            if not visible_collections:
                self.report({'ERROR'}, "No visible collections found in RACES! Make sure collections and armatures are visible.")
                return {'CANCELLED'}

            animation_list = set()
            export_directory = context.scene.export_directory
            export_count = 0

            bpy.ops.nla.bake(
                frame_start=context.scene.frame_start,
                frame_end=context.scene.frame_end,
                only_selected=False, 
                visual_keying=True, 
                clear_constraints=False,
                bake_types={'POSE'}
            )

            for collection_path, collection_data in visible_collections.items():
                collection = collection_data['collection']
                visible_armatures = collection_data['armatures']
                folder_name = collection_data['folder_name']
                
                if not visible_armatures:
                    continue

                output_folder = os.path.join(export_directory, folder_name)
                os.makedirs(output_folder, exist_ok=True)

                first_armature_name = visible_armatures[0]
                adjusted_skeleton_name = first_armature_name.replace('_skel', '')
                export_path = os.path.join(output_folder, f"{adjusted_skeleton_name}_{adjusted_animation_name}.gr2")

                try:
                    if not prepare_collection_for_export(collection_data):
                        continue
                    
                    bpy.ops.export_scene.nwn2mdk_gr2(
                        filepath=export_path,
                        check_existing=False,
                        use_selection=True,
                        data_type='ANIM'
                    )
                    export_count += 1

                except Exception as e:
                    continue

                animation_list.add(adjusted_animation_name)

            animation_list_file_path = os.path.join(export_directory, "AnimationList.txt")
            with open(animation_list_file_path, "w") as animation_list_file:
                for animation_name in animation_list:
                    animation_list_file.write(animation_name + "\n")

            self.report({'INFO'}, f"Exported animation '{adjusted_animation_name}' to {export_count} collections")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"An error occurred: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_ExtractOperator(Operator):
    bl_label = "Export Animation"
    bl_idname = "anim.extract_operator"
    bl_description = "Export current animation to GR2 file for each visible race collection (without baking)"

    def execute(self, context):
        if not context.scene.export_directory:
            self.report({'ERROR'}, "Export directory not specified")
            return {'CANCELLED'}

        try:
            animation_name = context.scene.animation_suffix
            
            if animation_name.startswith("Armature_"):
                adjusted_animation_name = animation_name.split('_', 1)[-1]
            else:
                adjusted_animation_name = animation_name

            visible_collections = get_visible_race_collections()
            
            if not visible_collections:
                self.report({'ERROR'}, "No visible collections found in RACES!")
                return {'CANCELLED'}

            animation_list = set()
            export_directory = context.scene.export_directory
            export_count = 0

            for collection_path, collection_data in visible_collections.items():
                collection = collection_data['collection']
                visible_armatures = collection_data['armatures']
                folder_name = collection_data['folder_name']
                
                if not visible_armatures:
                    continue

                output_folder = os.path.join(export_directory, folder_name)
                os.makedirs(output_folder, exist_ok=True)

                first_armature_name = visible_armatures[0]
                adjusted_skeleton_name = first_armature_name.replace('_skel', '')
                export_path = os.path.join(output_folder, f"{adjusted_skeleton_name}_{adjusted_animation_name}.gr2")
                
                try:
                    if not prepare_collection_for_export(collection_data):
                        continue
                    
                    bpy.ops.export_scene.nwn2mdk_gr2(
                        filepath=export_path,
                        check_existing=False,
                        use_selection=True,
                        data_type='ANIM'
                    )
                    export_count += 1
                except Exception as e:
                    continue

                animation_list.add(adjusted_animation_name)

            animation_list_file_path = os.path.join(export_directory, "AnimationList.txt")
            with open(animation_list_file_path, "w") as animation_list_file:
                for animation_name in animation_list:
                    animation_list_file.write(animation_name + "\n")

            self.report({'INFO'}, f"Animation exported to {export_count} collections")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to export animation: {str(e)}")
            return {'CANCELLED'}

class ANIM_OT_ExportAllAnimations(Operator):
    bl_label = "Export All Animations"
    bl_idname = "anim.export_all_animations"
    bl_description = "Export all animations to GR2 files for visible race collections"

    def execute(self, context):
        animation_names = [item[0] for item in update_animation_dropdown(None, context)]
        scene = context.scene

        if not animation_names:
            self.report({'ERROR'}, "No animations available to export")
            return {'CANCELLED'}

        success_count = 0
        for animation_name in animation_names:
            try:
                scene.ApplyAnimation_dropdown = animation_name
                apply_animation_to_armatures(animation_name, False)
                
                parts = animation_name.split('_')
                if len(parts) >= 3:
                    prefix = parts[0].lower()
                    if prefix in ['p', 'c', 'w']:
                        scene.animation_suffix = '_'.join(parts[2:])
                    else:
                        scene.animation_suffix = '_'.join(parts[-1:])
                else:
                    scene.animation_suffix = animation_name
                
                bpy.ops.anim.bake_and_extract_operator()
                success_count += 1
                
            except Exception as e:
                continue

        self.report({'INFO'}, f"Exported {success_count}/{len(animation_names)} animations successfully")
        return {'FINISHED'}

class ANIM_OT_DebugVisibleArmatures(Operator):
    bl_idname = "anim.debug_visible_armatures"
    bl_label = "Debug Visible Armatures"
    bl_description = "Print debug info about visible armatures in RACES collection"
    
    def execute(self, context):
        visible_collections = get_visible_race_collections()
        
        if not visible_collections:
            self.report({'WARNING'}, "No visible collections found!")
        else:
            self.report({'INFO'}, f"Found {len(visible_collections)} visible collections")
        
        return {'FINISHED'}

# ==============================================
# REGISTRATION
# ==============================================

classes = (
    AnimationListItem,
    ANIM_UL_actions_list,
    ANIM_UL_file_list,
    ANIM_OT_ToggleDisplayMode,
    ANIM_OT_UpdateAnimationList,
    # Animation file import operators (UPDATED FOR PANEL)
    ANIM_OT_RefreshAnimationFileList,
    ANIM_OT_ToggleFileSelection,  # UPDATED: New operator name
    ANIM_OT_ImportSelectedAnimationFiles,
    ANIM_OT_ImportAllAnimationFiles,
    ANIM_OT_SelectAllAnimationFiles,
    ANIM_OT_DeselectAllAnimationFiles,
    ANIM_OT_ImportSingleAnimationFile,
    # Legacy import operators
    ANIM_OT_ImportAllGR2Files,
    ANIM_OT_ImportAllAnimations,
    ANIM_OT_ApplyAnimationToArmatures,
    ANIM_OT_PreviousAnimation,
    ANIM_OT_NextAnimation,
    ANIM_OT_ApplyPrefix,
    ANIM_OT_DeleteBakedAnimations,
    ANIM_OT_CleanupCollections,
    ANIM_OT_JustBakeOperator,
    ANIM_OT_ExtractOperator,
    ANIM_OT_BakeAndExtractOperator,
    ANIM_OT_ExportAllAnimations,
    ANIM_OT_DebugVisibleArmatures,
)

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print(f"Failed to register {cls}: {e}")

    # NOTE: Most properties are now registered in panel.py
    # Only register properties that are specific to animation_tools.py
    
    # UI List properties
    bpy.types.Scene.animation_list_collection = CollectionProperty(type=AnimationListItem)
    bpy.types.Scene.animation_list_index = IntProperty(
        default=0,
        update=update_animation_suffix_from_list
    )
    
    # Dropdown property (backup)
    bpy.types.Scene.ApplyAnimation_dropdown = EnumProperty(
        name="Select Animation",
        description="Choose an animation to preview or apply",
        items=update_animation_dropdown,
        update=update_animation_suffix
    )
    
    # Animation display options
    bpy.types.Scene.display_all_animations = BoolProperty(
        name="Display Full Animation Names",
        description="Display all animations without filtering",
        default=False,
        update=update_display_all_animations
    )
    
    # Animation search and sort
    bpy.types.Scene.animation_search_filter = StringProperty(
        name="Search Animations",
        description="Filter animations by name",
        default=""
    )
    
    bpy.types.Scene.animation_sort_alphabetical = BoolProperty(
        name="Sort Alphabetically",
        description="Sort animations alphabetically",
        default=True
    )

def unregister():
    # Unregister properties that are specific to animation_tools.py
    props_to_remove = [
        'animation_list_collection',
        'animation_list_index',
        'ApplyAnimation_dropdown',
        'display_all_animations',
        'animation_search_filter',
        'animation_sort_alphabetical'
    ]
    
    for prop_name in props_to_remove:
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)
    
    # Unregister classes
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"Failed to unregister {cls}: {e}")

if __name__ == "__main__":
    register()